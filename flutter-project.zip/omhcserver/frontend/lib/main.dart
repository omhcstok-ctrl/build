import 'package:flutter/material.dart';
import 'models/user_model.dart';
import 'screens/admin/admin_dashboard.dart';
import 'screens/login_screen.dart';
import 'screens/user/user_dashboard.dart';
import 'services/api_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ApiService.I.init();
  runApp(const OmhcApp());
}

class OmhcApp extends StatelessWidget {
  const OmhcApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'OmhcServer',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF00BFA5), brightness: Brightness.dark, useMaterial3: true),
        home: const Splash(),
      );
}

Widget homeFor(UserModel u) => u.isAdmin ? const AdminDashboard() : const UserDashboard();

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    _go();
  }
  Future<void> _go() async {
    final u = await ApiService.I.me();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => u == null ? const LoginScreen() : homeFor(u)));
  }
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: CircularProgressIndicator()));
}
