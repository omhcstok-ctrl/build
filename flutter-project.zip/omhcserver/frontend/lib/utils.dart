String fmtBytes(num b) {
  if (b < 1024) return '${b.toInt()} B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  double v = b / 1024; int i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return '${v.toStringAsFixed(v < 10 ? 2 : 1)} ${u[i]}';
}

String fmtUptime(int sec) {
  if (sec <= 0) return '-';
  final d = sec ~/ 86400, h = (sec % 86400) ~/ 3600, m = (sec % 3600) ~/ 60;
  return d > 0 ? '${d}h ${h}j ${m}m' : (h > 0 ? '${h}j ${m}m' : '${m}m ${sec % 60}d');
}

String countdown(int expiresMs) {
  final diff = Duration(milliseconds: expiresMs - DateTime.now().millisecondsSinceEpoch);
  if (diff.isNegative) return 'Expired';
  return '${diff.inDays} hari ${diff.inHours % 24} jam lagi';
}
