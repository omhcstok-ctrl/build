import 'package:flutter/material.dart';
import '../../services/socket_service.dart';
import '../../widgets/terminal_view.dart';

class TerminalScreen extends StatefulWidget {
  final int? serverId;
  const TerminalScreen({super.key, this.serverId});
  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  final _sock = SocketService();
  final List<TermChunk> _chunks = [];
  bool _busy = false;
  bool _connected = false;

  @override
  void initState() {
    super.initState();
    _sock.connect(widget.serverId, onReady: (s) {
      s.onConnect((_) { if (mounted) setState(() => _connected = true); });
      s.onDisconnect((_) { if (mounted) setState(() => _connected = false); });
      s.on('terminal:history', (d) {
        if (!mounted || d is! List) return;
        setState(() {
          _chunks.clear();
          for (final e in d) { if (e is Map) _chunks.add(TermChunk('${e['d']}', '${e['t']}')); }
        });
      });
      s.on('terminal:data', (d) { if (mounted && d is Map) _add(TermChunk('${d['chunk']}', '${d['t']}')); });
      s.on('terminal:status', (d) { if (mounted) setState(() => _busy = true); });
      s.on('terminal:end', (d) { if (mounted) setState(() => _busy = false); });
      s.on('terminal:error', (d) { if (mounted && d is Map) _add(TermChunk('⚠ ${d['message']}\n', 'err')); });
      s.on('stats', (d) {
        if (mounted && d is Map) {
          final st = d['status'];
          final b = st == 'running' || st == 'installing';
          if (b != _busy) setState(() => _busy = b);
        }
      });
    });
  }
  @override
  void dispose() { _sock.dispose(); super.dispose(); }

  void _add(TermChunk c) => setState(() {
        _chunks.add(c);
        if (_chunks.length > 3000) _chunks.removeRange(0, _chunks.length - 3000);
      });

  void _send(String action) {
    _sock.socket?.emit('terminal:start', {if (widget.serverId != null) 'serverId': widget.serverId, 'action': action});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Terminal'), actions: [
          Padding(padding: const EdgeInsets.only(right: 12), child: Icon(Icons.circle, size: 12, color: _connected ? Colors.greenAccent : Colors.redAccent)),
          IconButton(icon: const Icon(Icons.delete_sweep), tooltip: 'Bersihkan tampilan', onPressed: () => setState(_chunks.clear)),
        ]),
        body: Column(children: [
          Expanded(child: TerminalView(chunks: _chunks)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                Expanded(child: FilledButton.icon(onPressed: _busy || !_connected ? null : () => _send('install'), icon: const Icon(Icons.inventory_2), label: const Text('NPM INSTALL'))),
                const SizedBox(width: 8),
                Expanded(child: FilledButton.icon(onPressed: _busy || !_connected ? null : () => _send('start'), icon: const Icon(Icons.play_arrow), label: const Text('START'))),
                const SizedBox(width: 8),
                Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700), onPressed: !_busy || !_connected ? null : () => _send('stop'), icon: const Icon(Icons.stop), label: const Text('STOP'))),
              ]),
            ),
          ),
        ]),
      );
}
