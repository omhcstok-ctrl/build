import 'dart:async';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../models/server_model.dart';
import '../../services/api_service.dart';
import '../../services/socket_service.dart';
import '../../utils.dart';
import '../../widgets/server_card.dart';
import '../login_screen.dart';
import 'file_manager_screen.dart';
import 'terminal_screen.dart';

class UserDashboard extends StatefulWidget {
  final int? serverId; // null = server milik user login; admin mengirim id
  const UserDashboard({super.key, this.serverId});
  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {
  ServerModel? _s;
  String? _err;
  Map<String, dynamic> _st = {};
  Map<String, dynamic>? _bk;
  final _sock = SocketService();
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    _load();
    _tick = Timer.periodic(const Duration(seconds: 30), (_) { if (mounted) setState(() {}); });
  }
  @override
  void dispose() { _tick?.cancel(); _sock.dispose(); super.dispose(); }

  Future<void> _load() async {
    try {
      final s = await ApiService.I.myServer(sid: widget.serverId);
      if (!mounted) return;
      setState(() { _s = s; _err = null; });
      _loadBackups();
      if (_sock.socket == null) {
        await _sock.connect(widget.serverId, onReady: (so) {
          so.on('stats', (d) { if (mounted && d is Map) setState(() => _st = Map<String, dynamic>.from(d)); });
        });
      }
    } catch (e) { if (mounted) setState(() => _err = errMsg(e)); }
  }
  Future<void> _loadBackups() async {
    try { final b = await ApiService.I.backups(sid: widget.serverId); if (mounted) setState(() => _bk = b); } catch (_) {}
  }
  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  void _copy(String t) { Clipboard.setData(ClipboardData(text: t)); _snack('Disalin: $t'); }

  Widget _bar(String label, num used, num total, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('$label: $text'),
          const SizedBox(height: 3),
          LinearProgressIndicator(value: total > 0 ? (used / total).clamp(0, 1).toDouble() : 0, minHeight: 7),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final s = _s;
    final isAdminView = widget.serverId != null;
    return Scaffold(
      appBar: AppBar(title: Text(s?.name ?? 'Server'), actions: [
        if (!isAdminView) IconButton(icon: const Icon(Icons.logout), onPressed: () async {
          await ApiService.I.logout();
          if (!context.mounted) return;
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
        }),
      ]),
      body: _err != null
          ? Center(child: Text(_err!))
          : s == null
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(14), children: [_header(s), const SizedBox(height: 10), _actions(s), const SizedBox(height: 10), _backups(s)])),
    );
  }

  Widget _header(ServerModel s) {
    final status = (_st['status'] ?? s.status).toString();
    final ramUsed = (_st['ramUsed'] ?? 0) as num, ramLimit = (_st['ramLimit'] ?? s.ramMb * 1048576) as num;
    final diskUsed = (_st['diskUsed'] ?? 0) as num, diskLimit = (_st['diskLimit'] ?? s.diskGb * 1024 * 1024 * 1024) as num;
    final cpu = (_st['cpu'] ?? 0) as num;
    final host = Uri.parse(ApiService.I.baseUrl).host;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [StatusChip(status), const Spacer(), Text('Uptime: ${fmtUptime((_st['uptime'] ?? 0) as int)}')]),
          const SizedBox(height: 6),
          _bar('RAM', ramUsed, ramLimit, '${fmtBytes(ramUsed)} / ${fmtBytes(ramLimit)}'),
          _bar('CPU', cpu, 100, '${cpu.toStringAsFixed(1)}%'),
          _bar('Disk', diskUsed, diskLimit, '${fmtBytes(diskUsed)} / ${fmtBytes(diskLimit)}'),
          const Divider(height: 24),
          Text('🌐 ${s.domain}'),
          Text('🔌 Port: ${s.port}'),
          Wrap(spacing: 8, children: [
            OutlinedButton.icon(onPressed: () => _copy(s.domain), icon: const Icon(Icons.copy, size: 16), label: const Text('Copy URL')),
            OutlinedButton.icon(onPressed: () => _copy('$host:${s.port}'), icon: const Icon(Icons.copy, size: 16), label: const Text('Copy IP:Port')),
          ]),
          const Divider(height: 24),
          Text('⏳ Expired: ${countdown(s.expiresAt)}  (${DateFormat('dd MMM yyyy HH:mm').format(DateTime.fromMillisecondsSinceEpoch(s.expiresAt))})'),
        ]),
      ),
    );
  }

  Widget _actions(ServerModel s) => Row(children: [
        Expanded(child: FilledButton.icon(icon: const Icon(Icons.folder), label: const Text('File Manager'),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FileManagerScreen(serverId: widget.serverId))))),
        const SizedBox(width: 10),
        Expanded(child: FilledButton.icon(icon: const Icon(Icons.terminal), label: const Text('Terminal'),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TerminalScreen(serverId: widget.serverId))))),
      ]);

  Widget _backups(ServerModel s) {
    final list = (_bk?['backups'] as List?) ?? [];
    final canRestore = _bk?['allow_restore'] == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('💾 Backup', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Spacer(),
            TextButton(onPressed: () async { try { await ApiService.I.backupNow(sid: widget.serverId); _snack('Backup diantrekan'); Future.delayed(const Duration(seconds: 6), _loadBackups); } catch (e) { _snack(errMsg(e)); } }, child: const Text('Backup Sekarang')),
            if (canRestore) TextButton(onPressed: () async {
              final r = await FilePicker.platform.pickFiles(withData: kIsWeb);
              if (r == null) return;
              try { _snack('Restore berjalan...'); await ApiService.I.restore(r.files.first, sid: widget.serverId); _snack('Restore selesai'); } catch (e) { _snack(errMsg(e)); }
            }, child: const Text('Restore')),
          ]),
          if (list.isEmpty) const Text('Belum ada backup'),
          for (final b in list.take(10))
            ListTile(
              dense: true, contentPadding: EdgeInsets.zero,
              title: Text(b['filename'].toString(), style: const TextStyle(fontSize: 12)),
              subtitle: Text('${fmtBytes((b['size'] ?? 0) as num)} · ${DateFormat('dd/MM HH:mm').format(DateTime.fromMillisecondsSinceEpoch((b['created_at'] as num).toInt()))}'),
              trailing: Text(b['status'] == 'sent' ? '✅ Telegram' : '⚠️ ${b['status']}', style: const TextStyle(fontSize: 12)),
            ),
        ]),
      ),
    );
  }
}
