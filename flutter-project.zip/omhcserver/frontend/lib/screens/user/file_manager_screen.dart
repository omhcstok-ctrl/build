import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api_service.dart';
import '../../utils.dart';

String _join(String a, String b) => a == '/' ? '/$b' : '$a/$b';
String _parent(String p) { final i = p.lastIndexOf('/'); return i <= 0 ? '/' : p.substring(0, i); }

class FileManagerScreen extends StatefulWidget {
  final int? serverId;
  const FileManagerScreen({super.key, this.serverId});
  @override
  State<FileManagerScreen> createState() => _FileManagerScreenState();
}

class _FileManagerScreenState extends State<FileManagerScreen> {
  String _path = '/';
  List<Map<String, dynamic>> _items = [];
  final Set<String> _sel = {};
  bool _loading = true;
  double? _progress;
  int? get _sid => widget.serverId;

  @override
  void initState() { super.initState(); _load(); }

  void _snack(String m) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m))); }

  Future<void> _load([String? p]) async {
    setState(() { _loading = true; _sel.clear(); });
    try {
      final target = p ?? _path;
      final items = await ApiService.I.listFiles(target, sid: _sid);
      if (mounted) setState(() { _path = target; _items = items; });
    } catch (e) { _snack(errMsg(e)); }
    finally { if (mounted) setState(() => _loading = false); }
  }

  Future<String?> _prompt(String title, {String initial = ''}) async {
    final c = TextEditingController(text: initial);
    return showDialog<String>(context: context, builder: (_) => AlertDialog(
      title: Text(title), content: TextField(controller: c, autofocus: true),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('OK'))]));
  }
  Future<bool> _confirm(String msg) async => (await showDialog<bool>(context: context, builder: (_) => AlertDialog(
        title: const Text('Konfirmasi'), content: Text(msg),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Ya, hapus'))]))) == true;

  Future<void> _guard(Future<void> Function() f) async {
    try { await f(); await _load(); } catch (e) { _snack(errMsg(e)); }
  }

  Future<void> _upload() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true, withData: kIsWeb);
    if (r == null || r.files.isEmpty) return;
    setState(() => _progress = 0);
    try {
      await ApiService.I.upload(r.files, _path, sid: _sid, onProgress: (s, t) { if (t > 0 && mounted) setState(() => _progress = s / t); });
      _snack('Upload selesai (${r.files.length} file)');
      await _load();
    } catch (e) { _snack(errMsg(e)); }
    finally { if (mounted) setState(() => _progress = null); }
  }

  Future<void> _move(List<String> paths) async {
    final dest = await showDialog<String>(context: context, builder: (_) => _FolderPicker(sid: _sid, start: _path));
    if (dest == null) return;
    await _guard(() => ApiService.I.move(paths, dest, sid: _sid));
  }

  Future<void> _menu(Map<String, dynamic> it, String a) async {
    final path = _join(_path, it['name']);
    switch (a) {
      case 'rename':
        final n = await _prompt('Rename', initial: it['name']);
        if (n != null && n.isNotEmpty) await _guard(() => ApiService.I.rename(path, n, sid: _sid));
        break;
      case 'move': await _move([path]); break;
      case 'delete':
        if (await _confirm('Hapus "${it['name']}"${it['type'] == 'dir' ? ' beserta isinya' : ''}?')) await _guard(() => ApiService.I.deleteFiles([path], sid: _sid));
        break;
      case 'extract':
        _snack('Mengekstrak...');
        await _guard(() => ApiService.I.unzip(path, sid: _sid));
        _snack('Ekstrak selesai');
        break;
      case 'download':
        final url = await ApiService.I.downloadUrl(path, sid: _sid);
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
        break;
      case 'edit':
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => _EditorPage(path: path, sid: _sid)));
        _load();
        break;
    }
  }

  List<String> _crumbs() => _path == '/' ? [] : _path.substring(1).split('/');

  @override
  Widget build(BuildContext context) {
    final crumbs = _crumbs();
    final selecting = _sel.isNotEmpty;
    return PopScope(
      canPop: _path == '/' && !selecting,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) { selecting ? setState(_sel.clear) : _load(_parent(_path)); } },
      child: Scaffold(
        appBar: AppBar(
          title: Text(selecting ? '${_sel.length} dipilih' : 'File Manager'),
          actions: selecting
              ? [
                  IconButton(icon: const Icon(Icons.drive_file_move), onPressed: () => _move(_sel.map((n) => _join(_path, n)).toList())),
                  IconButton(icon: const Icon(Icons.delete), onPressed: () async {
                    if (await _confirm('Hapus ${_sel.length} item?')) await _guard(() => ApiService.I.deleteFiles(_sel.map((n) => _join(_path, n)).toList(), sid: _sid));
                  }),
                ]
              : [IconButton(icon: const Icon(Icons.refresh), onPressed: () => _load())],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(40),
            child: SizedBox(
              height: 40,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                TextButton(onPressed: () => _load('/'), child: const Text('root')),
                for (int i = 0; i < crumbs.length; i++) ...[
                  const Center(child: Text('/')),
                  TextButton(onPressed: () => _load('/${crumbs.sublist(0, i + 1).join('/')}'), child: Text(crumbs[i])),
                ],
              ]),
            ),
          ),
        ),
        body: Column(children: [
          if (_progress != null) LinearProgressIndicator(value: _progress),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _items.isEmpty
                    ? const Center(child: Text('Folder kosong'))
                    : RefreshIndicator(
                        onRefresh: () => _load(),
                        child: ListView.builder(
                          itemCount: _items.length,
                          itemBuilder: (_, i) {
                            final it = _items[i];
                            final isDir = it['type'] == 'dir';
                            final name = it['name'] as String;
                            final isZip = name.toLowerCase().endsWith('.zip');
                            return ListTile(
                              selected: _sel.contains(name),
                              leading: Icon(isDir ? Icons.folder : (isZip ? Icons.archive : (it['type'] == 'link' ? Icons.link : Icons.insert_drive_file))),
                              title: Text(name),
                              subtitle: isDir ? null : Text(fmtBytes(it['size'] as num)),
                              onLongPress: () => setState(() => _sel.contains(name) ? _sel.remove(name) : _sel.add(name)),
                              onTap: () {
                                if (selecting) { setState(() => _sel.contains(name) ? _sel.remove(name) : _sel.add(name)); return; }
                                if (isDir) { _load(_join(_path, name)); } else if (it['type'] == 'file') { _menu(it, 'edit'); }
                              },
                              trailing: selecting ? null : PopupMenuButton<String>(
                                onSelected: (a) => _menu(it, a),
                                itemBuilder: (_) => [
                                  if (isZip) const PopupMenuItem(value: 'extract', child: Text('📦 Extract')),
                                  if (!isDir) const PopupMenuItem(value: 'edit', child: Text('✏️ Edit')),
                                  if (!isDir) const PopupMenuItem(value: 'download', child: Text('⬇️ Download')),
                                  const PopupMenuItem(value: 'rename', child: Text('Rename')),
                                  const PopupMenuItem(value: 'move', child: Text('Move')),
                                  const PopupMenuItem(value: 'delete', child: Text('Delete')),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ]),
        floatingActionButton: Column(mainAxisSize: MainAxisSize.min, children: [
          FloatingActionButton.small(heroTag: 'mk', onPressed: () async {
            final n = await _prompt('Nama folder baru');
            if (n != null && n.isNotEmpty) await _guard(() => ApiService.I.mkdir(_path, n, sid: _sid));
          }, child: const Icon(Icons.create_new_folder)),
          const SizedBox(height: 10),
          FloatingActionButton(heroTag: 'up', onPressed: _progress != null ? null : _upload, child: const Icon(Icons.upload_file)),
        ]),
      ),
    );
  }
}

class _FolderPicker extends StatefulWidget {
  final int? sid;
  final String start;
  const _FolderPicker({required this.sid, required this.start});
  @override
  State<_FolderPicker> createState() => _FolderPickerState();
}

class _FolderPickerState extends State<_FolderPicker> {
  late String _p = widget.start;
  List<Map<String, dynamic>> _dirs = [];
  @override
  void initState() { super.initState(); _go(_p); }
  Future<void> _go(String p) async {
    try {
      final l = await ApiService.I.listFiles(p, sid: widget.sid);
      if (mounted) setState(() { _p = p; _dirs = l.where((e) => e['type'] == 'dir').toList(); });
    } catch (_) {}
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text('Pindah ke: $_p', style: const TextStyle(fontSize: 14)),
        content: SizedBox(
          width: 360, height: 320,
          child: ListView(children: [
            if (_p != '/') ListTile(leading: const Icon(Icons.arrow_upward), title: const Text('..'), onTap: () => _go(_parent(_p))),
            for (final d in _dirs) ListTile(leading: const Icon(Icons.folder), title: Text(d['name']), onTap: () => _go(_join(_p, d['name']))),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, _p), child: const Text('Pilih folder ini'))],
      );
}

class _EditorPage extends StatefulWidget {
  final String path;
  final int? sid;
  const _EditorPage({required this.path, required this.sid});
  @override
  State<_EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<_EditorPage> {
  final _c = TextEditingController();
  bool _loading = true, _saving = false;
  String? _err;
  @override
  void initState() { super.initState(); _open(); }
  Future<void> _open() async {
    try { _c.text = await ApiService.I.readFile(widget.path, sid: widget.sid); }
    catch (e) { _err = errMsg(e); }
    if (mounted) setState(() => _loading = false);
  }
  Future<void> _save() async {
    setState(() => _saving = true);
    try { await ApiService.I.writeFile(widget.path, _c.text, sid: widget.sid); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tersimpan'))); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(errMsg(e)))); }
    if (mounted) setState(() => _saving = false);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.path.split('/').last), actions: [
          if (_err == null) IconButton(icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save), onPressed: _saving ? null : _save),
        ]),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _err != null
                ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(_err!)))
                : Padding(padding: const EdgeInsets.all(8), child: TextField(controller: _c, maxLines: null, expands: true, textAlignVertical: TextAlignVertical.top, style: const TextStyle(fontFamily: 'monospace', fontSize: 13), decoration: const InputDecoration(border: OutlineInputBorder()))),
      );
}
