import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/api_service.dart';

class CreateServerScreen extends StatefulWidget {
  final VoidCallback onCreated;
  const CreateServerScreen({super.key, required this.onCreated});
  @override
  State<CreateServerScreen> createState() => _CreateServerScreenState();
}

class _CreateServerScreenState extends State<CreateServerScreen> {
  final _c = {
    'username': TextEditingController(), 'password': TextEditingController(), 'name': TextEditingController(),
    'port': TextEditingController(text: '1400'), 'ram_mb': TextEditingController(text: '512'),
    'cpu': TextEditingController(text: '1'), 'disk_gb': TextEditingController(text: '5'), 'expired_days': TextEditingController(text: '7'),
  };
  bool _autoBackup = true, _allowRestore = false, _busy = false;

  Widget _f(String k, String label, {bool num = false, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: _c[k], keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
            decoration: InputDecoration(labelText: label, helperText: hint, border: const OutlineInputBorder())),
      );

  Future<void> _submit() async {
    setState(() => _busy = true);
    try {
      final body = <String, dynamic>{
        'username': _c['username']!.text.trim(), 'name': _c['name']!.text.trim(),
        if (_c['password']!.text.isNotEmpty) 'password': _c['password']!.text,
        'port': int.tryParse(_c['port']!.text), 'ram_mb': int.tryParse(_c['ram_mb']!.text),
        'cpu': double.tryParse(_c['cpu']!.text), 'disk_gb': double.tryParse(_c['disk_gb']!.text),
        'expired_days': int.tryParse(_c['expired_days']!.text), 'auto_backup': _autoBackup, 'allow_restore': _allowRestore,
      };
      final r = await ApiService.I.createServer(body);
      if (!mounted) return;
      final cred = r['credentials'];
      final text = 'URL: ${r['server']['domain']}\nPort: ${r['server']['port']}\nUsername: ${cred['username']}\nPassword: ${cred['password']}';
      await showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('Server dibuat ✅'),
        content: SelectableText(text),
        actions: [
          TextButton(onPressed: () => Clipboard.setData(ClipboardData(text: text)), child: const Text('Copy')),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ));
      for (final k in ['username', 'password', 'name']) { _c[k]!.clear(); }
      widget.onCreated();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(errMsg(e))));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        _f('username', 'Username', hint: '3-20 huruf kecil/angka (jadi subdomain)'),
        _f('password', 'Password user (kosong = auto-generate)'),
        _f('name', 'Nama server'),
        _f('port', 'Custom port', num: true, hint: 'Otomatis: UFW allow + ingress Cloudflared + mapping port:3000'),
        _f('ram_mb', 'RAM limit (MB)', num: true),
        _f('cpu', 'CPU limit (core)', num: true),
        _f('disk_gb', 'Disk limit (GB)', num: true),
        _f('expired_days', 'Expired (hari)', num: true),
        SwitchListTile(title: const Text('Auto backup harian'), value: _autoBackup, onChanged: (v) => setState(() => _autoBackup = v)),
        SwitchListTile(title: const Text('Izinkan user restore'), value: _allowRestore, onChanged: (v) => setState(() => _allowRestore = v)),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: _busy ? null : _submit, icon: const Icon(Icons.rocket_launch), label: Text(_busy ? 'Membuat...' : 'Buat Server')),
      ]);
}
