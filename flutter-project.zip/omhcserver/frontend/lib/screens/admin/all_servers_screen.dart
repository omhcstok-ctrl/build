import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/server_model.dart';
import '../../services/api_service.dart';
import '../../widgets/server_card.dart';
import '../user/user_dashboard.dart';

class AllServersScreen extends StatefulWidget {
  const AllServersScreen({super.key});
  @override
  State<AllServersScreen> createState() => AllServersScreenState();
}

class AllServersScreenState extends State<AllServersScreen> {
  List<ServerModel>? _list;
  String? _err;

  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    try { final l = await ApiService.I.listServers(); if (mounted) setState(() { _list = l; _err = null; }); }
    catch (e) { if (mounted) setState(() => _err = errMsg(e)); }
  }
  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _do(ServerModel s, String a) async {
    try {
      if (a == 'delete') {
        final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
          title: const Text('Hapus server?'), content: Text('${s.name} (${s.username}) akan di-backup lalu dihapus permanen.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus'))]));
        if (ok != true) return;
        await ApiService.I.deleteServer(s.id);
      } else if (a == 'backup') {
        await ApiService.I.backupNow(sid: s.id); _snack('Backup diantrekan → Telegram');
      } else if (a == 'restore') {
        final r = await FilePicker.platform.pickFiles(withData: kIsWeb);
        if (r == null) return;
        _snack('Restore berjalan...');
        await ApiService.I.restore(r.files.first, sid: s.id); _snack('Restore selesai');
      } else if (a == 'extend' || a == 'reset') {
        await _edit(s, a); return;
      } else {
        await ApiService.I.serverAction(s.id, a);
      }
      await load();
    } catch (e) { _snack(errMsg(e)); }
  }

  Future<void> _edit(ServerModel s, String a) async {
    final c = TextEditingController(text: a == 'extend' ? '7' : '');
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text(a == 'extend' ? 'Perpanjang (hari)' : 'Password baru (kosong = random)'),
      content: TextField(controller: c, keyboardType: a == 'extend' ? TextInputType.number : TextInputType.text),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('OK'))]));
    if (ok != true) return;
    try {
      final r = await ApiService.I.patchServer(s.id, a == 'extend' ? {'extend_days': int.tryParse(c.text) ?? 7} : (c.text.isEmpty ? {'reset_password': true} : {'password': c.text}));
      if (r['newPassword'] != null && mounted) {
        await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Password baru'), content: SelectableText(r['newPassword']),
          actions: [TextButton(onPressed: () => Clipboard.setData(ClipboardData(text: r['newPassword'])), child: const Text('Copy')), TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
      }
      await load();
    } catch (e) { _snack(errMsg(e)); }
  }

  @override
  Widget build(BuildContext context) {
    if (_err != null) return Center(child: Text(_err!));
    if (_list == null) return const Center(child: CircularProgressIndicator());
    if (_list!.isEmpty) return const Center(child: Text('Belum ada server'));
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(8), children: [
        for (final s in _list!)
          ServerCard(
            s: s,
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => UserDashboard(serverId: s.id))).then((_) => load()),
            trailing: PopupMenuButton<String>(
              onSelected: (a) => _do(s, a),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'start', child: Text('▶ Start container')),
                PopupMenuItem(value: 'stop', child: Text('⏹ Stop container')),
                PopupMenuItem(value: 'restart', child: Text('🔄 Restart')),
                PopupMenuItem(value: 'suspend', child: Text('⏸ Suspend')),
                PopupMenuItem(value: 'unsuspend', child: Text('⏯ Unsuspend')),
                PopupMenuItem(value: 'backup', child: Text('💾 Backup → Telegram')),
                PopupMenuItem(value: 'restore', child: Text('♻ Restore (.tar.gz)')),
                PopupMenuItem(value: 'extend', child: Text('📅 Perpanjang expired')),
                PopupMenuItem(value: 'reset', child: Text('🔑 Reset password')),
                PopupMenuItem(value: 'delete', child: Text('🗑 Hapus')),
              ],
            ),
          ),
      ]),
    );
  }
}
