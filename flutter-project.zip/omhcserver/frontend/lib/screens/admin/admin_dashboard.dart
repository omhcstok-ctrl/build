import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../utils.dart';
import '../login_screen.dart';
import 'all_servers_screen.dart';
import 'create_server_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _tab = 0;
  Map<String, dynamic>? _stats;
  String? _err;
  final _serversKey = GlobalKey<AllServersScreenState>();

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try { final s = await ApiService.I.adminStats(); if (mounted) setState(() { _stats = s; _err = null; }); }
    catch (e) { if (mounted) setState(() => _err = errMsg(e)); }
  }

  Widget _bar(String label, num used, num total, {bool bytes = true}) {
    final p = total > 0 ? (used / total).clamp(0, 1).toDouble() : 0.0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$label: ${bytes ? fmtBytes(used) : used.toStringAsFixed(2)} / ${bytes ? fmtBytes(total) : total}'),
        const SizedBox(height: 4),
        LinearProgressIndicator(value: p, minHeight: 8),
      ]),
    );
  }

  Widget _overview() {
    if (_err != null) return Center(child: Text(_err!));
    final s = _stats;
    if (s == null) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: _tile('User', '${s['users']}', Icons.people)),
          Expanded(child: _tile('Server', '${s['servers']}', Icons.dns)),
          Expanded(child: _tile('Aktif', '${s['active']}', Icons.check_circle)),
        ]),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          _bar('RAM host', s['mem']['used'], s['mem']['total']),
          _bar('Disk host', s['disk']['used'], s['disk']['total']),
          _bar('Load (1m)', (s['cpu']['load'] as num), (s['cpu']['cores'] as num), bytes: false),
        ]))),
      ]),
    );
  }

  Widget _tile(String t, String v, IconData i) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Icon(i), const SizedBox(height: 6), Text(v, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(t)])));

  @override
  Widget build(BuildContext context) {
    final pages = [_overview(), AllServersScreen(key: _serversKey), CreateServerScreen(onCreated: () { setState(() => _tab = 1); _serversKey.currentState?.load(); _load(); })];
    return Scaffold(
      appBar: AppBar(title: const Text('OmhcServer · Admin'), actions: [
        IconButton(icon: const Icon(Icons.logout), onPressed: () async {
          await ApiService.I.logout();
          if (!context.mounted) return;
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
        }),
      ]),
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (i) { setState(() => _tab = i); if (i == 0) _load(); if (i == 1) _serversKey.currentState?.load(); }, destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
        NavigationDestination(icon: Icon(Icons.dns), label: 'Servers'),
        NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'Create'),
      ]),
    );
  }
}
