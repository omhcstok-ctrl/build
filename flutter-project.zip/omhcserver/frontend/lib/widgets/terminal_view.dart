import 'package:flutter/material.dart';

class TermChunk {
  final String text;
  final String kind; // out | err | sys
  TermChunk(this.text, this.kind);
}

final _ansi = RegExp(r'\x1B\[[0-9;?]*[A-Za-z]');

class TerminalView extends StatefulWidget {
  final List<TermChunk> chunks;
  const TerminalView({super.key, required this.chunks});
  @override
  State<TerminalView> createState() => _TerminalViewState();
}

class _TerminalViewState extends State<TerminalView> {
  final _sc = ScrollController();
  @override
  void didUpdateWidget(covariant TerminalView old) {
    super.didUpdateWidget(old);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_sc.hasClients) _sc.jumpTo(_sc.position.maxScrollExtent);
    });
  }
  @override
  void dispose() { _sc.dispose(); super.dispose(); }

  Color _color(String k) => k == 'err' ? const Color(0xFFFF6B6B) : (k == 'sys' ? const Color(0xFF6EC1FF) : const Color(0xFFE0E0E0));

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: const Color(0xFF0B0F14),
      padding: const EdgeInsets.all(10),
      child: SingleChildScrollView(
        controller: _sc,
        child: SelectableText.rich(
          TextSpan(
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5, height: 1.35),
            children: [for (final c in widget.chunks) TextSpan(text: c.text.replaceAll(_ansi, ''), style: TextStyle(color: _color(c.kind)))],
          ),
        ),
      ),
    );
  }
}
