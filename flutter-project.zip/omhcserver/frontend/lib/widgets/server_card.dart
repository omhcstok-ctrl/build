import 'package:flutter/material.dart';
import '../models/server_model.dart';
import '../utils.dart';

Color statusColor(String s) {
  switch (s) {
    case 'running': case 'active': return Colors.greenAccent;
    case 'installing': return Colors.amberAccent;
    case 'suspended': return Colors.orangeAccent;
    case 'expired': return Colors.redAccent;
    default: return Colors.grey;
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Chip(
        visualDensity: VisualDensity.compact,
        avatar: CircleAvatar(radius: 5, backgroundColor: statusColor(status)),
        label: Text(status.toUpperCase(), style: const TextStyle(fontSize: 11)),
      );
}

class ServerCard extends StatelessWidget {
  final ServerModel s;
  final VoidCallback onTap;
  final Widget? trailing;
  const ServerCard({super.key, required this.s, required this.onTap, this.trailing});
  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          onTap: onTap,
          title: Text('${s.name} · ${s.username}  [${s.status}]'),
          subtitle: Text('Port ${s.port} · ${s.ramMb}MB · ${s.cpu} CPU · ${s.diskGb}GB\n${countdown(s.expiresAt)}'),
          isThreeLine: true,
          leading: Icon(Icons.dns, color: statusColor(s.status), size: 30),
          trailing: trailing,
        ),
      );
}
