class ServerModel {
  final int id, port, ramMb, expiresAt;
  final String name, username, domain, status;
  final double cpu, diskGb;
  final bool autoBackup, allowRestore;
  ServerModel({required this.id, required this.port, required this.ramMb, required this.expiresAt, required this.name,
    required this.username, required this.domain, required this.status, required this.cpu, required this.diskGb,
    required this.autoBackup, required this.allowRestore});
  factory ServerModel.fromJson(Map<String, dynamic> j) => ServerModel(
        id: j['id'] as int, port: j['port'] as int, ramMb: j['ram_mb'] as int, expiresAt: (j['expires_at'] as num).toInt(),
        name: j['name'] as String, username: j['username'] as String, domain: j['domain'] as String, status: j['status'] as String,
        cpu: (j['cpu'] as num).toDouble(), diskGb: (j['disk_gb'] as num).toDouble(),
        autoBackup: j['auto_backup'] == true, allowRestore: j['allow_restore'] == true);
}
