class UserModel {
  final int id;
  final String username, role;
  UserModel(this.id, this.username, this.role);
  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(j['id'] as int, j['username'] as String, j['role'] as String);
  bool get isAdmin => role == 'admin';
}
