import 'package:flutter/foundation.dart' show kIsWeb;

class Api {
  // flutter build apk --dart-define=API_URL=http://IP_VPS:8080
  static const _env = String.fromEnvironment('API_URL', defaultValue: 'https://omhc-prsrv.yakuza.biz.id');
  static String get defaultBase => kIsWeb ? Uri.base.origin : _env;
}
