import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import '../config/api.dart';
import '../models/server_model.dart';
import '../models/user_model.dart';
import 'storage_service.dart';

String errMsg(Object e) {
  if (e is DioException) {
    final d = e.response?.data;
    if (d is Map && d['error'] != null) return d['error'].toString();
    return e.message ?? 'Network error';
  }
  return e.toString();
}

class ApiService {
  ApiService._();
  static final ApiService I = ApiService._();
  late Dio _dio;
  String baseUrl = Api.defaultBase;

  Future<void> init() async {
    baseUrl = (await StorageService.getBaseUrl()) ?? Api.defaultBase;
    _build();
  }

  Future<void> setBase(String url) async {
    baseUrl = url.trim().replaceAll(RegExp(r'/+$'), '');
    await StorageService.setBaseUrl(baseUrl);
    _build();
  }

  void _build() {
    _dio = Dio(BaseOptions(baseUrl: '$baseUrl/api', connectTimeout: const Duration(seconds: 15), receiveTimeout: const Duration(minutes: 10)));
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) async {
        final t = await StorageService.getToken();
        if (t != null) o.headers['Authorization'] = 'Bearer $t';
        h.next(o);
      },
      onError: (e, h) async {
        if (e.response?.statusCode == 401 && e.requestOptions.extra['retried'] != true && !e.requestOptions.path.startsWith('/auth/')) {
          if (await _refresh()) {
            final o = e.requestOptions;
            o.extra['retried'] = true;
            o.headers['Authorization'] = 'Bearer ${await StorageService.getToken()}';
            try { return h.resolve(await _dio.fetch(o)); } catch (_) {}
          }
        }
        h.next(e);
      },
    ));
  }

  Future<bool> _refresh() async {
    final r = await StorageService.getRefresh();
    if (r == null) return false;
    try {
      final res = await Dio().post('$baseUrl/api/auth/refresh', data: {'refreshToken': r});
      await StorageService.saveTokens(res.data['token'], res.data['refreshToken']);
      return true;
    } catch (_) { await StorageService.clear(); return false; }
  }

  Map<String, dynamic> _q(int? sid, [Map<String, dynamic>? extra]) => {if (sid != null) 'serverId': sid, ...?extra};

  // ---- auth
  Future<UserModel> login(String u, String p) async {
    final r = await _dio.post('/auth/login', data: {'username': u, 'password': p});
    await StorageService.saveTokens(r.data['token'], r.data['refreshToken']);
    return UserModel.fromJson(r.data['user']);
  }
  Future<UserModel?> me() async {
    if (await StorageService.getToken() == null) return null;
    try { return UserModel.fromJson((await _dio.get('/auth/me')).data['user']); } catch (_) { return null; }
  }
  Future<void> logout() => StorageService.clear();

  // ---- admin
  Future<Map<String, dynamic>> adminStats() async => Map<String, dynamic>.from((await _dio.get('/admin/stats')).data);
  Future<List<ServerModel>> listServers() async =>
      ((await _dio.get('/admin/servers')).data['servers'] as List).map((e) => ServerModel.fromJson(e)).toList();
  Future<Map<String, dynamic>> createServer(Map<String, dynamic> body) async => Map<String, dynamic>.from((await _dio.post('/admin/servers', data: body)).data);
  Future<void> serverAction(int id, String action) => _dio.post('/admin/servers/$id/$action');
  Future<void> deleteServer(int id) => _dio.delete('/admin/servers/$id');
  Future<Map<String, dynamic>> patchServer(int id, Map<String, dynamic> body) async => Map<String, dynamic>.from((await _dio.patch('/admin/servers/$id', data: body)).data);

  // ---- server (user / admin)
  Future<ServerModel> myServer({int? sid}) async => ServerModel.fromJson((await _dio.get('/me/server', queryParameters: _q(sid))).data['server']);

  // ---- files
  Future<List<Map<String, dynamic>>> listFiles(String path, {int? sid}) async =>
      List<Map<String, dynamic>>.from((await _dio.get('/files/list', queryParameters: _q(sid, {'path': path}))).data['items']);
  Future<void> mkdir(String path, String name, {int? sid}) => _dio.post('/files/mkdir', queryParameters: _q(sid), data: {'path': path, 'name': name});
  Future<void> rename(String path, String newName, {int? sid}) => _dio.post('/files/rename', queryParameters: _q(sid), data: {'path': path, 'newName': newName});
  Future<void> move(List<String> paths, String dest, {int? sid}) => _dio.post('/files/move', queryParameters: _q(sid), data: {'paths': paths, 'dest': dest});
  Future<void> deleteFiles(List<String> paths, {int? sid}) => _dio.post('/files/delete', queryParameters: _q(sid), data: {'paths': paths});
  Future<String> readFile(String path, {int? sid}) async => (await _dio.get('/files/read', queryParameters: _q(sid, {'path': path}))).data['content'] as String;
  Future<void> writeFile(String path, String content, {int? sid}) => _dio.post('/files/write', queryParameters: _q(sid), data: {'path': path, 'content': content});
  Future<void> unzip(String path, {int? sid}) => _dio.post('/files/unzip', queryParameters: _q(sid), data: {'path': path});
  Future<String> downloadUrl(String path, {int? sid}) async {
    final t = await StorageService.getToken();
    return '$baseUrl/api/files/download?path=${Uri.encodeQueryComponent(path)}&token=$t${sid != null ? '&serverId=$sid' : ''}';
  }
  Future<MultipartFile> _mp(PlatformFile f) async => kIsWeb
      ? MultipartFile.fromBytes(f.bytes!, filename: f.name)
      : await MultipartFile.fromFile(f.path!, filename: f.name);
  Future<void> upload(List<PlatformFile> files, String path, {int? sid, void Function(int, int)? onProgress}) async {
    final fd = FormData();
    for (final f in files) { fd.files.add(MapEntry('files', await _mp(f))); }
    await _dio.post('/files/upload', queryParameters: _q(sid, {'path': path}), data: fd, onSendProgress: onProgress);
  }

  // ---- backups
  Future<Map<String, dynamic>> backups({int? sid}) async => Map<String, dynamic>.from((await _dio.get('/backups', queryParameters: _q(sid))).data);
  Future<void> backupNow({int? sid}) => _dio.post('/backups/now', queryParameters: _q(sid));
  Future<void> restore(PlatformFile f, {int? sid, void Function(int, int)? onProgress}) async =>
      _dio.post('/backups/restore', queryParameters: _q(sid), data: FormData.fromMap({'file': await _mp(f)}), onSendProgress: onProgress);
}
