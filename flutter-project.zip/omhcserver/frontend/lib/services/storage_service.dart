import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static Future<SharedPreferences> get _p => SharedPreferences.getInstance();
  static Future<String?> getToken() async => (await _p).getString('token');
  static Future<String?> getRefresh() async => (await _p).getString('refresh');
  static Future<void> saveTokens(String t, String r) async { final p = await _p; await p.setString('token', t); await p.setString('refresh', r); }
  static Future<void> clear() async { final p = await _p; await p.remove('token'); await p.remove('refresh'); }
  static Future<String?> getBaseUrl() async => (await _p).getString('baseUrl');
  static Future<void> setBaseUrl(String u) async => (await _p).setString('baseUrl', u);
}
