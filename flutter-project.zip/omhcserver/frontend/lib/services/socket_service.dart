import 'package:socket_io_client/socket_io_client.dart' as io;
import 'api_service.dart';
import 'storage_service.dart';

/// Satu instance per layar; panggil dispose() di dispose() State.
class SocketService {
  io.Socket? socket;
  Future<io.Socket> connect(int? serverId, {required void Function(io.Socket) onReady}) async {
    final token = await StorageService.getToken();
    final s = io.io('${ApiService.I.baseUrl}/terminal',
        io.OptionBuilder().setTransports(['websocket']).setAuth({'token': token}).disableAutoConnect().enableReconnection().build());
    s.onConnect((_) => s.emit('terminal:join', {if (serverId != null) 'serverId': serverId}));
    onReady(s);
    s.connect();
    socket = s;
    return s;
  }
  void dispose() { socket?.dispose(); socket = null; }
}
