# VOID STARS — Flutter

## Perubahan
- Branding aplikasi menjadi VOID STARS.
- Tema gelap galaxy dengan aksen biru dan violet.
- Font utama Poppins untuk tampilan yang lebih bersih.
- Kategori MUSIC terpisah dari kategori tools.
- Pemutar musik mencari judul melalui endpoint ytplayv2 dan hanya membaca `result.audio.url`, `result.thumbnail`, `result.title`, serta durasi.
- Halaman AM PREMIUM berada di kategori tools sebagai entry autentikasi aman. Halaman ini tidak memalsukan status premium atau mengirim magic link ke endpoint pihak ketiga.

## Menjalankan
1. Pasang Flutter SDK dan Android SDK.
2. Buka folder `VOID STARS`.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter run`.

File `android/local.properties` sengaja tidak disertakan karena path Flutter/Android SDK berbeda di tiap komputer.

Catatan: endpoint musik dan ketersediaan audio dikendalikan oleh layanan pihak ketiga; kegagalan endpoint akan ditampilkan di aplikasi.
