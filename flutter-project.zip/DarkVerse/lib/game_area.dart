import 'package:flutter/material.dart';
import 'game_area/tictac_page.dart';
import 'game_area/puzzle_page.dart';
import 'game_area/snake_page.dart';
import 'game_area/Quiz_Page.dart';
import 'game_area/catur_page.dart';
import 'game_area/ludo_page.dart';
import 'game_area/block_blast_page.dart';
import 'game_area/pukul_tikus.dart'; // ← tambahan
import 'game_area/uno_page.dart'; // ← tambahan Uno
import 'game_area/dino_game_page.dart'; // ← tambahan Dino Run

// ===================== DESIGN TOKENS =====================
class _C {
  static const bgTop    = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg     = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textDark = Color(0xFF10131A);
  static const textGrey = Color(0xFF7A8394);

  static const blue      = Color(0xFF2F6FED);
  static const blueDark  = Color(0xFF1B4FC4);
  static const blueLight = Color(0xFF57A6FF);

  static const live    = Color(0xFF16A34A);
  static const warning = Color(0xFFC98A00);
  static const purple  = Color(0xFF7C3AED);
  static const magenta = Color(0xFFDB2777);
  static const teal    = Color(0xFF0D9488);
  static const orange  = Color(0xFFEA580C); // ← warna untuk Pukul Tikus
  static const red     = Color(0xFFDC2626); // ← warna untuk Uno
  static const brown   = Color(0xFF92400E); // ← warna untuk Dino Run
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textDark, letterSpacing: 0.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textDark,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textGrey, letterSpacing: 0.2,
  );
}

// ===================== GAME AREA PAGE =====================
class GameAreaPage extends StatelessWidget {
  const GameAreaPage({super.key});

  static const _games = [
    {
      'title':    'Tic Tac Toe',
      'subtitle': 'Classic Strategy Game',
      'icon':     Icons.grid_3x3,
      'key':      'tictac',
    },
    {
      'title':    'Puzzle Game',
      'subtitle': 'Slide & Solve',
      'icon':     Icons.extension,
      'key':      'puzzle',
    },
    {
      'title':    'Snake Game',
      'subtitle': 'Retro Arcade Fun',
      'icon':     Icons.sports_esports,
      'key':      'snake',
    },
    {
      'title':    'Quiz Master',
      'subtitle': 'Tes Pengetahuanmu',
      'icon':     Icons.quiz,
      'key':      'quiz',
    },
    {
      'title':    'Catur',
      'subtitle': 'Chess vs AI',
      'icon':     Icons.casino,
      'key':      'catur',
    },
    {
      'title':    'Ludo',
      'subtitle': 'Board Game Klasik vs AI',
      'icon':     Icons.circle,
      'key':      'ludo',
    },
    {
      'title':    'Block Blast',
      'subtitle': 'Ledakkan Blok Berwarna',
      'icon':     Icons.grid_view_rounded,
      'key':      'blockblast',
    },
    // ── Pukul Tikus (tambahan) ──────────────────────────
    {
      'title':    'Pukul Tikus',
      'subtitle': 'Whack-A-Mole • Hindari Bom!',
      'icon':     Icons.sports_kabaddi_rounded,
      'key':      'pukultikus',
    },
    // ── Uno (tambahan) ───────────────────────────────────
    {
      'title':    'Uno',
      'subtitle': 'Kartu Seru • Cocokkan Warna & Angka',
      'icon':     Icons.style_rounded,
      'key':      'uno',
    },
    // ── Dino Run (tambahan) ──────────────────────────────
    {
      'title':    'Dino Run',
      'subtitle': 'Lompati Rintangan • Tap to Jump!',
      'icon':     Icons.pets,
      'key':      'dino',
    },
  ];

  Color _cardAccent(int i) {
    const colors = [
      _C.blue, _C.blueLight, _C.live, _C.warning,
      _C.purple, _C.magenta, _C.teal, _C.orange, _C.red, _C.brown,
    ];
    return colors[i % colors.length];
  }

  void _navigate(BuildContext context, String key) {
    Widget page;
    switch (key) {
      case 'tictac':
        page = const TicTacPage();
        break;
      case 'puzzle':
        page = const PuzzlePage();
        break;
      case 'snake':
        page = const SnakePage();
        break;
      case 'quiz':
        page = QuizPage();
        break;
      case 'catur':
        page = const CaturPage();
        break;
      case 'ludo':
        page = const LudoGamePage();
        break;
      case 'blockblast':
        page = const BlockBlastPage();
        break;
      case 'pukultikus':              // ← tambahan
        page = const PukulTikusPage();
        break;
      case 'uno':                     // ← tambahan Uno
        page = const UnoPage();
        break;
      case 'dino':                    // ← tambahan Dino Run
        page = const DinoGameScreen();
        break;
      default:
        return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end:   Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  itemCount: _games.length,
                  itemBuilder: (context, i) {
                    final game = _games[i];
                    return _buildGameRow(
                      context:  context,
                      index:    i,
                      icon:     game['icon']     as IconData,
                      title:    game['title']    as String,
                      subtitle: game['subtitle'] as String,
                      gameKey:  game['key']      as String,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: const BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: const Border(
          bottom: BorderSide(color: _C.cardBorder, width: 2),
          left:   BorderSide(color: _C.cardBorder, width: 2),
          right:  BorderSide(color: _C.cardBorder, width: 2),
        ),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Center(
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(text: 'GAME ',
                      style: _T.display(20).copyWith(color: _C.textDark)),
                  TextSpan(text: 'AREA',
                      style: _T.display(20).copyWith(color: _C.blue)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.blue.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text('Pick a game & start playing', style: _T.label(13)),
        ],
      ),
    );
  }

  Widget _buildGameRow({
    required BuildContext context,
    required int index,
    required IconData icon,
    required String title,
    required String subtitle,
    required String gameKey,
  }) {
    final color = _cardAccent(index);

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + index * 80),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
        offset: Offset((1 - v) * 30, 0),
        child: Opacity(opacity: v.clamp(0, 1), child: child),
      ),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: GestureDetector(
          onTap: () => _navigate(context, gameKey),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: _C.cardBg,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.cardBorder, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: color, width: 1.5),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: _T.heading(16)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: _T.label(12)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.chevron_right_rounded, color: color, size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}