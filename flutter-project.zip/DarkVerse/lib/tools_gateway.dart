// tools_gateway.dart
import 'package:flutter/material.dart';
import 'app_theme.dart'; // ✅ Theme global
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'hadis_page.dart';
import 'chat_main_page.dart';

// ══════════════════════════════════════════════════════════════
//  TOOLS PAGE
// ══════════════════════════════════════════════════════════════
class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final String username;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    required this.username,
  });

  static const _categories = [
    {
      'icon': Icons.forum_rounded,
      'title': 'Chat Tools',
      'subtitle': 'Chat Semua User',
      'key': 'ChatMainPage'
    },
    {
      'icon': Icons.flash_on,
      'title': 'DDoS Tools',
      'subtitle': 'Attack & Server',
      'key': 'ddos'
    },
    {
      'icon': Icons.wifi,
      'title': 'Network',
      'subtitle': 'WiFi & Spam',
      'key': 'network'
    },
    {
      'icon': Icons.search,
      'title': 'OSINT',
      'subtitle': 'Investigation',
      'key': 'osint'
    },
    {
      'icon': Icons.download,
      'title': 'Downloader',
      'subtitle': 'Social Media',
      'key': 'downloader'
    },
    {
      'icon': Icons.build,
      'title': 'Utilities',
      'subtitle': 'Extra Tools',
      'key': 'utility'
    },
    {
      'icon': Icons.mosque_rounded,
      'title': 'Islamic',
      'subtitle': 'Hadis & Quran',
      'key': 'islamic'
    },
    {
      'icon': Icons.rocket_launch,
      'title': 'Quick Access',
      'subtitle': 'Favorites',
      'key': 'quick'
    },
  ];

  Color _cardAccent(AppPalette c, int i) =>
      i.isEven ? c.accentBlue : c.accentBlue.withOpacity(0.7);

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(c),
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  itemCount: _categories.length,
                  itemBuilder: (context, i) {
                    final cat = _categories[i];
                    return _buildToolRow(
                      context,
                      c,
                      index: i,
                      icon: cat['icon'] as IconData,
                      title: cat['title'] as String,
                      subtitle: cat['subtitle'] as String,
                      catKey: cat['key'] as String,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader(AppPalette c) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border(
          bottom: BorderSide(color: c.border, width: 2),
          left: BorderSide(color: c.border, width: 2),
          right: BorderSide(color: c.border, width: 2),
        ),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: c.accentBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: c.border, width: 1.5),
                ),
                child: Icon(Icons.tune_rounded, color: c.accentBlue, size: 22),
              ),
              const SizedBox(width: 12),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'TOOLS ',
                      style: AppTheme.display(size: 20, color: c.textMain),
                    ),
                    TextSpan(
                      text: 'DASHBOARD',
                      style: AppTheme.display(size: 20, color: c.accentBlue),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                c.accentBlue.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Advanced Security & OSINT Tools',
            style: AppTheme.body(size: 13, color: c.textSub),
          ),
        ],
      ),
    );
  }

  // ── TOOL ROW ────────────────────────────────────────────
  Widget _buildToolRow(
    BuildContext context,
    AppPalette c, {
    required int index,
    required IconData icon,
    required String title,
    required String subtitle,
    required String catKey,
  }) {
    final color = catKey == 'ChatMainPage'
        ? const Color(0xFF7C4DFF)
        : (catKey == 'islamic' ? const Color(0xFF0E9B6E) : _cardAccent(c, index));

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + index * 80),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
        offset: Offset((1 - v) * 30, 0),
        child: Opacity(opacity: v.clamp(0, 1), child: child),
      ),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: GestureDetector(
          onTap: () => _onCategoryTap(context, catKey),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: c.cardBg,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: c.border, width: 2),
              boxShadow: AppTheme.hardShadowSm,
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: color, width: 1.5),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: AppTheme.heading(size: 16, color: c.textMain)),
                      const SizedBox(height: 2),
                      Text(subtitle,
                          style: AppTheme.body(size: 12, color: c.textSub)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child:
                      Icon(Icons.chevron_right_rounded, color: color, size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _onCategoryTap(BuildContext context, String key) {
    switch (key) {
      case 'ChatMainPage':
        _openChatMainPage(context);
        break;
      case 'ddos':
        _showDDoSTools(context);
        break;
      case 'network':
        _showNetworkTools(context);
        break;
      case 'osint':
        _showOSINTTools(context);
        break;
      case 'downloader':
        _showDownloaderTools(context);
        break;
      case 'utility':
        _showUtilityTools(context);
        break;
      case 'islamic':
        _showIslamicTools(context);
        break;
      case 'quick':
        _showComingSoon(context);
        break;
    }
  }

  void _openChatMainPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatMainPage(
          username: username,
          sessionKey: sessionKey,
          role: userRole,
        ),
      ),
    );
  }

  // ── BOTTOM SHEET BASE ────────────────────────────────────
  void _showSheet({
    required BuildContext context,
    required String title,
    required IconData headerIcon,
    required Color accentColor,
    required double heightFactor,
    required List<Widget> options,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Builder(builder: (sheetContext) {
        final c = PaletteScope.of(sheetContext);
        return Container(
          height: MediaQuery.of(sheetContext).size.height * heightFactor,
          decoration: BoxDecoration(
            color: c.bgSoft,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: c.border, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(0, -3)),
            ],
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 4),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: c.textSub.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: accentColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: accentColor, width: 1.5),
                      ),
                      child: Icon(headerIcon, color: accentColor, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Text(title,
                        style: AppTheme.heading(size: 18, color: c.textMain)),
                  ],
                ),
              ),
              Container(
                height: 1.5,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    Colors.transparent,
                    accentColor.withOpacity(0.5),
                    Colors.transparent,
                  ]),
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: options,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  // ── TOOL OPTION ITEM ─────────────────────────────────────
  Widget _buildToolOption({
    required BuildContext context,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    String? badge,
  }) {
    final c = PaletteScope.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: c.border, width: 1.5),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color, width: 1.5),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        title: Text(label,
            style: AppTheme.heading(size: 14, color: c.textMain)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (badge != null)
              Container(
                margin: const EdgeInsets.only(right: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: c.accentAmber.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border:
                      Border.all(color: c.accentAmber.withOpacity(0.6)),
                ),
                child: Text(
                  badge,
                  style: TextStyle(
                    fontFamily: AppTheme.font,
                    fontSize: 9,
                    color: c.accentAmber,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            Icon(Icons.arrow_forward_ios_rounded, color: c.textSub, size: 13),
          ],
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  // ── CATEGORY SHEETS ──────────────────────────────────────
  void _showDDoSTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'DDoS Tools',
      headerIcon: Icons.flash_on,
      accentColor: c.primaryRed,
      heightFactor: 0.55,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.flash_on,
          label: 'Attack Panel',
          color: c.primaryRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    AttackPanel(sessionKey: sessionKey, listDoos: listDoos),
              ),
            );
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.dns,
          label: 'Manage Server',
          color: c.primaryRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'Network Tools',
      headerIcon: Icons.wifi,
      accentColor: c.accentBlue,
      heightFactor: 0.65,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.newspaper_outlined,
          label: 'Spam NGL',
          color: c.accentBlue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => const NglPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.wifi_off,
          label: 'WiFi Killer (External)',
          color: c.accentBlue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const WifiKillerPage()));
          },
        ),
        if (userRole == 'owner' || userRole == 'developer')
          _buildToolOption(
            context: context,
            icon: Icons.router,
            label: 'WiFi Killer (Internal)',
            color: c.accentBlue,
            badge: 'VIP',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WifiInternalPage(sessionKey: sessionKey),
                ),
              );
            },
          ),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'OSINT Tools',
      headerIcon: Icons.search,
      accentColor: c.accentBlue,
      heightFactor: 0.72,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.badge,
          label: 'NIK Detail',
          color: c.accentBlue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.domain,
          label: 'Domain OSINT',
          color: c.accentBlue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.person_search,
          label: 'Phone Lookup',
          color: c.accentBlue,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          context: context,
          icon: Icons.email,
          label: 'Email OSINT',
          color: c.accentBlue,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'Media Downloader',
      headerIcon: Icons.download,
      accentColor: c.accentGreen,
      heightFactor: 0.55,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.video_library,
          label: 'TikTok Downloader',
          color: c.accentGreen,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.camera_alt,
          label: 'Instagram Downloader',
          color: c.accentGreen,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const InstagramDownloaderPage()));
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'Utility Tools',
      headerIcon: Icons.build,
      accentColor: c.accentAmber,
      heightFactor: 0.65,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.qr_code,
          label: 'QR Generator',
          color: c.accentAmber,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.security,
          label: 'IP Scanner',
          color: c.accentAmber,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          context: context,
          icon: Icons.network_check,
          label: 'Port Scanner',
          color: c.accentAmber,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showIslamicTools(BuildContext context) {
    final c = PaletteScope.of(context);
    _showSheet(
      context: context,
      title: 'Islamic Tools',
      headerIcon: Icons.mosque_rounded,
      accentColor: const Color(0xFF0E9B6E),
      heightFactor: 0.45,
      options: [
        _buildToolOption(
          context: context,
          icon: Icons.menu_book_rounded,
          label: 'Kumpulan Hadis',
          color: const Color(0xFF0E9B6E),
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => const HadisPage()));
          },
        ),
        _buildToolOption(
          context: context,
          icon: Icons.auto_stories_rounded,
          label: "Al-Qur'an",
          color: const Color(0xFF0E9B6E),
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  // ── SNACKBAR ─────────────────────────────────────────────
  void _showComingSoon(BuildContext context) {
    final c = PaletteScope.of(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top_rounded, color: c.accentAmber, size: 18),
            const SizedBox(width: 10),
            Text(
              'Feature Coming Soon!',
              style: AppTheme.heading(size: 13, color: c.textMain),
            ),
          ],
        ),
        backgroundColor: c.cardBg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: c.border, width: 1.5),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}