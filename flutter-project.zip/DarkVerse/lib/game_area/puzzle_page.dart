import 'dart:math';
import 'package:flutter/material.dart';

// ===================== DESIGN TOKENS =====================
class _C {
  static const bg0 = Color(0xFF050507);
  static const bg1 = Color(0xFF0C0C10);
  static const bg2 = Color(0xFF12121A);
  static const bg3 = Color(0xFF1A1A24);

  static const accent     = Color(0xFF7C6FFF);
  static const accentDim  = Color(0xFF4A41C4);
  static const accentGlow = Color(0x337C6FFF);
  static const accentSoft = Color(0x1A7C6FFF);

  static const cyan     = Color(0xFF00D4FF);
  static const cyanDim  = Color(0xFF0097B8);
  static const cyanGlow = Color(0x3300D4FF);

  static const live    = Color(0xFF10B981);
  static const liveGlow= Color(0x3310B981);
  static const warning = Color(0xFFFFB800);

  static const textPrimary   = Color(0xFFF0EEFF);
  static const textSecondary = Color(0xFF8A8AA0);
  static const textMuted     = Color(0xFF4A4A60);

  static const borderBright = Color(0xFF2E2E46);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 1.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.5,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.3,
  );
}

// ===================== PUZZLE PAGE =====================
class PuzzlePage extends StatefulWidget {
  const PuzzlePage({super.key});

  @override
  State<PuzzlePage> createState() => _PuzzlePageState();
}

class _PuzzlePageState extends State<PuzzlePage> {
  List<int> tiles = List.generate(9, (i) => i);
  int moves = 0;

  // Warna per-tile bergantian accent & cyan
  Color _tileColor(int value) {
    const colors = [_C.accent, _C.cyan, _C.live, _C.warning];
    return colors[(value - 1) % colors.length];
  }

  @override
  void initState() {
    super.initState();
    shuffle();
  }

  void shuffle() {
    setState(() {
      tiles.shuffle(Random());
      moves = 0;
    });
  }

  void move(int index) {
    final emptyIndex = tiles.indexOf(0);
    final diff = (index - emptyIndex).abs();
    if (diff == 1 || diff == 3) {
      setState(() {
        tiles[emptyIndex] = tiles[index];
        tiles[index] = 0;
        moves++;
      });
    }
  }

  bool get isWin {
    for (int i = 0; i < 8; i++) {
      if (tiles[i] != i + 1) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.bg0, _C.bg1, _C.bg0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildInfoRow(),
                        const SizedBox(height: 12),
                        _buildWinBanner(),
                        const SizedBox(height: 20),
                        _buildBoard(),
                        const SizedBox(height: 32),
                        _buildShuffleButton(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _C.accentDim.withOpacity(0.35),
            _C.bg2,
            _C.cyanDim.withOpacity(0.15),
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border.all(color: _C.accent.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.accentSoft,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: _C.accent, size: 16),
                ),
              ),
              const Spacer(),
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [_C.accent, _C.cyan],
                ).createShader(r),
                child: Text('PUZZLE GAME',
                    style: _T.display(20).copyWith(color: Colors.white)),
              ),
              const Spacer(),
              const SizedBox(width: 36),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.accent.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text('Slide & Solve', style: _T.label(13)),
        ],
      ),
    );
  }

  // ── INFO ROW (moves counter) ──────────────────────────────
  Widget _buildInfoRow() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.accent.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 12),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.touch_app_rounded, color: _C.accent, size: 18),
          const SizedBox(width: 8),
          Text('MOVES  ', style: _T.label(14)),
          Text('$moves', style: _T.heading(18).copyWith(color: _C.accent)),
        ],
      ),
    );
  }

  // ── WIN BANNER ───────────────────────────────────────────
  Widget _buildWinBanner() {
    return AnimatedOpacity(
      opacity: isWin ? 1 : 0,
      duration: const Duration(milliseconds: 400),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
        decoration: BoxDecoration(
          color: _C.live.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.live.withOpacity(0.4), width: 1),
          boxShadow: [
            BoxShadow(color: _C.liveGlow, blurRadius: 16),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.emoji_events_rounded, color: _C.live, size: 20),
            const SizedBox(width: 8),
            Text('YOU WIN!', style: _T.heading(18).copyWith(color: _C.live)),
          ],
        ),
      ),
    );
  }

  // ── BOARD ────────────────────────────────────────────────
  Widget _buildBoard() {
    return Container(
      width: 310,
      height: 310,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.bg2,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.accent.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24),
        ],
      ),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 9,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (context, index) {
          final val = tiles[index];
          final isEmpty = val == 0;
          final color = isEmpty ? _C.accent : _tileColor(val);

          return GestureDetector(
            onTap: () => move(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: isEmpty ? Colors.transparent : color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isEmpty ? _C.borderBright.withOpacity(0.3) : color.withOpacity(0.45),
                  width: isEmpty ? 1 : 1,
                ),
                boxShadow: isEmpty
                    ? []
                    : [BoxShadow(color: color.withOpacity(0.25), blurRadius: 10)],
              ),
              child: Center(
                child: isEmpty
                    ? null
                    : Text(
                        '$val',
                        style: TextStyle(
                          fontFamily: _T.font,
                          fontSize: 38,
                          fontWeight: FontWeight.w700,
                          color: color,
                          shadows: [
                            Shadow(color: color.withOpacity(0.7), blurRadius: 10),
                          ],
                        ),
                      ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ── SHUFFLE BUTTON ───────────────────────────────────────
  Widget _buildShuffleButton() {
    return GestureDetector(
      onTap: shuffle,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.accentDim, _C.accent],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: _C.accentGlow, blurRadius: 20, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.shuffle_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text('SHUFFLE', style: _T.heading(14).copyWith(color: Colors.white)),
          ],
        ),
      ),
    );
  }
}