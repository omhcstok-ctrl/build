import 'package:flutter/material.dart';

// ===================== DESIGN TOKENS =====================
class _C {
  static const bg0 = Color(0xFF050507);
  static const bg1 = Color(0xFF0C0C10);
  static const bg2 = Color(0xFF12121A);
  static const bg3 = Color(0xFF1A1A24);

  static const accent     = Color(0xFF7C6FFF);
  static const accentDim  = Color(0xFF4A41C4);
  static const accentGlow = Color(0x337C6FFF);
  static const accentSoft = Color(0x1A7C6FFF);

  static const cyan     = Color(0xFF00D4FF);
  static const cyanDim  = Color(0xFF0097B8);
  static const cyanGlow = Color(0x3300D4FF);

  static const live    = Color(0xFF10B981);
  static const danger  = Color(0xFFFF4757);
  static const warning = Color(0xFFFFB800);

  static const textPrimary   = Color(0xFFF0EEFF);
  static const textSecondary = Color(0xFF8A8AA0);
  static const textMuted     = Color(0xFF4A4A60);

  static const border       = Color(0xFF1E1E2E);
  static const borderBright = Color(0xFF2E2E46);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 1.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.5,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.3,
  );
}

// ===================== TIC TAC PAGE =====================
class TicTacPage extends StatefulWidget {
  const TicTacPage({super.key});

  @override
  State<TicTacPage> createState() => _TicTacPageState();
}

class _TicTacPageState extends State<TicTacPage> {
  List<String> board = List.generate(9, (_) => "");
  String currentPlayer = "X";
  String winner = "";

  // X  → accent (ungu), O → cyan
  Color get _xColor => _C.accent;
  Color get _oColor => _C.cyan;
  Color get _currentColor => currentPlayer == "X" ? _xColor : _oColor;

  void tap(int index) {
    if (board[index] != "" || winner != "") return;
    setState(() {
      board[index] = currentPlayer;
      _checkWinner();
      if (winner == "") currentPlayer = currentPlayer == "X" ? "O" : "X";
    });
  }

  void _checkWinner() {
    const patterns = [
      [0,1,2],[3,4,5],[6,7,8],
      [0,3,6],[1,4,7],[2,5,8],
      [0,4,8],[2,4,6],
    ];
    for (final p in patterns) {
      if (board[p[0]] != "" &&
          board[p[0]] == board[p[1]] &&
          board[p[1]] == board[p[2]]) {
        winner = board[p[0]];
        return;
      }
    }
    if (!board.contains("")) winner = "DRAW";
  }

  void reset() {
    setState(() {
      board = List.generate(9, (_) => "");
      currentPlayer = "X";
      winner = "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.bg0, _C.bg1, _C.bg0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildStatusBadge(),
                        const SizedBox(height: 28),
                        _buildBoard(),
                        const SizedBox(height: 32),
                        _buildResetButton(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _C.accentDim.withOpacity(0.35),
            _C.bg2,
            _C.cyanDim.withOpacity(0.15),
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border.all(color: _C.accent.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.accentSoft,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: _C.accent, size: 16),
                ),
              ),
              const Spacer(),
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [_C.accent, _C.cyan],
                ).createShader(r),
                child: Text(
                  'TIC TAC TOE',
                  style: _T.display(20).copyWith(color: Colors.white),
                ),
              ),
              const Spacer(),
              const SizedBox(width: 36),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.accent.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text('Classic Strategy Game', style: _T.label(13)),
        ],
      ),
    );
  }

  // ── STATUS BADGE ─────────────────────────────────────────
  Widget _buildStatusBadge() {
    final isWinner = winner != "" && winner != "DRAW";
    final isDraw   = winner == "DRAW";

    final Color badgeColor = isWinner
        ? (winner == "X" ? _xColor : _oColor)
        : isDraw
            ? _C.warning
            : _currentColor;

    final String text = isWinner
        ? "🏆  WINNER: $winner"
        : isDraw
            ? "🤝  IT'S A DRAW"
            : "TURN:  $currentPlayer";

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: badgeColor.withOpacity(0.4), width: 1),
        boxShadow: [
          BoxShadow(color: badgeColor.withOpacity(0.2), blurRadius: 16),
        ],
      ),
      child: Text(
        text,
        style: _T.heading(18).copyWith(color: badgeColor),
      ),
    );
  }

  // ── BOARD ────────────────────────────────────────────────
  Widget _buildBoard() {
    return Container(
      width: 310,
      height: 310,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.bg2,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.accent.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24),
        ],
      ),
      child: GridView.builder(
        itemCount: 9,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (context, index) {
          final val   = board[index];
          final color = val == "X" ? _xColor : _oColor;

          return GestureDetector(
            onTap: () => tap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: val.isEmpty
                    ? _C.bg3
                    : color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: val.isEmpty
                      ? _C.borderBright
                      : color.withOpacity(0.5),
                  width: 1,
                ),
                boxShadow: val.isEmpty
                    ? []
                    : [BoxShadow(color: color.withOpacity(0.3), blurRadius: 12)],
              ),
              child: Center(
                child: Text(
                  val,
                  style: TextStyle(
                    fontFamily: _T.font,
                    fontSize: 46,
                    fontWeight: FontWeight.w700,
                    color: color,
                    shadows: val.isEmpty
                        ? []
                        : [Shadow(color: color.withOpacity(0.8), blurRadius: 12)],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ── RESET BUTTON ─────────────────────────────────────────
  Widget _buildResetButton() {
    return GestureDetector(
      onTap: reset,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.accentDim, _C.accent],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: _C.accentGlow, blurRadius: 20, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              'RESET GAME',
              style: _T.heading(14).copyWith(color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}