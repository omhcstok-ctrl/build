import 'package:flutter/material.dart';

// ===================== DESIGN TOKENS =====================
class _C {
  static const bg0 = Color(0xFF050507);
  static const bg1 = Color(0xFF0C0C10);
  static const bg2 = Color(0xFF12121A);
  static const bg3 = Color(0xFF1A1A24);

  static const accent     = Color(0xFF7C6FFF);
  static const accentDim  = Color(0xFF4A41C4);
  static const accentGlow = Color(0x337C6FFF);
  static const accentSoft = Color(0x1A7C6FFF);

  static const cyan     = Color(0xFF00D4FF);
  static const cyanDim  = Color(0xFF0097B8);
  static const cyanGlow = Color(0x3300D4FF);

  static const live    = Color(0xFF10B981);
  static const liveGlow= Color(0x3310B981);
  static const danger  = Color(0xFFFF4757);
  static const warning = Color(0xFFFFB800);

  static const textPrimary   = Color(0xFFF0EEFF);
  static const textSecondary = Color(0xFF8A8AA0);
  static const textMuted     = Color(0xFF4A4A60);

  static const borderBright = Color(0xFF2E2E46);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 1.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.5,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.3,
  );
}

// ===================== QUIZ PAGE =====================
class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  String? selectedCategory;
  int currentQuestionIndex = 0;
  int score = 0;
  int? selectedAnswerIndex;
  bool isAnswered = false;
  String gameState = 'menu';

  // Warna per kategori
  Color _categoryColor(String cat) {
    const map = {
      'Matematika': _C.accent,
      'IPA':        _C.cyan,
      'Agama':      _C.live,
      'Umum':       _C.warning,
    };
    return map[cat] ?? _C.accent;
  }

  IconData _categoryIcon(String cat) {
    const map = {
      'Matematika': Icons.calculate_rounded,
      'IPA':        Icons.science_rounded,
      'Agama':      Icons.menu_book_rounded,
      'Umum':       Icons.public_rounded,
    };
    return map[cat] ?? Icons.quiz_rounded;
  }

  final Map<String, List<Map<String, dynamic>>> quizData = {
    "Matematika": [
      {"question": "Berapa hasil dari 15 x 4?",         "options": ["50","60","70","45"],               "answer": 1},
      {"question": "Akar kuadrat dari 81 adalah...",    "options": ["7","8","9","10"],                  "answer": 2},
      {"question": "Jika x + 5 = 12, berapa nilai x?", "options": ["5","6","7","8"],                   "answer": 2},
    ],
    "IPA": [
      {"question": "H2O adalah rumus kimia dari?",              "options": ["Garam","Gula","Air","Minyak"],          "answer": 2},
      {"question": "Planet terdekat dengan Matahari adalah?",   "options": ["Venus","Merkurius","Mars","Bumi"],       "answer": 1},
    ],
    "Agama": [
      {"question": "Rukun Islam yang pertama adalah?", "options": ["Sholat","Puasa","Syahadat","Zakat"], "answer": 2},
      {"question": "Kitab suci umat Islam adalah?",   "options": ["Injil","Zabur","Taurat","Al-Quran"], "answer": 3},
    ],
    "Umum": [
      {"question": "Ibu kota Indonesia adalah?",    "options": ["Bandung","Surabaya","Jakarta","Medan"],       "answer": 2},
      {"question": "Gunung tertinggi di dunia?",    "options": ["Kilimanjaro","Everest","Fuji","Kerinci"],     "answer": 1},
    ],
  };

  // ── LOGIKA ───────────────────────────────────────────────
  void startQuiz(String category) {
    setState(() {
      selectedCategory      = category;
      currentQuestionIndex  = 0;
      score                 = 0;
      selectedAnswerIndex   = null;
      isAnswered            = false;
      gameState             = 'play';
    });
  }

  void checkAnswer(int idx) {
    if (isAnswered) return;
    final correct = quizData[selectedCategory]![currentQuestionIndex]['answer'];
    setState(() {
      selectedAnswerIndex = idx;
      isAnswered          = true;
      if (idx == correct) score++;
    });
    Future.delayed(const Duration(milliseconds: 900), nextQuestion);
  }

  void nextQuestion() {
    final total = quizData[selectedCategory]!.length;
    if (currentQuestionIndex < total - 1) {
      setState(() {
        currentQuestionIndex++;
        selectedAnswerIndex = null;
        isAnswered          = false;
      });
    } else {
      setState(() => gameState = 'result');
    }
  }

  void goToMenu() => setState(() {
    gameState        = 'menu';
    selectedCategory = null;
  });

  // ── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.bg0, _C.bg1, _C.bg0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: () {
                  if (gameState == 'menu')   return _buildMenuView();
                  if (gameState == 'play')   return _buildPlayView();
                  return _buildResultView();
                }(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    final showBack = gameState != 'menu';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _C.accentDim.withOpacity(0.35),
            _C.bg2,
            _C.cyanDim.withOpacity(0.15),
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border.all(color: _C.accent.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Back button — ke Navigator.pop jika dari GameArea, ke menu jika in-game
              GestureDetector(
                onTap: () {
                  if (showBack) {
                    goToMenu();
                  } else {
                    Navigator.pop(context);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.accentSoft,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: _C.accent, size: 16),
                ),
              ),
              const Spacer(),
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [_C.accent, _C.cyan],
                ).createShader(r),
                child: Text('QUIZ MASTER',
                    style: _T.display(20).copyWith(color: Colors.white)),
              ),
              const Spacer(),
              const SizedBox(width: 36),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.accent.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            gameState == 'menu'
                ? 'Pilih Kategori'
                : gameState == 'play'
                    ? '$selectedCategory  •  Soal ${currentQuestionIndex + 1}/${quizData[selectedCategory]!.length}'
                    : 'Hasil Quiz',
            style: _T.label(13),
          ),
        ],
      ),
    );
  }

  // ── MENU VIEW ────────────────────────────────────────────
  Widget _buildMenuView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 1.15,
        children: quizData.keys.map((cat) {
          final color = _categoryColor(cat);
          final icon  = _categoryIcon(cat);
          final count = quizData[cat]!.length;

          return TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 450),
            curve: Curves.easeOutBack,
            builder: (_, v, child) => Transform.scale(scale: v, child: child),
            child: GestureDetector(
              onTap: () => startQuiz(cat),
              child: Container(
                decoration: BoxDecoration(
                  color: _C.bg2,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: color.withOpacity(0.3), width: 1),
                  boxShadow: [
                    BoxShadow(color: color.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4)),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: color.withOpacity(0.4), width: 1),
                          boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 8)],
                        ),
                        child: Icon(icon, color: color, size: 22),
                      ),
                      const SizedBox(height: 12),
                      Text(cat, style: _T.heading(13)),
                      const SizedBox(height: 3),
                      Text('$count Soal', style: _T.label(11)),
                      const SizedBox(height: 8),
                      Container(
                        height: 2, width: 28,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [color, color.withOpacity(0.2)]),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ── PLAY VIEW ────────────────────────────────────────────
  Widget _buildPlayView() {
    final questions = quizData[selectedCategory]!;
    final currentQ  = questions[currentQuestionIndex];
    final color     = _categoryColor(selectedCategory!);
    final progress  = (currentQuestionIndex + 1) / questions.length;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress bar
          Container(
            height: 6,
            decoration: BoxDecoration(
              color: _C.bg3,
              borderRadius: BorderRadius.circular(4),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: progress,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [color, _C.cyan]),
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: [BoxShadow(color: color.withOpacity(0.5), blurRadius: 6)],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Score chip
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.live.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.live.withOpacity(0.35)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.star_rounded, color: _C.live, size: 14),
                    const SizedBox(width: 4),
                    Text('$score', style: _T.heading(13).copyWith(color: _C.live)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Question card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _C.bg2,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withOpacity(0.25), width: 1),
              boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 16)],
            ),
            child: Text(
              currentQ['question'],
              style: _T.heading(16).copyWith(height: 1.5),
            ),
          ),
          const SizedBox(height: 20),
          // Options
          ...List.generate(4, (i) => _buildOption(i, currentQ['options'][i], currentQ['answer'])),
        ],
      ),
    );
  }

  Widget _buildOption(int index, String text, int correctIndex) {
    Color color = _C.borderBright;
    Color textColor = _C.textPrimary;
    Color bgColor   = _C.bg2;
    IconData? icon;

    if (isAnswered) {
      if (index == correctIndex) {
        color     = _C.live;
        bgColor   = _C.live.withOpacity(0.1);
        textColor = _C.live;
        icon      = Icons.check_circle_rounded;
      } else if (index == selectedAnswerIndex) {
        color     = _C.danger;
        bgColor   = _C.danger.withOpacity(0.08);
        textColor = _C.danger;
        icon      = Icons.cancel_rounded;
      }
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(isAnswered ? 0.5 : 0.3), width: 1),
        boxShadow: isAnswered && (index == correctIndex || index == selectedAnswerIndex)
            ? [BoxShadow(color: color.withOpacity(0.2), blurRadius: 10)]
            : [],
      ),
      child: GestureDetector(
        onTap: () => checkAnswer(index),
        child: Row(
          children: [
            if (icon != null) ...[
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 10),
            ] else ...[
              Container(
                width: 24, height: 24,
                decoration: BoxDecoration(
                  color: _C.bg3,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _C.borderBright),
                ),
                child: Center(
                  child: Text(
                    String.fromCharCode(65 + index), // A B C D
                    style: _T.label(11),
                  ),
                ),
              ),
              const SizedBox(width: 10),
            ],
            Expanded(
              child: Text(text, style: _T.heading(14).copyWith(color: textColor)),
            ),
          ],
        ),
      ),
    );
  }

  // ── RESULT VIEW ──────────────────────────────────────────
  Widget _buildResultView() {
    final total      = quizData[selectedCategory]!.length;
    final percentage = (score / total) * 100;
    final color      = _categoryColor(selectedCategory!);

    String message;
    Color  msgColor;
    IconData msgIcon;

    if (percentage >= 80) {
      message  = 'LUAR BIASA!';
      msgColor = _C.live;
      msgIcon  = Icons.emoji_events_rounded;
    } else if (percentage >= 50) {
      message  = 'BAGUS!';
      msgColor = _C.warning;
      msgIcon  = Icons.thumb_up_rounded;
    } else {
      message  = 'COBA LAGI!';
      msgColor = _C.danger;
      msgIcon  = Icons.fitness_center_rounded;
    }

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Result icon
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: msgColor.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: msgColor.withOpacity(0.4), width: 2),
                boxShadow: [BoxShadow(color: msgColor.withOpacity(0.25), blurRadius: 24)],
              ),
              child: Icon(msgIcon, color: msgColor, size: 40),
            ),
            const SizedBox(height: 16),
            Text(message, style: _T.display(26).copyWith(color: msgColor)),
            const SizedBox(height: 24),
            // Score circle
            Container(
              width: 130, height: 130,
              decoration: BoxDecoration(
                color: _C.bg2,
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.5), width: 2),
                boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 24)],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '$score/$total',
                    style: _T.display(30).copyWith(color: color),
                  ),
                  Text('SKOR', style: _T.label(11)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '${percentage.toStringAsFixed(0)}% Benar',
              style: _T.label(14),
            ),
            const SizedBox(height: 36),
            // Back to menu button
            GestureDetector(
              onTap: goToMenu,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_C.accentDim, _C.accent]),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 20, offset: const Offset(0, 4))],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.home_rounded, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Text('KEMBALI KE MENU', style: _T.heading(14).copyWith(color: Colors.white)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            // Play again button
            GestureDetector(
              onTap: () => startQuiz(selectedCategory!),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: color.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.replay_rounded, color: color, size: 18),
                    const SizedBox(width: 8),
                    Text('MAIN LAGI', style: _T.heading(14).copyWith(color: color)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}