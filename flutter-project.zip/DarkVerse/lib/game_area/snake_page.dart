import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ===================== DESIGN TOKENS =====================
class _C {
  static const bg0 = Color(0xFF050507);
  static const bg1 = Color(0xFF0C0C10);
  static const bg2 = Color(0xFF12121A);
  static const bg3 = Color(0xFF1A1A24);

  static const accent     = Color(0xFF7C6FFF);
  static const accentDim  = Color(0xFF4A41C4);
  static const accentGlow = Color(0x337C6FFF);
  static const accentSoft = Color(0x1A7C6FFF);

  static const cyan     = Color(0xFF00D4FF);
  static const cyanDim  = Color(0xFF0097B8);
  static const cyanGlow = Color(0x3300D4FF);

  static const live    = Color(0xFF10B981);
  static const liveGlow= Color(0x3310B981);
  static const danger  = Color(0xFFFF4757);
  static const warning = Color(0xFFFFB800);

  static const textPrimary   = Color(0xFFF0EEFF);
  static const textSecondary = Color(0xFF8A8AA0);

  static const borderBright = Color(0xFF2E2E46);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 1.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.5,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.3,
  );
}

// ===================== SNAKE PAGE =====================
class SnakePage extends StatefulWidget {
  const SnakePage({super.key});

  @override
  State<SnakePage> createState() => _SnakePageState();
}

class _SnakePageState extends State<SnakePage> {
  static const int rowSize      = 20;
  static const int totalSquares = rowSize * rowSize;

  List<int> snake = [45, 65, 85];
  int food        = 100;
  String direction = "down";
  Timer? timer;
  int score = 0;
  bool isPlaying = false;

  void startGame() {
    isPlaying = true;
    timer = Timer.periodic(const Duration(milliseconds: 180), (_) => moveSnake());
  }

  void moveSnake() {
    setState(() {
      int newHead;
      switch (direction) {
        case "down":  newHead = snake.last + rowSize; break;
        case "up":    newHead = snake.last - rowSize; break;
        case "left":  newHead = snake.last - 1;       break;
        default:      newHead = snake.last + 1;
      }

      if (newHead >= totalSquares || newHead < 0 || snake.contains(newHead)) {
        timer?.cancel();
        isPlaying = false;
        _showGameOver();
        return;
      }

      snake.add(newHead);
      if (newHead == food) {
        score++;
        food = Random().nextInt(totalSquares);
      } else {
        snake.removeAt(0);
      }
    });
  }

  void _showGameOver() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: _C.bg2,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.danger.withOpacity(0.4), width: 1),
            boxShadow: [
              BoxShadow(color: _C.danger.withOpacity(0.2), blurRadius: 30),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _C.danger.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.danger.withOpacity(0.4)),
                ),
                child: const Icon(Icons.sentiment_very_dissatisfied_rounded, color: _C.danger, size: 32),
              ),
              const SizedBox(height: 16),
              Text('GAME OVER', style: _T.display(22).copyWith(color: _C.danger)),
              const SizedBox(height: 8),
              Text('Final Score', style: _T.label(13)),
              const SizedBox(height: 4),
              Text('$score', style: _T.display(36).copyWith(color: _C.live)),
              const SizedBox(height: 24),
              // Restart button
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  resetGame();
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_C.accentDim, _C.accent],
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(color: _C.accentGlow, blurRadius: 16),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
                      const SizedBox(width: 8),
                      Text('RESTART', style: _T.heading(14).copyWith(color: Colors.white)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void resetGame() {
    setState(() {
      snake     = [45, 65, 85];
      direction = "down";
      score     = 0;
      food      = Random().nextInt(totalSquares);
    });
    startGame();
  }

  @override
  void initState() {
    super.initState();
    startGame();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.bg0, _C.bg1, _C.bg0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              const SizedBox(height: 16),
              _buildScoreBar(),
              const SizedBox(height: 12),
              Expanded(child: _buildBoard()),
              _buildDPad(),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _C.accentDim.withOpacity(0.35),
            _C.bg2,
            _C.cyanDim.withOpacity(0.15),
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border.all(color: _C.accent.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 24, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.accentSoft,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: _C.accent, size: 16),
                ),
              ),
              const Spacer(),
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [_C.accent, _C.cyan],
                ).createShader(r),
                child: Text('SNAKE GAME',
                    style: _T.display(20).copyWith(color: Colors.white)),
              ),
              const Spacer(),
              const SizedBox(width: 36),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.accent.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text('Retro Arcade Fun', style: _T.label(13)),
        ],
      ),
    );
  }

  // ── SCORE BAR ────────────────────────────────────────────
  Widget _buildScoreBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.live.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(color: _C.liveGlow, blurRadius: 12),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.sports_esports_rounded, color: _C.live, size: 18),
          const SizedBox(width: 8),
          Text('SCORE  ', style: _T.label(14)),
          Text('$score', style: _T.heading(18).copyWith(color: _C.live)),
        ],
      ),
    );
  }

  // ── GAME BOARD ───────────────────────────────────────────
  Widget _buildBoard() {
    return GestureDetector(
      onVerticalDragUpdate: (d) {
        if (d.delta.dy > 0 && direction != "up")   direction = "down";
        else if (d.delta.dy < 0 && direction != "down") direction = "up";
      },
      onHorizontalDragUpdate: (d) {
        if (d.delta.dx > 0 && direction != "left")  direction = "right";
        else if (d.delta.dx < 0 && direction != "right") direction = "left";
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: _C.bg2,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.borderBright, width: 1),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: totalSquares,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: rowSize,
            ),
            itemBuilder: (context, index) {
              // Snake head
              if (index == snake.last) {
                return Container(
                  margin: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    color: _C.cyan,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: [
                      BoxShadow(color: _C.cyanGlow, blurRadius: 8),
                    ],
                  ),
                );
              }
              // Snake body
              if (snake.contains(index)) {
                return Container(
                  margin: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    color: _C.live,
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: [
                      BoxShadow(color: _C.liveGlow, blurRadius: 4),
                    ],
                  ),
                );
              }
              // Food
              if (index == food) {
                return Container(
                  margin: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: _C.danger,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: _C.danger.withOpacity(0.6), blurRadius: 8),
                    ],
                  ),
                );
              }
              // Empty cell
              return Container(
                margin: const EdgeInsets.all(1),
                decoration: BoxDecoration(
                  color: _C.bg3,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // ── D-PAD CONTROLS ───────────────────────────────────────
  Widget _buildDPad() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        children: [
          _dBtn(Icons.keyboard_arrow_up_rounded,    () { if (direction != "down")  setState(() => direction = "up");    }),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _dBtn(Icons.keyboard_arrow_left_rounded,  () { if (direction != "right") setState(() => direction = "left");  }),
              const SizedBox(width: 48),
              _dBtn(Icons.keyboard_arrow_right_rounded, () { if (direction != "left")  setState(() => direction = "right"); }),
            ],
          ),
          _dBtn(Icons.keyboard_arrow_down_rounded,  () { if (direction != "up")    setState(() => direction = "down");  }),
        ],
      ),
    );
  }

  Widget _dBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(4),
        width: 48, height: 48,
        decoration: BoxDecoration(
          color: _C.bg3,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.accent.withOpacity(0.3), width: 1),
          boxShadow: [
            BoxShadow(color: _C.accentGlow, blurRadius: 8),
          ],
        ),
        child: Icon(icon, color: _C.accent, size: 26),
      ),
    );
  }
}