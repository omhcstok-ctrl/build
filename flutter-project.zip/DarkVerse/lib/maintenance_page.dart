// maintenance_page.dart
// ════════════════════════════════════════════════════════════════════════════
//  MAINTENANCE MODE — All-in-One
//  Berisi: MaintenanceService, MaintenancePopup, MaintenancePage
// ════════════════════════════════════════════════════════════════════════════
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '.dart'; // apiBaseUrl

// ══════════════════════════════════════════════════════════════════════════
//  MODEL
// ══════════════════════════════════════════════════════════════════════════
class MaintenanceStatus {
  final bool active;
  final String reason;
  final String? activatedBy;
  final String? activatedAt;

  MaintenanceStatus({
    required this.active,
    required this.reason,
    this.activatedBy,
    this.activatedAt,
  });

  factory MaintenanceStatus.fromJson(Map<String, dynamic> j) {
    return MaintenanceStatus(
      active: j['active'] == true,
      reason: (j['reason'] ?? '-').toString(),
      activatedBy: j['activatedBy']?.toString(),
      activatedAt: j['activatedAt']?.toString(),
    );
  }

  static MaintenanceStatus offline() =>
      MaintenanceStatus(active: false, reason: '');
}

// ══════════════════════════════════════════════════════════════════════════
//  SERVICE
// ══════════════════════════════════════════════════════════════════════════
class MaintenanceService {
  /// Ambil status maintenance dari server.
  /// Kalau gagal → return `active: false` (biar app tetap bisa dipakai).
  static Future<MaintenanceStatus> fetchStatus() async {
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/maintenance/status'))
          .timeout(const Duration(seconds: 6));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        return MaintenanceStatus.fromJson(data);
      }
    } catch (_) {}
    return MaintenanceStatus.offline();
  }

  static Future<Map<String, dynamic>> activate({
    required String key,
    required String reason,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$apiBaseUrl/maintenance/activate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': key, 'reason': reason}),
      );
      return jsonDecode(res.body);
    } catch (e) {
      return {'valid': false, 'message': 'Network error: $e'};
    }
  }

  static Future<Map<String, dynamic>> deactivate({
    required String key,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$apiBaseUrl/maintenance/deactivate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': key}),
      );
      return jsonDecode(res.body);
    } catch (e) {
      return {'valid': false, 'message': 'Network error: $e'};
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  POPUP — Kartun 2D Hitam-Putih + Background Blur
// ══════════════════════════════════════════════════════════════════════════
class MaintenancePopup extends StatefulWidget {
  final String reason;
  final String? activatedBy;

  const MaintenancePopup({
    super.key,
    required this.reason,
    this.activatedBy,
  });

  static Future<void> show(
    BuildContext context, {
    required String reason,
    String? activatedBy,
  }) {
    return showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'maintenance',
      barrierColor: Colors.black.withOpacity(0.35),
      transitionDuration: const Duration(milliseconds: 380),
      pageBuilder: (_, __, ___) => MaintenancePopup(
        reason: reason,
        activatedBy: activatedBy,
      ),
      transitionBuilder: (context, anim, _, child) {
        final curved =
            CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.85, end: 1.0).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  @override
  State<MaintenancePopup> createState() => _MaintenancePopupState();
}

class _MaintenancePopupState extends State<MaintenancePopup>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _wiggle;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _wiggle = Tween<double>(begin: -0.02, end: 0.02).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
      child: Center(
        child: AnimatedBuilder(
          animation: _wiggle,
          builder: (_, child) =>
              Transform.rotate(angle: _wiggle.value * 0.15, child: child),
          child: _card(context),
        ),
      ),
    );
  }

  Widget _card(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24),
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Container(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.black, width: 3),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon 2D kartun
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 3),
                ),
                child: const Center(
                  child: Text(
                    '⚠',
                    style: TextStyle(
                      fontSize: 52,
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      height: 1.0,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // Judul
              const Text(
                'MAINTANCE MODE ON',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  letterSpacing: 1.2,
                  fontFamily: 'Rajdhani',
                ),
              ),
              const SizedBox(height: 8),
              _dashedDivider(),
              const SizedBox(height: 14),

              const Text(
                'ALASAN',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  color: Colors.black54,
                  letterSpacing: 2,
                  fontFamily: 'Rajdhani',
                ),
              ),
              const SizedBox(height: 6),

              // Kotak alasan
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.black, width: 2),
                ),
                child: Text(
                  widget.reason.isEmpty ? '-' : widget.reason,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 15,
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),

              if (widget.activatedBy != null) ...[
                const SizedBox(height: 12),
                Text(
                  'by ${widget.activatedBy}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black45,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],

              const SizedBox(height: 22),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                      side: const BorderSide(color: Colors.black, width: 2),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'OKE, SAYA TUNGGU',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      fontSize: 13,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dashedDivider() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        22,
        (i) => Container(
          width: 6,
          height: 3,
          margin: const EdgeInsets.symmetric(horizontal: 1.5),
          color: Colors.black,
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  HALAMAN FOUNDER — Aktifkan / Matikan Maintenance
// ══════════════════════════════════════════════════════════════════════════
class MaintenancePage extends StatefulWidget {
  final String sessionKey;

  const MaintenancePage({super.key, required this.sessionKey});

  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage>
    with SingleTickerProviderStateMixin {
  MaintenanceStatus? _status;
  bool _loading = true;
  bool _submitting = false;
  late AnimationController _glowCtrl;

  // Palet light (sesuai halaman lain)
  static const Color bgTop = Color(0xFFEAF4FF);
  static const Color bgBottom = Color(0xFFCFE7FF);
  static const Color cardBg = Color(0xFFF3F8FF);
  static const Color cardBorder = Color(0xFF0B0B0B);
  static const Color accent = Color(0xFF2F6FED);
  static const Color accentDim = Color(0xFF1B4FC4);
  static const Color textPrimary = Color(0xFF10131A);
  static const Color textSecondary = Color(0xFF7A8394);
  static const Color danger = Color(0xFFE0245E);
  static const Color success = Color(0xFF16A34A);

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _loadStatus();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadStatus() async {
    setState(() => _loading = true);
    final s = await MaintenanceService.fetchStatus();
    if (mounted) {
      setState(() {
        _status = s;
        _loading = false;
      });
    }
  }

  Future<void> _confirmActivate() async {
    final reason = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _ReasonDialog(),
    );
    if (reason == null || reason.trim().isEmpty) return;
    await _activate(reason.trim());
  }

  Future<void> _activate(String reason) async {
    setState(() => _submitting = true);
    final res = await MaintenanceService.activate(
      key: widget.sessionKey,
      reason: reason,
    );
    setState(() => _submitting = false);

    if (res['valid'] == true) {
      _snack('✅ MAINTENANCE AKTIF', false);
      await _loadStatus();
    } else {
      _snack(res['message']?.toString() ?? 'Gagal aktifkan', true);
    }
  }

  Future<void> _deactivate() async {
    setState(() => _submitting = true);
    final res = await MaintenanceService.deactivate(
      key: widget.sessionKey,
    );
    setState(() => _submitting = false);

    if (res['valid'] == true) {
      _snack('✅ Maintenance dimatikan', false);
      await _loadStatus();
    } else {
      _snack(res['message']?.toString() ?? 'Gagal matikan', true);
    }
  }

  void _snack(String msg, bool isError) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani')),
        backgroundColor: isError ? danger : success,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final active = _status?.active == true;

    return Scaffold(
      backgroundColor: bgBottom,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: textPrimary),
        title: const Text(
          "🛠️ FOUNDER · MAINTENANCE",
          style: TextStyle(
            color: textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
            fontFamily: 'Rajdhani',
          ),
        ),
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgTop, bgBottom],
          ),
        ),
        child: SafeArea(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(color: accent),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Status card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: cardBg,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: cardBorder, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 0,
                              offset: Offset(4, 6),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            AnimatedBuilder(
                              animation: _glowCtrl,
                              builder: (_, __) => Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  color: active
                                      ? danger
                                      : success.withOpacity(0.85),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: cardBorder, width: 2),
                                  boxShadow: active
                                      ? [
                                          BoxShadow(
                                            color: danger.withOpacity(
                                                0.25 + 0.2 * _glowCtrl.value),
                                            blurRadius: 20,
                                          ),
                                        ]
                                      : [],
                                ),
                                child: Icon(
                                  active
                                      ? Icons.warning_amber_rounded
                                      : Icons.check_rounded,
                                  color: Colors.white,
                                  size: 44,
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              active ? "MAINTENANCE AKTIF" : "NORMAL",
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                                color: textPrimary,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            const SizedBox(height: 6),
                            if (active)
                              Text(
                                _status?.reason ?? '-',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: textSecondary,
                                  fontSize: 13,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Tombol aksi
                      if (!active)
                        _bigButton(
                          label: "🔴 AKTIFKAN MAINTENANCE",
                          onTap: _submitting ? null : _confirmActivate,
                          color: danger,
                        )
                      else
                        _bigButton(
                          label: "🟢 MATIKAN MAINTENANCE",
                          onTap: _submitting ? null : _deactivate,
                          color: success,
                        ),

                      const SizedBox(height: 20),
                      const Text(
                        "Hanya role FOUNDER yang bisa mengakses fitur ini.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: textSecondary,
                          fontStyle: FontStyle.italic,
                          fontSize: 12,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  Widget _bigButton({
    required String label,
    VoidCallback? onTap,
    required Color color,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: cardBorder, width: 2),
          ),
          elevation: 0,
        ),
        child: _submitting
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
            : Text(
                label,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                  fontSize: 14,
                  fontFamily: 'Rajdhani',
                ),
              ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════
//  DIALOG MASUKKAN ALASAN — pakai BLOCKQUOTE
// ══════════════════════════════════════════════════════════════════════════
class _ReasonDialog extends StatefulWidget {
  const _ReasonDialog();

  @override
  State<_ReasonDialog> createState() => _ReasonDialogState();
}

class _ReasonDialogState extends State<_ReasonDialog> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
        side: const BorderSide(color: Colors.black, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Text('🛠️', style: TextStyle(fontSize: 26)),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'AKTIFKAN MAINTENANCE',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      letterSpacing: 1.2,
                      color: Colors.black,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // BLOCKQUOTE
            Container(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              decoration: const BoxDecoration(
                color: Color(0xFFF3F3F3),
                border: Border(
                  left: BorderSide(color: Colors.black, width: 4),
                ),
              ),
              child: const Text(
                '“ Silahkan masukkan alasan anda untuk mengaktifkan mode '
                'maintenance. Alasan akan ditampilkan ke semua user yang '
                'mencoba login. ”',
                style: TextStyle(
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                  color: Colors.black87,
                  height: 1.5,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ),

            const SizedBox(height: 16),

            TextField(
              controller: _ctrl,
              maxLines: 4,
              autofocus: true,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 14,
                fontFamily: 'Rajdhani',
              ),
              decoration: InputDecoration(
                hintText: 'Tulis alasan di sini...',
                hintStyle: const TextStyle(
                  color: Colors.black38,
                  fontFamily: 'Rajdhani',
                ),
                filled: true,
                fillColor: const Color(0xFFFAFAFA),
                contentPadding: const EdgeInsets.all(14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: Colors.black, width: 2),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: Colors.black, width: 2),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: Colors.black, width: 2.5),
                ),
              ),
            ),

            const SizedBox(height: 18),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, null),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: Colors.black, width: 2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'BATAL',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      final v = _ctrl.text.trim();
                      if (v.isEmpty) return;
                      Navigator.pop(context, v);
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'AKTIFKAN',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}