import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'app_theme.dart';
import '.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGlobal;
  final List<Map<String, dynamic>> listBugGroup;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    // ⬇️ Diubah: opsional dengan default list kosong
    this.listBugGlobal = const [],
    this.listBugGroup = const [],
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  late ScrollController _payloadScrollController;

  String selectedBugId = "";
  bool _isSending = false;
  String? _responseMessage;

  String _selectedSenderType = "private";
  List<String> activeSenders = [];
  bool _isLoadingSenders = false;
  String? _senderError;

  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _payloadScrollController = ScrollController();
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
    _initializeVideoPlayer();
    _fetchActiveSenders();
  }

  // ══════════════════════════════════════════════════════════════
  //  ACTIVE BUG LIST — dinamis sesuai mode sender
  // ══════════════════════════════════════════════════════════════
  List<Map<String, dynamic>> get _activeBugList {
    switch (_selectedSenderType) {
      case 'global':
        return widget.listBugGlobal;
      case 'group':
        return widget.listBugGroup;
      default:
        return widget.listBug;
    }
  }

  List<Map<String, dynamic>> _bugListFor(String type) {
    switch (type) {
      case 'global':
        return widget.listBugGlobal;
      case 'group':
        return widget.listBugGroup;
      default:
        return widget.listBug;
    }
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((e) {
      setState(() => _isVideoInitialized = false);
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    targetController.dispose();
    _payloadScrollController.dispose();
    _videoController.dispose();
    if (_isVideoInitialized) _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool _isValidGroupInput(String input) {
    final trimmed = input.trim();
    if (trimmed.contains('chat.whatsapp.com/')) return true;
    if (trimmed.endsWith('@g.us')) return true;
    return false;
  }

  Future<void> _fetchActiveSenders() async {
    setState(() {
      _isLoadingSenders = true;
      _senderError = null;
    });
    try {
      final res = await http
          .get(Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data["valid"] == true) {
          final globalConnections =
              data["globalConnections"] as List<dynamic>? ?? [];
          setState(() {
            activeSenders = globalConnections
                .whereType<Map>()
                .map((item) =>
                    item["sessionName"]?.toString() ??
                    item["id"]?.toString() ??
                    "Unknown")
                .toList();
          });
        } else {
          setState(() {
            _senderError = data["message"] ?? "Gagal memuat sender aktif";
            activeSenders = [];
          });
        }
      } else {
        setState(() {
          _senderError = "Server error: ${res.statusCode}";
          activeSenders = [];
        });
      }
    } catch (e) {
      setState(() {
        _senderError = "Connection failed: $e";
        activeSenders = [];
      });
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    // Validasi sesuai mode
    if (_selectedSenderType == "group") {
      if (!_isValidGroupInput(rawInput)) {
        _showAlert(
            "Invalid Group Link",
            "Masukkan link grup WhatsApp (https://chat.whatsapp.com/...)\natau JID grup (xxxxx@g.us).");
        return;
      }
    } else {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number",
            "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    }

    if (selectedBugId.isEmpty) {
      _showAlert("Bug Belum Dipilih", "Pilih payload bug terlebih dahulu.");
      return;
    }

    if (_selectedSenderType == "global" && activeSenders.isEmpty) {
      await _fetchActiveSenders();
      if (activeSenders.isEmpty) {
        _showAlert("Global Sender Kosong",
            "Belum ada global sender aktif saat ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "$apiBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderType=$_selectedSenderType"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        final wait = data["wait"];
        setState(() => _responseMessage = wait == null
            ? "⏳ Cooldown: Tunggu beberapa saat."
            : "⏳ Cooldown: tunggu $wait detik lagi.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() =>
            _responseMessage = "⚠️ ${data["message"] ?? "Gagal mengirim bug."}");
      } else {
        String label;
        if (_selectedSenderType == "global") {
          label = "global sender";
        } else if (_selectedSenderType == "group") {
          label = "group attack";
        } else {
          label = "sender pribadi";
        }
        setState(() => _responseMessage = "✅ Berhasil mengirim bug dengan $label!");
        targetController.clear();
      }
    } catch (_) {
      setState(() =>
          _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
      if (_selectedSenderType == "global") _fetchActiveSenders();
    }
  }

  // ══════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ══════════════════════════════════════════════════════════════
  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Builder(builder: (dialogContext) {
          final c = PaletteScope.of(dialogContext);
          return Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: c.cardBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.border, width: 2),
              boxShadow: AppTheme.hardShadowLg,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: c.primaryRed.withOpacity(0.12),
                    shape: BoxShape.circle,
                    border: Border.all(color: c.primaryRed, width: 1.5),
                  ),
                  child: Icon(Icons.warning_amber_rounded,
                      color: c.primaryRed, size: 24),
                ),
                const SizedBox(height: 14),
                Text(title,
                    style: AppTheme.heading(size: 16, color: c.textMain)),
                const SizedBox(height: 8),
                Text(msg,
                    style: AppTheme.body(size: 13, color: c.textSub),
                    textAlign: TextAlign.center),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(dialogContext),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            c.accentBlue.withOpacity(0.8),
                            c.accentBlue,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: c.border, width: 2),
                        boxShadow: AppTheme.hardShadowSm,
                      ),
                      child: Text(
                        "OK",
                        style: AppTheme.heading(size: 15, color: Colors.white),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  WIDGETS
  // ══════════════════════════════════════════════════════════════
  Widget _buildSectionCard(AppPalette c, {required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowSm,
      ),
      child: child,
    );
  }

  Widget _buildSectionLabel(AppPalette c, String text, IconData icon) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 18,
          decoration: BoxDecoration(
            color: c.accentBlue,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 8),
        Icon(icon, color: c.accentBlue, size: 16),
        const SizedBox(width: 6),
        Text(
          text,
          style: AppTheme.heading(size: 13, color: c.textMain)
              .copyWith(letterSpacing: 1.2),
        ),
      ],
    );
  }

  Widget _buildHeaderPanel(AppPalette c) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: c.cardBg,
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) => Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: c.border, width: 2),
                boxShadow: [
                  BoxShadow(
                    color:
                        c.accentBlue.withOpacity(_pulseController.value * 0.35),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: ClipOval(
                  child:
                      Image.asset('assets/images/logo.png', fit: BoxFit.cover)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: AppTheme.display(size: 20, color: c.textMain)
                      .copyWith(letterSpacing: 0.5),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: c.accentBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: c.accentBlue, width: 1.2),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: c.accentBlue,
                          fontFamily: AppTheme.font,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text("Exp: ${widget.expiredDate}",
                        style: AppTheme.body(size: 11, color: c.textSub)),
                  ],
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: c.accentGreen.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: c.accentGreen, width: 1.5),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                          color: c.accentGreen, shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text(
                    "LIVE",
                    style: TextStyle(
                      color: c.accentGreen,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      fontFamily: AppTheme.font,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer(AppPalette c) {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          color: c.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: c.border, width: 2),
        ),
        child: Center(
            child: CircularProgressIndicator(
                color: c.accentBlue, strokeWidth: 2.5)),
      );
    }
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Chewie(controller: _chewieController),
        ),
      ),
    );
  }

  Widget _buildPayloadSelector(AppPalette c) {
    final activeList = _activeBugList;
    final modeLabel = _selectedSenderType.toUpperCase();

    return _buildSectionCard(
      c,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _buildSectionLabel(c, "PILIH PAYLOAD", Icons.security_rounded),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: c.accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: c.accentBlue.withOpacity(0.4)),
                ),
                child: Text(
                  modeLabel,
                  style: TextStyle(
                    fontFamily: AppTheme.font,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    color: c.accentBlue,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const Spacer(),
              Row(children: [
                Icon(Icons.chevron_left_rounded, color: c.textMuted, size: 16),
                Text("geser",
                    style: AppTheme.body(size: 10, color: c.textMuted)),
                Icon(Icons.chevron_right_rounded, color: c.textMuted, size: 16),
              ]),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 115,
            child: activeList.isEmpty
                ? Center(
                    child: Text("Tidak ada payload tersedia untuk mode ini",
                        style: AppTheme.body(size: 12, color: c.textMuted)))
                : ListView.separated(
                    controller: _payloadScrollController,
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    itemCount: activeList.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final bug = activeList[index];
                      final bugId = bug['bug_id'] as String;
                      final bugName = bug['bug_name'] as String? ?? 'Unknown';
                      final bugDesc = bug['bug_desc'] as String? ?? '';
                      final isSelected = selectedBugId == bugId;
                      return _buildPayloadCard(c,
                          bugId: bugId,
                          bugName: bugName,
                          bugDesc: bugDesc,
                          index: index,
                          isSelected: isSelected);
                    },
                  ),
          ),
          const SizedBox(height: 12),
          if (selectedBugId.isNotEmpty)
            Builder(builder: (_) {
              final selected = activeList.firstWhere(
                (b) => b['bug_id'] == selectedBugId,
                orElse: () => {},
              );
              if (selected.isEmpty) return const SizedBox.shrink();
              return Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: c.accentBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: c.accentBlue, width: 1.5),
                ),
                child: Row(
                  children: [
                    Icon(Icons.security_rounded,
                        color: c.accentBlue, size: 16),
                    const SizedBox(width: 8),
                    Text("Payload aktif: ",
                        style: AppTheme.body(size: 12, color: c.textSub)),
                    Expanded(
                      child: Text(
                        selected['bug_name'] ?? '',
                        style:
                            AppTheme.heading(size: 12, color: c.accentBlue),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _buildPayloadCard(
    AppPalette c, {
    required String bugId,
    required String bugName,
    required String bugDesc,
    required int index,
    required bool isSelected,
  }) {
    // ← FIX: border idle pakai abu soft, bukan hitam tebal
    final idleBorder = c.textMuted.withOpacity(0.3);

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => selectedBugId = bugId);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        width: 128,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? c.accentBlue.withOpacity(0.1) : c.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? c.accentBlue : idleBorder,
            width: isSelected ? 2.5 : 1.2,
          ),
          boxShadow: isSelected ? AppTheme.hardShadowSm : const [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? c.accentBlue.withOpacity(0.15)
                        : c.accentBlue.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(
                        color: isSelected ? c.accentBlue : idleBorder),
                  ),
                  child: Icon(
                    Icons.security_rounded,
                    color: isSelected ? c.accentBlue : c.textMuted,
                    size: 18,
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? c.accentBlue.withOpacity(0.12)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: isSelected ? c.accentBlue : idleBorder),
                  ),
                  child: Text(
                    "#${(index + 1).toString().padLeft(2, '0')}",
                    style: TextStyle(
                      color: isSelected ? c.accentBlue : c.textMuted,
                      fontSize: 9,
                      fontFamily: AppTheme.font,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              bugName,
              style: AppTheme.heading(
                size: 12,
                color: isSelected ? c.textMain : c.textSub,
              ).copyWith(letterSpacing: 0.4),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const Spacer(),
            if (bugDesc.isNotEmpty)
              Text(bugDesc,
                  style: AppTheme.body(size: 9, color: c.textMuted),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel(AppPalette c) {
    final isGroup = _selectedSenderType == "group";
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSectionCard(
          c,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionLabel(
                  c,
                  isGroup ? "LINK GRUP WA" : "NOMOR TARGET",
                  isGroup ? Icons.group_add_rounded : Icons.phone_android_rounded),
              const SizedBox(height: 12),
              TextField(
                controller: targetController,
                style: AppTheme.body(size: 14, color: c.textMain),
                cursorColor: c.accentBlue,
                keyboardType: isGroup ? TextInputType.url : TextInputType.phone,
                decoration: InputDecoration(
                  hintText: isGroup
                      ? "https://chat.whatsapp.com/xxxxx"
                      : "Contoh: +62xxxxxxxxxx",
                  hintStyle: AppTheme.body(size: 13, color: c.textMuted),
                  filled: true,
                  fillColor: c.cardBg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: c.border, width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: c.border, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: c.accentBlue, width: 2.5),
                  ),
                  prefixIcon: Icon(
                      isGroup
                          ? Icons.link_rounded
                          : Icons.phone_android_rounded,
                      color: c.accentBlue,
                      size: 20),
                  contentPadding: const EdgeInsets.symmetric(
                      vertical: 16, horizontal: 16),
                ),
              ),
              if (isGroup) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: c.accentAmber.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: c.accentAmber.withOpacity(0.4), width: 1.3),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline_rounded,
                          color: c.accentAmber, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "Bot akan otomatis join grup via link, kirim bug, lalu leave.",
                          style:
                              AppTheme.body(size: 11, color: c.textSub),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 14),
        _buildPayloadSelector(c),
      ],
    );
  }

  Widget _buildSenderTypeSelector(AppPalette c) {
    return _buildSectionCard(
      c,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionLabel(c, "PILIH SENDER", Icons.swap_horiz_rounded),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _buildSenderOption(c,
                      type: "private",
                      icon: Icons.person_rounded,
                      label: "PRIVATE",
                      sub: "Sender pribadi")),
              const SizedBox(width: 10),
              Expanded(
                  child: _buildSenderOption(c,
                      type: "global",
                      icon: Icons.public_rounded,
                      label: "GLOBAL",
                      sub: "Sender global")),
              const SizedBox(width: 10),
              Expanded(
                  child: _buildSenderOption(c,
                      type: "group",
                      icon: Icons.groups_rounded,
                      label: "GROUP",
                      sub: "Attack grup WA")),
            ],
          ),
          const SizedBox(height: 12),
          if (_selectedSenderType == "global") ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: c.bgSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: c.border, width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text("SENDER AKTIF",
                          style: AppTheme.body(
                              size: 11,
                              color: c.textSub,
                              weight: FontWeight.w700)),
                      const Spacer(),
                      GestureDetector(
                        onTap: _fetchActiveSenders,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: c.accentBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: c.accentBlue.withOpacity(0.4)),
                          ),
                          child: Icon(Icons.refresh_rounded,
                              color: c.accentBlue, size: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_isLoadingSenders)
                    Center(
                        child: SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: c.accentBlue)))
                  else if (_senderError != null)
                    Text(_senderError!,
                        style: AppTheme.body(size: 12, color: c.primaryRed))
                  else if (activeSenders.isEmpty)
                    Text("Tidak ada global sender aktif",
                        style: AppTheme.body(size: 12, color: c.textMuted))
                  else
                    ...activeSenders.map((sender) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Container(
                                  width: 7,
                                  height: 7,
                                  decoration: BoxDecoration(
                                      color: c.accentGreen,
                                      shape: BoxShape.circle)),
                              const SizedBox(width: 8),
                              Expanded(
                                  child: Text(sender,
                                      style: AppTheme.body(
                                          size: 12, color: c.textMain),
                                      overflow: TextOverflow.ellipsis)),
                            ],
                          ),
                        )),
                ],
              ),
            ),
          ] else if (_selectedSenderType == "group") ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: c.bgSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: c.border, width: 1.5),
              ),
              child: Row(
                children: [
                  Icon(Icons.group_work_rounded,
                      color: c.accentBlue, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(
                          "Mode Group Attack — masukkan link grup WhatsApp sebagai target",
                          style: AppTheme.body(size: 12, color: c.textSub))),
                ],
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: c.bgSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: c.border, width: 1.5),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: c.accentBlue, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(
                          "Menggunakan sender pribadi dari session Anda",
                          style: AppTheme.body(size: 12, color: c.textSub))),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSenderOption(
    AppPalette c, {
    required String type,
    required IconData icon,
    required String label,
    required String sub,
  }) {
    final isActive = _selectedSenderType == type;
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _selectedSenderType = type;
          // Reset pilihan bug ke item pertama di list baru
          final list = _bugListFor(type);
          selectedBugId = list.isNotEmpty ? list[0]['bug_id'] as String : "";
        });
        if (type == "global" && activeSenders.isEmpty) {
          _fetchActiveSenders();
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
        decoration: BoxDecoration(
          color: isActive ? c.accentBlue.withOpacity(0.1) : c.bgSoft,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: c.border, width: isActive ? 2.5 : 1.5),
          boxShadow: isActive ? AppTheme.hardShadowSm : const [],
        ),
        child: Column(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: isActive
                    ? c.accentBlue.withOpacity(0.15)
                    : c.accentBlue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(11),
                border:
                    Border.all(color: isActive ? c.accentBlue : c.border),
              ),
              child: Icon(icon,
                  color: isActive ? c.accentBlue : c.textMuted, size: 20),
            ),
            const SizedBox(height: 8),
            Text(label,
                style: AppTheme.heading(
                    size: 11,
                    color: isActive ? c.accentBlue : c.textSub)),
            const SizedBox(height: 2),
            Text(sub,
                style: AppTheme.body(size: 9, color: c.textMuted),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton(AppPalette c) {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              colors: [c.accentBlue.withOpacity(0.8), c.accentBlue],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            border: Border.all(color: c.border, width: 2.5),
            boxShadow: AppTheme.hardShadowLg,
          ),
          child: ElevatedButton(
            onPressed: _isSending
                ? null
                : () {
                    HapticFeedback.mediumImpact();
                    _sendBug();
                  },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2.5))
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.bug_report_rounded,
                          color: Colors.white, size: 22),
                      const SizedBox(width: 12),
                      Text(
                        "SEND BUG",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                          fontFamily: AppTheme.font,
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage(AppPalette c) {
    if (_responseMessage == null) return const SizedBox.shrink();
    Color bg, borderC, textC;
    IconData icon;
    if (_responseMessage!.startsWith('✅')) {
      bg = c.accentGreen.withOpacity(0.1);
      borderC = c.accentGreen;
      textC = c.accentGreen;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bg = c.primaryRed.withOpacity(0.1);
      borderC = c.primaryRed;
      textC = c.primaryRed;
      icon = Icons.error_outline_rounded;
    } else {
      bg = c.accentBlue.withOpacity(0.1);
      borderC = c.accentBlue;
      textC = c.accentBlue;
      icon = Icons.info_outline_rounded;
    }
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderC, width: 2),
        ),
        child: Row(
          children: [
            Icon(icon, color: textC, size: 22),
            const SizedBox(width: 10),
            Expanded(
                child: Text(_responseMessage!,
                    style: AppTheme.heading(size: 13, color: textC))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeaderPanel(c),
                const SizedBox(height: 16),
                _buildVideoPlayer(c),
                const SizedBox(height: 16),
                _buildInputPanel(c),
                const SizedBox(height: 14),
                _buildSenderTypeSelector(c),
                const SizedBox(height: 24),
                _buildSendButton(c),
                _buildResponseMessage(c),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}