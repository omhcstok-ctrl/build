
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // ✅ TAMBAH INI
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import '.dart';

class PublicChatPage extends StatefulWidget {
  final String username;
  const PublicChatPage({super.key, required this.username});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<dynamic> _messages = [];
  Timer? _refreshTimer;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _fetchMessages();

    // Auto refresh chat setiap 2 detik
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchMessages();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  //  API
  // ══════════════════════════════════════════════════════════════
  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(Uri.parse("$apiBaseUrl/get-public-chat"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final List newMsgs = data['messages'];
          final shouldScroll = newMsgs.length > _messages.length;

          if (mounted) {
            setState(() {
              _messages = newMsgs;
            });
            if (shouldScroll) _scrollToBottom();
          }
        }
      }
    } catch (_) {
      // silent
    }
  }

  Future<void> _sendMessage() async {
    final text = _msgController.text.trim();
    if (text.isEmpty) return;

    _msgController.clear();
    setState(() => _isSending = true);

    try {
      await http.post(
        Uri.parse("$apiBaseUrl/send-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "username": widget.username,
          "message": text,
        }),
      );
      await _fetchMessages();
      _scrollToBottom();
    } catch (e) {
      if (mounted) {
        final c = PaletteScope.of(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text("Gagal mengirim pesan",
                style: TextStyle(fontFamily: 'Rajdhani')),
            backgroundColor: c.primaryRed,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(c),
              Expanded(
                child: _messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                color: c.cardBg,
                                shape: BoxShape.circle,
                                border: Border.all(color: c.border, width: 2),
                              ),
                              child: Icon(Icons.forum_outlined,
                                  color: c.accentBlue, size: 34),
                            ),
                            const SizedBox(height: 14),
                            Text('Belum ada pesan',
                                style: AppTheme.heading(
                                    size: 16, color: c.textMain)),
                            const SizedBox(height: 6),
                            Text('Jadilah yang pertama!',
                                style: AppTheme.body(
                                    size: 12, color: c.textSub)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final msg = _messages[index];
                          final isMe = msg['username'] == widget.username;
                          return _buildChatBubble(c, msg, isMe);
                        },
                      ),
              ),
              _buildInputArea(c),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────────
  Widget _buildHeader(AppPalette c) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        color: c.cardBg,
        border: Border(bottom: BorderSide(color: c.border, width: 2)),
        boxShadow: AppTheme.hardShadowSm,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.pop(context);
            },
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: c.bgSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: c.border, width: 1.5),
              ),
              child: Icon(Icons.arrow_back_rounded,
                  color: c.accentBlue, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: c.accentBlue.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(color: c.accentBlue, width: 1.5),
            ),
            child: Icon(Icons.public_rounded, color: c.accentBlue, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DØRAX PUBLIC',
                    style: AppTheme.heading(size: 15, color: c.textMain)
                        .copyWith(letterSpacing: 1)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: c.accentGreen,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Live • ${_messages.length} messages',
                      style: AppTheme.body(size: 10, color: c.textSub),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── BUBBLE ──────────────────────────────────────────────────
  Widget _buildChatBubble(AppPalette c, dynamic msg, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        child: Column(
          crossAxisAlignment:
              isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            // Nama user kalau bukan saya
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(left: 12, bottom: 4),
                child: Text(
                  msg['username'] ?? '',
                  style: AppTheme.heading(size: 11, color: c.accentBlue),
                ),
              ),

            // Bubble
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isMe
                    ? c.accentBlue.withOpacity(0.15)
                    : c.cardBg,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isMe ? 18 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 18),
                ),
                border: Border.all(
                  color: isMe ? c.accentBlue : c.border,
                  width: isMe ? 1.5 : 1.5,
                ),
                boxShadow: AppTheme.hardShadowSm,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    msg['message'] ?? '',
                    style: AppTheme.body(size: 14, color: c.textMain)
                        .copyWith(height: 1.4),
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      msg['time'] ?? '',
                      style: AppTheme.body(size: 9, color: c.textMuted),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── INPUT AREA ──────────────────────────────────────────────
  Widget _buildInputArea(AppPalette c) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: c.cardBg,
        border: Border(top: BorderSide(color: c.border, width: 2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(
                color: c.bgSoft,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: c.border, width: 1.5),
              ),
              child: TextField(
                controller: _msgController,
                style: AppTheme.body(size: 14, color: c.textMain),
                cursorColor: c.accentBlue,
                onSubmitted: (_) => _sendMessage(),
                decoration: InputDecoration(
                  hintText: "Type a message...",
                  hintStyle: AppTheme.body(size: 13, color: c.textMuted),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _isSending ? null : _sendMessage,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _isSending ? c.textMuted : c.accentBlue,
                shape: BoxShape.circle,
                border: Border.all(color: c.border, width: 1.5),
                boxShadow: _isSending ? const [] : AppTheme.hardShadowSm,
              ),
              child: Icon(
                _isSending
                    ? Icons.hourglass_top_rounded
                    : Icons.send_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }
}