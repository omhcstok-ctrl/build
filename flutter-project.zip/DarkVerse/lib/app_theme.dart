// app_theme.dart
import 'package:flutter/material.dart';

// ══════════════════════════════════════════════════════════════
//  PALETTE — paket warna lengkap, immutable
// ══════════════════════════════════════════════════════════════
@immutable
class AppPalette {
  final String id;
  final String label;
  final String emoji;
  final Brightness brightness;

  final Color bg;
  final Color bgSoft;
  final Color cardBg;
  final Color border;
  final Color textMain;
  final Color textSub;
  final Color textMuted;

  final Color primaryRed;
  final Color accentBlue;
  final Color accentGreen;
  final Color accentAmber;

  const AppPalette({
    required this.id,
    required this.label,
    this.emoji = '🎨',
    required this.brightness,
    required this.bg,
    required this.bgSoft,
    required this.cardBg,
    required this.border,
    required this.textMain,
    required this.textSub,
    required this.textMuted,
    required this.primaryRed,
    required this.accentBlue,
    required this.accentGreen,
    required this.accentAmber,
  });

  // ── ICE (default) ──
  static const ice = AppPalette(
    id: 'ice',
    label: 'Ice Blue',
    emoji: '❄️',
    brightness: Brightness.light,
    bg: Color(0xFFDCEBFA),
    bgSoft: Color(0xFFEAF3FB),
    cardBg: Colors.white,
    border: Colors.black,
    textMain: Colors.black,
    textSub: Color(0xFF555555),
    textMuted: Color(0xFF8A8A8A),
    primaryRed: Color(0xFFE53935),
    accentBlue: Color(0xFF2F6FED),
    accentGreen: Color(0xFF2E7D32),
    accentAmber: Color(0xFFC98A00),
  );

  // ── DARK ──
  static const dark = AppPalette(
    id: 'dark',
    label: 'Dark Night',
    emoji: '🌙',
    brightness: Brightness.dark,
    bg: Color(0xFF0F0F12),
    bgSoft: Color(0xFF17171B),
    cardBg: Color(0xFF1C1C22),
    border: Color(0xFFE5E5E5),
    textMain: Color(0xFFF0F0F0),
    textSub: Color(0xFFAAAAAA),
    textMuted: Color(0xFF666666),
    primaryRed: Color(0xFFEF5350),
    accentBlue: Color(0xFF64B5F6),
    accentGreen: Color(0xFF66BB6A),
    accentAmber: Color(0xFFFFCA28),
  );

  // ── SUNSET ──
  static const sunset = AppPalette(
    id: 'sunset',
    label: 'Sunset',
    emoji: '🌅',
    brightness: Brightness.light,
    bg: Color(0xFFFFE9D6),
    bgSoft: Color(0xFFFFF3E6),
    cardBg: Colors.white,
    border: Color(0xFF3E2723),
    textMain: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
    textMuted: Color(0xFF9E8075),
    primaryRed: Color(0xFFD84315),
    accentBlue: Color(0xFF00838F),
    accentGreen: Color(0xFF558B2F),
    accentAmber: Color(0xFFF57F17),
  );

  // ── TOON 2D ──
  static const toon = AppPalette(
    id: 'toon',
    label: 'Toon 2D',
    emoji: '✏️',
    brightness: Brightness.light,
    bg: Color(0xFFF5F5F5),
    bgSoft: Color(0xFFFFFFFF),
    cardBg: Color(0xFFFFFFFF),
    border: Color(0xFF000000),
    textMain: Color(0xFF000000),
    textSub: Color(0xFF3A3A3A),
    textMuted: Color(0xFF7A7A7A),
    primaryRed: Color(0xFF000000),
    accentBlue: Color(0xFF1F1F1F),
    accentGreen: Color(0xFF3D3D3D),
    accentAmber: Color(0xFF5A5A5A),
  );

  // ── CYBERPUNK ──
  static const cyber = AppPalette(
    id: 'cyber',
    label: 'Cyberpunk',
    emoji: '🌆',
    brightness: Brightness.dark,
    bg: Color(0xFF0A0416),
    bgSoft: Color(0xFF140A2E),
    cardBg: Color(0xFF1B0F3F),
    border: Color(0xFF00F0FF),
    textMain: Color(0xFFFF2FB3),
    textSub: Color(0xFFB98EFF),
    textMuted: Color(0xFF6E5FA8),
    primaryRed: Color(0xFFFF006E),
    accentBlue: Color(0xFF00F0FF),
    accentGreen: Color(0xFF39FF14),
    accentAmber: Color(0xFFFFEA00),
  );

  // ── BLOOD MOON ──
  static const blood = AppPalette(
    id: 'blood',
    label: 'Blood Moon',
    emoji: '🩸',
    brightness: Brightness.dark,
    bg: Color(0xFF0D0000),
    bgSoft: Color(0xFF1A0505),
    cardBg: Color(0xFF240A0A),
    border: Color(0xFFFF1744),
    textMain: Color(0xFFFFCDD2),
    textSub: Color(0xFFCF8484),
    textMuted: Color(0xFF7A4A4A),
    primaryRed: Color(0xFFFF1744),
    accentBlue: Color(0xFFE57373),
    accentGreen: Color(0xFFFF8A80),
    accentAmber: Color(0xFFFFAB40),
  );

  // ── FOREST ──
  static const forest = AppPalette(
    id: 'forest',
    label: 'Forest',
    emoji: '🌲',
    brightness: Brightness.light,
    bg: Color(0xFFE8F5E9),
    bgSoft: Color(0xFFF1F8E9),
    cardBg: Color(0xFFFFFFFF),
    border: Color(0xFF1B5E20),
    textMain: Color(0xFF1B5E20),
    textSub: Color(0xFF4E6B4F),
    textMuted: Color(0xFF81A882),
    primaryRed: Color(0xFFC62828),
    accentBlue: Color(0xFF00695C),
    accentGreen: Color(0xFF2E7D32),
    accentAmber: Color(0xFF9E7B00),
  );

  // ── SAKURA ──
  static const sakura = AppPalette(
    id: 'sakura',
    label: 'Sakura',
    emoji: '🌸',
    brightness: Brightness.light,
    bg: Color(0xFFFCE4EC),
    bgSoft: Color(0xFFFFF0F5),
    cardBg: Color(0xFFFFFFFF),
    border: Color(0xFFAD1457),
    textMain: Color(0xFF880E4F),
    textSub: Color(0xFFB15A82),
    textMuted: Color(0xFFD4A5B8),
    primaryRed: Color(0xFFE91E63),
    accentBlue: Color(0xFF9C27B0),
    accentGreen: Color(0xFF00897B),
    accentAmber: Color(0xFFFF6F00),
  );

  // ── NEON HACKER ──
  static const neon = AppPalette(
    id: 'neon',
    label: 'Neon Hacker',
    emoji: '💚',
    brightness: Brightness.dark,
    bg: Color(0xFF000000),
    bgSoft: Color(0xFF0A0F0A),
    cardBg: Color(0xFF0F1A0F),
    border: Color(0xFF00FF41),
    textMain: Color(0xFF00FF41),
    textSub: Color(0xFF4CAF50),
    textMuted: Color(0xFF2E5A2E),
    primaryRed: Color(0xFFFF3D00),
    accentBlue: Color(0xFF00E5FF),
    accentGreen: Color(0xFF00FF41),
    accentAmber: Color(0xFFFFEA00),
  );

  // ── ROYAL ──
  static const royal = AppPalette(
    id: 'royal',
    label: 'Royal Gold',
    emoji: '👑',
    brightness: Brightness.dark,
    bg: Color(0xFF1A0B2E),
    bgSoft: Color(0xFF251542),
    cardBg: Color(0xFF2D1A4D),
    border: Color(0xFFFFD54F),
    textMain: Color(0xFFFFF8E1),
    textSub: Color(0xFFD4B8F0),
    textMuted: Color(0xFF8B75A8),
    primaryRed: Color(0xFFD32F2F),
    accentBlue: Color(0xFF9575CD),
    accentGreen: Color(0xFF66BB6A),
    accentAmber: Color(0xFFFFD54F),
  );

  // ── MONOCHROME ──
  static const mono = AppPalette(
    id: 'mono',
    label: 'Monochrome',
    emoji: '⚫',
    brightness: Brightness.dark,
    bg: Color(0xFF121212),
    bgSoft: Color(0xFF1E1E1E),
    cardBg: Color(0xFF2A2A2A),
    border: Color(0xFFFAFAFA),
    textMain: Color(0xFFFAFAFA),
    textSub: Color(0xFFB0B0B0),
    textMuted: Color(0xFF666666),
    primaryRed: Color(0xFFE0E0E0),
    accentBlue: Color(0xFFBDBDBD),
    accentGreen: Color(0xFF9E9E9E),
    accentAmber: Color(0xFFCCCCCC),
  );

  // ── MINT ──
  static const mint = AppPalette(
    id: 'mint',
    label: 'Mint Fresh',
    emoji: '🍃',
    brightness: Brightness.light,
    bg: Color(0xFFE0F7F4),
    bgSoft: Color(0xFFEFFBF9),
    cardBg: Color(0xFFFFFFFF),
    border: Color(0xFF004D40),
    textMain: Color(0xFF004D40),
    textSub: Color(0xFF3E7B72),
    textMuted: Color(0xFF87BDB5),
    primaryRed: Color(0xFFE53935),
    accentBlue: Color(0xFF00897B),
    accentGreen: Color(0xFF2E7D32),
    accentAmber: Color(0xFFF9A825),
  );

  // ── NORD ──
  static const nord = AppPalette(
    id: 'nord',
    label: 'Nord',
    emoji: '🧊',
    brightness: Brightness.dark,
    bg: Color(0xFF2E3440),
    bgSoft: Color(0xFF3B4252),
    cardBg: Color(0xFF434C5E),
    border: Color(0xFF88C0D0),
    textMain: Color(0xFFECEFF4),
    textSub: Color(0xFFD8DEE9),
    textMuted: Color(0xFF7A8699),
    primaryRed: Color(0xFFBF616A),
    accentBlue: Color(0xFF81A1C1),
    accentGreen: Color(0xFFA3BE8C),
    accentAmber: Color(0xFFEBCB8B),
  );

  // ── COFFEE ──
  static const coffee = AppPalette(
    id: 'coffee',
    label: 'Coffee',
    emoji: '☕',
    brightness: Brightness.light,
    bg: Color(0xFFEFE7DD),
    bgSoft: Color(0xFFF7F1E8),
    cardBg: Color(0xFFFFFBF5),
    border: Color(0xFF3E2723),
    textMain: Color(0xFF3E2723),
    textSub: Color(0xFF6D4C41),
    textMuted: Color(0xFFA1887F),
    primaryRed: Color(0xFFBF360C),
    accentBlue: Color(0xFF5D4037),
    accentGreen: Color(0xFF558B2F),
    accentAmber: Color(0xFFEF6C00),
  );

  // ── OCEAN ──
  static const ocean = AppPalette(
    id: 'ocean',
    label: 'Deep Ocean',
    emoji: '🌊',
    brightness: Brightness.dark,
    bg: Color(0xFF001F3F),
    bgSoft: Color(0xFF002A52),
    cardBg: Color(0xFF003666),
    border: Color(0xFF64FFDA),
    textMain: Color(0xFFE0F7FA),
    textSub: Color(0xFF80DEEA),
    textMuted: Color(0xFF4A8FA8),
    primaryRed: Color(0xFFFF5252),
    accentBlue: Color(0xFF18FFFF),
    accentGreen: Color(0xFF69F0AE),
    accentAmber: Color(0xFFFFD740),
  );

  static const List<AppPalette> all = [
    ice,
    dark,
    toon,
    sunset,
    forest,
    mint,
    sakura,
    coffee,
    cyber,
    neon,
    blood,
    royal,
    ocean,
    nord,
    mono,
  ];
}

// ══════════════════════════════════════════════════════════════
//  CONTROLLER
// ══════════════════════════════════════════════════════════════
class ThemeController extends ChangeNotifier {
  AppPalette _palette = AppPalette.ice;
  AppPalette get palette => _palette;

  void setPalette(AppPalette p) {
    if (p.id == _palette.id) return;
    _palette = p;
    notifyListeners();
  }

  void next() {
    final i = AppPalette.all.indexWhere((p) => p.id == _palette.id);
    setPalette(AppPalette.all[(i + 1) % AppPalette.all.length]);
  }
}

// ══════════════════════════════════════════════════════════════
//  SCOPE
// ══════════════════════════════════════════════════════════════
class PaletteScope extends InheritedWidget {
  final AppPalette palette;
  const PaletteScope({
    super.key,
    required this.palette,
    required super.child,
  });

  static AppPalette of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<PaletteScope>();
    assert(scope != null, 'PaletteScope tidak ditemukan di atas context ini!');
    return scope!.palette;
  }

  @override
  bool updateShouldNotify(PaletteScope oldWidget) =>
      oldWidget.palette.id != palette.id;
}

// ══════════════════════════════════════════════════════════════
//  APP THEME — accessor + utility
// ══════════════════════════════════════════════════════════════
class AppTheme {
  static final ThemeController controller = ThemeController();

  static const String font = 'Rajdhani';

  static AppPalette get p => controller.palette;

  static bool get isToon => p.id == 'toon';

  static Color get bg          => p.bg;
  static Color get bgSoft      => p.bgSoft;
  static Color get cardBg      => p.cardBg;
  static Color get border      => p.border;
  static Color get textMain    => p.textMain;
  static Color get textSub     => p.textSub;
  static Color get textMuted   => p.textMuted;
  static Color get primaryRed  => p.primaryRed;
  static Color get accentBlue  => p.accentBlue;
  static Color get accentGreen => p.accentGreen;
  static Color get accentAmber => p.accentAmber;

  static Color get card         => cardBg;
  static Color get surface      => cardBg;
  static Color get surface2     => bgSoft;
  static Color get primary      => accentBlue;
  static Color get primaryLight => accentBlue.withOpacity(0.7);
  static Color get primaryDark  => accentBlue.withOpacity(0.8);
  static Color get primarySoft  => bgSoft;
  static Color get textPrimary  => textMain;
  static Color get textSec      => textSub;
  static Color get error        => primaryRed;
  static Color get warning      => accentAmber;
  static Color get success      => accentGreen;

  static List<BoxShadow> get hardShadowSm => [
    BoxShadow(color: border, offset: Offset(isToon ? 3 : 2, isToon ? 3 : 2)),
  ];
  static List<BoxShadow> get hardShadowMd => [
    BoxShadow(color: border, offset: Offset(isToon ? 4 : 3, isToon ? 4 : 3)),
  ];
  static List<BoxShadow> get hardShadowLg => [
    BoxShadow(color: border, offset: Offset(isToon ? 5 : 4, isToon ? 5 : 4)),
  ];

  static List<BoxShadow> get cardShadow     => hardShadowLg;
  static List<BoxShadow> get softShadow     => hardShadowSm;
  static List<BoxShadow> get elevatedShadow => hardShadowLg;

  static LinearGradient get primaryGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accentBlue, accentBlue.withOpacity(0.75)],
  );
  static LinearGradient get headerGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accentBlue, accentBlue.withOpacity(0.55)],
  );
  static LinearGradient get softBlueGradient => LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [bgSoft, bg],
  );

  static TextStyle display({double size = 22, Color? color}) => TextStyle(
    fontFamily: font,
    fontSize: size,
    fontWeight: FontWeight.w800,
    color: color ?? textMain,
    letterSpacing: isToon ? 1.0 : 0.5,
  );

  static TextStyle heading({double size = 18, Color? color}) => TextStyle(
    fontFamily: font,
    fontSize: size,
    fontWeight: FontWeight.w700,
    color: color ?? textMain,
    letterSpacing: isToon ? 0.8 : 0.3,
  );

  static TextStyle body({
    double size = 12.5,
    Color? color,
    double height = 1.55,
    FontWeight weight = FontWeight.w500,
    double spacing = 0.2,
  }) => TextStyle(
    fontFamily: font,
    fontSize: size,
    fontWeight: weight,
    color: color ?? textSub,
    height: height,
    letterSpacing: spacing,
  );

  static TextStyle label({double size = 11, Color? color, double spacing = 1.2}) =>
      TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w700,
        color: color ?? textMain,
        letterSpacing: spacing,
      );

  static BoxDecoration cardDecoration({
    Color? color,
    double radius = 18,
    double borderWidth = 2.5,
    List<BoxShadow>? shadow,
  }) => BoxDecoration(
    color: color ?? cardBg,
    borderRadius: BorderRadius.circular(isToon ? radius * 0.7 : radius),
    border: Border.all(
      color: border,
      width: isToon ? borderWidth + 0.5 : borderWidth,
    ),
    boxShadow: shadow ?? hardShadowLg,
  );

  static BoxDecoration pillDecoration(Color accent, {double borderWidth = 1.5}) =>
      BoxDecoration(
        color: accent.withOpacity(isToon ? 0.08 : 0.12),
        borderRadius: BorderRadius.circular(isToon ? 8 : 20),
        border: Border.all(
          color: accent,
          width: isToon ? borderWidth + 0.5 : borderWidth,
        ),
      );

  static ThemeData themeData(AppPalette palette) {
    return ThemeData(
      brightness: palette.brightness,
      scaffoldBackgroundColor: palette.bg,
      fontFamily: font,
      colorScheme: ColorScheme.fromSeed(
        seedColor: palette.accentBlue,
        brightness: palette.brightness,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: palette.bgSoft,
        foregroundColor: palette.textMain,
        elevation: 0,
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  BRUTAL CARD
// ══════════════════════════════════════════════════════════════
class BrutalCard extends StatelessWidget {
  final Widget child;
  final Color? color;
  final double radius;
  final EdgeInsets padding;

  const BrutalCard({
    super.key,
    required this.child,
    this.color,
    this.radius = 18,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: AppTheme.cardDecoration(
        color: color ?? c.cardBg,
        radius: radius,
      ),
      child: child,
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  BRUTAL BUTTON
// ══════════════════════════════════════════════════════════════
class BrutalButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final Color? bgColor;
  final Color? textColor;
  final VoidCallback onTap;
  final double height;

  const BrutalButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.bgColor,
    this.textColor,
    this.height = 54,
  });

  @override
  State<BrutalButton> createState() => _BrutalButtonState();
}

class _BrutalButtonState extends State<BrutalButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    final bg = widget.bgColor ?? c.accentBlue;
    final fg = widget.textColor ?? Colors.white;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        width: double.infinity,
        height: widget.height,
        transform: _pressed
            ? (Matrix4.identity()..translate(2.0, 2.0))
            : Matrix4.identity(),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: c.border,
            width: AppTheme.isToon ? 3 : 2.5,
          ),
          boxShadow: _pressed
              ? [BoxShadow(color: c.border, offset: const Offset(1, 1))]
              : AppTheme.hardShadowMd,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (widget.icon != null) ...[
              Icon(widget.icon, color: fg, size: 20),
              const SizedBox(width: 10),
            ],
            Text(
              widget.label,
              style: TextStyle(
                color: fg,
                fontSize: 13.5,
                fontWeight: FontWeight.bold,
                fontFamily: AppTheme.font,
                letterSpacing: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  TOUCH EFFECT (stc.png)
// ══════════════════════════════════════════════════════════════
class TouchEffect extends StatefulWidget {
  final Widget child;
  final String imagePath;
  final double size;
  final Duration duration;

  const TouchEffect({
    super.key,
    required this.child,
    this.imagePath = 'assets/stc.png',
    this.size = 80,
    this.duration = const Duration(milliseconds: 600),
  });

  @override
  State<TouchEffect> createState() => _TouchEffectState();
}

class _TouchEffectState extends State<TouchEffect> {
  final List<_TouchRipple> _ripples = [];

  void _addRipple(Offset globalPos) {
    final id = DateTime.now().microsecondsSinceEpoch;
    setState(() {
      _ripples.add(_TouchRipple(id: id, position: globalPos));
    });
    Future.delayed(widget.duration, () {
      if (mounted) {
        setState(() {
          _ripples.removeWhere((r) => r.id == id);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (event) => _addRipple(event.position),
      child: Stack(
        children: [
          widget.child,
          ..._ripples.map((r) {
            return Positioned(
              left: r.position.dx - widget.size / 2,
              top: r.position.dy - widget.size / 2,
              child: _TouchRippleWidget(
                key: ValueKey(r.id),
                size: widget.size,
                duration: widget.duration,
                imagePath: widget.imagePath,
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _TouchRipple {
  final int id;
  final Offset position;
  _TouchRipple({required this.id, required this.position});
}

class _TouchRippleWidget extends StatefulWidget {
  final double size;
  final Duration duration;
  final String imagePath;

  const _TouchRippleWidget({
    super.key,
    required this.size,
    required this.duration,
    required this.imagePath,
  });

  @override
  State<_TouchRippleWidget> createState() => _TouchRippleWidgetState();
}

class _TouchRippleWidgetState extends State<_TouchRippleWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  late final Animation<double> _opacity;
  late final Animation<double> _rotate;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: widget.duration);

    _scale = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.15, end: 1.35)
            .chain(CurveTween(curve: Curves.easeOutBack)),
        weight: 55,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.35, end: 1.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 45,
      ),
    ]).animate(_ctrl);

    _opacity = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.0, end: 1.0)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 0.0)
            .chain(CurveTween(curve: Curves.easeIn)),
        weight: 80,
      ),
    ]).animate(_ctrl);

    _rotate = Tween<double>(begin: -0.15, end: 0.25).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );

    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Opacity(
          opacity: _opacity.value.clamp(0.0, 1.0),
          child: Transform.rotate(
            angle: _rotate.value,
            child: Transform.scale(
              scale: _scale.value,
              child: Image.asset(
                widget.imagePath,
                width: widget.size,
                height: widget.size,
                fit: BoxFit.contain,
                errorBuilder: (_, error, __) {
                  debugPrint('TouchEffect: gagal load "${widget.imagePath}" → $error');
                  return Container(
                    width: widget.size,
                    height: widget.size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.purpleAccent.withOpacity(0.5),
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  🎨 THEME PICKER PAGE
//  Pilih tema dengan preview dulu — baru di-apply saat klik tombol.
// ══════════════════════════════════════════════════════════════
class ThemePickerPage extends StatefulWidget {
  const ThemePickerPage({super.key});

  @override
  State<ThemePickerPage> createState() => _ThemePickerPageState();
}

class _ThemePickerPageState extends State<ThemePickerPage> {
  /// Palet yang sedang di-PREVIEW (belum diapply ke seluruh app)
  late AppPalette _selected;

  @override
  void initState() {
    super.initState();
    // Preview mulai dari palet aktif sekarang
    _selected = AppTheme.controller.palette;
  }

  bool get _hasChanged =>
      _selected.id != AppTheme.controller.palette.id;

  void _apply() {
    AppTheme.controller.setPalette(_selected);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Text(
              'Tema "${_selected.label}" diterapkan',
              style: const TextStyle(fontFamily: 'Rajdhani'),
            ),
          ],
        ),
        backgroundColor: _selected.accentGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    // Preview pakai palet yang sedang dipilih, bukan palet global
    final c = _selected;

    return Theme(
      data: ThemeData(
        brightness: c.brightness,
        scaffoldBackgroundColor: c.bg,
        fontFamily: 'Rajdhani',
      ),
      child: Scaffold(
        backgroundColor: c.bg,
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [c.bgSoft, c.bg],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                // ── HEADER ──
                _buildHeader(c),

                // ── PREVIEW CARD ──
                _buildPreviewCard(c),

                // ── GRID PALETTE ──
                Expanded(
                  child: GridView.builder(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.78,
                    ),
                    itemCount: AppPalette.all.length,
                    itemBuilder: (context, i) {
                      final p = AppPalette.all[i];
                      final isSelected = p.id == _selected.id;
                      return _paletteCard(p, isSelected);
                    },
                  ),
                ),

                // ── ACTION BAR ──
                _buildActionBar(c),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── HEADER ──
  Widget _buildHeader(AppPalette c) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: c.cardBg,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: c.border, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: c.border,
                    offset: const Offset(2, 3),
                  ),
                ],
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: c.accentBlue, size: 18),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'PILIH ',
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: c.textMain,
                      letterSpacing: 1.2,
                    ),
                  ),
                  TextSpan(
                    text: 'TEMA',
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: c.accentBlue,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: c.cardBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.border, width: 1.5),
            ),
            child: Text(
              '${AppPalette.all.length} TEMA',
              style: TextStyle(
                fontFamily: 'Rajdhani',
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
                color: c.textSub,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── PREVIEW CARD (mock UI pakai palet yang dipilih) ──
  Widget _buildPreviewCard(AppPalette c) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border, width: 2),
        boxShadow: [
          BoxShadow(color: c.border, offset: const Offset(3, 4)),
        ],
      ),
      child: Row(
        children: [
          // Icon kolom
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: c.accentBlue.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: c.border, width: 2),
            ),
            child: Center(
              child: Text(
                c.emoji,
                style: const TextStyle(fontSize: 26),
              ),
            ),
          ),
          const SizedBox(width: 14),
          // Info kolom
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  c.label,
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: c.textMain,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _colorDot(c.bg),
                    const SizedBox(width: 4),
                    _colorDot(c.cardBg),
                    const SizedBox(width: 4),
                    _colorDot(c.accentBlue),
                    const SizedBox(width: 4),
                    _colorDot(c.accentGreen),
                    const SizedBox(width: 4),
                    _colorDot(c.primaryRed),
                    const SizedBox(width: 4),
                    _colorDot(c.accentAmber),
                  ],
                ),
                const SizedBox(height: 8),
                // Mock button
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: c.accentBlue,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: c.border, width: 1.5),
                  ),
                  child: Text(
                    'PREVIEW',
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _colorDot(Color color) {
    return Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: _selected.border, width: 1.5),
      ),
    );
  }

  // ── PALETTE CARD (grid item) ──
  Widget _paletteCard(AppPalette p, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() => _selected = p);
        // Haptic saat pilih tema
        Feedback.forTap(context);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          color: p.bgSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? p.accentBlue : p.border,
            width: isSelected ? 3 : 1.8,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: p.accentBlue.withOpacity(0.35),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ]
              : [
                  BoxShadow(
                    color: p.border.withOpacity(0.35),
                    offset: const Offset(2, 3),
                  ),
                ],
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Preview window kecil
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: p.bg,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: p.border, width: 1.2),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // mini card
                            Container(
                              height: 12,
                              decoration: BoxDecoration(
                                color: p.cardBg,
                                borderRadius: BorderRadius.circular(4),
                                border:
                                    Border.all(color: p.border, width: 1),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              height: 6,
                              width: 30,
                              decoration: BoxDecoration(
                                color: p.accentBlue,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                            const SizedBox(height: 3),
                            Container(
                              height: 6,
                              width: 20,
                              decoration: BoxDecoration(
                                color: p.accentGreen,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                            const Spacer(),
                            Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    color: p.primaryRed,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 3),
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    color: p.accentAmber,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  // Label
                  Text(
                    '${p.emoji}  ${p.label}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                      color: p.textMain,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),

            // Checkmark kalau selected
            if (isSelected)
              Positioned(
                top: 4,
                right: 4,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: p.accentBlue,
                    shape: BoxShape.circle,
                    border: Border.all(color: p.border, width: 1.5),
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: Colors.white, size: 14),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── ACTION BAR ──
  Widget _buildActionBar(AppPalette c) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: BoxDecoration(
        color: c.bgSoft,
        border: Border(
          top: BorderSide(color: c.border, width: 2),
        ),
      ),
      child: Row(
        children: [
          // Batal
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                height: 52,
                decoration: BoxDecoration(
                  color: c.cardBg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: c.border, width: 2),
                  boxShadow: [
                    BoxShadow(color: c.border, offset: const Offset(2, 3)),
                  ],
                ),
                child: Center(
                  child: Text(
                    'BATAL',
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5,
                      color: c.textMain,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Apply
          Expanded(
            flex: 2,
            child: GestureDetector(
              onTap: _hasChanged ? _apply : null,
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: _hasChanged ? 1.0 : 0.5,
                child: Container(
                  height: 52,
                  decoration: BoxDecoration(
                    color: _hasChanged ? c.accentBlue : c.textMuted,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: c.border, width: 2),
                    boxShadow: _hasChanged
                        ? [
                            BoxShadow(
                              color: c.border,
                              offset: const Offset(3, 4),
                            ),
                          ]
                        : [],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _hasChanged
                            ? Icons.palette_rounded
                            : Icons.check_circle_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _hasChanged ? 'TERAPKAN TEMA' : 'TEMA AKTIF',
                        style: const TextStyle(
                          fontFamily: 'Rajdhani',
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}