// BY toweng.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';
import 'wave_bottom_nav.dart';
import 'public_chat_page.dart';
import 'dorax_am_premium_page.dart'; // ✅ Tambahan baru
import 'maintenance_page.dart';
import 'game_area.dart';
import 'nik_check.dart';
import 'home_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'seller_page.dart';
import 'high_admin_page.dart';
import 'moderator_page.dart';
import 'tangan_kanan_page.dart';
import 'developer_page.dart';
import 'vip_page.dart';
import 'partner_page.dart';
import '.dart';

// ===================== ACTION DATA MODEL =====================
class _ActionData {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionData({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

// ===================== DASHBOARD PAGE =====================
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGlobal; // ← TAMBAHAN
  final List<Map<String, dynamic>> listBugGroup;  // ← TAMBAHAN
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    this.listBugGlobal = const [], // ← TAMBAHAN (opsional)
    this.listBugGroup = const [],  // ← TAMBAHAN (opsional)
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late Animation<double> _fadeAnim;
  late Animation<double> _pulseAnim;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  int? _sidebarTabIndex;

  int onlineUsers = 0;
  int activeConnections = 0;

  final Battery _battery = Battery();
  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;
  String _cpuInfo = 'Unknown';
  int _cpuCores = 0;

  Map<String, String> _prayerTimes = {};
  bool _prayerLoading = true;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeController = AnimationController(
        duration: const Duration(milliseconds: 600), vsync: this);
    _pulseController = AnimationController(
        duration: const Duration(seconds: 2), vsync: this)
      ..repeat(reverse: true);

    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
        CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    _fadeController.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _initDeviceInfo();
    _fetchPrayerTimes();
  }

  Future<void> _fetchPrayerTimes() async {
    try {
      final today = DateTime.now();
      final dateStr =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final res = await http.get(Uri.parse(
        'https://api.myquran.com/v2/sholat/jadwal/1301/$dateStr',
      ));
      final data = jsonDecode(res.body);
      final j = data['data']['jadwal'];
      if (mounted) {
        setState(() {
          _prayerTimes = {
            'Subuh': j['subuh'] ?? '-',
            'Dzuhur': j['dzuhur'] ?? '-',
            'Ashar': j['ashar'] ?? '-',
            'Maghrib': j['maghrib'] ?? '-',
            'Isya': j['isya'] ?? '-',
          };
          _prayerLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _prayerLoading = false);
    }
  }

  Future<void> _initDeviceInfo() async {
    try {
      _batteryLevel = await _battery.batteryLevel;
      _battery.onBatteryStateChanged.listen((state) {
        if (mounted) setState(() => _batteryState = state);
      });
      Future.doWhile(() async {
        await Future.delayed(const Duration(seconds: 15));
        if (!mounted) return false;
        final lvl = await _battery.batteryLevel;
        setState(() => _batteryLevel = lvl);
        return true;
      });
    } catch (_) {}

    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      setState(() {
        _cpuCores = Platform.numberOfProcessors;
        _cpuInfo = deviceInfo.supportedAbis.isNotEmpty
            ? deviceInfo.supportedAbis.first
            : 'Unknown';
      });
    } catch (_) {
      setState(() => _cpuCores = Platform.numberOfProcessors);
    }
    if (mounted) setState(() {});
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('$apiBaseUrl'));
    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        if (reason == 'androidIdMismatch') {
          _handleInvalidSession('Your account is logged in on another device.');
        } else if (reason == 'keyInvalid') {
          _handleInvalidSession('Session expired. Please log in again.');
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildAlertDialog(
        title: 'Session Expired',
        content: message,
        onConfirm: () {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (r) => false,
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ══════════════════════════════════════════════════════════════
  Widget _buildAlertDialog({
    required String title,
    required String content,
    required VoidCallback onConfirm,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Builder(builder: (dialogContext) {
        final c = PaletteScope.of(dialogContext);
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: c.cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: c.border, width: 2),
            boxShadow: AppTheme.hardShadowLg,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: c.primaryRed.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: c.primaryRed, width: 1.5),
                ),
                child: Icon(Icons.warning_amber_rounded,
                    color: c.primaryRed, size: 26),
              ),
              const SizedBox(height: 16),
              Text(title, style: AppTheme.heading(size: 18, color: c.textMain)),
              const SizedBox(height: 8),
              Text(content,
                  style: AppTheme.body(size: 14, color: c.textSub),
                  textAlign: TextAlign.center),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: _GlowButton(label: 'OK', onTap: onConfirm),
              ),
            ],
          ),
        );
      }),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  NAV
  // ══════════════════════════════════════════════════════════════
  void _onBottomNavTapped(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      _bottomNavIndex = index;
      _sidebarTabIndex = null;
      _fadeController.reset();
      _fadeController.forward();
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      _sidebarTabIndex = index;
      _fadeController.reset();
      _fadeController.forward();
    });
    Navigator.pop(context);
  }

  Widget _resolveCurrentPage(BuildContext context) {
    if (_sidebarTabIndex != null) {
      switch (_sidebarTabIndex) {
        case 1:
          return SellerPage(keyToken: sessionKey);
        case 2:
          return AdminPage(sessionKey: sessionKey);
        case 3:
          return OwnerPage(sessionKey: sessionKey, username: username);
        case 4:
          return DeveloperPage(keyToken: sessionKey);
        case 5:
          return HighAdminPage(keyToken: sessionKey);
        case 6:
          return ModeratorPage(keyToken: sessionKey);
        case 7:
          return TanganKananPage(keyToken: sessionKey);
        case 8:
          return VipPage(keyToken: sessionKey);
        case 9:
          return PartnerPage(keyToken: sessionKey);
      }
    }
    switch (_bottomNavIndex) {
      case 0:
        return _buildHomePage(context);
      case 1:
        return HomePage(
          username: username,
          password: password,
          listBug: listBug,
          listBugGlobal: widget.listBugGlobal, // ← TAMBAHAN
          listBugGroup: widget.listBugGroup,   // ← TAMBAHAN
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      case 2:
        return const GameAreaPage();
      case 3:
        return ToolsPage(
          sessionKey: sessionKey,
          username: username,
          userRole: role,
          listDoos: listDoos,
        );
    }
    return _buildHomePage(context);
  }

  // ══════════════════════════════════════════════════════════════
  //  HOME PAGE
  // ══════════════════════════════════════════════════════════════
  Widget _buildHomePage(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            _buildHeroCard(context),
            const SizedBox(height: 20),
            _buildDeviceInfoGrid(context),
            const SizedBox(height: 28),
            _buildSectionHeader(
                context, 'Latest Updates', '${newsList.length} articles'),
            const SizedBox(height: 12),
            _buildNewsSlider(context),
            const SizedBox(height: 20),
            _buildPrayerCard(context),
            const SizedBox(height: 16),
            _buildJoinCommunityButton(context),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroCard(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: c.cardBg,
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color:
                            c.accentBlue.withOpacity(_pulseAnim.value * 0.4),
                        blurRadius: 16,
                        spreadRadius: 1,
                      ),
                    ],
                    border: Border.all(color: c.border, width: 2),
                  ),
                  child: ClipOval(
                    child: _profileImage != null
                        ? Image.file(_profileImage!, fit: BoxFit.cover)
                        : Image.asset('assets/images/logo.png',
                            fit: BoxFit.cover),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Welcome back,',
                        style: AppTheme.body(size: 12, color: c.textSub)),
                    Text(
                      username,
                      style: AppTheme.display(size: 18, color: c.accentBlue),
                    ),
                  ],
                ),
              ),
              _RoleBadge(role: role),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                c.accentBlue.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Icon(Icons.calendar_today_rounded, color: c.textSub, size: 14),
              const SizedBox(width: 6),
              Text('Exp: $expiredDate',
                  style: AppTheme.body(size: 12, color: c.textSub)),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: c.accentBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: c.accentBlue.withOpacity(0.4)),
                ),
                child: Text(
                  '◈ DØRAXLAVEGAS',
                  style: TextStyle(
                    fontFamily: AppTheme.font,
                    fontSize: 9,
                    color: c.accentBlue,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceInfoGrid(BuildContext context) {
    final c = PaletteScope.of(context);
    final isCharging = _batteryState == BatteryState.charging;
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.7,
      children: [
        _InfoTile(
          icon: Icons.memory_rounded,
          label: 'CPU',
          value: _cpuCores > 0 ? '$_cpuCores Cores' : 'Loading...',
          sub: _cpuInfo,
          color: c.accentBlue,
        ),
        _InfoTile(
          icon: isCharging
              ? Icons.battery_charging_full_rounded
              : Icons.battery_std_rounded,
          label: 'Battery',
          value: '$_batteryLevel%',
          sub: isCharging ? 'Charging' : 'Not Charging',
          color: _batteryLevel <= 20 ? c.primaryRed : c.accentGreen,
        ),
        _InfoTile(
          icon: Icons.send_rounded,
          label: 'Sender',
          value: role == 'owner' || role == 'admin' ? 'Available' : 'Private',
          sub: 'Manage Devices',
          color: c.accentBlue,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          ),
        ),
        _InfoTile(
          icon: Icons.workspace_premium_rounded,
          label: 'Role',
          value: role.toUpperCase(),
          sub: 'Exp: $expiredDate',
          color: c.accentAmber,
        ),
      ],
    );
  }

  Widget _buildSectionHeader(
      BuildContext context, String title, String? trailing) {
    final c = PaletteScope.of(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 3,
              height: 20,
              decoration: BoxDecoration(
                color: c.accentBlue,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(width: 10),
            Text(title, style: AppTheme.heading(size: 16, color: c.textMain)),
          ],
        ),
        if (trailing != null)
          Text(trailing, style: AppTheme.body(size: 12, color: c.textSub)),
      ],
    );
  }

  Widget _buildNewsSlider(BuildContext context) {
    final c = PaletteScope.of(context);
    if (newsList.isEmpty) {
      return Container(
        height: 160,
        decoration: BoxDecoration(
          color: c.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: c.border, width: 2),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.newspaper_rounded, color: c.textMuted, size: 36),
              const SizedBox(height: 8),
              Text('No updates yet',
                  style: AppTheme.body(size: 13, color: c.textSub)),
            ],
          ),
        ),
      );
    }

    return SizedBox(
      height: 210,
      child: PageView.builder(
        controller: PageController(viewportFraction: 0.92),
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          final item = newsList[index];
          return Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: c.cardBg,
              border: Border.all(color: c.border, width: 2),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (item['image'] != null &&
                    item['image'].toString().isNotEmpty)
                  NewsMedia(url: item['image']),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.75),
                        Colors.transparent,
                      ],
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: c.accentBlue,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: c.border, width: 1.5),
                    ),
                    child: const Text(
                      'UPDATE',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 8,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.85),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: c.border, width: 1.5),
                    ),
                    child: Text('${index + 1}/${newsList.length}',
                        style: AppTheme.body(size: 10, color: c.textMain)),
                  ),
                ),
                Positioned(
                  bottom: 16,
                  left: 16,
                  right: 16,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item['title'] ?? 'Untitled',
                          style: AppTheme.heading(size: 15)
                              .copyWith(color: Colors.white),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text(item['desc'] ?? '',
                          style: AppTheme.body(size: 11)
                              .copyWith(color: Colors.white70),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildPrayerCard(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: c.accentBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: c.accentBlue, width: 1.3),
                ),
                child:
                    Icon(Icons.mosque_rounded, color: c.accentBlue, size: 18),
              ),
              const SizedBox(width: 10),
              Text('Jadwal Sholat',
                  style: AppTheme.heading(size: 15, color: c.textMain)),
            ],
          ),
          const SizedBox(height: 14),
          _prayerLoading
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: CircularProgressIndicator(
                        color: c.accentBlue, strokeWidth: 2),
                  ),
                )
              : _prayerTimes.isEmpty
                  ? Center(
                      child: Text('Gagal memuat jadwal sholat',
                          style: AppTheme.body(size: 12, color: c.textSub)),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: _prayerTimes.entries
                          .map((e) => Column(
                                children: [
                                  Text(e.key,
                                      style: AppTheme.body(
                                          size: 10, color: c.textSub)),
                                  const SizedBox(height: 4),
                                  Text(
                                    e.value,
                                    style: AppTheme.heading(
                                        size: 13, color: c.accentBlue),
                                  ),
                                ],
                              ))
                          .toList(),
                    ),
        ],
      ),
    );
  }

  Widget _buildJoinCommunityButton(BuildContext context) {
    final c = PaletteScope.of(context);
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _openUrl('https://t.me/verlyxcore');
      },
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: c.primaryRed,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowMd,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.telegram_rounded, color: Colors.white, size: 22),
            const SizedBox(width: 10),
            Text(
              'JOIN COMMUNITY',
              style: TextStyle(
                color: Colors.white,
                fontFamily: AppTheme.font,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  QUICK ACTIONS
  // ══════════════════════════════════════════════════════════════
  List<_ActionData> _actions(BuildContext context) {
    final c = PaletteScope.of(context);
    return [
      _ActionData(
        icon: Icons.forum_rounded,
        iconColor: c.accentBlue,
        title: 'Public Chat',
        subtitle: 'Live Chat Global',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PublicChatPage(username: username),
          ),
        ),
      ),
      _ActionData(
        icon: Icons.telegram_rounded,
        iconColor: const Color(0xFF29B6F6),
        title: 'Telegram',
        subtitle: 'Join Channel',
        onTap: () => _openUrl('https://t.me/verlyxcore'),
      ),
      _ActionData(
        icon: Icons.phone_android_rounded,
        iconColor: c.accentBlue,
        title: 'Sender',
        subtitle: 'Manage Devices',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ),
        ),
      ),
      _ActionData(
        icon: Icons.history_rounded,
        iconColor: c.accentBlue,
        title: 'History',
        subtitle: 'Activity Log',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role),
          ),
        ),
      ),
      _ActionData(
        icon: Icons.shopping_bag_rounded,
        iconColor: c.accentAmber,
        title: 'Shop',
        subtitle: 'Buy Items',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const TokoPage()),
        ),
      ),
      _ActionData(
        icon: Icons.headset_mic_rounded,
        iconColor: const Color(0xFF25D366),
        title: 'Contact',
        subtitle: 'Get Help',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ContactPage()),
        ),
      ),
    ];
  }

  // ══════════════════════════════════════════════════════════════
  //  DRAWER
  // ══════════════════════════════════════════════════════════════
  Widget _buildDrawer(BuildContext context) {
    final c = PaletteScope.of(context);
    return Drawer(
      backgroundColor: c.bgSoft,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Column(
        children: [
          _buildDrawerHeader(context),
          Expanded(
            child: Container(
              color: c.bgSoft,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 6),
                    child: Text('QUICK ACCESS',
                        style: AppTheme.body(
                            size: 11, color: c.textSub, spacing: 1.5)),
                  ),
                  ..._actions(context).map((a) => _buildDrawerItem(
                        context,
                        icon: a.icon,
                        label: a.title,
                        onTap: () {
                          Navigator.pop(context);
                          a.onTap();
                        },
                      )),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(height: 1.5, color: c.border),
                  ),
                  const SizedBox(height: 12),

                  // ═════════════════════════════════════════════════
                  //  🔥 EXTRA MENU — semua role bisa akses
                  // ═════════════════════════════════════════════════

                  // Ganti Tema
                  _buildDrawerItem(
                    context,
                    icon: Icons.palette_rounded,
                    label: 'Ganti Tema',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ThemePickerPage(),
                        ),
                      );
                    },
                  ),

                  // ✨ DoraxAmPremium — SEMUA ROLE BISA AKSES
                  _buildDrawerItem(
                    context,
                    icon: Icons.auto_awesome_rounded,
                    label: 'DoraxAmPremium',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const DoraxAmPremiumPage(),
                        ),
                      );
                    },
                  ),

                  // 👑 FOUNDER ONLY — Maintenance Mode
                  if (role.toLowerCase() == 'founder')
                    _buildDrawerItem(
                      context,
                      icon: Icons.build_circle_rounded,
                      label: 'Maintenance Mode',
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                MaintenancePage(sessionKey: sessionKey),
                          ),
                        );
                      },
                    ),

                  const SizedBox(height: 4),

                  // ═════════════════════════════════════════════════
                  //  ROLE PANEL
                  // ═════════════════════════════════════════════════
                  if (role == 'reseller')
                    _buildDrawerItem(context,
                        icon: Icons.storefront_rounded,
                        label: 'Seller Panel',
                        onTap: () => _onSidebarTabSelected(1)),
                  if (role == 'admin')
                    _buildDrawerItem(context,
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Panel',
                        onTap: () => _onSidebarTabSelected(2)),
                  if (role == 'owner')
                    _buildDrawerItem(context,
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Panel',
                        onTap: () => _onSidebarTabSelected(3)),
                  if (role == 'developer')
                    _buildDrawerItem(context,
                        icon: Icons.code_rounded,
                        label: 'Developer Panel',
                        onTap: () => _onSidebarTabSelected(4)),
                  if (role == 'highadmin')
                    _buildDrawerItem(context,
                        icon: Icons.security_rounded,
                        label: 'High Admin Panel',
                        onTap: () => _onSidebarTabSelected(5)),
                  if (role == 'moderator')
                    _buildDrawerItem(context,
                        icon: Icons.shield_moon_rounded,
                        label: 'Moderator Panel',
                        onTap: () => _onSidebarTabSelected(6)),
                  if (role == 'tk')
                    _buildDrawerItem(context,
                        icon: Icons.handshake_rounded,
                        label: 'Tangan Kanan Panel',
                        onTap: () => _onSidebarTabSelected(7)),
                  if (role == 'vip')
                    _buildDrawerItem(context,
                        icon: Icons.star_rounded,
                        label: 'VIP Panel',
                        onTap: () => _onSidebarTabSelected(8)),
                  if (role == 'pt')
                    _buildDrawerItem(context,
                        icon: Icons.groups_rounded,
                        label: 'PT Panel',
                        onTap: () => _onSidebarTabSelected(9)),

                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(height: 1.5, color: c.border),
                  ),
                  const SizedBox(height: 12),
                  _buildDrawerItem(
                    context,
                    icon: Icons.logout_rounded,
                    label: 'Log Out',
                    isDestructive: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (r) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          Container(
            color: c.bgSoft,
            padding: const EdgeInsets.all(16),
            child: Text(
              '◈ DØRAXLAVEGAS v2.0',
              style: TextStyle(
                fontFamily: AppTheme.font,
                fontSize: 9,
                color: c.textMuted,
                letterSpacing: 2,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      height: 240,
      color: c.bgSoft,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_menuVideoController != null &&
              _menuVideoController!.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _menuVideoController!.value.size.width,
                height: _menuVideoController!.value.size.height,
                child: VideoPlayer(_menuVideoController!),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.1),
                  c.bgSoft.withOpacity(0.95),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(height: 2, color: c.border),
          ),
          SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color:
                                c.accentBlue.withOpacity(_pulseAnim.value * 0.4),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                        ],
                        border: Border.all(color: c.border, width: 2),
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : Image.asset('assets/images/logo.png',
                                fit: BoxFit.cover),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(username,
                      style: AppTheme.heading(size: 18, color: c.textMain)),
                  const SizedBox(height: 6),
                  _RoleBadge(role: role),
                  const SizedBox(height: 6),
                  Text('Exp: $expiredDate',
                      style: AppTheme.body(size: 11, color: c.textSub)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final c = PaletteScope.of(context);
    final color = isDestructive ? c.primaryRed : c.accentBlue;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.border, width: 1.5),
      ),
      child: ListTile(
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        title: Text(
          label,
          style: AppTheme.heading(
              size: 14, color: isDestructive ? c.primaryRed : c.textMain),
        ),
        trailing:
            Icon(Icons.arrow_forward_ios_rounded, color: c.textMuted, size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(context),
      drawer: _buildDrawer(context),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: _resolveCurrentPage(context),
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(context),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    final c = PaletteScope.of(context);
    return AppBar(
      backgroundColor: c.bgSoft.withOpacity(0.95),
      elevation: 0,
      iconTheme: IconThemeData(color: c.textMain),
      flexibleSpace: ClipRect(
        child: Container(
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: c.border, width: 2)),
          ),
        ),
      ),
      title: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: c.border, width: 1.5),
            ),
            child: ClipOval(
              child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'DØRAXLAVEGAS',
                style: TextStyle(
                  fontFamily: AppTheme.font,
                  fontSize: 13,
                  color: c.accentBlue,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text('Dashboard',
                  style: AppTheme.body(size: 10, color: c.textSub)),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.headset_mic_outlined, size: 20),
          color: c.textSub,
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const ContactPage())),
        ),
        IconButton(
          icon: const Icon(Icons.person_outline_rounded, size: 20),
          color: c.textSub,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProfilePage(
                username: username,
                password: password,
                role: role,
                expiredDate: expiredDate,
                sessionKey: sessionKey,
              ),
            ),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  BOTTOM NAV
  // ══════════════════════════════════════════════════════════════
  Widget _buildBottomNav(BuildContext context) {
    final c = PaletteScope.of(context);
    return WaveBottomNav(
      selectedIndex: _sidebarTabIndex == null ? _bottomNavIndex : 0,
      onTap: _onBottomNavTapped,
      barBackgroundImage: 'assets/bgnav.jpg',
      barFallbackColor: c.accentBlue,
      backgroundColor: c.bg,
      inactiveIconColor: Colors.white,
      items: const [
        WaveNavItem(icon: Icons.space_dashboard_rounded), // Home
        WaveNavItem(icon: Icons.bug_report_rounded),      // Whatsapp
        WaveNavItem(icon: Icons.sports_esports_rounded),  // Game
        WaveNavItem(icon: Icons.tune_rounded),            // Tools
      ],
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _fadeController.dispose();
    _pulseController.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

// ===================== REUSABLE COMPONENTS =====================

class _RoleBadge extends StatelessWidget {
  final String role;
  const _RoleBadge({required this.role});

  Color _color(BuildContext context) {
    final c = PaletteScope.of(context);
    switch (role.toLowerCase()) {
      case 'founder':
        return const Color(0xFFD4AF37); // gold
      case 'owner':
        return c.accentAmber;
      case 'developer':
        return const Color(0xFF7C3AED);
      case 'highadmin':
      case 'admin':
        return c.primaryRed;
      case 'moderator':
        return c.accentBlue;
      case 'tk':
        return const Color(0xFFDB2777);
      case 'pt':
      case 'partner':
        return const Color(0xFF14B8A6);
      case 'reseller':
        return c.accentGreen;
      case 'vip':
        return c.accentBlue;
      default:
        return c.accentBlue;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _color(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color, width: 1.5),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          fontFamily: AppTheme.font,
          fontSize: 9,
          color: color,
          letterSpacing: 1.5,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String sub;
  final Color color;
  final VoidCallback? onTap;
  const _InfoTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.sub,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: c.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowSm,
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color, width: 1.3),
              ),
              child: Icon(icon, color: color, size: 17),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(label,
                      style: AppTheme.body(size: 9, color: c.textSub)),
                  Text(value,
                      style: AppTheme.heading(size: 13, color: color),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Text(sub,
                      style: AppTheme.body(size: 8, color: c.textSub),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _GlowButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [c.accentBlue.withOpacity(0.8), c.accentBlue],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowMd,
        ),
        child: Text(
          label,
          style: AppTheme.heading(size: 15, color: Colors.white),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

// ===================== NEWS MEDIA =====================
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return Center(child: CircularProgressIndicator(color: c.accentBlue));
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: c.cardBg,
        child: Icon(Icons.broken_image_rounded, color: c.textMuted),
      ),
    );
  }
}

// ===================== TOKO PAGE =====================
class TokoPage extends StatelessWidget {
  const TokoPage({super.key});

  final List<Map<String, dynamic>> produkList = const [];

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      appBar: AppBar(
        title: Text('Shop', style: AppTheme.heading(size: 18, color: c.textMain)),
        backgroundColor: c.bgSoft,
        elevation: 0,
        iconTheme: IconThemeData(color: c.textMain),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: c.border),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: produkList.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: c.cardBg,
                        shape: BoxShape.circle,
                        border: Border.all(color: c.border, width: 2),
                      ),
                      child: Icon(Icons.shopping_bag_outlined,
                          size: 36, color: c.accentBlue),
                    ),
                    const SizedBox(height: 16),
                    Text('No products yet',
                        style: AppTheme.heading(size: 16, color: c.textMain)),
                    const SizedBox(height: 6),
                    Text('Check back later',
                        style: AppTheme.body(size: 13, color: c.textSub)),
                  ],
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.75,
                ),
                itemCount: produkList.length,
                itemBuilder: (context, index) {
                  final p = produkList[index];
                  return Container(
                    decoration: BoxDecoration(
                      color: c.cardBg,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: c.border, width: 2),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.network(p['gambar'],
                            height: 120,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                                  height: 120,
                                  color: c.cardBg,
                                  child: Icon(
                                      Icons.image_not_supported_rounded,
                                      color: c.textMuted),
                                )),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p['nama'],
                                  style: AppTheme.heading(
                                      size: 13, color: c.textMain),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 3),
                              Text(p['deskripsi'],
                                  style: AppTheme.body(
                                      size: 10, color: c.textSub),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(p['harga'],
                                      style: TextStyle(
                                        fontFamily: AppTheme.font,
                                        fontSize: 13,
                                        color: c.accentBlue,
                                        fontWeight: FontWeight.w700,
                                      )),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: c.accentBlue,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                          color: c.border, width: 1.5),
                                    ),
                                    child: const Text(
                                      'Buy',
                                      style: TextStyle(
                                        fontFamily: 'Rajdhani',
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}