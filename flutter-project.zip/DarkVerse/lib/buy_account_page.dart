// buy_account_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart'; // ✅ Theme global

// ══════════════════════════════════════════════════════════════
//  BUY ACCOUNT PAGE
// ══════════════════════════════════════════════════════════════
class BuyAccountPage extends StatelessWidget {
  const BuyAccountPage({super.key});

  final List<Map<String, String>> priceList = const [
    {
      "title": "Member Account",
      "monthly": "15K IDR / Month",
      "permanent": "25K IDR / Permanent",
      "icon": "person",
    },
    {
      "title": "Reseller Account",
      "monthly": "35K IDR",
      "icon": "storefront",
    },
    {
      "title": "Partner Account",
      "monthly": "45K IDR",
      "icon": "handshake",
    },
    {
      "title": "Mod Account",
      "monthly": "50K IDR",
      "icon": "shield",
    },
    {
      "title": "Owner Account",
      "monthly": "60K IDR",
      "icon": "workspace_premium",
    },
    {
      "title": "Project Account",
      "monthly": "70K IDR",
      "icon": "rocket_launch",
    },
    {
      "title": "High Admin Account",
      "monthly": "80K IDR",
      "icon": "admin_panel_settings",
    },
  ];

  static const Map<String, IconData> _iconMap = {
    "person": Icons.person_rounded,
    "storefront": Icons.storefront_rounded,
    "handshake": Icons.handshake_rounded,
    "shield": Icons.shield_rounded,
    "workspace_premium": Icons.workspace_premium_rounded,
    "rocket_launch": Icons.rocket_launch_rounded,
    "admin_panel_settings": Icons.admin_panel_settings_rounded,
  };

  // ── Dialog QRIS + Dana + Contact ──────────────────────────
  Future<void> _showBuyDialog(
      BuildContext context, String plan, String price) async {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Builder(builder: (dialogContext) {
          final c = PaletteScope.of(dialogContext);
          return Container(
            decoration: BoxDecoration(
              color: c.cardBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: c.border, width: 2),
              boxShadow: AppTheme.hardShadowLg,
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ── Header ──
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'BUY ',
                          style: AppTheme.display(size: 18, color: c.textMain),
                        ),
                        TextSpan(
                          text: plan.toUpperCase(),
                          style: AppTheme.display(size: 18, color: c.accentBlue),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    price,
                    style: AppTheme.body(
                      size: 14,
                      color: c.accentBlue,
                      weight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── QRIS Image ──
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: c.border, width: 2),
                      boxShadow: AppTheme.hardShadowSm,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.network(
                        'https://files.catbox.moe/-.jpg',
                        height: 220,
                        fit: BoxFit.contain,
                        loadingBuilder: (_, child, progress) {
                          if (progress == null) return child;
                          return SizedBox(
                            height: 220,
                            child: Center(
                              child: CircularProgressIndicator(
                                color: c.accentBlue,
                                value: progress.expectedTotalBytes != null
                                    ? progress.cumulativeBytesLoaded /
                                        progress.expectedTotalBytes!
                                    : null,
                              ),
                            ),
                          );
                        },
                        errorBuilder: (_, __, ___) => SizedBox(
                          height: 220,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.qr_code_2_rounded,
                                    color: c.accentBlue, size: 60),
                                const SizedBox(height: 8),
                                Text('QRIS tidak tersedia',
                                    style: AppTheme.body(
                                        size: 12, color: c.textSub)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ── Dana Number ──
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: c.bgSoft,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: c.border, width: 1.5),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: c.accentBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: c.accentBlue.withOpacity(0.4)),
                          ),
                          child: Icon(
                              Icons.account_balance_wallet_rounded,
                              color: c.accentBlue,
                              size: 18),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('DANA',
                                  style: AppTheme.heading(
                                      size: 13, color: c.accentBlue)),
                              Text(
                                '0831-7099-4108',
                                style: AppTheme.display(
                                        size: 15, color: c.textMain)
                                    .copyWith(letterSpacing: 2),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(
                                const ClipboardData(text: '082135863015'));
                            ScaffoldMessenger.of(dialogContext)
                                .showSnackBar(
                              SnackBar(
                                content: Text(
                                  'Nomor disalin!',
                                  style: AppTheme.body(
                                      size: 13, color: Colors.white),
                                ),
                                backgroundColor: c.accentBlue,
                                behavior: SnackBarBehavior.floating,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(
                                      color: c.border, width: 1.5),
                                ),
                                duration: const Duration(seconds: 2),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              color: c.accentBlue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(9),
                              border:
                                  Border.all(color: c.accentBlue, width: 1.2),
                            ),
                            child: Icon(Icons.copy_rounded,
                                color: c.accentBlue, size: 16),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── Divider ──
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 1.5,
                          color: c.border.withOpacity(0.15),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Text(
                          'ATAU HUBUNGI',
                          style: AppTheme.body(size: 9, color: c.textSub)
                              .copyWith(letterSpacing: 2),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 1.5,
                          color: c.border.withOpacity(0.15),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ── Contact Buttons ──
                  Row(
                    children: [
                      Expanded(
                        child: _contactBtn(
                          context: dialogContext,
                          icon: Icons.telegram_rounded,
                          label: 'Telegram',
                          color: const Color(0xFF29B6F6),
                          onTap: () async {
                            Navigator.pop(dialogContext);
                            final uri = Uri.parse(
                                "tg://resolve?domain=towngreal01");
                            if (await canLaunchUrl(uri)) {
                              await launchUrl(uri,
                                  mode: LaunchMode.externalApplication);
                            } else {
                              await launchUrl(
                                  Uri.parse("https://t.me/towngreal01"),
                                  mode: LaunchMode.externalApplication);
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _contactBtn(
                          context: dialogContext,
                          icon: Icons.chat_rounded,
                          label: 'WhatsApp',
                          color: const Color(0xFF25D366),
                          onTap: () async {
                            Navigator.pop(dialogContext);
                            final uri = Uri.parse(
                                "https://wa.me/MashD?text=Halo%20saya%20mau%20beli%20$plan");
                            if (await canLaunchUrl(uri)) {
                              await launchUrl(uri,
                                  mode: LaunchMode.externalApplication);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ── Close ──
                  GestureDetector(
                    onTap: () => Navigator.pop(dialogContext),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 24),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: c.border.withOpacity(0.3), width: 1.2),
                      ),
                      child: Text(
                        'TUTUP',
                        style: AppTheme.body(size: 13, color: c.textSub)
                            .copyWith(letterSpacing: 2),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _contactBtn({
    required BuildContext context,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(label, style: AppTheme.heading(size: 14, color: color)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ── AppBar custom ──
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        HapticFeedback.lightImpact();
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: c.cardBg,
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(color: c.border, width: 2),
                          boxShadow: AppTheme.hardShadowSm,
                        ),
                        child: Icon(Icons.arrow_back_ios_new_rounded,
                            color: c.accentBlue, size: 18),
                      ),
                    ),
                    const SizedBox(width: 14),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'BUY ',
                            style: AppTheme.display(
                                size: 22, color: c.textMain),
                          ),
                          TextSpan(
                            text: 'ACCESS',
                            style: AppTheme.display(
                                size: 22, color: c.accentBlue),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: c.cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: c.border, width: 1.5),
                      ),
                      child: Text(
                        '${priceList.length} PLANS',
                        style: AppTheme.body(
                          size: 10,
                          color: c.textSub,
                          spacing: 1.5,
                          weight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // ── List ──
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 8),
                  itemCount: priceList.length,
                  itemBuilder: (context, index) {
                    final item = priceList[index];
                    return _buildPriceCard(context, c, item, index);
                  },
                ),
              ),

              // ── Footer ──
              Padding(
                padding: const EdgeInsets.only(bottom: 16, top: 4),
                child: Text(
                  '© 2026 DØRAX LAVEGAS',
                  style: AppTheme.body(size: 11, color: c.textSub),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPriceCard(
    BuildContext context,
    AppPalette c,
    Map<String, String> item,
    int index,
  ) {
    final icon = _iconMap[item["icon"]] ?? Icons.workspace_premium_rounded;
    final cardAccent = index.isEven
        ? c.accentBlue
        : c.accentBlue.withOpacity(0.7);

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + index * 60),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
        offset: Offset(0, (1 - v) * 16),
        child: Opacity(opacity: v.clamp(0, 1), child: child),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: c.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowSm,
        ),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ── Icon badge ──
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: cardAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: cardAccent, width: 1.5),
                ),
                child: Icon(icon, color: cardAccent, size: 24),
              ),
              const SizedBox(width: 14),

              // ── Info ──
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item["title"]!,
                      style: AppTheme.heading(size: 15, color: c.textMain),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.calendar_month_rounded,
                            color: c.textSub, size: 13),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(
                            item["monthly"]!,
                            style: AppTheme.body(
                              size: 12,
                              color: c.textMain,
                              weight: FontWeight.w600,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    if (item["permanent"] != null) ...[
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Icon(Icons.all_inclusive_rounded,
                              color: c.accentBlue, size: 13),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              item["permanent"]!,
                              style:
                                  AppTheme.body(size: 12, color: c.textSub),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 10),

              // ── Buy Button ──
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _showBuyDialog(
                    context,
                    item["title"]!,
                    item["monthly"]!,
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 18, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        c.accentBlue.withOpacity(0.8),
                        c.accentBlue,
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: c.border, width: 1.5),
                    boxShadow: AppTheme.hardShadowSm,
                  ),
                  child: Text(
                    'BUY',
                    style: AppTheme.heading(size: 13, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}