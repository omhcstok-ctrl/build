// wave_bottom_nav.dart
import 'package:flutter/material.dart';

/// ─── WAVE BOTTOM NAVIGATION — ATOMIC PIXEL STYLE ─────────────────────
/// Bottom nav bergelombang, background bar pakai gambar (bgnav.jpg),
/// dengan outline hitam tegas + hard shadow ala neo-brutalism/pixel art.
/// Lekukan & tombol mengambang GESER ke item yang di-tap.
///
/// Pemakaian:
/// int _selectedIndex = 0;
///
/// WaveBottomNav(
///   selectedIndex: _selectedIndex,
///   onTap: (i) => setState(() => _selectedIndex = i),
///   items: [
///     WaveNavItem(icon: Icons.home_rounded),
///     WaveNavItem(icon: Icons.chat_bubble_outline),
///     WaveNavItem(icon: Icons.notifications_none_rounded),
///     WaveNavItem(icon: Icons.build_outlined),
///   ],
/// )
class WaveNavItem {
  final IconData icon;
  const WaveNavItem({required this.icon});
}

class WaveBottomNav extends StatelessWidget {
  final List<WaveNavItem> items;
  final int selectedIndex;
  final ValueChanged<int> onTap;

  /// Background bar — gambar pixel art (assets/bgnav.jpg)
  final String barBackgroundImage;
  /// Warna fallback kalau gambar gagal load, sekaligus warna tombol mengambang
  final Color barFallbackColor;
  final Color backgroundColor;
  final Color inactiveIconColor;
  final double barHeight;
  final double floatingButtonSize;

  const WaveBottomNav({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onTap,
    this.barBackgroundImage = 'assets/bgnav.jpg',
    this.barFallbackColor = const Color(0xFF3D6FE8),
    this.backgroundColor = const Color(0xFFEAF0FB),
    this.inactiveIconColor = Colors.white,
    this.barHeight = 78,
    this.floatingButtonSize = 64,
  });

  static const Color _pixelBorder = Colors.black;
  static const double _borderWidth = 3;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final slotWidth = width / items.length;
        double centerXFor(int index) => slotWidth * index + slotWidth / 2;

        return SizedBox(
          height: barHeight + (floatingButtonSize / 2) - 12,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: [
              Positioned.fill(child: Container(color: backgroundColor)),

              // Bar bergelombang — background image + outline pixel + icon
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: TweenAnimationBuilder<double>(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                  tween: Tween<double>(
                    begin: centerXFor(selectedIndex),
                    end: centerXFor(selectedIndex),
                  ),
                  builder: (context, notchX, child) {
                    final clipper = _WaveNotchClipper(notchCenterX: notchX);
                    return SizedBox(
                      height: barHeight,
                      width: double.infinity,
                      child: Stack(
                        children: [
                          // Layer 1: background gambar pixel art (di-clip wave)
                          ClipPath(
                            clipper: clipper,
                            child: Container(
                              height: barHeight,
                              decoration: BoxDecoration(
                                color: barFallbackColor,
                                image: DecorationImage(
                                  image: AssetImage(barBackgroundImage),
                                  fit: BoxFit.cover,
                                  onError: (_, __) {},
                                  colorFilter: ColorFilter.mode(
                                    Colors.black.withOpacity(0.18),
                                    BlendMode.darken,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          // Layer 2: outline pixel hitam tegas di sekeliling wave
                          Positioned.fill(
                            child: CustomPaint(
                              painter: _WaveOutlinePainter(
                                clipper: clipper,
                                color: _pixelBorder,
                                strokeWidth: _borderWidth,
                              ),
                            ),
                          ),

                          // Layer 3: icon-icon menu
                          Row(
                            children: List.generate(items.length, (i) {
                              final isSelected = i == selectedIndex;
                              return Expanded(
                                child: GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () => onTap(i),
                                  child: Center(
                                    child: AnimatedOpacity(
                                      duration:
                                          const Duration(milliseconds: 200),
                                      opacity: isSelected ? 0.0 : 1.0,
                                      child: Icon(
                                        items[i].icon,
                                        color: inactiveIconColor,
                                        size: 24,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              // Tombol mengambang — pixel style: border hitam + hard shadow
              _AnimatedFloatingButton(
                targetX: centerXFor(selectedIndex),
                bottom: barHeight - (floatingButtonSize / 2) - 4,
                size: floatingButtonSize,
                fillColor: barFallbackColor,
                ringColor: backgroundColor,
                icon: items[selectedIndex].icon,
                onTap: () => onTap(selectedIndex),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AnimatedFloatingButton extends StatelessWidget {
  final double targetX;
  final double bottom;
  final double size;
  final Color fillColor;
  final Color ringColor;
  final IconData icon;
  final VoidCallback onTap;

  const _AnimatedFloatingButton({
    required this.targetX,
    required this.bottom,
    required this.size,
    required this.fillColor,
    required this.ringColor,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedPositioned(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      left: targetX - (size / 2),
      bottom: bottom,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(shape: BoxShape.circle, color: ringColor),
          padding: const EdgeInsets.all(5),
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: fillColor,
              border: Border.all(color: Colors.black, width: 3),
              boxShadow: const [
                BoxShadow(color: Colors.black, offset: Offset(3, 3)),
              ],
            ),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child:
                  Icon(icon, key: ValueKey(icon), color: Colors.white, size: 26),
            ),
          ),
        ),
      ),
    );
  }
}

/// Path clipper: bar rata dengan lekukan yang posisinya mengikuti
/// notchCenterX — dipakai bareng buat clip gambar & painter outline.
class _WaveNotchClipper extends CustomClipper<Path> {
  final double notchCenterX;
  const _WaveNotchClipper({required this.notchCenterX});

  static const double notchRadius = 46;
  static const double dip = 46;

  @override
  Path getClip(Size size) {
    const double flatTopY = 0;
    final double cx = notchCenterX.clamp(
      notchRadius + 14,
      size.width - notchRadius - 14,
    );

    final path = Path();
    path.moveTo(0, flatTopY);
    path.lineTo(cx - notchRadius - 14, flatTopY);
    path.cubicTo(
      cx - notchRadius,
      flatTopY,
      cx - notchRadius,
      flatTopY + dip,
      cx,
      flatTopY + dip,
    );
    path.cubicTo(
      cx + notchRadius,
      flatTopY + dip,
      cx + notchRadius,
      flatTopY,
      cx + notchRadius + 14,
      flatTopY,
    );
    path.lineTo(size.width, flatTopY);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant _WaveNotchClipper oldClipper) =>
      oldClipper.notchCenterX != notchCenterX;
}

/// Menggambar outline hitam tegas HANYA di sisi lengkung atas wave
/// (bukan sisi kiri/kanan/bawah yang nempel ke tepi layar).
class _WaveOutlinePainter extends CustomPainter {
  final _WaveNotchClipper clipper;
  final Color color;
  final double strokeWidth;

  _WaveOutlinePainter({
    required this.clipper,
    required this.color,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const double flatTopY = 0;
    final double cx = clipper.notchCenterX.clamp(
      _WaveNotchClipper.notchRadius + 14,
      size.width - _WaveNotchClipper.notchRadius - 14,
    );
    const r = _WaveNotchClipper.notchRadius;
    const dip = _WaveNotchClipper.dip;

    final path = Path();
    path.moveTo(0, flatTopY);
    path.lineTo(cx - r - 14, flatTopY);
    path.cubicTo(cx - r, flatTopY, cx - r, flatTopY + dip, cx, flatTopY + dip);
    path.cubicTo(cx + r, flatTopY + dip, cx + r, flatTopY, cx + r + 14, flatTopY);
    path.lineTo(size.width, flatTopY);

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _WaveOutlinePainter oldDelegate) =>
      oldDelegate.clipper.notchCenterX != clipper.notchCenterX;
}