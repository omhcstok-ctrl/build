// login_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';
import 'app_theme.dart';
import 'maintenance_page.dart';
import '.dart';

// ══════════════════════════════════════════════════════════════
//  LOGIN PAGE
// ══════════════════════════════════════════════════════════════
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscure = true;
  String? androidId;

  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _fadeAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _initLogin();
    _checkMaintenanceOnBoot();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  //  MAINTENANCE CHECK (boot)
  // ══════════════════════════════════════════════════════════════
  Future<void> _checkMaintenanceOnBoot() async {
    final status = await MaintenanceService.fetchStatus();
    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    final cachedRole = (prefs.getString('role') ?? '').toLowerCase();
    final isFounder = cachedRole == 'founder';

    if (status.active && !isFounder) {
      await MaintenancePopup.show(
        context,
        reason: status.reason,
        activatedBy: status.activatedBy,
      );
    }
  }

  // ══════════════════════════════════════════════════════════════
  //  AUTO LOGIN
  // ══════════════════════════════════════════════════════════════
  Future<void> _initLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        '$apiBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey',
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          await prefs.setString(
              'role', (data['role'] ?? 'member').toString().toLowerCase());
          _goToSplash(savedUser, savedPass, data);
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    return info.id ?? 'unknown_device';
  }

  // ══════════════════════════════════════════════════════════════
  //  LOGIN
  // ══════════════════════════════════════════════════════════════
  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    HapticFeedback.lightImpact();
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse('$apiBaseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': androidId ?? 'unknown_device',
        },
      );
      final data = jsonDecode(res.body);

      // 🛠️ CEK MAINTENANCE DULU
      if (data['maintenance'] == true) {
        setState(() => isLoading = false);
        if (mounted) {
          await MaintenancePopup.show(
            context,
            reason: (data['reason'] ?? 'Server sedang dalam maintenance.').toString(),
            activatedBy: data['activatedBy']?.toString(),
          );
        }
        return;
      }

      if (data['expired'] == true) {
        _showDialog(
          icon: Icons.timer_off_rounded,
          iconColor: AppTheme.controller.palette.accentAmber,
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          showContact: true,
        );
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? '').toString().toLowerCase();
        final isDevice = msg.contains('perangkat') ||
            msg.contains('device') ||
            msg.contains('another');
        _showDialog(
          icon: isDevice
              ? Icons.devices_other_rounded
              : Icons.lock_person_rounded,
          iconColor: AppTheme.controller.palette.primaryRed,
          title: isDevice ? 'Sesi Aktif' : 'Login Gagal',
          message: isDevice
              ? 'Akun ini sedang login di perangkat lain. Logout terlebih dahulu.'
              : 'Username atau password salah.',
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key', data['key']);
        await prefs.setString(
            'role', (data['role'] ?? 'member').toString().toLowerCase());

        if (mounted) _goToSplash(username, password, data);
      }
    } catch (e) {
      _showDialog(
        icon: Icons.wifi_off_rounded,
        iconColor: AppTheme.controller.palette.primaryRed,
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa internet Anda.',
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _goToSplash(String user, String pass, Map data) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => SplashScreen(
          username: user,
          password: pass,
          role: data['role'],
          sessionKey: data['key'],
          expiredDate: data['expiredDate'],
          listBug: (data['listBug'] as List? ?? [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
          listBugGlobal: (data['listBugGlobal'] as List? ?? [])  // ← TAMBAHAN
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
          listBugGroup: (data['listBugGroup'] as List? ?? [])    // ← TAMBAHAN
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
          listDoos: (data['listDDoS'] as List? ?? [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
          news: (data['news'] as List? ?? [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ══════════════════════════════════════════════════════════════
  void _showDialog({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String message,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Builder(builder: (dialogContext) {
          final c = PaletteScope.of(dialogContext);
          return Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: c.cardBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.border, width: 2),
              boxShadow: AppTheme.hardShadowLg,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.12),
                    shape: BoxShape.circle,
                    border: Border.all(color: iconColor, width: 1.5),
                  ),
                  child: Icon(icon, color: iconColor, size: 26),
                ),
                const SizedBox(height: 14),
                Text(title,
                    style: AppTheme.heading(size: 18, color: c.textMain)),
                const SizedBox(height: 8),
                Text(message,
                    style: AppTheme.body(size: 13, color: c.textSub),
                    textAlign: TextAlign.center),
                const SizedBox(height: 24),
                if (showContact)
                  GestureDetector(
                    onTap: () async {
                      await launchUrl(Uri.parse('https://t.me/towngreal01'),
                          mode: LaunchMode.externalApplication);
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: c.accentBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: c.accentBlue, width: 1.5),
                      ),
                      child: Text(
                        'Hubungi Admin',
                        style:
                            AppTheme.heading(size: 14, color: c.accentBlue),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                GestureDetector(
                  onTap: () => Navigator.pop(dialogContext),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: c.bgSoft,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: c.border, width: 1.5),
                    ),
                    child: Text(
                      'Tutup',
                      style: AppTheme.heading(size: 14, color: c.textSub),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: Center(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      _buildLogo(c),
                      const SizedBox(height: 32),
                      _buildTitleBlock(c),
                      const SizedBox(height: 48),
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            _buildInput(c, _userCtrl, 'Username',
                                Icons.person_outline_rounded),
                            const SizedBox(height: 16),
                            _buildInput(c, _passCtrl, 'Password',
                                Icons.lock_outline_rounded,
                                isPassword: true),
                            const SizedBox(height: 36),
                            _buildLoginBtn(c),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      _buildBottomLinks(c),
                      const SizedBox(height: 24),
                      _buildFooter(c),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo(AppPalette c) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Hero(
        tag: 'logo',
        child: Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: c.border, width: 2),
            boxShadow: [
              BoxShadow(
                color: c.accentBlue.withOpacity(_pulseAnim.value * 0.35),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Image.asset('assets/images/login.png', fit: BoxFit.cover),
          ),
        ),
      ),
    );
  }

  Widget _buildTitleBlock(AppPalette c) {
    return Column(
      children: [
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'Welcome ',
                style: AppTheme.display(size: 32, color: c.textMain),
              ),
              TextSpan(
                text: 'Back',
                style: AppTheme.display(size: 32, color: c.accentBlue),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text('Masuk ke akun Anda',
            style: AppTheme.body(size: 15, color: c.textSub)),
      ],
    );
  }

  Widget _buildInput(
    AppPalette c,
    TextEditingController ctrl,
    String label,
    IconData icon, {
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: c.border, width: 2),
      ),
      child: TextFormField(
        controller: ctrl,
        obscureText: isPassword ? _obscure : false,
        style: AppTheme.heading(size: 15, color: c.textMain),
        cursorColor: c.accentBlue,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: AppTheme.body(size: 13, color: c.textSub),
          prefixIcon: Icon(icon, color: c.accentBlue, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscure
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: c.textMuted,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _obscure = !_obscure),
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: c.accentBlue, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.transparent),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: c.primaryRed),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: c.primaryRed, width: 2),
          ),
        ),
        validator: (v) =>
            (v == null || v.isEmpty) ? '$label tidak boleh kosong' : null,
      ),
    );
  }

  Widget _buildLoginBtn(AppPalette c) {
    final w = MediaQuery.of(context).size.width - 56;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      width: isLoading ? 58 : w,
      height: 56,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c.accentBlue.withOpacity(0.8), c.accentBlue],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowMd,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : _login,
          borderRadius: BorderRadius.circular(30),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                        strokeWidth: 2.5, color: Colors.white),
                  )
                : Text(
                    'Sign In',
                    style: AppTheme.heading(size: 17, color: Colors.white)
                        .copyWith(letterSpacing: 1.2),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomLinks(AppPalette c) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: 'Developer?',
            style: AppTheme.body(size: 13, color: c.textSub),
          ),
          TextSpan(
            text: 'CLICK',
            style: AppTheme.heading(size: 13, color: c.accentBlue)
                .copyWith(letterSpacing: 0.5),
            recognizer: TapGestureRecognizer()
              ..onTap = () async {
                await launchUrl(Uri.parse('https://t.me/towngreal01'),
                    mode: LaunchMode.externalApplication);
              },
          ),
        ],
      ),
    );
  }

  Widget _buildFooter(AppPalette c) {
    return Text(
      '© 2026 DØRAX LAVEGAS',
      style: AppTheme.body(size: 11, color: c.textSub),
    );
  }
}