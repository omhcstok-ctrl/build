// dorax_am_premium_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart'; // ✅ Theme global

class DoraxAmPremiumPage extends StatefulWidget {
  const DoraxAmPremiumPage({super.key});

  @override
  State<DoraxAmPremiumPage> createState() => _DoraxAmPremiumPageState();
}

class _DoraxAmPremiumPageState extends State<DoraxAmPremiumPage> {
  final emailController = TextEditingController();
  final magicController = TextEditingController();
  final scrollController = ScrollController();

  int currentStep = 0;
  bool serverOnline = false;
  bool isAdmin = false;
  bool obscureMagic = true;
  String page = 'home';

  final List<_LogItem> logs = <_LogItem>[
    _LogItem('DØRAXMOTION siap digunakan.', 'ok'),
    _LogItem('Hubungkan ke server untuk memulai.', 'info'),
  ];

  final List<_HistoryItem> history = <_HistoryItem>[];

  @override
  void dispose() {
    emailController.dispose();
    magicController.dispose();
    scrollController.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  //  HELPERS
  // ══════════════════════════════════════════════════════════════
  void _toast(String message, {Color? color}) {
    final c = PaletteScope.of(context);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontFamily: 'Rajdhani')),
        backgroundColor: color ?? c.accentBlue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: c.border, width: 1.5),
        ),
      ),
    );
  }

  void _log(String message, String type) {
    setState(() => logs.add(_LogItem(message, type)));
  }

  void _checkServer() {
    final c = PaletteScope.of(context);
    setState(() => serverOnline = !serverOnline);
    _log(
      serverOnline ? 'Server berhasil terhubung.' : 'Server sedang offline.',
      serverOnline ? 'ok' : 'err',
    );
    _toast(
      serverOnline ? 'Status server: ONLINE' : 'Status server: OFFLINE',
      color: serverOnline ? c.accentGreen : c.primaryRed,
    );
  }

  bool _validEmail(String value) {
    return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim());
  }

  Future<void> _requestMagic() async {
    final c = PaletteScope.of(context);
    if (!_validEmail(emailController.text)) {
      _toast('Masukkan email yang valid.', color: c.primaryRed);
      return;
    }

    try {
      final email = emailController.text.trim();
      final uri = Uri.parse(
        'https://api.kyzznekoo.my.id/api/alightmotion/v1/magic-link',
      ).replace(queryParameters: {'email': email});

      _log('Mengirim request magic link...', 'info');
      await http.get(uri);

      if (!mounted) return;
      setState(() => currentStep = 1);
      _log('Magic link berhasil dikirim.', 'ok');
      _toast('Magic link berhasil dikirim.', color: c.accentGreen);
    } catch (e) {
      if (!mounted) return;
      _log('Error koneksi: $e', 'err');
      _toast('Gagal terhubung ke server.', color: c.primaryRed);
    }
  }

  void _verifyMagic() {
    final c = PaletteScope.of(context);
    if (magicController.text.trim().isEmpty) {
      _toast('Masukkan magic link terlebih dahulu.', color: c.primaryRed);
      return;
    }
    setState(() => currentStep = 2);
    _log('Magic link berhasil diverifikasi.', 'ok');
    _toast('Magic link terverifikasi.', color: c.accentGreen);
  }

  Future<void> _applyPremium() async {
    final c = PaletteScope.of(context);
    if (emailController.text.trim().isEmpty) {
      _toast('Email tidak boleh kosong.', color: c.primaryRed);
      return;
    }

    if (magicController.text.trim().isEmpty) {
      _toast('Magic link tidak boleh kosong.', color: c.primaryRed);
      return;
    }

    try {
      final email = emailController.text.trim();
      final link = magicController.text.trim();

      final uri = Uri.parse(
        'https://api.kyzznekoo.my.id/api/alightmotion/v1/applyPremium',
      ).replace(queryParameters: {'email': email, 'link': link});

      _log('Memproses aktivasi Premium...', 'info');
      await http.get(uri);

      if (!mounted) return;
      setState(() {
        currentStep = 3;
        history.insert(
          0,
          _HistoryItem(
            email: email,
            action: 'Aktivasi Premium',
            status: 'success',
            date: DateTime.now(),
          ),
        );
      });

      _log('Premium berhasil diterapkan.', 'ok');
      _toast('Aktivasi Premium berhasil!', color: c.accentGreen);
    } catch (e) {
      if (!mounted) return;
      _log('Error koneksi: $e', 'err');
      _toast('Gagal terhubung ke server.', color: c.primaryRed);
    }
  }

  void _reset() {
    setState(() {
      emailController.clear();
      magicController.clear();
      currentStep = 0;
    });
    _log('Sesi aktivasi direset.', 'info');
    _toast('Sesi aktivasi direset.');
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    final width = MediaQuery.sizeOf(context).width;
    final mobile = width < 760;

    return Scaffold(
      backgroundColor: c.bg,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: c.cardBg,
        surfaceTintColor: Colors.transparent,
        iconTheme: IconThemeData(color: c.textMain),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: InkWell(
          onTap: () => setState(() => page = 'home'),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _LogoBox(),
              const SizedBox(width: 10),
              Text(
                'DØRAXMOTION',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  color: c.textMain,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: c.border),
        ),
        actions: mobile
            ? [
                IconButton(
                  icon: const Icon(Icons.menu),
                  onPressed: () => _openMenu(context),
                ),
              ]
            : [
                _NavButton('Aktivasi', page == 'home',
                    () => setState(() => page = 'home')),
                _NavButton('Riwayat', page == 'history',
                    () => setState(() => page = 'history')),
                _NavButton('Tentang', page == 'about',
                    () => setState(() => page = 'about')),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: _BrutalButton(
                    text: isAdmin ? 'ADMIN' : 'ADMIN LOGIN',
                    icon: Icons.admin_panel_settings_outlined,
                    color: isAdmin ? c.accentGreen : c.cardBg,
                    onTap: _showAdminDialog,
                  ),
                ),
              ],
      ),
      body: SafeArea(
        top: false,
        child: CustomPaint(
          painter: _BackgroundPainter(
            circle1: c.accentGreen.withOpacity(0.24),
            circle2: c.accentBlue.withOpacity(0.14),
          ),
          child: SingleChildScrollView(
            controller: scrollController,
            padding: EdgeInsets.fromLTRB(
                mobile ? 14 : 24, 18, mobile ? 14 : 24, 40),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1280),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: switch (page) {
                    'history' => _historyPage(),
                    'about' => _aboutPage(),
                    _ => _homePage(mobile),
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _homePage(bool mobile) {
    final c = PaletteScope.of(context);
    return Column(
      key: const ValueKey('home'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (mobile)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: _BrutalButton(
              text: isAdmin ? 'ADMIN' : 'ADMIN LOGIN',
              icon: Icons.admin_panel_settings_outlined,
              color: isAdmin ? c.accentGreen : c.cardBg,
              onTap: _showAdminDialog,
            ),
          ),
        mobile
            ? Column(
                children: [
                  _heroText(),
                  const SizedBox(height: 20),
                  _statusCard(),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(child: _heroText()),
                  const SizedBox(width: 28),
                  SizedBox(width: 320, child: _statusCard()),
                ],
              ),
        const SizedBox(height: 28),
        mobile
            ? Column(
                children: [
                  _activationPanel(),
                  const SizedBox(height: 20),
                  _sidePanel(),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: _activationPanel()),
                  const SizedBox(width: 24),
                  SizedBox(width: 340, child: _sidePanel()),
                ],
              ),
        _footer(),
      ],
    );
  }

  Widget _heroText() {
    final c = PaletteScope.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            _Dot(color: c.accentGreen),
            const SizedBox(width: 8),
            Text(
              'PUSAT AKTIVASI',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
                color: c.textMain,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        RichText(
          text: TextSpan(
            style: TextStyle(
              fontSize: 48,
              height: 1.04,
              fontWeight: FontWeight.w900,
              color: c.textMain,
              fontFamily: 'Rajdhani',
            ),
            children: [
              const TextSpan(text: 'Aktivasi '),
              TextSpan(
                  text: 'Premium',
                  style: TextStyle(color: c.accentBlue)),
              const TextSpan(text: '\nlebih mudah.'),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text(
          'Kelola proses aktivasi dalam satu tempat dengan tampilan sederhana, cepat, dan mudah dipahami.',
          style: TextStyle(
            fontSize: 13,
            height: 1.7,
            color: c.textSub,
            fontFamily: 'Rajdhani',
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 18,
          runSpacing: 8,
          children: [
            _Stat(label: 'Online', color: c.accentGreen),
            _Stat(label: 'Secure', color: c.accentBlue),
            _Stat(label: 'Real-time', color: c.accentAmber),
            _Stat(label: 'HTTPS', color: const Color(0xFF9B5DE5)),
          ],
        ),
        const SizedBox(height: 18),
        _BrutalButton(
          text: 'Mulai Aktivasi',
          icon: Icons.arrow_downward,
          color: c.accentGreen,
          onTap: () => scrollController.animateTo(
            450,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
          ),
        ),
      ],
    );
  }

  Widget _statusCard() {
    final c = PaletteScope.of(context);
    return _BrutalCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'STATUS SISTEM',
            style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
                color: c.textMain,
                fontFamily: 'Rajdhani'),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                  child: _statusItem('Server',
                      serverOnline ? 'ONLINE' : 'OFFLINE',
                      serverOnline ? c.accentGreen : c.primaryRed)),
              const SizedBox(width: 8),
              Expanded(
                  child: _statusItem('Session', 'READY', c.accentGreen)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                  child: _statusItem(
                      'Magic',
                      currentStep >= 2 ? 'VALID' : 'WAITING',
                      currentStep >= 2 ? c.accentGreen : c.accentAmber)),
              const SizedBox(width: 8),
              Expanded(
                  child: _statusItem(
                      'Premium',
                      currentStep == 3 ? 'ACTIVE' : 'WAITING',
                      currentStep == 3 ? c.accentGreen : c.accentAmber)),
            ],
          ),
          const SizedBox(height: 12),
          _BrutalButton(
            text: 'Refresh Status',
            icon: Icons.refresh,
            color: c.cardBg,
            onTap: _checkServer,
            fullWidth: true,
          ),
        ],
      ),
    );
  }

  Widget _statusItem(String title, String value, Color color) {
    final c = PaletteScope.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: c.cardBg,
        border: Border.all(color: c.border, width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: TextStyle(
                fontSize: 8,
                color: c.textSub,
                fontWeight: FontWeight.w700,
                fontFamily: 'Rajdhani'),
          ),
          const SizedBox(height: 5),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withOpacity(0.18),
              border: Border.all(color: c.border),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              value,
              style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: c.textMain,
                  fontFamily: 'Rajdhani'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _activationPanel() {
    final c = PaletteScope.of(context);
    return _BrutalCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(22),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Aktivasi Premium',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: c.textMain,
                            fontFamily: 'Rajdhani'),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'Ikuti langkah aktivasi secara berurutan.',
                        style: TextStyle(
                            fontSize: 11,
                            color: c.textSub,
                            fontFamily: 'Rajdhani'),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    border: Border.all(color: c.border),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'STEP ${currentStep + 1}/4',
                    style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        color: c.textMain,
                        fontFamily: 'Rajdhani'),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 2, color: c.border),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
            child: Row(
              children: List.generate(4, (i) {
                final active = i <= currentStep;
                return Expanded(
                  child: Container(
                    height: 6,
                    margin: EdgeInsets.only(right: i == 3 ? 0 : 5),
                    decoration: BoxDecoration(
                      color: active
                          ? (i < currentStep ? c.accentGreen : c.accentBlue)
                          : c.bgSoft,
                      border: Border.all(color: c.border),
                    ),
                  ),
                );
              }),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: switch (currentStep) {
                0 => _emailStep(),
                1 => _magicStep(),
                2 => _premiumStep(),
                _ => _successStep(),
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _emailStep() {
    final c = PaletteScope.of(context);
    return _StepCard(
      key: const ValueKey('email'),
      number: '01',
      title: 'Masukkan Email',
      subtitle: 'Gunakan alamat email yang valid.',
      child: Column(
        children: [
          TextField(
            controller: emailController,
            keyboardType: TextInputType.emailAddress,
            style: TextStyle(
                fontFamily: 'Rajdhani', color: c.textMain, fontSize: 13),
            decoration:
                _inputDecoration('nama@email.com', Icons.email_outlined),
          ),
          const SizedBox(height: 14),
          _BrutalButton(
            text: 'Request Magic Link',
            icon: Icons.send_outlined,
            color: c.accentGreen,
            fullWidth: true,
            onTap: _requestMagic,
          ),
        ],
      ),
    );
  }

  Widget _magicStep() {
    final c = PaletteScope.of(context);
    return _StepCard(
      key: const ValueKey('magic'),
      number: '02',
      title: 'Verifikasi Magic Link',
      subtitle: 'Masukkan kode atau magic link yang diterima.',
      child: Column(
        children: [
          TextField(
            controller: magicController,
            obscureText: obscureMagic,
            style: TextStyle(
                fontFamily: 'Rajdhani', color: c.textMain, fontSize: 13),
            decoration: _inputDecoration(
                    'Masukkan magic link', Icons.key_outlined)
                .copyWith(
              suffixIcon: IconButton(
                icon: Icon(
                  obscureMagic
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: c.textSub,
                ),
                onPressed: () =>
                    setState(() => obscureMagic = !obscureMagic),
              ),
            ),
          ),
          const SizedBox(height: 14),
          _BrutalButton(
            text: 'Verifikasi',
            icon: Icons.verified_outlined,
            color: c.accentGreen,
            fullWidth: true,
            onTap: _verifyMagic,
          ),
        ],
      ),
    );
  }

  Widget _premiumStep() {
    final c = PaletteScope.of(context);
    return _StepCard(
      key: const ValueKey('premium'),
      number: '03',
      title: 'Terapkan Premium',
      subtitle: 'Konfirmasi proses aktivasi akun.',
      child: Column(
        children: [
          Text(
            'Data siap diproses. Klik tombol di bawah untuk menyelesaikan aktivasi.',
            style: TextStyle(
                fontSize: 12,
                color: c.textSub,
                height: 1.5,
                fontFamily: 'Rajdhani'),
          ),
          const SizedBox(height: 14),
          _BrutalButton(
            text: 'Apply Premium',
            icon: Icons.workspace_premium_outlined,
            color: c.accentGreen,
            fullWidth: true,
            onTap: _applyPremium,
          ),
        ],
      ),
    );
  }

  Widget _successStep() {
    final c = PaletteScope.of(context);
    return _StepCard(
      key: const ValueKey('success'),
      number: '✓',
      title: 'Aktivasi Berhasil',
      subtitle: 'Premium berhasil diterapkan.',
      success: true,
      child: Column(
        children: [
          Icon(Icons.check_circle_outline, size: 64, color: c.textMain),
          const SizedBox(height: 10),
          Text(
            'Selesai!',
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: c.textMain,
                fontFamily: 'Rajdhani'),
          ),
          const SizedBox(height: 6),
          Text(
            emailController.text.trim(),
            style: TextStyle(
                color: c.textSub, fontSize: 12, fontFamily: 'Rajdhani'),
          ),
          const SizedBox(height: 16),
          _BrutalButton(
            text: 'Reset Aktivasi',
            icon: Icons.restart_alt,
            color: c.cardBg,
            fullWidth: true,
            onTap: _reset,
          ),
        ],
      ),
    );
  }

  Widget _sidePanel() {
    final c = PaletteScope.of(context);
    return Column(
      children: [
        _BrutalCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'CONSOLE',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: c.textMain,
                        fontFamily: 'Rajdhani'),
                  ),
                  Text(
                    'LIVE',
                    style: TextStyle(
                        fontSize: 9,
                        color: c.textSub,
                        fontFamily: 'Rajdhani'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                constraints: const BoxConstraints(maxHeight: 240),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: c.bgSoft,
                  border: Border.all(color: c.border, width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: logs.isEmpty
                    ? Text(
                        'Belum ada aktivitas.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: c.textSub, fontFamily: 'Rajdhani'),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: logs.length,
                        itemBuilder: (context, i) {
                          final log = logs[i];
                          final col = switch (log.type) {
                            'ok' => c.accentGreen,
                            'err' => c.primaryRed,
                            'warn' => c.accentAmber,
                            _ => c.accentBlue,
                          };
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 3),
                            child: Text(
                              '• ${log.message}',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: col,
                                  fontFamily: 'Rajdhani'),
                            ),
                          );
                        },
                      ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                      child: _BrutalButton(
                          text: 'Clear',
                          icon: Icons.clear_all,
                          color: c.cardBg,
                          onTap: () => setState(logs.clear))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: _BrutalButton(
                          text: 'Check',
                          icon: Icons.refresh,
                          color: c.cardBg,
                          onTap: _checkServer)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _BrutalCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'AKTIVITAS TERBARU',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: c.textMain,
                    fontFamily: 'Rajdhani'),
              ),
              const SizedBox(height: 12),
              if (history.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'Belum ada riwayat.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: c.textSub,
                        fontSize: 11,
                        fontFamily: 'Rajdhani'),
                  ),
                )
              else
                ...history.take(5).map((item) => _recentItem(item, c)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _recentItem(_HistoryItem item, AppPalette c) => Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: c.bgSoft,
          border: Border.all(color: c.border, width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.email,
                        style: TextStyle(
                            fontSize: 9,
                            color: c.textSub,
                            fontFamily: 'Rajdhani')),
                    Text(item.action,
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: c.textMain,
                            fontFamily: 'Rajdhani')),
                  ]),
            ),
            Text(
              'SUCCESS',
              style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  color: c.accentGreen,
                  fontFamily: 'Rajdhani'),
            ),
          ],
        ),
      );

  Widget _historyPage() {
    final c = PaletteScope.of(context);
    return Column(
      key: const ValueKey('history'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Riwayat Aktivasi',
          style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              color: c.textMain,
              fontFamily: 'Rajdhani'),
        ),
        const SizedBox(height: 8),
        Text(
          'Daftar aktivitas yang telah dilakukan pada sesi ini.',
          style: TextStyle(color: c.textSub, fontFamily: 'Rajdhani'),
        ),
        const SizedBox(height: 20),
        _BrutalCard(
          child: history.isEmpty
              ? Padding(
                  padding: const EdgeInsets.all(40),
                  child: Center(
                    child: Text(
                      'Belum ada riwayat aktivasi.',
                      style:
                          TextStyle(color: c.textSub, fontFamily: 'Rajdhani'),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(
                          label: Text('EMAIL',
                              style: TextStyle(
                                  color: c.textMain,
                                  fontFamily: 'Rajdhani'))),
                      DataColumn(
                          label: Text('AKSI',
                              style: TextStyle(
                                  color: c.textMain,
                                  fontFamily: 'Rajdhani'))),
                      DataColumn(
                          label: Text('STATUS',
                              style: TextStyle(
                                  color: c.textMain,
                                  fontFamily: 'Rajdhani'))),
                    ],
                    rows: history
                        .map((e) => DataRow(cells: [
                              DataCell(Text(e.email,
                                  style: TextStyle(
                                      fontFamily: 'Rajdhani',
                                      color: c.textMain))),
                              DataCell(Text(e.action,
                                  style: TextStyle(
                                      fontFamily: 'Rajdhani',
                                      color: c.textMain))),
                              DataCell(Text('SUCCESS',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      color: c.accentGreen,
                                      fontFamily: 'Rajdhani'))),
                            ]))
                        .toList(),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _aboutPage() {
    final c = PaletteScope.of(context);
    return Column(
      key: const ValueKey('about'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tentang',
          style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              color: c.textMain,
              fontFamily: 'Rajdhani'),
        ),
        const SizedBox(height: 20),
        LayoutBuilder(builder: (context, constraints) {
          final small = constraints.maxWidth < 700;
          final cards = [
            _BrutalCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text('DØRAXMOTION',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: c.textMain,
                          fontFamily: 'Rajdhani')),
                  const SizedBox(height: 8),
                  Text(
                    'Pusat aktivasi dengan gaya visual neo-brutalism yang mempertahankan struktur halaman asli.',
                    style: TextStyle(
                        color: c.textSub,
                        height: 1.6,
                        fontFamily: 'Rajdhani'),
                  ),
                ])),
            _BrutalCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text('Owner',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: c.textMain,
                          fontFamily: 'Rajdhani')),
                  const SizedBox(height: 8),
                  Text(
                    'Informasi pemilik dan detail aplikasi dapat ditempatkan di sini.',
                    style: TextStyle(
                        color: c.textSub,
                        height: 1.6,
                        fontFamily: 'Rajdhani'),
                  ),
                ])),
          ];
          return small
              ? Column(children: [
                  cards[0],
                  const SizedBox(height: 20),
                  cards[1]
                ])
              : Row(children: [
                  Expanded(child: cards[0]),
                  const SizedBox(width: 24),
                  Expanded(child: cards[1])
                ]);
        }),
      ],
    );
  }

  Widget _footer() {
    final c = PaletteScope.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '© DØRAXMOTION',
            style: TextStyle(
                fontSize: 10, color: c.textSub, fontFamily: 'Rajdhani'),
          ),
          Row(children: [
            TextButton(
                onPressed: () => _toast(
                    'Privasi: data sesi tidak disimpan permanen.'),
                child: Text('Privacy',
                    style: TextStyle(
                        color: c.textMain, fontFamily: 'Rajdhani'))),
            TextButton(
                onPressed: () => setState(() => page = 'about'),
                child: Text('About',
                    style: TextStyle(
                        color: c.textMain, fontFamily: 'Rajdhani'))),
          ]),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint, IconData icon) {
    final c = PaletteScope.of(context);
    return InputDecoration(
      hintText: hint,
      prefixIcon: Icon(icon, color: c.textSub, size: 20),
      filled: true,
      fillColor: c.bgSoft,
      hintStyle: TextStyle(
          color: c.textMuted, fontSize: 12, fontFamily: 'Rajdhani'),
      enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: c.border, width: 2),
          borderRadius: BorderRadius.circular(8)),
      focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: c.accentBlue, width: 2),
          borderRadius: BorderRadius.circular(8)),
    );
  }

  void _openMenu(BuildContext context) {
    final c = PaletteScope.of(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: c.cardBg,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _menuItem('Aktivasi', Icons.flash_on_outlined, 'home'),
          _menuItem('Riwayat', Icons.history, 'history'),
          _menuItem('Tentang', Icons.info_outline, 'about'),
        ]),
      ),
    );
  }

  Widget _menuItem(String label, IconData icon, String target) {
    final c = PaletteScope.of(context);
    return ListTile(
      leading: Icon(icon, color: c.accentBlue),
      title: Text(label,
          style: TextStyle(
              fontWeight: FontWeight.w800,
              color: c.textMain,
              fontFamily: 'Rajdhani')),
      onTap: () {
        Navigator.pop(context);
        setState(() => page = target);
      },
    );
  }

  void _showAdminDialog() {
    final c = PaletteScope.of(context);
    final password = TextEditingController();
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: c.cardBg,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: c.border, width: 3)),
        title: Text('Admin Login',
            style: TextStyle(
                fontWeight: FontWeight.w900,
                color: c.textMain,
                fontFamily: 'Rajdhani')),
        content: TextField(
          controller: password,
          obscureText: true,
          style: TextStyle(fontFamily: 'Rajdhani', color: c.textMain),
          decoration:
              _inputDecoration('Password', Icons.lock_outline),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text('Batal',
                  style: TextStyle(
                      color: c.textSub, fontFamily: 'Rajdhani'))),
          _BrutalButton(
            text: 'Login',
            icon: Icons.login,
            color: c.accentGreen,
            onTap: () {
              setState(() => isAdmin = password.text.trim().isNotEmpty);
              Navigator.pop(dialogContext);
              _toast(isAdmin ? 'Mode admin aktif.' : 'Password kosong.',
                  color: isAdmin ? c.accentGreen : c.primaryRed);
            },
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  REUSABLE WIDGETS
// ══════════════════════════════════════════════════════════════

class _LogoBox extends StatelessWidget {
  const _LogoBox();
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
          color: c.accentGreen,
          border: Border.all(color: c.border, width: 2),
          borderRadius: BorderRadius.circular(9)),
      child: Icon(Icons.bolt, color: c.textMain, size: 18),
    );
  }
}

class _NavButton extends StatelessWidget {
  final String text;
  final bool active;
  final VoidCallback onTap;
  const _NavButton(this.text, this.active, this.onTap);

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: TextButton(
        onPressed: onTap,
        style: TextButton.styleFrom(
          foregroundColor: c.textMain,
          backgroundColor: active ? c.accentGreen : Colors.transparent,
          side: active
              ? BorderSide(color: c.border, width: 2)
              : BorderSide.none,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(text,
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                fontFamily: 'Rajdhani')),
      ),
    );
  }
}

class _BrutalButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final bool fullWidth;

  const _BrutalButton({
    required this.text,
    required this.icon,
    required this.color,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    final child = ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 17),
      label: Text(text,
          style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 11,
              fontFamily: 'Rajdhani')),
      style: ElevatedButton.styleFrom(
        elevation: 0,
        backgroundColor: color,
        foregroundColor: c.textMain,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        side: BorderSide(color: c.border, width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      ),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: child) : child;
  }
}

class _BrutalCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _BrutalCard(
      {required this.child, this.padding = const EdgeInsets.all(20)});

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: c.cardBg,
        border: Border.all(color: c.border, width: 2),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: c.border, offset: const Offset(4, 4))],
      ),
      child: child,
    );
  }
}

class _StepCard extends StatelessWidget {
  final String number;
  final String title;
  final String subtitle;
  final Widget child;
  final bool success;

  const _StepCard({
    super.key,
    required this.number,
    required this.title,
    required this.subtitle,
    required this.child,
    this.success = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: success ? c.accentGreen.withOpacity(0.3) : c.cardBg,
        border: Border.all(color: c.border, width: success ? 3 : 2),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: c.border, offset: const Offset(4, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            Container(
              width: 28,
              height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: c.bgSoft,
                border: Border.all(color: c.border, width: 2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(number,
                  style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: c.textMain,
                      fontFamily: 'Rajdhani')),
            ),
            const SizedBox(width: 10),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: c.textMain,
                          fontFamily: 'Rajdhani')),
                  Text(subtitle,
                      style: TextStyle(
                          fontSize: 10,
                          color: c.textSub,
                          fontFamily: 'Rajdhani')),
                ])),
          ]),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;
  const _Dot({required this.color});
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Container(
      width: 8,
      height: 8,
      decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: c.border)),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final Color color;
  const _Stat({required this.label, required this.color});
  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _Dot(color: color),
      const SizedBox(width: 6),
      Text(label,
          style: TextStyle(
              fontSize: 11, color: c.textSub, fontFamily: 'Rajdhani')),
    ]);
  }
}

class _LogItem {
  final String message;
  final String type;
  _LogItem(this.message, this.type);
}

class _HistoryItem {
  final String email;
  final String action;
  final String status;
  final DateTime date;
  _HistoryItem(
      {required this.email,
      required this.action,
      required this.status,
      required this.date});
}

class _BackgroundPainter extends CustomPainter {
  final Color circle1;
  final Color circle2;
  const _BackgroundPainter({required this.circle1, required this.circle2});

  @override
  void paint(Canvas canvas, Size size) {
    final paint1 = Paint()..color = circle1;
    final paint2 = Paint()..color = circle2;
    canvas.drawCircle(const Offset(80, 80), 90, paint1);
    canvas.drawCircle(Offset(size.width - 80, 130), 110, paint2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}