// splash.dart
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGlobal; // ← TAMBAHAN
  final List<Map<String, dynamic>> listBugGroup;  // ← TAMBAHAN
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    this.listBugGlobal = const [], // ← TAMBAHAN (opsional)
    this.listBugGroup = const [],  // ← TAMBAHAN (opsional)
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;
  late AnimationController _progressController;

  bool _fadeOutStarted = false;
  bool _videoInitialized = false;
  bool _navigated = false;
  int _progress = 0;

  // === WARNA THEME (dark — konsisten dengan PintuPage) ===
  final Color primaryColor = const Color(0xFF00E5FF);
  final Color secondaryColor = const Color(0xFF7C4DFF);
  final Color greyDark = const Color(0xFFB0BEC5);
  static const String font = 'Rajdhani';

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..addListener(() {
        final val = (_progressController.value * 100).round();
        if (val != _progress) {
          setState(() => _progress = val);
        }
      });

    _progressController.forward().whenComplete(() {
      if (!_fadeOutStarted) {
        _fadeOutStarted = true;
        _fadeController.forward().whenComplete(_navigateToDashboard);
      }
    });

    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _videoInitialized = true;
        });
        _videoController.setLooping(true);
        _videoController.play();
      });
  }

  void _navigateToDashboard() {
    if (!mounted || _navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listBugGlobal: widget.listBugGlobal, // ← TAMBAHAN
          listBugGroup: widget.listBugGroup,   // ← TAMBAHAN
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _skipNow() {
    if (_fadeOutStarted) return;
    _fadeOutStarted = true;
    _progressController.stop();
    _fadeController.forward().whenComplete(_navigateToDashboard);
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _skipNow,
        child: Stack(
          children: [
            // --- VIDEO BACKGROUND ---
            if (_videoInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              )
            else
              Container(color: Colors.black),

            // --- DARK OVERLAY ---
            Positioned.fill(
              child: Container(color: Colors.black.withOpacity(0.45)),
            ),

            // --- KONTEN TENGAH ---
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildShieldLoader(),
                  const SizedBox(height: 28),
                  _buildProgressText(),
                ],
              ),
            ),

            // --- TEKS BAWAH ---
            Positioned(
              bottom: 70,
              left: 0,
              right: 0,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(
                      "Selamat datang di Apps Dørax",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: greyDark.withOpacity(0.85),
                        letterSpacing: 1.5,
                        fontStyle: FontStyle.italic,
                        fontFamily: font,
                        shadows: [
                          Shadow(
                            color: Colors.black.withOpacity(0.6),
                            blurRadius: 8,
                            offset: const Offset(1, 1),
                          ),
                        ],
                      ),
                    ),
                  ),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [primaryColor, secondaryColor],
                    ).createShader(bounds),
                    child: const Text(
                      "DØRAX",
                      style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 4,
                        fontFamily: font,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // --- HINT "Tap untuk lewati" ---
            Positioned(
              bottom: 24,
              left: 0,
              right: 0,
              child: Center(
                child: AnimatedOpacity(
                  opacity: _fadeOutStarted ? 0 : 0.5,
                  duration: const Duration(milliseconds: 400),
                  child: Text(
                    "Ketuk layar untuk melewati",
                    style: TextStyle(
                      fontSize: 11,
                      color: greyDark,
                      letterSpacing: 1,
                      fontFamily: font,
                    ),
                  ),
                ),
              ),
            ),

            // --- FADE OUT OVERLAY ---
            if (_fadeOutStarted)
              FadeTransition(
                opacity: _fadeController.drive(Tween(begin: 0.0, end: 1.0)),
                child: Container(color: Colors.black),
              ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  SHIELD LOADER
  // ══════════════════════════════════════════════════════════════
  Widget _buildShieldLoader() {
    return SizedBox(
      width: 160,
      height: 160,
      child: AnimatedBuilder(
        animation: Listenable.merge(
            [_rotateController, _pulseController, _progressController]),
        builder: (context, child) {
          final pulseScale = 1.0 + (_pulseController.value * 0.05);

          return Stack(
            alignment: Alignment.center,
            children: [
              // Outer glow ring berputar
              Transform.rotate(
                angle: _rotateController.value * 6.28319,
                child: Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: SweepGradient(
                      colors: [
                        primaryColor.withOpacity(0.0),
                        primaryColor.withOpacity(0.9),
                        secondaryColor.withOpacity(0.9),
                        primaryColor.withOpacity(0.0),
                      ],
                      stops: const [0.0, 0.3, 0.6, 1.0],
                    ),
                  ),
                ),
              ),

              // Mask lingkaran hitam
              Container(
                width: 146,
                height: 146,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black,
                ),
              ),

              // Progress ring
              SizedBox(
                width: 146,
                height: 146,
                child: CircularProgressIndicator(
                  value: _progressController.value,
                  strokeWidth: 3.5,
                  backgroundColor: Colors.white.withOpacity(0.08),
                  valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
                ),
              ),

              // Lingkaran dalam + shield
              Transform.scale(
                scale: pulseScale,
                child: Container(
                  width: 108,
                  height: 108,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF10151A),
                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withOpacity(0.35),
                        blurRadius: 24,
                        spreadRadius: 2,
                      ),
                    ],
                    border: Border.all(
                      color: primaryColor.withOpacity(0.4),
                      width: 1,
                    ),
                  ),
                  child: Center(
                    child: ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [primaryColor, secondaryColor],
                      ).createShader(bounds),
                      child: const Icon(
                        Icons.verified_user_rounded,
                        size: 56,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  PROGRESS TEXT
  // ══════════════════════════════════════════════════════════════
  Widget _buildProgressText() {
    return AnimatedBuilder(
      animation: _progressController,
      builder: (context, child) {
        return Column(
          children: [
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [primaryColor, secondaryColor],
              ).createShader(bounds),
              child: Text(
                "$_progress%",
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 1,
                  fontFamily: font,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "MEMUAT DATA...",
              style: TextStyle(
                fontSize: 11,
                color: greyDark.withOpacity(0.7),
                letterSpacing: 2,
                fontFamily: font,
              ),
            ),
          ],
        );
      },
    );
  }
}