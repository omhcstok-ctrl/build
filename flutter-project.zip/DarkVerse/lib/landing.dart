// landing.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'buy_account_page.dart';
import 'app_theme.dart'; // ✅ Theme global

// ── Links ──────────────────────────────────────────────────
const String kDeveloperTelegramUrl = 'https://t.me/towngreal01';
const String kCreatorTelegramUrl = 'https://t.me/kkiynn';

// ══════════════════════════════════════════════════════════════
//  LANDING PAGE
// ══════════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _fadeAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));
    _entryCtrl.forward();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _openTelegram(String url) async {
    HapticFeedback.lightImpact();
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = PaletteScope.of(context);
    return Scaffold(
      backgroundColor: c.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.bgSoft, c.bg],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeaderImage(c),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 28),
                          _buildTitle(c),
                          const SizedBox(height: 16),
                          _buildSubtitle(c),
                          const SizedBox(height: 28),
                          _buildInfoCard(c),
                          const SizedBox(height: 24),
                          _buildSignInButton(c),
                          const SizedBox(height: 14),
                          _buildDevCreatorRow(c),
                          const SizedBox(height: 14),
                          _buildBuyButton(c),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Header image (top banner) ──────────────────────────────
  Widget _buildHeaderImage(AppPalette c) {
    return SizedBox(
      width: double.infinity,
      height: 240,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/landing.png',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: c.bgSoft,
              child: Icon(Icons.image_not_supported_rounded,
                  size: 48, color: c.textSub),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 90,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    c.bgSoft.withOpacity(0.6),
                    c.bgSoft,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Title ───────────────────────────────────────────────────
  Widget _buildTitle(AppPalette c) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: 'DØRAX ',
            style: AppTheme.display(size: 40, color: c.textMain),
          ),
          TextSpan(
            text: 'LAVEGAS',
            style: AppTheme.display(size: 40, color: c.accentBlue),
          ),
        ],
      ),
    );
  }

  // ── Subtitle ────────────────────────────────────────────────
  Widget _buildSubtitle(AppPalette c) {
    return Text(
      'Aplikasi Yang Dikembangkan Dørax Lavegas Team',
      style: AppTheme.body(
        size: 17,
        color: c.textSub,
        weight: FontWeight.w600,
      ),
    );
  }

  // ── Info card ───────────────────────────────────────────────
  Widget _buildInfoCard(AppPalette c) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: c.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border, width: 2),
        boxShadow: AppTheme.hardShadowLg,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline_rounded, color: c.accentBlue, size: 22),
              const SizedBox(width: 8),
              Text('Tentang Dørax Lavegas',
                  style: AppTheme.heading(size: 20, color: c.textMain)),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'dørax lavegas adalah platform tools canggih yang dirancang untuk '
            'memberikan performa terbaik. Dikembangkan secara profesional oleh '
            'tim dørax lavegas dengan teknologi mutakhir dan sistem keamanan tinggi.',
            style: AppTheme.body(size: 16, color: c.textSub),
          ),
        ],
      ),
    );
  }

  // ── Sign In button ─────────────────────────────────────────
  Widget _buildSignInButton(AppPalette c) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.pushNamed(context, '/login');
      },
      child: Container(
        width: double.infinity,
        height: 58,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [c.accentBlue.withOpacity(0.8), c.accentBlue],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowMd,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.login_rounded, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Text(
              'Sign-In To Dørax Lavegas',
              style: AppTheme.heading(size: 17, color: Colors.white),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right_rounded,
                color: Colors.white, size: 22),
          ],
        ),
      ),
    );
  }

  // ── Developer / Creator row ─────────────────────────────────
  Widget _buildDevCreatorRow(AppPalette c) {
    return Row(
      children: [
        Expanded(
          child: _buildTeleButton(
            c,
            label: 'Developer',
            colors: [c.accentBlue.withOpacity(0.8), c.accentBlue],
            url: kDeveloperTelegramUrl,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _buildTeleButton(
            c,
            label: 'Creator',
            colors: [c.accentBlue, c.accentBlue.withOpacity(0.7)],
            url: kCreatorTelegramUrl,
          ),
        ),
      ],
    );
  }

  Widget _buildTeleButton(
    AppPalette c, {
    required String label,
    required List<Color> colors,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => _openTelegram(url),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowSm,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.send_rounded, size: 14, color: c.accentBlue),
            ),
            const SizedBox(width: 8),
            Text(label, style: AppTheme.heading(size: 15, color: Colors.white)),
          ],
        ),
      ),
    );
  }

  // ── Buy Access button ──────────────────────────────────────
  Widget _buildBuyButton(AppPalette c) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BuyAccountPage()),
        );
      },
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: c.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border, width: 2),
          boxShadow: AppTheme.hardShadowSm,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_rounded, color: c.accentBlue, size: 20),
            const SizedBox(width: 10),
            Text('Buy Access',
                style: AppTheme.heading(size: 17, color: c.accentBlue)),
          ],
        ),
      ),
    );
  }
}