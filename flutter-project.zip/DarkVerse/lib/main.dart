import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'pintu_page.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'buy_account_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // ⬇️ Listen ke ThemeController → MaterialApp rebuild saat tema ganti
    return ListenableBuilder(
      listenable: AppTheme.controller,
      builder: (context, _) {
        final palette = AppTheme.controller.palette;

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'DoràxLavègas',

          // Theme dinamis mengikuti palette yang aktif
          theme: AppTheme.themeData(palette),

          // ⬇️ Bungkus semua halaman dengan PaletteScope
          // supaya `PaletteScope.of(context)` bisa dipanggil di mana saja
          builder: (context, child) {
            return PaletteScope(
              palette: palette,
              child: child ?? const SizedBox.shrink(),
            );
          },

          initialRoute: '/',
          onGenerateRoute: (settings) {
            switch (settings.name) {
              case '/':
                return MaterialPageRoute(
                  builder: (_) => const PintuPage(),
                );

              case '/landing':
                return MaterialPageRoute(
                  builder: (_) => const LandingPage(),
                );

              case '/login':
                return MaterialPageRoute(
                  builder: (_) => const LoginPage(),
                );

              case '/buy':
                return MaterialPageRoute(
                  builder: (_) => const BuyAccountPage(),
                );

              case '/dashboard':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => DashboardPage(
                    username: args['username'],
                    password: args['password'],
                    role: args['role'],
                    sessionKey: args['key'],
                    expiredDate: args['expiredDate'],
                    listBug: List<Map<String, dynamic>>.from(
                        args['listBug'] ?? []),
                    listBugGlobal: List<Map<String, dynamic>>.from(  // ← TAMBAHAN
                        args['listBugGlobal'] ?? []),
                    listBugGroup: List<Map<String, dynamic>>.from(   // ← TAMBAHAN
                        args['listBugGroup'] ?? []),
                    listDoos: List<Map<String, dynamic>>.from(
                        args['listDoos'] ?? []),
                    news: List<Map<String, dynamic>>.from(
                        args['news'] ?? []),
                  ),
                );

              case '/home':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => HomePage(
                    username: args['username'],
                    password: args['password'],
                    listBug: List<Map<String, dynamic>>.from(
                        args['listBug'] ?? []),
                    listBugGlobal: List<Map<String, dynamic>>.from(  // ← TAMBAHAN
                        args['listBugGlobal'] ?? []),
                    listBugGroup: List<Map<String, dynamic>>.from(   // ← TAMBAHAN
                        args['listBugGroup'] ?? []),
                    role: args['role'],
                    expiredDate: args['expiredDate'],
                    sessionKey: args['sessionKey'],
                  ),
                );

              case '/seller':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => SellerPage(
                    keyToken: args['keyToken'],
                  ),
                );

              case '/admin':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => AdminPage(
                    sessionKey: args['sessionKey'],
                  ),
                );

              case '/owner':
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (_) => OwnerPage(
                    sessionKey: args['sessionKey'],
                    username: args['username'],
                  ),
                );

              default:
                return MaterialPageRoute(
                  builder: (_) => const Scaffold(
                    body: Center(child: Text("404 - Not Found")),
                  ),
                );
            }
          },
        );
      },
    );
  }
}