plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.nullx.atomic"
    compileSdk = 36
    ndkVersion = "28.2.13676358"

    // ═══════════════════════════════════════════════════════════════════
    // 🔧 FIX: Core Library Desugaring (buat flutter_local_notifications)
    // ═══════════════════════════════════════════════════════════════════
    compileOptions {
        isCoreLibraryDesugaringEnabled = true          // ← TAMBAH INI
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    tasks.withType<JavaCompile>().configureEach {
        options.compilerArgs.addAll(listOf(
            "-Xlint:-deprecation",
            "-Xlint:-unchecked",
            "-Xlint:none",
            "-nowarn"
        ))
        options.isWarnings = false
    }

    kotlinOptions {
        jvmTarget = "11"
        freeCompilerArgs = listOf("-Xno-source-debug-extension")
    }

    defaultConfig {
        applicationId = "com.nullx.atomic"
        minSdk = 24                          // ← Naikin ke 24 (WebRTC butuh minimal ini)
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true               // ← TAMBAH INI (buat WebRTC)
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    lint {
        disable += "Deprecation"
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            // ═══ FIX: Exclude native lib duplikat (WebRTC) ═══
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE"
            excludes += "/META-INF/LICENSE.txt"
            excludes += "/META-INF/NOTICE"
            excludes += "/META-INF/NOTICE.txt"
        }
        // ═══ FIX: Pick first native lib (WebRTC) ═══
        jniLibs {
            pickFirsts += "**/libc++_shared.so"
            pickFirsts += "**/libjingle_peerconnection_so.so"
        }
    }
}

flutter {
    source = "../.."
}

// ═══════════════════════════════════════════════════════════════════════
// 🔧 FIX: Desugar library (buat flutter_local_notifications)
// ═══════════════════════════════════════════════════════════════════════
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}