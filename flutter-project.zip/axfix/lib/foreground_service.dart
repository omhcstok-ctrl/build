// foreground_service.dart
// ═══════════════════════════════════════════════════════════════════════════
// FOREGROUND SERVICE — biar notif call tetep masuk walau app di background
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(ForegroundTaskHandler());
}

class ForegroundTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    debugPrint('[FOREGROUND] Task started at $timestamp');
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    // Dipanggil tiap interval
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    debugPrint('[FOREGROUND] Task destroyed');
  }

  @override
  void onReceiveData(Object data) {
    try {
      if (data is Map) {
        debugPrint('[FOREGROUND] Data (Map): $data');
        return;
      }

      if (data is String) {
        try {
          final json = jsonDecode(data);
          debugPrint('[FOREGROUND] Data (String→JSON): $json');
        } catch (_) {
          debugPrint('[FOREGROUND] Data (String): $data');
        }
        return;
      }

      debugPrint('[FOREGROUND] Data (Unknown type): $data');
    } catch (e) {
      debugPrint('[FOREGROUND] Error parse data: $e');
    }
  }

  @override
  void onNotificationButtonPressed(String id) {
    debugPrint('[FOREGROUND] Button: $id');
    if (id == 'accept_call' || id == 'reject_call') {
      FlutterForegroundTask.sendDataToMain(id);
    }
  }

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }
}

class ForegroundService {
  static final ForegroundService _instance = ForegroundService._internal();
  factory ForegroundService() => _instance;
  ForegroundService._internal();

  bool _isRunning = false;

  Future<void> init() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'foreground_service_channel',
        channelName: 'Foreground Service',
        channelDescription: 'Service buat panggilan realtime',
        channelImportance: NotificationChannelImportance.HIGH,
        priority: NotificationPriority.HIGH,
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );

    final perm = await FlutterForegroundTask.checkNotificationPermission();
    if (perm != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }

    await FlutterForegroundTask.requestIgnoreBatteryOptimization();
  }

  Future<void> start({
    required String title,
    required String text,
  }) async {
    if (_isRunning) {
      debugPrint('[FOREGROUND] Already running');
      return;
    }

    final result = await FlutterForegroundTask.startService(
      notificationTitle: title,
      notificationText: text,
      notificationIcon: const NotificationIcon(
        metaDataName: 'com.example.xxo25.NOTIFICATION_ICON',
      ),
      callback: startCallback,
    );

    _isRunning = result is ServiceRequestSuccess;
    debugPrint('[FOREGROUND] Started: $_isRunning');
  }

  Future<void> update({
    required String title,
    required String text,
  }) async {
    await FlutterForegroundTask.updateService(
      notificationTitle: title,
      notificationText: text,
    );
  }

  Future<void> stop() async {
    if (!_isRunning) return;
    await FlutterForegroundTask.stopService();
    _isRunning = false;
    debugPrint('[FOREGROUND] Stopped');
  }

  void sendToMain(Map<String, dynamic> data) {
    FlutterForegroundTask.sendDataToMain(data);
  }

  bool get isRunning => _isRunning;
}