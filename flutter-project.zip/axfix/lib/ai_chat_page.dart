// ai_chat_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// AI CHAT — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'glass_theme.dart';

class AiChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const AiChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  final List<Map<String, dynamic>> _messages = [];
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _messages.add({
      'from': 'Atomic AI',
      'message':
          'Halo ${widget.username}! 👋\n\nAku Atomic AI, asisten cerdas dari ATOMIC X PROJECT. Tanya apa aja ya, aku siap bantu!',
      'time': DateTime.now().toIso8601String(),
      'fromMe': false,
      'isAi': true,
    });
  }

  Future<void> _sendMessage() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _loading) return;

    setState(() {
      _messages.add({
        'from': widget.username,
        'message': text,
        'time': DateTime.now().toIso8601String(),
        'fromMe': true,
        'isAi': false,
      });
      _loading = true;
    });
    _msgCtrl.clear();
    _scrollToBottom();

    try {
      final res = await http.post(
        Uri.parse(apiUrl('/api/ai/deepseek')),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'ask': text,
        }),
      ).timeout(const Duration(seconds: 50));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final reply =
            (data['reply'] ?? data['result'] ?? 'Gak ada jawaban').toString();

        setState(() {
          _messages.add({
            'from': 'Atomic AI',
            'message': reply,
            'time': DateTime.now().toIso8601String(),
            'fromMe': false,
            'isAi': true,
          });
          _loading = false;
        });
      } else {
        final errBody = jsonDecode(res.body);
        final errMsg = (errBody['error'] ?? 'Error ${res.statusCode}').toString();
        setState(() {
          _messages.add({
            'from': 'Atomic AI',
            'message': '❌ $errMsg',
            'time': DateTime.now().toIso8601String(),
            'fromMe': false,
            'isAi': true,
          });
          _loading = false;
        });
      }
    } catch (e) {
      setState(() {
        _messages.add({
          'from': 'Atomic AI',
          'message': '❌ Gagal konek ke server. Cek koneksi lu ya.',
          'time': DateTime.now().toIso8601String(),
          'fromMe': false,
          'isAi': true,
        });
        _loading = false;
      });
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(child: _buildMessages()),
              _buildInputBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: GlassPalette.teal,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.teal.withOpacity(0.7),
                  blurRadius: 10,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'ATOMIC AI',
            style: GlassFont.pixel(
              size: 11,
              weight: FontWeight.w700,
              color: GlassPalette.white,
              letterSpacing: 1.5,
              shadows: const [
                Shadow(color: Color(0x662AABEE), blurRadius: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessages() {
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      itemCount: _messages.length + (_loading ? 1 : 0),
      itemBuilder: (_, i) {
        if (i == _messages.length && _loading) {
          return _buildLoadingBubble();
        }
        final m = _messages[i];
        return _buildBubble(m, m['fromMe'] == true);
      },
    );
  }

  Widget _buildLoadingBubble() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, right: 60),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Center(
              child: SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                    color: GlassPalette.white, strokeWidth: 2),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: Text('Atomic AI sedang mikir...',
                style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub)),
          ),
        ],
      ),
    );
  }

  Widget _buildBubble(Map m, bool fromMe) {
    final isAi = m['isAi'] == true;
    final sender = (m['from'] ?? '').toString();

    return Padding(
      padding: EdgeInsets.only(
        bottom: 10,
        left: fromMe ? 60 : 0,
        right: fromMe ? 0 : 60,
      ),
      child: Column(
        crossAxisAlignment:
            fromMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (!fromMe)
            Padding(
              padding: const EdgeInsets.only(left: 44, bottom: 5),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    sender,
                    style: GlassFont.pixel(
                      size: 8,
                      weight: FontWeight.w700,
                      color: isAi ? GlassPalette.red : GlassPalette.orange,
                    ),
                  ),
                  if (isAi) ...[
                    const SizedBox(width: 4),
                    const Icon(Icons.auto_awesome_rounded,
                        color: GlassPalette.red, size: 12),
                  ],
                ],
              ),
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment:
                fromMe ? MainAxisAlignment.end : MainAxisAlignment.start,
            children: [
              if (!fromMe) ...[
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: isAi
                        ? GlassPalette.red.withOpacity(0.25)
                        : GlassPalette.orange.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isAi
                          ? GlassPalette.red.withOpacity(0.6)
                          : GlassPalette.orange.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: Icon(
                    isAi ? Icons.psychology_rounded : Icons.person_rounded,
                    color: GlassPalette.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: GestureDetector(
                  onLongPress: () {
                    Clipboard.setData(
                        ClipboardData(text: m['message'] ?? ''));
                    GlassDialog.show(
                      context,
                      title: 'Tersalin',
                      message: 'Pesan disalin!',
                      icon: Icons.copy_rounded,
                      accentColor: GlassPalette.teal,
                    );
                  },
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: fromMe
                          ? LinearGradient(
                              colors: [
                                GlassPalette.blue.withOpacity(0.4),
                                GlassPalette.purple.withOpacity(0.3),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : LinearGradient(
                              colors: [
                                Colors.white.withOpacity(0.12),
                                Colors.white.withOpacity(0.06),
                              ],
                            ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: fromMe
                            ? GlassPalette.blue.withOpacity(0.5)
                            : Colors.white.withOpacity(0.2),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (fromMe
                                  ? GlassPalette.blue
                                  : Colors.black)
                              .withOpacity(0.3),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        SelectableText(
                          m['message'] ?? '',
                          style: GlassFont.body(
                            size: 13,
                            weight: FontWeight.w500,
                            color: GlassPalette.white,
                            height: 1.4,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _formatTime(m['time'] ?? ''),
                              style: GlassFont.body(
                                size: 9,
                                weight: FontWeight.w500,
                                color: GlassPalette.textDim,
                              ),
                            ),
                            if (fromMe) ...[
                              const SizedBox(width: 4),
                              const Icon(Icons.done_all_rounded,
                                  color: GlassPalette.white, size: 12),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.2,
                ),
              ),
              child: TextField(
                controller: _msgCtrl,
                style: GlassFont.body(
                    size: 13,
                    weight: FontWeight.w500,
                    color: GlassPalette.white),
                cursorColor: GlassPalette.white,
                maxLength: 500,
                maxLines: null,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendMessage(),
                decoration: InputDecoration(
                  hintText: 'Tanya sesuatu ke Atomic AI...',
                  hintStyle: GlassFont.body(
                      size: 12,
                      weight: FontWeight.w400,
                      color: GlassPalette.textDim),
                  border: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  counterText: '',
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _loading ? null : _sendMessage,
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _loading
                      ? [
                          Colors.white.withOpacity(0.1),
                          Colors.white.withOpacity(0.05)
                        ]
                      : [
                          GlassPalette.blue.withOpacity(0.6),
                          GlassPalette.purple.withOpacity(0.5)
                        ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
                boxShadow: !_loading
                    ? [
                        BoxShadow(
                          color: GlassPalette.blue.withOpacity(0.5),
                          blurRadius: 15,
                        ),
                      ]
                    : null,
              ),
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            color: GlassPalette.white, strokeWidth: 2),
                      ),
                    )
                  : const Icon(Icons.send_rounded,
                      color: GlassPalette.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}