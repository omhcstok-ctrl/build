// chat_room_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// CHAT ROOM — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';
import 'app_config.dart';
import 'chat_service.dart';
import 'call_service.dart';
import 'call_screen.dart';
import 'incoming_call_screen.dart';
import 'notification_service.dart';
import 'glass_theme.dart';

class ChatRoomPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  final String withUser;

  const ChatRoomPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    required this.withUser,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  late ChatService _chat;
  late CallService _call;

  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _imagePicker = ImagePicker();

  List<ChatMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;
  Timer? _pollTimer;

  ChatMessage? _replyingTo;

  final _recorder = AudioRecorder();
  bool _isRecording = false;
  Timer? _recordTimer;
  int _recordSec = 0;

  final _audioPlayer = AudioPlayer();
  String? _playingId;

  bool _isCalling = false;
  bool _showingIncoming = false;

  @override
  void initState() {
    super.initState();
    _chat = ChatService(widget.sessionKey);
    _call = CallService(
      sessionKey: widget.sessionKey,
      myUsername: widget.username,
    );

    _initCall();

    _loadMessages();

    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _loadMessages(silent: true);
    });

    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playingId = null);
    });
  }

  Future<void> _initCall() async {
    await _call.init();
    _call.connectWebSocket();

    _call.onIncomingCall = (payload) async {
      if (!mounted) return;
      if (_showingIncoming) return;

      try {
        final data = jsonDecode(payload);
        final fromUser = data['from']?.toString() ?? '';
        final callType = data['callType'] == 'video'
            ? CallType.video
            : CallType.audio;
        final sdpOffer = data['sdp']?.toString() ?? '';
        final incomingCallId = data['callId']?.toString() ?? '';

        if (fromUser.isEmpty || sdpOffer.isEmpty) return;

        _showingIncoming = true;

        try {
          await NotificationService().showIncomingCall(
            fromUser: fromUser,
            callType: callType == CallType.video ? 'video' : 'audio',
            callId: incomingCallId,
          );
        } catch (e) {
          debugPrint('[CHAT] Notif error: $e');
        }

        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => IncomingCallScreen(
              callService: _call,
              fromUsername: fromUser,
              callType: callType,
              sdpOffer: sdpOffer,
              callId: incomingCallId,
            ),
          ),
        );
      } catch (e) {
        debugPrint('[CHAT] onIncomingCall error: $e');
      } finally {
        _showingIncoming = false;
      }
    };

    _call.onCallEnded = () {
      if (!mounted) return;
      NotificationService().cancelIncomingCall().catchError((_) {});
    };
  }

  Future<void> _loadMessages({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    final res = await _chat.getMessages(widget.withUser);
    if (!mounted) return;
    final hadNew = res.length != _messages.length;
    setState(() {
      _messages = res;
      _loading = false;
    });
    await _chat.markRead(widget.withUser);
    if (hadNew) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }
  }

  void _scrollToBottom() {
    if (!_scrollCtrl.hasClients) return;
    _scrollCtrl.animateTo(
      _scrollCtrl.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  Future<void> _sendText() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() => _sending = true);
    final replyId = _replyingTo?.id;
    _msgCtrl.clear();
    setState(() => _replyingTo = null);

    final ok = await _chat.sendText(
      to: widget.withUser,
      message: text,
      replyTo: replyId,
    );
    if (mounted) {
      setState(() => _sending = false);
      if (ok) {
        await _loadMessages(silent: true);
      } else {
        _showSnack('Gagal kirim pesan');
      }
    }
  }

  Future<void> _sendImage() async {
    try {
      final img = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 75,
        maxWidth: 1600,
      );
      if (img == null) return;

      setState(() => _sending = true);
      final replyId = _replyingTo?.id;
      setState(() => _replyingTo = null);

      final ok = await _chat.sendMedia(
        to: widget.withUser,
        file: File(img.path),
        type: 'image',
        replyTo: replyId,
      );
      if (mounted) {
        setState(() => _sending = false);
        if (ok) {
          _loadMessages(silent: true);
        } else {
          _showSnack('Gagal kirim gambar');
        }
      }
    } catch (e) {
      if (mounted) setState(() => _sending = false);
      _showSnack('Error: $e');
    }
  }

  Future<void> _sendVideo() async {
    try {
      final vid = await _imagePicker.pickVideo(source: ImageSource.gallery);
      if (vid == null) return;

      setState(() => _sending = true);
      final replyId = _replyingTo?.id;
      setState(() => _replyingTo = null);

      final ok = await _chat.sendMedia(
        to: widget.withUser,
        file: File(vid.path),
        type: 'video',
        replyTo: replyId,
      );
      if (mounted) {
        setState(() => _sending = false);
        if (ok) {
          _loadMessages(silent: true);
        } else {
          _showSnack('Gagal kirim video');
        }
      }
    } catch (e) {
      if (mounted) setState(() => _sending = false);
      _showSnack('Error: $e');
    }
  }

  Future<void> _startRecord() async {
    try {
      final perm = await Permission.microphone.request();
      if (!perm.isGranted) {
        _showSnack('Izin mikrofon ditolak');
        return;
      }

      final dir = await getTemporaryDirectory();
      final path =
          '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc),
        path: path,
      );

      setState(() {
        _isRecording = true;
        _recordSec = 0;
      });

      _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recordSec++);
      });
    } catch (e) {
      _showSnack('Gagal mulai rekam: $e');
    }
  }

  Future<void> _stopAndSendRecord() async {
    try {
      final path = await _recorder.stop();
      _recordTimer?.cancel();
      setState(() {
        _isRecording = false;
        _recordSec = 0;
      });

      if (path == null) return;
      final file = File(path);
      if (!await file.exists()) return;

      setState(() => _sending = true);
      final replyId = _replyingTo?.id;
      setState(() => _replyingTo = null);

      final ok = await _chat.sendMedia(
        to: widget.withUser,
        file: file,
        type: 'voice',
        replyTo: replyId,
      );
      if (mounted) {
        setState(() => _sending = false);
        if (ok) {
          _loadMessages(silent: true);
        } else {
          _showSnack('Gagal kirim voice note');
        }
      }
    } catch (e) {
      if (mounted) setState(() => _sending = false);
      _showSnack('Error: $e');
    }
  }

  Future<void> _cancelRecord() async {
    try {
      await _recorder.stop();
      _recordTimer?.cancel();
      setState(() {
        _isRecording = false;
        _recordSec = 0;
      });
    } catch (_) {}
  }

  Future<void> _playVoice(ChatMessage m) async {
    if (m.mediaUrl == null) return;
    try {
      if (_playingId == m.id) {
        await _audioPlayer.stop();
        setState(() => _playingId = null);
        return;
      }
      await _audioPlayer.stop();
      setState(() => _playingId = m.id);
      await _audioPlayer.play(UrlSource(m.mediaUrl!));
    } catch (e) {
      _showSnack('Gagal play: $e');
      setState(() => _playingId = null);
    }
  }

  void _openImageFullscreen(ChatMessage m) {
    if (m.mediaUrl == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _ImageFullscreenPage(imageUrl: m.mediaUrl!),
      ),
    );
  }

  void _openVideoPlayer(ChatMessage m) {
    if (m.mediaUrl == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _VideoFullscreenPage(videoUrl: m.mediaUrl!),
      ),
    );
  }

  Future<void> _startAudioCall() async {
    if (_isCalling) return;

    final micPerm = await Permission.microphone.request();
    if (!micPerm.isGranted) {
      _showSnack('Izin mikrofon dibutuhkan buat call');
      return;
    }

    setState(() => _isCalling = true);

    try {
      await _call.startCall(
        toUsername: widget.withUser,
        type: CallType.audio,
      );

      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CallScreen(
            callService: _call,
            peerUsername: widget.withUser,
            callType: CallType.audio,
            isIncoming: false,
          ),
        ),
      );
    } catch (e) {
      _showSnack('Gagal memulai panggilan: $e');
    } finally {
      if (mounted) setState(() => _isCalling = false);
    }
  }

  Future<void> _startVideoCall() async {
    if (_isCalling) return;

    final micPerm = await Permission.microphone.request();
    final camPerm = await Permission.camera.request();
    if (!micPerm.isGranted || !camPerm.isGranted) {
      _showSnack('Izin kamera & mikrofon dibutuhkan buat video call');
      return;
    }

    setState(() => _isCalling = true);

    try {
      await _call.startCall(
        toUsername: widget.withUser,
        type: CallType.video,
      );

      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CallScreen(
            callService: _call,
            peerUsername: widget.withUser,
            callType: CallType.video,
            isIncoming: false,
          ),
        ),
      );
    } catch (e) {
      _showSnack('Gagal memulai video call: $e');
    } finally {
      if (mounted) setState(() => _isCalling = false);
    }
  }

  void _showMessageOptions(ChatMessage m) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.5),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withOpacity(0.25),
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
              margin: const EdgeInsets.only(bottom: 12),
            ),
            _menuOption(
              icon: Icons.reply_rounded,
              label: 'Reply Pesan',
              color: GlassPalette.teal,
              onTap: () {
                Navigator.pop(context);
                setState(() => _replyingTo = m);
              },
            ),
            const SizedBox(height: 8),
            _menuOption(
              icon: Icons.person_remove_rounded,
              label: 'Hapus untuk Saya',
              color: GlassPalette.orange,
              onTap: () async {
                Navigator.pop(context);
                await _deleteMessage(m, 'me');
              },
            ),
            if (m.fromMe) ...[
              const SizedBox(height: 8),
              _menuOption(
                icon: Icons.delete_forever_rounded,
                label: 'Hapus untuk Semua',
                color: GlassPalette.red,
                onTap: () async {
                  Navigator.pop(context);
                  await _deleteMessage(m, 'everyone');
                },
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _menuOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: color.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: Icon(icon, color: GlassPalette.white, size: 16),
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteMessage(ChatMessage m, String mode) async {
    final ok = await _chat.deleteMessage(messageId: m.id, mode: mode);
    if (!mounted) return;
    if (ok) {
      _showSnack(mode == 'everyone'
          ? 'Pesan dihapus untuk semua'
          : 'Pesan dihapus untuk kamu');
      _loadMessages(silent: true);
    } else {
      _showSnack('Gagal hapus pesan');
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: GlassFont.body(size: 12, color: GlassPalette.white)),
        backgroundColor: GlassPalette.red.withOpacity(0.9),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _recordTimer?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _recorder.dispose();
    _audioPlayer.dispose();
    _call.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: _loading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: GlassPalette.white))
                    : _buildMessages(),
              ),
              if (_replyingTo != null) _buildReplyPreview(),
              _isRecording ? _buildRecordingBar() : _buildInputBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 18),
            ),
          ),
          const SizedBox(width: 10),

          Container(
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: CircleAvatar(
              radius: 20,
              backgroundColor: GlassPalette.teal.withOpacity(0.3),
              child: Text(
                widget.withUser.isNotEmpty
                    ? widget.withUser[0].toUpperCase()
                    : '?',
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.withUser,
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: GlassPalette.teal,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'Online',
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w500,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          GestureDetector(
            onTap: _isCalling ? null : _startAudioCall,
            child: Container(
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.teal.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: _isCalling
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        color: GlassPalette.white,
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(Icons.call_rounded,
                      color: GlassPalette.white, size: 18),
            ),
          ),

          GestureDetector(
            onTap: _isCalling ? null : _startVideoCall,
            child: Container(
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.red.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: _isCalling
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        color: GlassPalette.white,
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(Icons.videocam_rounded,
                      color: GlassPalette.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessages() {
    if (_messages.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: GlassPalette.blue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(0.6),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: GlassPalette.blue.withOpacity(0.5),
                      blurRadius: 25,
                    ),
                  ],
                ),
                child: const Icon(Icons.waving_hand_rounded,
                    color: GlassPalette.white, size: 42),
              ),
              const SizedBox(height: 18),
              Text(
                'MULAI CHAT',
                style: GlassFont.pixel(
                  size: 12,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Kirim pesan pertama ke ${widget.withUser}',
                textAlign: TextAlign.center,
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      itemCount: _messages.length,
      itemBuilder: (_, i) => _buildBubble(_messages[i]),
    );
  }

  Widget _buildBubble(ChatMessage m) {
    final isMe = m.fromMe;
    return GestureDetector(
      onLongPress: () => _showMessageOptions(m),
      child: Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.75,
          ),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: isMe
                ? LinearGradient(
                    colors: [
                      GlassPalette.blue.withOpacity(0.4),
                      GlassPalette.purple.withOpacity(0.3),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.12),
                      Colors.white.withOpacity(0.06),
                    ],
                  ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isMe
                  ? GlassPalette.blue.withOpacity(0.5)
                  : Colors.white.withOpacity(0.2),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: (isMe ? GlassPalette.blue : Colors.black)
                    .withOpacity(0.3),
                blurRadius: 12,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (m.replyTo != null && m.replyPreview != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6),
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                      left: BorderSide(
                          color: GlassPalette.teal, width: 4),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        m.replyFrom ?? 'Reply',
                        style: GlassFont.pixel(
                          size: 8,
                          weight: FontWeight.w700,
                          color: GlassPalette.teal,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        m.replyPreview!,
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w500,
                          color: GlassPalette.textSub,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),

              if (m.type == 'reaction') _reactionContent(m),
              if (m.type == 'reply_status') _replyStatusContent(m),
              if (m.type == 'text') _textContent(m),
              if (m.type == 'image') _imageContent(m),
              if (m.type == 'video') _videoContent(m),
              if (m.type == 'voice') _voiceContent(m),
              const SizedBox(height: 4),
              Text(
                _timeAgo(m.createdAt),
                style: GlassFont.body(
                  size: 8,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _textContent(ChatMessage m) {
    return Text(
      m.message,
      style: GlassFont.body(
        size: 13,
        weight: FontWeight.w500,
        color: GlassPalette.white,
        height: 1.4,
      ),
    );
  }

  Widget _reactionContent(ChatMessage m) {
    return Row(
      children: [
        Text(
          m.reaction ?? '❤️',
          style: const TextStyle(fontSize: 28),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            m.message,
            style: GlassFont.body(
              size: 12,
              weight: FontWeight.w500,
              color: GlassPalette.white,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }

  Widget _replyStatusContent(ChatMessage m) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
          decoration: BoxDecoration(
            color: GlassPalette.teal.withOpacity(0.25),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: GlassPalette.teal.withOpacity(0.6),
              width: 1.2,
            ),
          ),
          child: Text(
            'BALASAN STATUS',
            style: GlassFont.pixel(
              size: 8,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          m.message,
          style: GlassFont.body(
            size: 12,
            weight: FontWeight.w500,
            color: GlassPalette.white,
            height: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _imageContent(ChatMessage m) {
    if (m.mediaUrl == null) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => _openImageFullscreen(m),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: CachedNetworkImage(
          imageUrl: m.mediaUrl!,
          fit: BoxFit.cover,
          width: 220,
          placeholder: (_, __) => Container(
            width: 220,
            height: 150,
            color: Colors.white.withOpacity(0.1),
            child: const Center(
              child: CircularProgressIndicator(
                  color: GlassPalette.white, strokeWidth: 2),
            ),
          ),
          errorWidget: (_, __, ___) => Container(
            width: 220,
            height: 150,
            color: Colors.white.withOpacity(0.1),
            child: const Center(
              child: Icon(Icons.broken_image_rounded,
                  color: GlassPalette.textDim, size: 30),
            ),
          ),
        ),
      ),
    );
  }

  Widget _videoContent(ChatMessage m) {
    if (m.mediaUrl == null) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => _openVideoPlayer(m),
      child: Container(
        width: 220,
        height: 150,
        decoration: BoxDecoration(
          color: GlassPalette.blue.withOpacity(0.25),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: GlassPalette.blue.withOpacity(0.6),
            width: 1.2,
          ),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const Center(
              child: Icon(Icons.play_circle_filled_rounded,
                  color: GlassPalette.white, size: 52),
            ),
            Positioned(
              bottom: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'VIDEO',
                  style: GlassFont.pixel(
                    size: 8,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _voiceContent(ChatMessage m) {
    final playing = _playingId == m.id;
    return GestureDetector(
      onTap: () => _playVoice(m),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              playing
                  ? Icons.pause_circle_filled_rounded
                  : Icons.play_circle_filled_rounded,
              color: GlassPalette.white,
              size: 26,
            ),
            const SizedBox(width: 8),
            Row(
              children: List.generate(12, (i) {
                final h = 4.0 + (i % 4) * 3.0;
                return Container(
                  width: 3,
                  height: h,
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  color: playing ? GlassPalette.red : GlassPalette.textDim,
                );
              }),
            ),
            const SizedBox(width: 8),
            Text(
              'Voice',
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w600,
                color: GlassPalette.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReplyPreview() {
    final m = _replyingTo!;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 40,
            decoration: BoxDecoration(
              color: GlassPalette.teal,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const Icon(Icons.reply_rounded,
                        color: GlassPalette.teal, size: 12),
                    const SizedBox(width: 4),
                    Text(
                      'Balas ke ${m.fromMe ? "diri sendiri" : widget.withUser}',
                      style: GlassFont.pixel(
                        size: 8,
                        weight: FontWeight.w700,
                        color: GlassPalette.teal,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  _replyPreviewText(m),
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => setState(() => _replyingTo = null),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.close_rounded,
                  color: GlassPalette.white, size: 14),
            ),
          ),
        ],
      ),
    );
  }

  String _replyPreviewText(ChatMessage m) {
    switch (m.type) {
      case 'image':
        return '📷 Foto';
      case 'video':
        return '🎥 Video';
      case 'voice':
        return '🎤 Voice Note';
      case 'reaction':
        return '${m.reaction ?? "❤️"} ${m.message}';
      case 'reply_status':
        return m.message;
      default:
        return m.message;
    }
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _miniBtn(
            icon: Icons.image_rounded,
            onTap: _sending ? null : _sendImage,
          ),
          const SizedBox(width: 6),
          _miniBtn(
            icon: Icons.videocam_rounded,
            onTap: _sending ? null : _sendVideo,
          ),
          const SizedBox(width: 6),
          _miniBtn(
            icon: Icons.mic_rounded,
            onTap: _sending ? null : _startRecord,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.2,
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: TextField(
                controller: _msgCtrl,
                minLines: 1,
                maxLines: 4,
                style: GlassFont.body(
                  size: 13,
                  weight: FontWeight.w500,
                  color: GlassPalette.white,
                ),
                cursorColor: GlassPalette.white,
                decoration: InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w500,
                    color: GlassPalette.textDim,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: _sending ? null : _sendText,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    GlassPalette.blue.withOpacity(0.6),
                    GlassPalette.purple.withOpacity(0.5),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: _sending
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          color: GlassPalette.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.send_rounded,
                      color: GlassPalette.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecordingBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          top: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _cancelRecord,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.close_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(
              color: GlassPalette.red,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Merekam... ${_recordSec}s',
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
          ),
          GestureDetector(
            onTap: _stopAndSendRecord,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    GlassPalette.blue.withOpacity(0.6),
                    GlassPalette.purple.withOpacity(0.5),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: const Icon(Icons.send_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniBtn({required IconData icon, VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.2,
          ),
        ),
        child: Icon(icon, color: GlassPalette.white, size: 18),
      ),
    );
  }

  String _timeAgo(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m';
    } catch (_) {
      return '';
    }
  }
}

class _ImageFullscreenPage extends StatelessWidget {
  final String imageUrl;
  const _ImageFullscreenPage({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.6),
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: GlassPalette.white, size: 18),
          ),
        ),
        title: Text(
          'FOTO',
          style: GlassFont.pixel(
            size: 10,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
      body: PhotoView(
        imageProvider: CachedNetworkImageProvider(imageUrl),
        minScale: PhotoViewComputedScale.contained,
        maxScale: PhotoViewComputedScale.covered * 3,
        initialScale: PhotoViewComputedScale.contained,
        backgroundDecoration: const BoxDecoration(color: Colors.black),
        loadingBuilder: (context, event) => const Center(
          child: CircularProgressIndicator(
              color: GlassPalette.white, strokeWidth: 2),
        ),
        errorBuilder: (context, error, stackTrace) => const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.broken_image_rounded,
                  color: Colors.white54, size: 80),
              SizedBox(height: 12),
              Text('Gagal memuat gambar',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _VideoFullscreenPage extends StatefulWidget {
  final String videoUrl;
  const _VideoFullscreenPage({required this.videoUrl});

  @override
  State<_VideoFullscreenPage> createState() => _VideoFullscreenPageState();
}

class _VideoFullscreenPageState extends State<_VideoFullscreenPage> {
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool _initializing = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      _videoController = VideoPlayerController.networkUrl(
        Uri.parse(widget.videoUrl),
      );

      await _videoController.initialize();

      _chewieController = ChewieController(
        videoPlayerController: _videoController,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showControls: true,
        aspectRatio: _videoController.value.aspectRatio,
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_rounded,
                    color: Colors.white54, size: 60),
                const SizedBox(height: 12),
                Text(
                  'Gagal memutar video',
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w500,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          );
        },
      );

      if (mounted) setState(() => _initializing = false);
    } catch (e) {
      if (mounted) {
        setState(() {
          _initializing = false;
          _error = e.toString();
        });
      }
    }
  }

  @override
  void dispose() {
    _chewieController?.dispose();
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.6),
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: GlassPalette.white, size: 18),
          ),
        ),
        title: Text(
          'VIDEO',
          style: GlassFont.pixel(
            size: 10,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
      body: Center(
        child: _initializing
            ? const CircularProgressIndicator(
                color: GlassPalette.white, strokeWidth: 2)
            : _error != null
                ? Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.broken_image_rounded,
                            color: Colors.white54, size: 80),
                        const SizedBox(height: 12),
                        Text(
                          'Gagal memuat video',
                          style: GlassFont.pixel(
                            size: 11,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w400,
                            color: Colors.white54,
                          ),
                        ),
                      ],
                    ),
                  )
                : _chewieController != null
                    ? AspectRatio(
                        aspectRatio: _videoController.value.aspectRatio,
                        child: Chewie(controller: _chewieController!),
                      )
                    : const SizedBox.shrink(),
      ),
    );
  }
}