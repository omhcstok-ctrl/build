// status_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// STATUS PAGE (ATOMIC X GRAM) — GLASSMORPHISM EDITION
// Support: Foto, Video, Teks (dengan pilih warna background)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'app_config.dart';
import 'status_viewer.dart';
import 'glass_theme.dart';

class StatusPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const StatusPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> {
  List<dynamic> _statuses = [];
  List<dynamic> _myStatuses = [];
  bool _loading = true;
  final ImagePicker _picker = ImagePicker();

  final List<Color> _textColors = [
    const Color(0xFF1A1A1A),
    const Color(0xFF2563EB),
    const Color(0xFF16A34A),
    const Color(0xFFE53935),
    const Color(0xFFFF6D00),
    const Color(0xFF7C3AED),
    const Color(0xFF1E8A76),
    const Color(0xFFB45309),
  ];

  @override
  void initState() {
    super.initState();
    _fetchStatus();
  }

  Future<void> _fetchStatus() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/status/list?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _statuses = data['statuses'] ?? [];
      }

      final res2 = await http.get(
        Uri.parse('$kBaseUrl/status/my?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data2 = jsonDecode(res2.body);
      if (data2['valid'] == true) {
        _myStatuses = data2['statuses'] ?? [];
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SHOW PICKER TIPE STATUS
  // ═══════════════════════════════════════════════════════════════════════
  void _showTypePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: GlassPalette.bg.withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 25,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
              margin: const EdgeInsets.only(bottom: 12),
            ),
            Text(
              'PILIH TIPE STATUS',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _typeOption(
                    icon: Icons.image_rounded,
                    label: 'FOTO',
                    color: GlassPalette.teal,
                    onTap: () {
                      Navigator.pop(context);
                      _pickAndUploadImage();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _typeOption(
                    icon: Icons.videocam_rounded,
                    label: 'VIDEO',
                    color: GlassPalette.red,
                    onTap: () {
                      Navigator.pop(context);
                      _pickAndUploadVideo();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _typeOption(
                    icon: Icons.text_fields_rounded,
                    label: 'TEKS',
                    color: GlassPalette.purple,
                    onTap: () {
                      Navigator.pop(context);
                      _pickAndUploadText();
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _typeOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withOpacity(0.6),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 12,
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.35),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: color.withOpacity(0.7),
                  width: 1.2,
                ),
              ),
              child: Icon(icon, color: GlassPalette.white, size: 24),
            ),
            const SizedBox(height: 10),
            Text(
              label,
              style: GlassFont.pixel(
                size: 8,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickAndUploadImage() async {
    try {
      final image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1080,
      );
      if (image == null) return;

      final caption = await _promptCaption();
      if (caption == null) return;

      await _uploadMedia(
        file: File(image.path),
        type: 'image',
        caption: caption,
      );
    } catch (e) {
      if (mounted) {
        GlassDialog.show(context,
            title: 'Error',
            message: 'Error: $e',
            icon: Icons.error_outline,
            accentColor: GlassPalette.red);
      }
    }
  }

  Future<void> _pickAndUploadVideo() async {
    try {
      final video = await _picker.pickVideo(source: ImageSource.gallery);
      if (video == null) return;

      final file = File(video.path);
      final sizeInBytes = await file.length();
      final sizeInMB = sizeInBytes / (1024 * 1024);

      debugPrint('[ATOMIC-X] [VIDEO] Size: ${sizeInMB.toStringAsFixed(2)} MB');

      if (sizeInMB > 100) {
        if (mounted) {
          GlassDialog.show(context,
              title: 'Video Terlalu Besar',
              message:
                  'Ukuran video ${sizeInMB.toStringAsFixed(1)} MB. Maksimal 100 MB.\n\nSilakan pilih video lain atau kompres dulu.',
              icon: Icons.warning_amber_rounded,
              accentColor: GlassPalette.red);
        }
        return;
      }

      if (sizeInMB > 50) {
        final confirm = await showDialog<bool>(
          context: context,
          builder: (_) => GlassDialog(
            title: 'Video Besar',
            message:
                'Ukuran video ${sizeInMB.toStringAsFixed(1)} MB. Proses upload mungkin lama. Lanjutkan?',
            icon: Icons.info_outline,
            accentColor: GlassPalette.yellow,
            actions: [
              GlassButton(
                text: 'Batal',
                fullWidth: false,
                bgColor: Colors.white,
                onTap: () => Navigator.pop(context, false),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
              ),
              const SizedBox(width: 8),
              GlassButton(
                text: 'Lanjut',
                fullWidth: false,
                bgColor: GlassPalette.yellow,
                onTap: () => Navigator.pop(context, true),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
              ),
            ],
          ),
        );
        if (confirm != true) return;
      }

      final caption = await _promptCaption();
      if (caption == null) return;

      await _uploadMedia(
        file: file,
        type: 'video',
        caption: caption,
      );
    } catch (e) {
      if (mounted) {
        GlassDialog.show(context,
            title: 'Error',
            message: 'Error: $e',
            icon: Icons.error_outline,
            accentColor: GlassPalette.red);
      }
    }
  }

  Future<void> _pickAndUploadText() async {
    final ctrl = TextEditingController();
    Color selectedColor = _textColors[0];

    final result = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: GlassPalette.bg.withOpacity(0.95),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 30,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: GlassPalette.purple.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: GlassPalette.purple.withOpacity(0.7),
                          width: 1.2,
                        ),
                      ),
                      child: const Icon(Icons.text_fields_rounded,
                          color: GlassPalette.white, size: 18),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'STATUS TEKS',
                      style: GlassFont.pixel(
                        size: 10,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  height: 120,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: selectedColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.2,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      ctrl.text.isEmpty ? 'Preview text...' : ctrl.text,
                      style: GlassFont.pixel(
                        size: 11,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.2,
                    ),
                  ),
                  child: TextField(
                    controller: ctrl,
                    maxLines: 4,
                    minLines: 2,
                    style: GlassFont.body(
                      size: 13,
                      weight: FontWeight.w600,
                      color: GlassPalette.text,
                    ),
                    cursorColor: GlassPalette.white,
                    onChanged: (_) => setStateDialog(() {}),
                    decoration: InputDecoration(
                      hintText: 'Ketik status kamu...',
                      hintStyle: GlassFont.body(
                        size: 12,
                        weight: FontWeight.w600,
                        color: GlassPalette.textDim,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.all(12),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'PILIH WARNA',
                  style: GlassFont.pixel(
                    size: 8,
                    weight: FontWeight.w700,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _textColors.map((c) {
                    final selected = c.value == selectedColor.value;
                    return GestureDetector(
                      onTap: () =>
                          setStateDialog(() => selectedColor = c),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: c,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: selected
                                ? GlassPalette.white
                                : Colors.white.withOpacity(0.3),
                            width: selected ? 3 : 1.2,
                          ),
                          boxShadow: selected
                              ? [
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.4),
                                    blurRadius: 12,
                                  ),
                                ]
                              : null,
                        ),
                        child: selected
                            ? const Icon(Icons.check,
                                color: Colors.white, size: 18)
                            : null,
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: GlassButton(
                        text: 'Batal',
                        onTap: () => Navigator.pop(context, false),
                        bgColor: Colors.white,
                        textColor: GlassPalette.bg,
                        padding:
                            const EdgeInsets.symmetric(vertical: 12),
                        fontSize: 9,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GlassButton(
                        text: 'Upload',
                        onTap: () {
                          if (ctrl.text.trim().isEmpty) return;
                          Navigator.pop(context, true);
                        },
                        bgColor: GlassPalette.yellow,
                        textColor: GlassPalette.black,
                        padding:
                            const EdgeInsets.symmetric(vertical: 12),
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (result != true) return;
    final text = ctrl.text.trim();
    if (text.isEmpty) return;

    final hexColor =
        '#${selectedColor.value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';

    await _uploadText(text: text, bgColor: hexColor);
  }

  Future<String?> _promptCaption() async {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: GlassPalette.bg.withOpacity(0.95),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 30,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'CAPTION (OPSIONAL)',
                style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.text,
                ),
              ),
              const SizedBox(height: 14),
              GlassInput(
                controller: ctrl,
                hint: 'Tulis caption...',
                icon: Icons.text_fields,
                maxLines: 2,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      text: 'Batal',
                      onTap: () => Navigator.pop(context, ''),
                      bgColor: Colors.white,
                      textColor: GlassPalette.bg,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 9,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GlassButton(
                      text: 'Upload',
                      onTap: () => Navigator.pop(context, ctrl.text.trim()),
                      bgColor: GlassPalette.yellow,
                      textColor: GlassPalette.black,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _uploadMedia({
    required File file,
    required String type,
    String caption = '',
  }) async {
    _showLoadingDialog('Mengunggah ${type == 'video' ? 'video' : 'foto'}...');

    try {
      final uri = Uri.parse('$kBaseUrl/status/upload-media');
      final request = http.MultipartRequest('POST', uri);
      request.fields['key'] = widget.sessionKey;
      request.fields['username'] = widget.username;
      request.fields['type'] = type;
      request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('media', file.path));

      final streamedRes =
          await request.send().timeout(const Duration(seconds: 300));
      final res = await http.Response.fromStream(streamedRes);
      final data = jsonDecode(res.body);

      if (mounted) Navigator.pop(context);

      if (data['valid'] == true) {
        if (mounted) {
          GlassDialog.show(context,
              title: 'Sukses',
              message: 'Status berhasil diunggah!',
              icon: Icons.check_circle_rounded,
              accentColor: GlassPalette.teal);
        }
        _fetchStatus();
      } else {
        if (mounted) {
          GlassDialog.show(context,
              title: 'Gagal',
              message: data['message'] ?? 'Gagal upload',
              icon: Icons.error_outline,
              accentColor: GlassPalette.red);
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) {
        GlassDialog.show(context,
            title: 'Error',
            message: 'Error: $e',
            icon: Icons.error_outline,
            accentColor: GlassPalette.red);
      }
    }
  }

  Future<void> _uploadText({
    required String text,
    required String bgColor,
  }) async {
    _showLoadingDialog('Mengunggah status teks...');

    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/status/upload-text'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'username': widget.username,
          'text': text,
          'bgColor': bgColor,
        }),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (mounted) Navigator.pop(context);

      if (data['valid'] == true) {
        if (mounted) {
          GlassDialog.show(context,
              title: 'Sukses',
              message: 'Status teks berhasil diunggah!',
              icon: Icons.check_circle_rounded,
              accentColor: GlassPalette.teal);
        }
        _fetchStatus();
      } else {
        if (mounted) {
          GlassDialog.show(context,
              title: 'Gagal',
              message: data['message'] ?? 'Gagal upload',
              icon: Icons.error_outline,
              accentColor: GlassPalette.red);
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) {
        GlassDialog.show(context,
            title: 'Error',
            message: 'Error: $e',
            icon: Icons.error_outline,
            accentColor: GlassPalette.red);
      }
    }
  }

  void _showLoadingDialog(String text) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: GlassPalette.bg.withOpacity(0.95),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 30,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(
                  color: GlassPalette.white, strokeWidth: 3),
              const SizedBox(height: 16),
              Text(
                text,
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.text,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _deleteMyStatus(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => GlassDialog(
        title: 'Hapus Status?',
        message: 'Status bakal dihapus permanen.',
        icon: Icons.warning_amber_rounded,
        accentColor: GlassPalette.red,
        actions: [
          GlassButton(
            text: 'Batal',
            fullWidth: false,
            bgColor: Colors.white,
            onTap: () => Navigator.pop(context, false),
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          ),
          const SizedBox(width: 8),
          GlassButton(
            text: 'Hapus',
            fullWidth: false,
            bgColor: GlassPalette.red,
            textColor: GlassPalette.white,
            onTap: () => Navigator.pop(context, true),
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      final res = await http.delete(
        Uri.parse(
            '$kBaseUrl/status/delete?key=${widget.sessionKey}&status_id=$id'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _fetchStatus();
      }
    } catch (_) {}
  }

  void _openViewer(int index) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatusViewer(
          statuses: _statuses,
          initialIndex: index,
          sessionKey: widget.sessionKey,
          username: widget.username,
        ),
      ),
    ).then((_) => _fetchStatus());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: _loading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: GlassPalette.white))
                    : RefreshIndicator(
                        onRefresh: _fetchStatus,
                        color: GlassPalette.white,
                        child: ListView(
                          padding: const EdgeInsets.all(16),
                          children: [
                            if (_myStatuses.isNotEmpty) ...[
                              Text(
                                'STATUS SAYA',
                                style: GlassFont.pixel(
                                  size: 8,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.textSub,
                                ),
                              ),
                              const SizedBox(height: 10),
                              SizedBox(
                                height: 110,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: _myStatuses.length,
                                  itemBuilder: (_, i) {
                                    final st = _myStatuses[i];
                                    return Padding(
                                      padding:
                                          const EdgeInsets.only(right: 10),
                                      child: GestureDetector(
                                        onTap: () {
                                          showDialog(
                                            context: context,
                                            builder: (_) => Dialog(
                                              backgroundColor:
                                                  Colors.transparent,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                child: _previewMyStatus(st),
                                              ),
                                            ),
                                          );
                                        },
                                        onLongPress: () =>
                                            _deleteMyStatus(st['id']),
                                        child: Column(
                                          children: [
                                            Container(
                                              width: 80,
                                              height: 80,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                                color: Colors.white
                                                    .withOpacity(0.08),
                                                border: Border.all(
                                                  color: Colors.white
                                                      .withOpacity(0.25),
                                                  width: 1.5,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: GlassPalette.blue
                                                        .withOpacity(0.3),
                                                    blurRadius: 12,
                                                  ),
                                                ],
                                              ),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                                child: _thumbMyStatus(st),
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              '${st['view_count'] ?? 0} views',
                                              style: GlassFont.body(
                                                size: 9,
                                                weight: FontWeight.w600,
                                                color:
                                                    GlassPalette.textSub,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(height: 20),
                            ],
                            Text(
                              'STATUS TERBARU',
                              style: GlassFont.pixel(
                                size: 8,
                                weight: FontWeight.w700,
                                color: GlassPalette.textSub,
                              ),
                            ),
                            const SizedBox(height: 10),
                            if (_statuses.isEmpty)
                              GlassCard(
                                borderWidth: 1.5,
                                radius: 20,
                                padding: const EdgeInsets.all(40),
                                child: Center(
                                  child: Text(
                                    'Belum ada status dari user lain',
                                    style: GlassFont.body(
                                      size: 12,
                                      weight: FontWeight.w600,
                                      color: GlassPalette.textSub,
                                    ),
                                  ),
                                ),
                              )
                            else
                              ..._statuses.asMap().entries.map((entry) {
                                final idx = entry.key;
                                final user = entry.value;
                                return _buildStatusUserCard(user, idx);
                              }),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showTypePicker,
        backgroundColor: GlassPalette.blue.withOpacity(0.9),
        foregroundColor: GlassPalette.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(
            color: Colors.white.withOpacity(0.3),
            width: 1.2,
          ),
        ),
        icon: const Icon(Icons.add_a_photo_rounded,
            color: GlassPalette.white),
        label: Text(
          'Upload Status',
          style: GlassFont.pixel(
            size: 8,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
    );
  }

  Widget _thumbMyStatus(dynamic st) {
    final type = (st['type'] ?? 'image').toString();
    final image = (st['image'] ?? '').toString();
    final text = (st['text'] ?? '').toString();
    final bgColor = (st['bgColor'] ?? '#1A1A1A').toString();

    if (type == 'text') {
      return Container(
        color: _hexToColor(bgColor),
        padding: const EdgeInsets.all(6),
        child: Center(
          child: Text(
            text,
            style: GlassFont.pixel(
              size: 6,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    if (type == 'video') {
      return Stack(
        fit: StackFit.expand,
        children: [
          Container(color: GlassPalette.blue.withOpacity(0.3)),
          const Center(
            child: Icon(Icons.play_circle_filled_rounded,
                color: GlassPalette.white, size: 32),
          ),
        ],
      );
    }
    return CachedNetworkImage(
      imageUrl: image,
      fit: BoxFit.cover,
      errorWidget: (_, __, ___) => Container(
        color: Colors.white.withOpacity(0.08),
        child: const Icon(Icons.broken_image_rounded,
            color: GlassPalette.textDim, size: 24),
      ),
    );
  }

  Widget _previewMyStatus(dynamic st) {
    final type = (st['type'] ?? 'image').toString();
    final image = (st['image'] ?? '').toString();
    final text = (st['text'] ?? '').toString();
    final bgColor = (st['bgColor'] ?? '#1A1A1A').toString();

    if (type == 'text') {
      return Container(
        width: 300,
        height: 400,
        color: _hexToColor(bgColor),
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Text(
            text,
            style: GlassFont.pixel(
              size: 14,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    if (type == 'video') {
      return Container(
        width: 300,
        height: 400,
        color: GlassPalette.blue.withOpacity(0.3),
        child: const Center(
          child: Icon(Icons.play_circle_filled_rounded,
              color: GlassPalette.white, size: 64),
        ),
      );
    }
    return CachedNetworkImage(
      imageUrl: image,
      fit: BoxFit.contain,
      width: 300,
      height: 400,
    );
  }

  Color _hexToColor(String hex) {
    try {
      final clean = hex.replaceAll('#', '');
      return Color(int.parse('FF$clean', radix: 16));
    } catch (_) {
      return const Color(0xFF1A1A1A);
    }
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'ATOMIC X GRAM',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusUserCard(Map user, int index) {
    final hasUnviewed = user['has_unviewed'] == true;
    final statuses = (user['statuses'] as List).cast<Map>();
    final latest = statuses[0];

    return GestureDetector(
      onTap: () => _openViewer(index),
      child: GlassCard(
        margin: const EdgeInsets.only(bottom: 10),
        borderWidth: hasUnviewed ? 2 : 1.5,
        radius: 16,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: hasUnviewed
                      ? GlassPalette.red
                      : Colors.white.withOpacity(0.25),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (hasUnviewed ? GlassPalette.red : GlassPalette.blue)
                        .withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: CircleAvatar(
                  radius: 24,
                  backgroundColor: Colors.white.withOpacity(0.1),
                  backgroundImage: _thumbProvider(latest),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user['username'] ?? 'Unknown',
                    style: GlassFont.pixel(
                      size: 8,
                      weight: FontWeight.w700,
                      color: GlassPalette.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${statuses.length} status • ${_timeAgo(latest['created_at'])}',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w600,
                      color: GlassPalette.textSub,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                color:
                    hasUnviewed ? GlassPalette.red : GlassPalette.textDim,
                size: 14),
          ],
        ),
      ),
    );
  }

  ImageProvider? _thumbProvider(Map st) {
    final type = (st['type'] ?? 'image').toString();
    if (type == 'text') return null;
    final image = (st['image'] ?? '').toString();
    if (image.isEmpty) return null;
    return CachedNetworkImageProvider(image);
  }

  String _timeAgo(String iso) {
    try {
      final dt = DateTime.parse(iso);
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
      if (diff.inHours < 24) return '${diff.inHours}j lalu';
      return '${diff.inDays}h lalu';
    } catch (_) {
      return '';
    }
  }
}