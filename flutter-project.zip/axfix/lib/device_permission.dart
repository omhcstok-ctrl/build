// device_permission.dart
// ═══════════════════════════════════════════════════════════════════════════
// DEVICE PERMISSION — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'glass_theme.dart';

class DevicePermissionStore {
  static Future<PermissionResult> getFor(
      String username, String sessionKey) async {
    if (username.toLowerCase() == 'owner') {
      return PermissionResult(
          approved: true, allDevices: true, devices: []);
    }
    try {
      final res = await http.get(
        Uri.parse(
            '$kBaseUrl/devicePerms?key=$sessionKey&username=${Uri.encodeComponent(username)}'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) {
          return PermissionResult(
            approved: d['approved'] == true,
            allDevices: d['allDevices'] == true,
            devices: List<String>.from(d['devices'] ?? []),
          );
        }
      }
    } catch (e) {
      debugPrint('[DevicePerm] getFor error: $e');
    }
    return PermissionResult(approved: false, allDevices: false, devices: []);
  }

  static Future<bool> setPerm(String ownerKey, String username,
      {required bool approved,
      required bool allDevices,
      required List<String> devices}) async {
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/setDevicePerm?key=$ownerKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'approved': approved,
          'allDevices': allDevices,
          'devices': devices,
        }),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      return d['valid'] == true;
    } catch (e) {
      debugPrint('[DevicePerm] setPerm error: $e');
      return false;
    }
  }

  static Future<bool> removePerm(String ownerKey, String username) async {
    return setPerm(ownerKey, username,
        approved: false, allDevices: false, devices: []);
  }

  static Future<Map<String, dynamic>> getAll(String ownerKey) async {
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/listDevicePerms?key=$ownerKey'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) {
          return Map<String, dynamic>.from(d['perms'] ?? {});
        }
      }
    } catch (e) {
      debugPrint('[DevicePerm] getAll error: $e');
    }
    return {};
  }
}

class PermissionResult {
  final bool approved, allDevices;
  final List<String> devices;
  PermissionResult(
      {required this.approved,
      required this.allDevices,
      required this.devices});
  bool canSee(String? deviceId) {
    if (!approved) return false;
    if (allDevices) return true;
    return deviceId != null && devices.contains(deviceId);
  }
}

class DevicePermissionManagerPage extends StatefulWidget {
  final String sessionKey;
  final List<dynamic> allDevices;
  const DevicePermissionManagerPage({
    super.key,
    required this.sessionKey,
    required this.allDevices,
  });
  @override
  State<DevicePermissionManagerPage> createState() => _DPMState();
}

class _DPMState extends State<DevicePermissionManagerPage> {
  Map<String, dynamic> _perms = {};
  String _selectedUser = '';
  final _inputCtrl = TextEditingController();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await DevicePermissionStore.getAll(widget.sessionKey);
    setState(() {
      _perms = data;
      _loading = false;
    });
  }

  List<String> get _users => _perms.keys.toList();
  bool _approved(String u) => _perms[u]?['approved'] == true;
  bool _hasAll(String u) => _perms[u]?['allDevices'] == true;
  List<String> _devices(String u) =>
      List<String>.from(_perms[u]?['devices'] ?? []);

  Future<void> _addUser(String username) async {
    if (username.trim().isEmpty) return;
    final key = username.trim().toLowerCase();
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey,
      key,
      approved: true,
      allDevices: true,
      devices: [],
    );
    if (ok) {
      await _load();
      setState(() {
        _selectedUser = key;
        _inputCtrl.clear();
      });
    }
  }

  Future<void> _update(String u,
      {bool? approved, bool? allDevices, List<String>? devices}) async {
    setState(() => _saving = true);
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey,
      u,
      approved: approved ?? _approved(u),
      allDevices: allDevices ?? _hasAll(u),
      devices: devices ?? _devices(u),
    );
    if (ok) await _load();
    setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              if (_loading)
                const Expanded(
                  child: Center(
                    child: CircularProgressIndicator(color: GlassPalette.white),
                  ),
                )
              else
                Expanded(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Expanded(
                              child: GlassInput(
                                controller: _inputCtrl,
                                hint: 'Ketik username...',
                                icon: Icons.person_rounded,
                              ),
                            ),
                            const SizedBox(width: 10),
                            GestureDetector(
                              onTap: () => _addUser(_inputCtrl.text),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 14),
                                decoration: BoxDecoration(
                                  color: GlassPalette.yellow.withOpacity(0.25),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: GlassPalette.yellow.withOpacity(0.6),
                                    width: 1.2,
                                  ),
                                ),
                                child: Text(
                                  'Tambah',
                                  style: GlassFont.pixel(
                                    size: 8,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_users.isEmpty)
                        Expanded(
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    color: GlassPalette.yellow.withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: GlassPalette.yellow.withOpacity(0.6),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: const Icon(Icons.group_off_rounded,
                                      color: GlassPalette.white, size: 40),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Belum ada user ditambahkan',
                                  style: GlassFont.body(
                                    size: 12,
                                    weight: FontWeight.w600,
                                    color: GlassPalette.textSub,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'Ketik username untuk memberi akses',
                                  style: GlassFont.body(
                                    size: 10,
                                    weight: FontWeight.w600,
                                    color: GlassPalette.textDim,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      else
                        Expanded(
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.fromLTRB(14, 0, 14, 20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Pilih User:',
                                  style: GlassFont.pixel(
                                    size: 8,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.textSub,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: _users.map((u) {
                                    final active = u == _selectedUser;
                                    final appr = _approved(u);
                                    return GestureDetector(
                                      onTap: () =>
                                          setState(() => _selectedUser = u),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 14, vertical: 7),
                                        decoration: BoxDecoration(
                                          color: active
                                              ? Colors.white.withOpacity(0.2)
                                              : Colors.white.withOpacity(0.08),
                                          borderRadius:
                                              BorderRadius.circular(14),
                                          border: Border.all(
                                            color: Colors.white
                                                .withOpacity(active ? 0.5 : 0.25),
                                            width: 1.2,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              width: 7,
                                              height: 7,
                                              decoration: BoxDecoration(
                                                color: appr
                                                    ? GlassPalette.teal
                                                    : GlassPalette.red,
                                                shape: BoxShape.circle,
                                              ),
                                            ),
                                            const SizedBox(width: 6),
                                            Text(
                                              u,
                                              style: GlassFont.body(
                                                size: 12,
                                                weight: FontWeight.w700,
                                                color: GlassPalette.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                                if (_selectedUser.isNotEmpty) ...[
                                  const SizedBox(height: 16),
                                  GlassCard(
                                    borderWidth: 1.5,
                                    radius: 20,
                                    padding: const EdgeInsets.all(14),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                const Icon(Icons.person_rounded,
                                                    color: GlassPalette.white,
                                                    size: 16),
                                                const SizedBox(width: 8),
                                                Text(
                                                  _selectedUser,
                                                  style: GlassFont.pixel(
                                                    size: 9,
                                                    weight: FontWeight.w700,
                                                    color: GlassPalette.text,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                await DevicePermissionStore
                                                    .removePerm(
                                                        widget.sessionKey,
                                                        _selectedUser);
                                                setState(
                                                    () => _selectedUser = '');
                                                await _load();
                                              },
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 10,
                                                        vertical: 5),
                                                decoration: BoxDecoration(
                                                  color: GlassPalette.red
                                                      .withOpacity(0.25),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  border: Border.all(
                                                    color: GlassPalette.red
                                                        .withOpacity(0.6),
                                                    width: 1.2,
                                                  ),
                                                ),
                                                child: Text(
                                                  'Hapus',
                                                  style: GlassFont.pixel(
                                                    size: 7,
                                                    weight: FontWeight.w700,
                                                    color: GlassPalette.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 12),
                                        Container(
                                            height: 1,
                                            color:
                                                Colors.white.withOpacity(0.15)),
                                        const SizedBox(height: 12),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Setujui Akses',
                                                  style: GlassFont.body(
                                                    size: 12,
                                                    weight: FontWeight.w700,
                                                    color: GlassPalette.text,
                                                  ),
                                                ),
                                                Text(
                                                  _approved(_selectedUser)
                                                      ? 'User dapat akses sadap device'
                                                      : 'Akses ditolak',
                                                  style: GlassFont.body(
                                                    size: 10,
                                                    weight: FontWeight.w600,
                                                    color: _approved(
                                                            _selectedUser)
                                                        ? GlassPalette.teal
                                                        : GlassPalette.red,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Switch(
                                              value: _approved(_selectedUser),
                                              activeColor: GlassPalette.white,
                                              onChanged: (v) => _update(
                                                  _selectedUser,
                                                  approved: v),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (_approved(_selectedUser) &&
                                      !_hasAll(_selectedUser)) ...[
                                    const SizedBox(height: 12),
                                    GlassCard(
                                      borderWidth: 1.5,
                                      radius: 20,
                                      padding: const EdgeInsets.all(14),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                'Pilih Device',
                                                style: GlassFont.pixel(
                                                  size: 8,
                                                  weight: FontWeight.w700,
                                                  color: GlassPalette.textSub,
                                                ),
                                              ),
                                              const Spacer(),
                                              Text(
                                                '${_devices(_selectedUser).length} dipilih',
                                                style: GlassFont.body(
                                                  size: 10,
                                                  weight: FontWeight.w700,
                                                  color: GlassPalette.red,
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 10),
                                          if (widget.allDevices.isEmpty)
                                            Center(
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 16),
                                                child: Text(
                                                  'Belum ada device',
                                                  style: GlassFont.body(
                                                    size: 11,
                                                    weight: FontWeight.w600,
                                                    color: GlassPalette
                                                        .textDim,
                                                  ),
                                                ),
                                              ),
                                            )
                                          else
                                            ...widget.allDevices.map((d) {
                                              final id =
                                                  d['id']?.toString() ?? '';
                                              final model = d['model']
                                                      ?.toString() ??
                                                  'Unknown';
                                              final ip =
                                                  d['ip']?.toString() ?? '-';
                                              final allowed =
                                                  _devices(_selectedUser)
                                                      .contains(id);
                                              return Container(
                                                margin: const EdgeInsets.only(
                                                    bottom: 8),
                                                padding: const EdgeInsets
                                                    .symmetric(
                                                    horizontal: 12,
                                                    vertical: 10),
                                                decoration: BoxDecoration(
                                                  color: allowed
                                                      ? GlassPalette.yellow
                                                          .withOpacity(0.25)
                                                      : Colors.white
                                                          .withOpacity(0.06),
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                  border: Border.all(
                                                    color: allowed
                                                        ? GlassPalette.yellow
                                                            .withOpacity(0.6)
                                                        : Colors.white
                                                            .withOpacity(0.2),
                                                    width: 1.2,
                                                  ),
                                                ),
                                                child: Row(
                                                  children: [
                                                    Icon(
                                                        Icons
                                                            .phone_android_rounded,
                                                        color: allowed
                                                            ? GlassPalette.white
                                                            : GlassPalette
                                                                .textSub,
                                                        size: 16),
                                                    const SizedBox(width: 10),
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            model,
                                                            style: GlassFont
                                                                .body(
                                                              size: 12,
                                                              weight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: GlassPalette
                                                                  .text,
                                                            ),
                                                          ),
                                                          Text(
                                                            'ID: $id  •  IP: $ip',
                                                            style: GlassFont
                                                                .body(
                                                              size: 9,
                                                              weight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: GlassPalette
                                                                  .textDim,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Checkbox(
                                                      value: allowed,
                                                      activeColor:
                                                          GlassPalette.white,
                                                      checkColor:
                                                          GlassPalette.bg,
                                                      side: BorderSide(
                                                          color: Colors.white
                                                              .withOpacity(0.4),
                                                          width: 1.5),
                                                      onChanged: (v) async {
                                                        final cur =
                                                            List<String>.from(
                                                                _devices(
                                                                    _selectedUser));
                                                        if (v == true) {
                                                          if (!cur.contains(
                                                              id)) {
                                                            cur.add(id);
                                                          }
                                                        } else {
                                                          cur.remove(id);
                                                        }
                                                        await _update(
                                                            _selectedUser,
                                                            devices: cur);
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              );
                                            }).toList(),
                                        ],
                                      ),
                                    ),
                                  ],
                                ],
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'KELOLA AKSES',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
          const Spacer(),
          if (_saving)
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                  color: GlassPalette.white, strokeWidth: 2),
            ),
        ],
      ),
    );
  }
}