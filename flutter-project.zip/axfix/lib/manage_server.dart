// manage_server.dart
// ═══════════════════════════════════════════════════════════════════════════
// MANAGE SERVER — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchVpsList();
  }

  Future<void> _fetchVpsList() async {
    setState(() => isLoading = true);
    final uri = Uri.parse('$kBaseUrl/myServer?key=${widget.keyToken}');
    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      setState(() => vpsList = List<Map<String, dynamic>>.from(data));
    } catch (_) {
      _showError("Gagal mengambil data VPS.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _addVps() async {
    final host = _hostController.text.trim();
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (host.isEmpty || user.isEmpty || pass.isEmpty) {
      _showError("Isi semua field terlebih dahulu.");
      return;
    }

    final uri = Uri.parse('$kBaseUrl/addServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
        'username': user,
        'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear();
        _userController.clear();
        _passController.clear();
        _fetchVpsList();
      } else {
        _showError(data['error'] ?? 'Gagal menambah VPS');
      }
    } catch (_) {
      _showError("Gagal terhubung ke server.");
    }
  }

  Future<void> _deleteVps(String host) async {
    final uri = Uri.parse('$kBaseUrl/delServer');
    try {
      final res = await http.post(uri, body: {
        'key': widget.keyToken,
        'host': host,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _fetchVpsList();
      } else {
        _showError("Gagal menghapus VPS.");
      }
    } catch (_) {
      _showError("Gagal menghubungi server.");
    }
  }

  void _showError(String msg) {
    GlassDialog.show(
      context,
      title: 'Error',
      message: msg,
      icon: Icons.error_outline_rounded,
      accentColor: GlassPalette.red,
    );
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: GlassCard(
          borderWidth: 1.5,
          radius: 22,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Tambah VPS',
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                ),
              ),
              const SizedBox(height: 16),
              GlassInput(
                controller: _hostController,
                hint: 'IP VPS',
                icon: Icons.dns_rounded,
              ),
              const SizedBox(height: 12),
              GlassInput(
                controller: _userController,
                hint: 'Username',
                icon: Icons.person_rounded,
              ),
              const SizedBox(height: 12),
              GlassInput(
                controller: _passController,
                hint: 'Password',
                icon: Icons.lock_rounded,
                obscure: true,
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      text: 'BATAL',
                      onTap: () => Navigator.pop(context),
                      bgColor: Colors.white,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GlassButton(
                      text: 'TAMBAH',
                      onTap: () {
                        Navigator.pop(context);
                        _addVps();
                      },
                      bgColor: GlassPalette.blue,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                GlassCard(
                  borderWidth: 1.5,
                  radius: 20,
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.4),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.dns_rounded,
                            color: GlassPalette.white, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        'MY VPS LIST',
                        style: GlassFont.pixel(
                          size: 11,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: _showAddDialog,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: GlassPalette.blue.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: GlassPalette.blue.withOpacity(0.6),
                              width: 1.2,
                            ),
                          ),
                          child: const Icon(Icons.add,
                              color: GlassPalette.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                Expanded(
                  child: isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: GlassPalette.white))
                      : vpsList.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(20),
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                          .withOpacity(0.06),
                                      borderRadius:
                                          BorderRadius.circular(24),
                                      border: Border.all(
                                        color: Colors.white
                                            .withOpacity(0.15),
                                        width: 1.2,
                                      ),
                                    ),
                                    child: const Icon(
                                        Icons.dns_outlined,
                                        color: GlassPalette.textDim,
                                        size: 40),
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    'Belum ada VPS',
                                    style: GlassFont.body(
                                      size: 12,
                                      weight: FontWeight.w500,
                                      color: GlassPalette.textSub,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              itemCount: vpsList.length,
                              itemBuilder: (context, index) {
                                final vps = vpsList[index];
                                return GlassCard(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  borderWidth: 1.5,
                                  radius: 16,
                                  padding: const EdgeInsets.all(14),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                          color: GlassPalette.blue
                                              .withOpacity(0.25),
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          border: Border.all(
                                            color: GlassPalette.blue
                                                .withOpacity(0.6),
                                            width: 1.2,
                                          ),
                                        ),
                                        child: const Icon(
                                            Icons.dns_rounded,
                                            color: GlassPalette.white,
                                            size: 20),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "${vps['host']}",
                                              style: GlassFont.pixel(
                                                size: 9,
                                                weight: FontWeight.w700,
                                                color: GlassPalette.white,
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              "User: ${vps['username']}",
                                              style: GlassFont.body(
                                                size: 10,
                                                weight: FontWeight.w500,
                                                color:
                                                    GlassPalette.textSub,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () =>
                                            _deleteVps(vps['host']),
                                        child: Container(
                                          padding: const EdgeInsets.all(9),
                                          decoration: BoxDecoration(
                                            color: GlassPalette.red
                                                .withOpacity(0.25),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color: GlassPalette.red
                                                  .withOpacity(0.6),
                                              width: 1.2,
                                            ),
                                          ),
                                          child: const Icon(
                                              Icons.delete,
                                              color: GlassPalette.white,
                                              size: 18),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}