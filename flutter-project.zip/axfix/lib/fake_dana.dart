// fake_dana.dart
// ═══════════════════════════════════════════════════════════════════════════
// FAKE DANA — GLASSMORPHISM EDITION + FULLSCREEN
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'app_config.dart';
import 'glass_theme.dart';

class FakeDanaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const FakeDanaPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<FakeDanaPage> createState() => _FakeDanaPageState();
}

class _FakeDanaPageState extends State<FakeDanaPage> {
  final TextEditingController _saldoController =
      TextEditingController(text: 'Rp 3.392');
  final TextEditingController _jamController =
      TextEditingController(text: '11:44');
  final TextEditingController _batteryController =
      TextEditingController(text: '92');

  bool _showEye = true;
  bool _isLoading = false;
  Uint8List? _resultImage;
  String? _errorMessage;

  @override
  void dispose() {
    _saldoController.dispose();
    _jamController.dispose();
    _batteryController.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final saldo = _saldoController.text.trim();
    final jam = _jamController.text.trim();
    final battery = _batteryController.text.trim();

    if (saldo.isEmpty) {
      setState(() {
        _errorMessage = 'Saldo tidak boleh kosong.';
        _resultImage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _resultImage = null;
    });

    try {
      final response = await http.post(
        Uri.parse(apiUrl('/api/fakedana/generate')),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'saldo': saldo,
          'jam': jam,
          'battery': battery,
          'showEye': _showEye,
        }),
      ).timeout(const Duration(seconds: 45));

      if (response.statusCode != 200) {
        setState(() {
          _errorMessage = 'Server error (${response.statusCode}). Coba lagi.';
        });
        return;
      }

      final contentType = response.headers['content-type'] ?? '';

      if (contentType.contains('image')) {
        setState(() {
          _resultImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        try {
          final json = jsonDecode(utf8.decode(response.bodyBytes));
          if (json['status'] == true && json['url'] != null) {
            final imgRes = await http.get(Uri.parse(json['url'].toString()));
            setState(() {
              _resultImage = imgRes.bodyBytes;
              _errorMessage = null;
            });
          } else if (json['data'] != null && json['data']['url'] != null) {
            final imgRes =
                await http.get(Uri.parse(json['data']['url'].toString()));
            setState(() {
              _resultImage = imgRes.bodyBytes;
              _errorMessage = null;
            });
          } else {
            setState(() {
              _errorMessage = json['message']?.toString() ??
                  'Gagal generate. Format response tidak dikenal.';
            });
          }
        } catch (_) {
          setState(() {
            _resultImage = response.bodyBytes;
          });
        }
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _shareImage() async {
    if (_resultImage == null) return;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
        '${tempDir.path}/fakedana_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(_resultImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Fake Dana — ${_saldoController.text}',
      );
    } catch (e) {
      if (!mounted) return;
      GlassDialog.show(
        context,
        title: 'Share Gagal',
        message: 'Error sharing: $e',
        icon: Icons.error_rounded,
        accentColor: GlassPalette.red,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      // FULLSCREEN — edge to edge
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.account_balance_wallet_rounded,
                  color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'FAKE DANA',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + kToolbarHeight + 16,
              bottom: MediaQuery.of(context).padding.bottom + 40,
              left: 16,
              right: 16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 16),
                _buildFormCard(),
                const SizedBox(height: 16),
                if (_errorMessage != null) ...[
                  _buildErrorCard(),
                  const SizedBox(height: 16),
                ],
                if (_resultImage != null) _buildResultCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.blue.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.account_balance_wallet_rounded,
                color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'FAKE DANA CANVAS',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Generate screenshot Dana palsu',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'KONFIGURASI',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.white,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 12),
          _buildLabel('SALDO', 'Contoh: Rp 3.392'),
          const SizedBox(height: 6),
          GlassInput(
            controller: _saldoController,
            hint: 'Rp 3.392',
            icon: Icons.money_rounded,
          ),
          const SizedBox(height: 14),
          _buildLabel('JAM', 'Format HH:MM'),
          const SizedBox(height: 6),
          GlassInput(
            controller: _jamController,
            hint: '11:44',
            icon: Icons.access_time_rounded,
          ),
          const SizedBox(height: 14),
          _buildLabel('BATTERY', 'Persentase 0-100'),
          const SizedBox(height: 6),
          GlassInput(
            controller: _batteryController,
            hint: '92',
            icon: Icons.battery_full_rounded,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 14),
          _buildLabel('SHOW EYE', 'Tampilkan ikon mata'),
          const SizedBox(height: 6),
          _buildEyeToggle(),
          const SizedBox(height: 18),
          GlassButton(
            text: _isLoading ? 'LOADING...' : 'GENERATE',
            icon: _isLoading ? null : Icons.auto_awesome_rounded,
            isLoading: _isLoading,
            onTap: _isLoading ? null : _generate,
            bgColor: GlassPalette.blue,
            textColor: GlassPalette.white,
            fullWidth: true,
            padding: const EdgeInsets.symmetric(vertical: 14),
            fontSize: 11,
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String title, String sub) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: GlassPalette.blue.withOpacity(0.25),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: GlassPalette.blue.withOpacity(0.6),
              width: 1,
            ),
          ),
          child: Text(
            title,
            style: GlassFont.pixel(
              size: 8,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            sub,
            style: GlassFont.body(
              size: 10,
              weight: FontWeight.w400,
              color: GlassPalette.textDim,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEyeToggle() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _showEye = true),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: _showEye
                    ? GlassPalette.blue.withOpacity(0.3)
                    : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _showEye
                      ? GlassPalette.blue.withOpacity(0.7)
                      : Colors.white.withOpacity(0.15),
                  width: _showEye ? 1.5 : 1.2,
                ),
              ),
              child: Center(
                child: Text(
                  'TRUE',
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _showEye = false),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: !_showEye
                    ? GlassPalette.blue.withOpacity(0.3)
                    : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: !_showEye
                      ? GlassPalette.blue.withOpacity(0.7)
                      : Colors.white.withOpacity(0.15),
                  width: !_showEye ? 1.5 : 1.2,
                ),
              ),
              child: Center(
                child: Text(
                  'FALSE',
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 16,
      bgColor: GlassPalette.red.withOpacity(0.2),
      borderColor: GlassPalette.red.withOpacity(0.6),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.7),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w600,
                color: GlassPalette.white,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.amber.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.amber.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.image_rounded,
                    color: GlassPalette.white, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'HASIL GENERATE',
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                    ),
                    Text(
                      'Tap untuk lihat fullscreen',
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w400,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ],
                ),
              ),
              GlassBadge(
                text: 'PNG',
                bgColor: GlassPalette.blue,
                textColor: GlassPalette.white,
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () => _showFullscreen(_resultImage!),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.5,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.memory(
                  _resultImage!,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    height: 200,
                    color: Colors.white.withOpacity(0.06),
                    child: const Center(
                      child: Icon(Icons.broken_image_rounded,
                          color: GlassPalette.textDim, size: 40),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GlassButton(
            text: 'SHARE IMAGE',
            icon: Icons.share_rounded,
            onTap: _shareImage,
            bgColor: GlassPalette.amber,
            textColor: GlassPalette.white,
            fullWidth: true,
            padding: const EdgeInsets.symmetric(vertical: 12),
            fontSize: 10,
          ),
        ],
      ),
    );
  }

  void _showFullscreen(Uint8List image) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: GlassPalette.bg.withOpacity(0.9),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: InteractiveViewer(
              child: Image.memory(image, fit: BoxFit.contain),
            ),
          ),
        ),
      ),
    );
  }
}