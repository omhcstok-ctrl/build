// domain_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// DOMAIN OSINT — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'glass_theme.dart';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<dynamic>? _subdomainsData;
  String? _errorMessage;

  @override
  void dispose() {
    _domainController.dispose();
    super.dispose();
  }

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      setState(() {
        _errorMessage = "Domain tidak boleh kosong.";
        _dnsData = null;
        _subdomainsData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _subdomainsData = null;
    });

    try {
      final dnsResult = await _fetchDnsInfo(domain);
      final subdoResult = await _fetchSubdomains(domain);

      if (dnsResult != null && subdoResult != null) {
        setState(() {
          _dnsData = dnsResult;
          _subdomainsData = subdoResult;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data domain.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<Map<String, dynamic>?> _fetchDnsInfo(String domain) async {
    final url =
        Uri.parse("https://api.siputzx.my.id/api/tools/dns?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  Future<List<dynamic>?> _fetchSubdomains(String domain) async {
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/subdomains?domain=$domain");
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    GlassDialog.show(
      context,
      title: 'Tersalin',
      message: '$label disalin ke clipboard',
      icon: Icons.copy_rounded,
      accentColor: GlassPalette.teal,
    );
  }

  Widget _categoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 16),
      borderWidth: 1.5,
      radius: 20,
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(20)),
              border: Border(
                bottom: BorderSide(
                  color: GlassPalette.blue.withOpacity(0.4),
                  width: 1.2,
                ),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: GlassPalette.white, size: 20),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }

  Widget _infoRow({
    required String label,
    required String? value,
    bool showCopy = false,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.15),
          width: 1.2,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GlassFont.body(
                    size: 10,
                    weight: FontWeight.w600,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: GlassFont.body(
                    size: 13,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ],
            ),
          ),
          if (showCopy)
            GestureDetector(
              onTap: () => _copyToClipboard(value, label),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.blue.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.copy,
                    color: GlassPalette.white, size: 16),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _buildDnsRecords() {
    if (_dnsData == null || _dnsData!['records'] == null) return [];

    final records = _dnsData!['records'] as Map<String, dynamic>;
    final widgets = <Widget>[];

    if (records['ns']?['response']?['answer'] != null) {
      final nsRecords = records['ns']!['response']!['answer'] as List;
      if (nsRecords.isNotEmpty) {
        widgets.addAll([
          Text('Name Servers',
              style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.white)),
          const SizedBox(height: 8),
          ...nsRecords.map((record) => _infoRow(
                label: 'NS Record',
                value: record['record']?['target']?.toString(),
                showCopy: true,
              )),
          const SizedBox(height: 16),
        ]);
      }
    }

    if (records['soa']?['response']?['answer'] != null) {
      final soaRecords = records['soa']!['response']!['answer'] as List;
      if (soaRecords.isNotEmpty) {
        final soa = soaRecords.first['record'];
        widgets.addAll([
          Text('SOA Record',
              style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.white)),
          const SizedBox(height: 8),
          _infoRow(
              label: 'Primary NS',
              value: soa?['host']?.toString(),
              showCopy: true),
          _infoRow(
              label: 'Admin Email',
              value: soa?['admin']?.toString(),
              showCopy: true),
          _infoRow(label: 'Serial', value: soa?['serial']?.toString()),
          _infoRow(label: 'Refresh', value: soa?['refresh']?.toString()),
          _infoRow(label: 'Retry', value: soa?['retry']?.toString()),
          _infoRow(label: 'Expire', value: soa?['expire']?.toString()),
          _infoRow(label: 'Minimum TTL', value: soa?['minimum']?.toString()),
          const SizedBox(height: 16),
        ]);
      }
    }

    if (records['a']?['response']?['answer'] != null) {
      final aRecords = records['a']!['response']!['answer'] as List;
      if (aRecords.isNotEmpty) {
        widgets.addAll([
          Text('A Records',
              style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.white)),
          const SizedBox(height: 8),
          ...aRecords.map((record) => _infoRow(
                label: 'A Record',
                value: record['record']?['data']?.toString(),
                showCopy: true,
              )),
        ]);
      }
    }

    return widgets;
  }

  List<Widget> _buildSubdomainsList() {
    if (_subdomainsData == null) return [];

    final cleanSubdomains = _subdomainsData!
        .map((item) => item.toString().split('\n').last.trim())
        .where((subdomain) =>
            subdomain.isNotEmpty && !subdomain.startsWith('*'))
        .toSet()
        .toList()
      ..sort();

    return [
      Text('Ditemukan ${cleanSubdomains.length} subdomain',
          style: GlassFont.body(
              size: 11,
              weight: FontWeight.w500,
              color: GlassPalette.textSub)),
      const SizedBox(height: 12),
      ...cleanSubdomains.map((subdomain) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.2,
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.link, color: GlassPalette.white, size: 16),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(subdomain,
                      style: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w600,
                          color: GlassPalette.white)),
                ),
                GestureDetector(
                  onTap: () => _copyToClipboard(subdomain, 'Subdomain'),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: GlassPalette.blue.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: GlassPalette.blue.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.copy,
                        color: GlassPalette.white, size: 14),
                  ),
                ),
              ],
            ),
          )).toList(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: GlassPalette.white, size: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'DOMAIN OSINT',
                      style: GlassFont.pixel(
                        size: 11,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            GlassInput(
                              controller: _domainController,
                              hint: 'Masukkan domain (contoh: google.com)',
                              icon: Icons.domain_rounded,
                            ),
                            const SizedBox(height: 16),
                            GlassButton(
                              text: _isLoading
                                  ? 'MEMPROSES...'
                                  : 'CEK DOMAIN',
                              icon: _isLoading ? null : Icons.search,
                              isLoading: _isLoading,
                              onTap: _isLoading ? null : _checkDomain,
                              bgColor: GlassPalette.blue,
                              textColor: GlassPalette.white,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16),
                              fontSize: 11,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      if (_errorMessage != null)
                        GlassCard(
                          borderWidth: 1.5,
                          radius: 16,
                          bgColor: GlassPalette.red.withOpacity(0.2),
                          borderColor: GlassPalette.red.withOpacity(0.6),
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: GlassPalette.red.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color:
                                        GlassPalette.red.withOpacity(0.7),
                                    width: 1.2,
                                  ),
                                ),
                                child: const Icon(Icons.error_outline,
                                    color: GlassPalette.white, size: 16),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _errorMessage!,
                                  style: GlassFont.body(
                                    size: 12,
                                    weight: FontWeight.w600,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                      if (_dnsData != null || _subdomainsData != null) ...[
                        if (_dnsData != null)
                          _categoryCard(
                            title: 'INFORMASI DOMAIN',
                            icon: Icons.domain,
                            children: [
                              _infoRow(
                                label: "Domain",
                                value: _dnsData!['unicodeDomain']?.toString(),
                                showCopy: true,
                              ),
                              _infoRow(
                                label: "Punycode",
                                value: _dnsData!['punycodeDomain']?.toString(),
                                showCopy: true,
                              ),
                              ..._buildDnsRecords(),
                            ],
                          ),

                        if (_subdomainsData != null)
                          _categoryCard(
                            title: 'SUBDOMAINS',
                            icon: Icons.list,
                            children: _buildSubdomainsList(),
                          ),

                        if (_dnsData != null && _dnsData!['records'] != null)
                          _categoryCard(
                            title: 'INFORMASI SERVER',
                            icon: Icons.dns,
                            children: [
                              if (_dnsData!['records']['a']?['query']
                                      ?['server'] !=
                                  null)
                                _infoRow(
                                  label: "DNS Server",
                                  value: _dnsData!['records']['a']!['query']!
                                          ['server']!['ip']
                                      ?.toString(),
                                  showCopy: true,
                                ),
                              if (_dnsData!['records']['a']?['query']?['server']
                                      ?['location'] !=
                                  null)
                                _infoRow(
                                  label: "Lokasi Server",
                                  value:
                                      "Lat: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lat']}, Lon: ${_dnsData!['records']['a']!['query']!['server']!['location']!['lon']}",
                                ),
                            ],
                          ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}