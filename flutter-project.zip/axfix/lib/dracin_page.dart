// dracin_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// DRACIN — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'glass_theme.dart';

String _ytThumb(String videoId) =>
    'https://img.youtube.com/vi/$videoId/mqdefault.jpg';
String _ytSearch(String q) =>
    'https://www.youtube.com/results?search_query=${Uri.encodeComponent(q)}';

final List<Map<String, dynamic>> _list = [
  {
    'title': 'Battle Through the Heavens',
    'genre': 'Action · Cultivation',
    'ep': '40+',
    'tag': 'Donghua',
    'img': _ytThumb('JGjfTZMaXcU'),
    'url': _ytSearch('battle through the heavens donghua episode 1')
  },
  {
    'title': 'Soul Land (Douluo Dalu)',
    'genre': 'Adventure · Fantasy',
    'ep': '200+',
    'tag': 'Donghua',
    'img': _ytThumb('NMPVmQKLzv4'),
    'url': _ytSearch('douluo dalu soul land episode 1 english sub')
  },
  {
    'title': "The King's Avatar",
    'genre': 'E-Sports · Action',
    'ep': '24',
    'tag': 'Donghua',
    'img': _ytThumb('RMBMkOL7ofU'),
    'url': _ytSearch('the kings avatar donghua full episode')
  },
  {
    'title': 'Martial Universe',
    'genre': 'Martial Arts · Fantasy',
    'ep': '40+',
    'tag': 'Donghua',
    'img': _ytThumb('s9YrjnQDVHc'),
    'url': _ytSearch('martial universe donghua episode 1')
  },
  {
    'title': 'Perfect World',
    'genre': 'Cultivation · Fantasy',
    'ep': '50+',
    'tag': 'Donghua',
    'img': _ytThumb('EQ5D3gBNzH8'),
    'url': _ytSearch('perfect world donghua full episode')
  },
  {
    'title': "Heaven Official's Blessing",
    'genre': 'Romance · Fantasy',
    'ep': '24',
    'tag': 'Donghua',
    'img': _ytThumb('5O0m7YfVnXk'),
    'url': _ytSearch('heaven officials blessing tgcf episode 1')
  },
  {
    'title': 'Stellar Transformations',
    'genre': 'Sci-Fi · Cultivation',
    'ep': '44+',
    'tag': 'Donghua',
    'img': _ytThumb('VcaF7ykfGDw'),
    'url': _ytSearch('stellar transformations donghua episode 1')
  },
  {
    'title': 'A Will Eternal',
    'genre': 'Comedy · Cultivation',
    'ep': '40+',
    'tag': 'Donghua',
    'img': _ytThumb('fKuHBXrn2ac'),
    'url': _ytSearch('a will eternal donghua full')
  },
  {
    'title': 'Swallowed Star',
    'genre': 'Sci-Fi · Action',
    'ep': '100+',
    'tag': 'Donghua',
    'img': _ytThumb('h7JfR_l3RRE'),
    'url': _ytSearch('swallowed star donghua episode 1')
  },
  {
    'title': 'The Daily Life of the Immortal King',
    'genre': 'Comedy · Cultivation',
    'ep': '50+',
    'tag': 'Donghua',
    'img': _ytThumb('gM5PXa8T5oA'),
    'url': _ytSearch('daily life immortal king donghua full')
  },
  {
    'title': 'The Untamed (陈情令)',
    'genre': 'Romance · Wuxia',
    'ep': '50',
    'tag': 'Drama',
    'img': _ytThumb('E6mwJIxbPEI'),
    'url': _ytSearch('the untamed chen qing ling full drama english sub')
  },
  {
    'title': 'Word of Honor (山河令)',
    'genre': 'Action · Bromance',
    'ep': '36',
    'tag': 'Drama',
    'img': _ytThumb('1x9yMPrYcXk'),
    'url': _ytSearch('word of honor shan he ling drama full')
  },
  {
    'title': 'Love Between Fairy and Devil',
    'genre': 'Romance · Fantasy',
    'ep': '36',
    'tag': 'Drama',
    'img': _ytThumb('dVaqshAiYjM'),
    'url': _ytSearch('love between fairy and devil full drama')
  },
  {
    'title': 'Eternal Love (三生三世)',
    'genre': 'Romance · Xianxia',
    'ep': '58',
    'tag': 'Drama',
    'img': _ytThumb('aNgkb3DHPNA'),
    'url': _ytSearch('eternal love ten miles peach blossoms drama full')
  },
  {
    'title': 'Ashes of Love (香蜜沉沉烬如霜)',
    'genre': 'Romance · Fantasy',
    'ep': '63',
    'tag': 'Drama',
    'img': _ytThumb('x7nOJMHdFk0'),
    'url': _ytSearch('ashes of love chinese drama full episode')
  },
  {
    'title': 'Nirvana in Fire (琅琊榜)',
    'genre': 'Political · Wuxia',
    'ep': '54',
    'tag': 'Drama',
    'img': _ytThumb('W1MeWMfq_wY'),
    'url': _ytSearch('nirvana in fire lang ya bang full drama')
  },
  {
    'title': 'Lost You Forever (长相思)',
    'genre': 'Romance · Xianxia',
    'ep': '39',
    'tag': 'Drama',
    'img': _ytThumb('b8Jv0HwfJHk'),
    'url': _ytSearch('lost you forever chang xiang si drama full')
  },
  {
    'title': 'Go Go Squid! (亲爱的，热爱的)',
    'genre': 'Romance · E-Sports',
    'ep': '41',
    'tag': 'Drama',
    'img': _ytThumb('4s6TYZ79YoI'),
    'url': _ytSearch('go go squid chinese drama full episode')
  },
  {
    'title': 'You Are My Glory (你是我的荣耀)',
    'genre': 'Romance · Modern',
    'ep': '32',
    'tag': 'Drama',
    'img': _ytThumb('XarRwGrHkY4'),
    'url': _ytSearch('you are my glory chinese drama full')
  },
  {
    'title': 'The Story of Ming Lan (知否)',
    'genre': 'Historical · Romance',
    'ep': '73',
    'tag': 'Drama',
    'img': _ytThumb('zJNAjYj7ZJo'),
    'url': _ytSearch('story of minglan chinese drama full')
  },
];

final _tags = ['Semua', 'Donghua', 'Drama'];

class DracinPage extends StatefulWidget {
  const DracinPage({super.key});
  @override
  State<DracinPage> createState() => _DracinPageState();
}

class _DracinPageState extends State<DracinPage> {
  String _q = '';
  String _tag = 'Semua';
  final _ctrl = TextEditingController();

  List<Map<String, dynamic>> get _filtered => _list.where((d) {
        final matchQ = _q.isEmpty ||
            (d['title'] as String? ?? '')
                .toLowerCase()
                .contains(_q.toLowerCase()) ||
            (d['genre'] as String? ?? '')
                .toLowerCase()
                .contains(_q.toLowerCase());
        final matchT = _tag == 'Semua' || d['tag'] == _tag;
        return matchQ && matchT;
      }).toList();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: GlassPalette.red.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: GlassPalette.red.withOpacity(0.6),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: GlassPalette.red.withOpacity(0.5),
                            blurRadius: 15,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.play_circle_rounded,
                          color: GlassPalette.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('DRACIN',
                            style: GlassFont.pixel(
                                size: 14,
                                weight: FontWeight.w700,
                                color: GlassPalette.white,
                                letterSpacing: 2)),
                        Text('Donghua & Drama China',
                            style: GlassFont.body(
                                size: 11,
                                weight: FontWeight.w500,
                                color: GlassPalette.textSub)),
                      ],
                    ),
                    const Spacer(),
                    Text('${_filtered.length} judul',
                        style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w500,
                            color: GlassPalette.textDim)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.2,
                    ),
                  ),
                  child: TextField(
                    controller: _ctrl,
                    onChanged: (v) => setState(() => _q = v),
                    style: GlassFont.body(
                        size: 13,
                        weight: FontWeight.w500,
                        color: GlassPalette.white),
                    cursorColor: GlassPalette.white,
                    decoration: InputDecoration(
                      hintText: 'Cari judul atau genre...',
                      hintStyle: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w400,
                          color: GlassPalette.textDim),
                      prefixIcon: const Icon(Icons.search_rounded,
                          color: GlassPalette.white, size: 18),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 34,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _tags.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final t = _tags[i];
                    final active = t == _tag;
                    return GestureDetector(
                      onTap: () => setState(() => _tag = t),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: active
                              ? GlassPalette.red.withOpacity(0.3)
                              : Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: active
                                ? GlassPalette.red.withOpacity(0.7)
                                : Colors.white.withOpacity(0.2),
                            width: active ? 1.5 : 1.2,
                          ),
                        ),
                        child: Text(t,
                            style: GlassFont.body(
                                size: 12,
                                weight: active
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                color: GlassPalette.white)),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: _filtered.isEmpty
                    ? Center(
                        child: Text('Tidak ditemukan',
                            style: GlassFont.body(
                                size: 12,
                                weight: FontWeight.w500,
                                color: GlassPalette.textDim)))
                    : GridView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.57,
                        ),
                        itemCount: _filtered.length,
                        itemBuilder: (ctx, i) {
                          final d = _filtered[i];
                          return GestureDetector(
                            onTap: () async {
                              final u = Uri.parse(d['url'] as String);
                              if (await canLaunchUrl(u)) {
                                launchUrl(u,
                                    mode: LaunchMode.externalApplication);
                              }
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.2),
                                  width: 1.2,
                                ),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.network(
                                          d['img'] as String,
                                          fit: BoxFit.cover,
                                          headers: const {
                                            'Referer':
                                                'https://www.youtube.com/'
                                          },
                                          loadingBuilder:
                                              (_, child, progress) {
                                            if (progress == null) return child;
                                            return Container(
                                              color: Colors.white
                                                  .withOpacity(0.05),
                                              child: const Center(
                                                child:
                                                    CircularProgressIndicator(
                                                  color: GlassPalette.white,
                                                  strokeWidth: 2,
                                                ),
                                              ),
                                            );
                                          },
                                          errorBuilder: (_, __, ___) =>
                                              Container(
                                            color: Colors.white
                                                .withOpacity(0.05),
                                            child: const Center(
                                              child: Icon(
                                                Icons.live_tv_rounded,
                                                color: GlassPalette.white,
                                                size: 32,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          child: Container(
                                            height: 60,
                                            decoration: BoxDecoration(
                                              gradient: LinearGradient(
                                                colors: [
                                                  Colors.transparent,
                                                  Colors.black
                                                      .withOpacity(0.75),
                                                ],
                                                begin: Alignment.topCenter,
                                                end: Alignment.bottomCenter,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          top: 8,
                                          left: 8,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 6, vertical: 3),
                                            decoration: BoxDecoration(
                                              color: GlassPalette.red
                                                  .withOpacity(0.8),
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                            ),
                                            child: Row(
                                              children: [
                                                const Icon(Icons.play_arrow,
                                                    color: GlassPalette.white,
                                                    size: 10),
                                                const SizedBox(width: 2),
                                                Text('YT',
                                                    style: GlassFont.pixel(
                                                        size: 7,
                                                        weight:
                                                            FontWeight.w700,
                                                        color: GlassPalette
                                                            .white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          top: 8,
                                          right: 8,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 7, vertical: 3),
                                            decoration: BoxDecoration(
                                              color: GlassPalette.red
                                                  .withOpacity(0.7),
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                            ),
                                            child: Text('EP ${d["ep"]}',
                                                style: GlassFont.pixel(
                                                    size: 8,
                                                    weight: FontWeight.w700,
                                                    color:
                                                        GlassPalette.white)),
                                          ),
                                        ),
                                        Center(
                                          child: Container(
                                            padding: const EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: Colors.black
                                                  .withOpacity(0.4),
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: Colors.white
                                                    .withOpacity(0.3),
                                                width: 1.2,
                                              ),
                                            ),
                                            child: const Icon(
                                                Icons.play_arrow_rounded,
                                                color: GlassPalette.white,
                                                size: 28),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          d['title'] as String,
                                          style: GlassFont.body(
                                              size: 11,
                                              weight: FontWeight.w700,
                                              color: GlassPalette.white),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Container(
                                              padding: const EdgeInsets
                                                  .symmetric(
                                                  horizontal: 5, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: (d['tag'] as String) ==
                                                        'Drama'
                                                    ? GlassPalette.purple
                                                        .withOpacity(0.3)
                                                    : GlassPalette.red
                                                        .withOpacity(0.3),
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                d['tag'] as String,
                                                style: GlassFont.pixel(
                                                    size: 7,
                                                    weight: FontWeight.w700,
                                                    color:
                                                        GlassPalette.white),
                                              ),
                                            ),
                                            const SizedBox(width: 4),
                                            Expanded(
                                              child: Text(
                                                d['genre'] as String,
                                                style: GlassFont.body(
                                                    size: 9,
                                                    weight: FontWeight.w500,
                                                    color: GlassPalette
                                                        .textSub),
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}