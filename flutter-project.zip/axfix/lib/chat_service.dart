// chat_service.dart
// ═══════════════════════════════════════════════════════════════════════════
// PRIVATE CHAT SERVICE — API CALL HELPER
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'app_config.dart';

class ChatUser {
  final String username;
  final String role;
  final String? expiredDate;
  ChatUser({required this.username, required this.role, this.expiredDate});

  factory ChatUser.fromJson(Map<String, dynamic> j) => ChatUser(
        username: (j['username'] ?? '').toString(),
        role: (j['role'] ?? 'member').toString(),
        expiredDate: j['expiredDate']?.toString(),
      );
}

class ChatConversation {
  final String withUser;
  final String? lastMessage;
  final String? lastTime;
  final int unread;
  ChatConversation({
    required this.withUser,
    this.lastMessage,
    this.lastTime,
    this.unread = 0,
  });

  factory ChatConversation.fromJson(Map<String, dynamic> j) => ChatConversation(
        withUser: (j['with'] ?? '').toString(),
        lastMessage: j['lastMessage']?.toString(),
        lastTime: j['lastTime']?.toString(),
        unread: int.tryParse(j['unread']?.toString() ?? '0') ?? 0,
      );
}

class ChatMessage {
  final String id;
  final String from;
  final String to;
  final String type;
  final String message;
  final String? mediaUrl;
  final String? replyTo;
  final String? replyPreview;
  final String? replyFrom;
  final String? reaction;
  final String createdAt;
  final bool fromMe;
  final bool deletedForEveryone;
  final List<String> deletedFor;

  ChatMessage({
    required this.id,
    required this.from,
    required this.to,
    required this.type,
    required this.message,
    this.mediaUrl,
    this.replyTo,
    this.replyPreview,
    this.replyFrom,
    this.reaction,
    required this.createdAt,
    this.fromMe = false,
    this.deletedForEveryone = false,
    this.deletedFor = const [],
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        id: (j['id'] ?? '').toString(),
        from: (j['from'] ?? '').toString(),
        to: (j['to'] ?? '').toString(),
        type: (j['type'] ?? 'text').toString(),
        message: (j['message'] ?? '').toString(),
        mediaUrl: j['mediaUrl']?.toString(),
        replyTo: j['replyTo']?.toString(),
        replyPreview: j['replyPreview']?.toString(),
        replyFrom: j['replyFrom']?.toString(),
        reaction: j['reaction']?.toString(),
        createdAt: (j['createdAt'] ?? '').toString(),
        fromMe: j['fromMe'] == true,
        deletedForEveryone: j['deletedForEveryone'] == true,
        deletedFor: (j['deletedFor'] is List)
            ? List<String>.from(j['deletedFor'].map((e) => e.toString()))
            : const [],
      );
}

class ChatService {
  final String sessionKey;
  ChatService(this.sessionKey);

  Future<List<ChatUser>> searchUser(String q) async {
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/api/chat/search-user?key=$sessionKey&q=${Uri.encodeComponent(q)}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        return (data['users'] as List)
            .map((u) => ChatUser.fromJson(Map<String, dynamic>.from(u)))
            .toList();
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  Future<List<ChatConversation>> listConversations() async {
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/api/chat/list?key=$sessionKey'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        return (data['conversations'] as List)
            .map((c) => ChatConversation.fromJson(Map<String, dynamic>.from(c)))
            .toList();
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  Future<List<ChatMessage>> getMessages(String withUser) async {
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/api/chat/messages?key=$sessionKey&with=${Uri.encodeComponent(withUser)}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        return (data['messages'] as List)
            .map((m) => ChatMessage.fromJson(Map<String, dynamic>.from(m)))
            .toList();
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  Future<bool> sendText({
    required String to,
    required String message,
    String? replyTo,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'to': to,
          'message': message,
          if (replyTo != null) 'replyTo': replyTo,
        }),
      ).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> sendMedia({
    required String to,
    required File file,
    required String type,
    String caption = '',
    String? replyTo,
  }) async {
    try {
      final uri = Uri.parse('$kBaseUrl/api/chat/send-media');
      final request = http.MultipartRequest('POST', uri);
      request.fields['key'] = sessionKey;
      request.fields['to'] = to;
      request.fields['type'] = type;
      request.fields['caption'] = caption;
      if (replyTo != null) request.fields['replyTo'] = replyTo;

      final ext = file.path.split('.').last.toLowerCase();
      String mime = 'application/octet-stream';
      if (type == 'image') {
        mime = ext == 'png' ? 'image/png' : 'image/jpeg';
      } else if (type == 'video') {
        mime = 'video/mp4';
      } else if (type == 'voice') {
        mime = 'audio/m4a';
      }

      request.files.add(await http.MultipartFile.fromPath(
        'file',
        file.path,
        contentType: MediaType.parse(mime),
      ));

      final streamedRes = await request.send().timeout(const Duration(seconds: 60));
      final res = await http.Response.fromStream(streamedRes);
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<void> markRead(String withUser) async {
    try {
      await http.post(
        Uri.parse('$kBaseUrl/api/chat/read'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': sessionKey, 'with': withUser}),
      ).timeout(const Duration(seconds: 10));
    } catch (_) {}
  }

  Future<int> unreadCount() async {
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/api/chat/unread-count?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        return int.tryParse(data['count']?.toString() ?? '0') ?? 0;
      }
      return 0;
    } catch (_) {
      return 0;
    }
  }

  Future<bool> reactStatus({
    required String statusOwner,
    required String emoji,
    String? statusId,
    String? statusPreview,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/chat/react-status'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'statusOwner': statusOwner,
          'emoji': emoji,
          if (statusId != null) 'statusId': statusId,
          if (statusPreview != null) 'statusPreview': statusPreview,
        }),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> replyStatus({
    required String statusOwner,
    required String replyText,
    String? statusId,
    String? statusPreview,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/chat/reply-status'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'statusOwner': statusOwner,
          'replyText': replyText,
          if (statusId != null) 'statusId': statusId,
          if (statusPreview != null) 'statusPreview': statusPreview,
        }),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> deleteMessage({
    required String messageId,
    required String mode,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/chat/delete-message'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'messageId': messageId,
          'mode': mode,
        }),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> deleteConversation(String withUser) async {
    try {
      final res = await http.delete(
        Uri.parse('$kBaseUrl/api/chat/delete?key=$sessionKey&with=${Uri.encodeComponent(withUser)}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      return data['valid'] == true;
    } catch (_) {
      return false;
    }
  }
}