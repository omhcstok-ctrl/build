// jadwal_sholat_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// JADWAL SHOLAT — GLASSMORPHISM EDITION
// API: MyQuran (https://api.myquran.com/v2/sholat)
// Ga butuh API key — gratis & akurat
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'glass_theme.dart';

class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  final TextEditingController _kotaCtrl = TextEditingController();

  bool _loading = false;
  String? _errorMsg;
  String _kotaNama = '';
  String _tanggal = '';
  Map<String, String> _jadwal = {};

  static const String _prefsKey = 'jadwal_sholat_kota';

  @override
  void initState() {
    super.initState();
    _loadSavedKota();
  }

  @override
  void dispose() {
    _kotaCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════
  // LOAD KOTA YANG DISIMPAN
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _loadSavedKota() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefsKey);
    if (saved != null && saved.isNotEmpty) {
      _kotaCtrl.text = saved;
      _fetchJadwal(saved);
    } else {
      _kotaCtrl.text = 'jakarta';
      _fetchJadwal('jakarta');
    }
  }

  Future<void> _saveKota(String kota) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, kota);
  }

  // ═══════════════════════════════════════════════════════════════════════
  // FETCH JADWAL SHOLAT
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _fetchJadwal(String kota) async {
    if (kota.trim().isEmpty) {
      setState(() {
        _errorMsg = 'Nama kota tidak boleh kosong';
      });
      return;
    }

    setState(() {
      _loading = true;
      _errorMsg = null;
      _jadwal = {};
    });

    try {
      // Step 1: Cari ID kota
      final searchUrl = Uri.parse(
        'https://api.myquran.com/v2/sholat/kota/cari/${Uri.encodeComponent(kota.trim().toLowerCase())}',
      );
      final searchRes = await http
          .get(searchUrl)
          .timeout(const Duration(seconds: 15));

      if (searchRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Gagal cari kota (${searchRes.statusCode})';
        });
        return;
      }

      final searchJson = jsonDecode(searchRes.body);

      if (searchJson['status'] != true ||
          searchJson['data'] == null ||
          (searchJson['data'] as List).isEmpty) {
        setState(() {
          _loading = false;
          _errorMsg =
              'Kota "$kota" tidak ditemukan.\nCoba nama lain (contoh: jakarta, bandung, surabaya).';
        });
        return;
      }

      // Ambil kota pertama
      final kotaData = (searchJson['data'] as List).first;
      final kotaId = kotaData['id']?.toString() ?? '';
      final kotaNama = kotaData['lokasi']?.toString() ?? kota;

      if (kotaId.isEmpty) {
        setState(() {
          _loading = false;
          _errorMsg = 'ID kota tidak ditemukan';
        });
        return;
      }

      // Step 2: Ambil jadwal hari ini
      final now = DateTime.now();
      final year = now.year.toString();
      final month = now.month.toString().padLeft(2, '0');
      final day = now.day.toString().padLeft(2, '0');

      final jadwalUrl = Uri.parse(
        'https://api.myquran.com/v2/sholat/jadwal/$kotaId/$year/$month/$day',
      );
      final jadwalRes = await http
          .get(jadwalUrl)
          .timeout(const Duration(seconds: 15));

      if (jadwalRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Gagal ambil jadwal (${jadwalRes.statusCode})';
        });
        return;
      }

      final jadwalJson = jsonDecode(jadwalRes.body);

      if (jadwalJson['status'] != true || jadwalJson['data'] == null) {
        setState(() {
          _loading = false;
          _errorMsg = 'Jadwal tidak tersedia untuk hari ini';
        });
        return;
      }

      final data = jadwalJson['data'];
      final jadwalData = data['jadwal'] ?? {};

      setState(() {
        _loading = false;
        _kotaNama = kotaNama;
        _tanggal = data['date']?.toString() ?? '';
        _jadwal = {
          'Imsak': jadwalData['imsak']?.toString() ?? '-',
          'Subuh': jadwalData['subuh']?.toString() ?? '-',
          'Terbit': jadwalData['terbit']?.toString() ?? '-',
          'Dhuha': jadwalData['dhuha']?.toString() ?? '-',
          'Dzuhur': jadwalData['dzuhur']?.toString() ?? '-',
          'Ashar': jadwalData['ashar']?.toString() ?? '-',
          'Maghrib': jadwalData['maghrib']?.toString() ?? '-',
          'Isya': jadwalData['isya']?.toString() ?? '-',
        };
      });

      await _saveKota(kota);
    } catch (e) {
      setState(() {
        _loading = false;
        _errorMsg = 'Koneksi error: ${e.toString().split('\n').first}';
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SHOLAT BERIKUTNYA (buat highlight)
  // ═══════════════════════════════════════════════════════════════════════
  String _nextSholatKey() {
    if (_jadwal.isEmpty) return '';
    final now = DateTime.now();
    final currentMinutes = now.hour * 60 + now.minute;

    final sholatList = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
    for (final s in sholatList) {
      final time = _jadwal[s];
      if (time == null || time == '-') continue;
      final parts = time.split(':');
      if (parts.length != 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      final sholatMinutes = h * 60 + m;
      if (sholatMinutes > currentMinutes) {
        return s;
      }
    }
    // Kalau udah lewat semua, next = Subuh besok
    return 'Subuh';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.mosque_rounded,
                  color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'JADWAL SHOLAT',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          top: false,
          bottom: false,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + kToolbarHeight + 16,
              bottom: MediaQuery.of(context).padding.bottom + 40,
              left: 16,
              right: 16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSearchCard(),
                const SizedBox(height: 16),
                if (_errorMsg != null) ...[
                  _buildErrorCard(),
                  const SizedBox(height: 16),
                ],
                if (_loading) ...[
                  _buildLoadingCard(),
                ] else if (_jadwal.isNotEmpty) ...[
                  _buildHeaderKota(),
                  const SizedBox(height: 12),
                  _buildJadwalGrid(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SEARCH CARD
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildSearchCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.search_rounded,
                    color: GlassPalette.white, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                'CARI KOTA',
                style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.2,
                    ),
                  ),
                  child: TextField(
                    controller: _kotaCtrl,
                    style: GlassFont.body(
                      size: 13,
                      weight: FontWeight.w600,
                      color: GlassPalette.white,
                    ),
                    cursorColor: GlassPalette.white,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (v) => _fetchJadwal(v),
                    decoration: InputDecoration(
                      hintText: 'Contoh: jakarta, bandung, surabaya...',
                      hintStyle: GlassFont.body(
                        size: 12,
                        weight: FontWeight.w400,
                        color: GlassPalette.textDim,
                      ),
                      prefixIcon: const Icon(Icons.location_city_rounded,
                          color: GlassPalette.white, size: 18),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 14),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _loading ? null : () => _fetchJadwal(_kotaCtrl.text),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        GlassPalette.teal.withOpacity(0.6),
                        GlassPalette.blue.withOpacity(0.5),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.25),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.teal.withOpacity(0.5),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: GlassPalette.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.search_rounded,
                          color: GlassPalette.white, size: 20),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // HEADER KOTA
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildHeaderKota() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.teal.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: GlassPalette.teal.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.teal.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.mosque_rounded,
                color: GlassPalette.white, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _kotaNama.toUpperCase(),
                  style: GlassFont.pixel(
                    size: 12,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                        color: GlassPalette.teal.withOpacity(0.6),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  _tanggal.isEmpty ? 'Hari ini' : _tanggal,
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // GRID JADWAL
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildJadwalGrid() {
    final nextKey = _nextSholatKey();

    final List<Map<String, dynamic>> items = [
      {'label': 'Imsak', 'icon': Icons.nightlight_round, 'color': GlassPalette.purple},
      {'label': 'Subuh', 'icon': Icons.wb_twilight_rounded, 'color': GlassPalette.blue},
      {'label': 'Terbit', 'icon': Icons.wb_sunny_rounded, 'color': GlassPalette.orange},
      {'label': 'Dhuha', 'icon': Icons.wb_sunny_outlined, 'color': GlassPalette.amber},
      {'label': 'Dzuhur', 'icon': Icons.light_mode_rounded, 'color': GlassPalette.yellow},
      {'label': 'Ashar', 'icon': Icons.cloud_rounded, 'color': GlassPalette.orange},
      {'label': 'Maghrib', 'icon': Icons.brightness_3_rounded, 'color': GlassPalette.red},
      {'label': 'Isya', 'icon': Icons.dark_mode_rounded, 'color': GlassPalette.purple},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.5,
      ),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final item = items[i];
        final label = item['label'] as String;
        final icon = item['icon'] as IconData;
        final color = item['color'] as Color;
        final time = _jadwal[label] ?? '-';
        final isNext = label == nextKey;

        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isNext
                ? color.withOpacity(0.3)
                : Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isNext
                  ? color.withOpacity(0.8)
                  : Colors.white.withOpacity(0.15),
              width: isNext ? 2 : 1.2,
            ),
            boxShadow: isNext
                ? [
                    BoxShadow(
                      color: color.withOpacity(0.5),
                      blurRadius: 15,
                    ),
                  ]
                : null,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: color.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: Icon(icon, color: GlassPalette.white, size: 14),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      label.toUpperCase(),
                      style: GlassFont.pixel(
                        size: 8,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                        letterSpacing: 0.5,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (isNext)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 2),
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'NEXT',
                        style: GlassFont.pixel(
                          size: 6,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              Text(
                time,
                style: GlassFont.pixel(
                  size: 18,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: color.withOpacity(0.6),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // LOADING CARD
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildLoadingCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(30),
      child: Column(
        children: [
          const CircularProgressIndicator(color: GlassPalette.white),
          const SizedBox(height: 16),
          Text(
            'Mengambil jadwal sholat...',
            style: GlassFont.body(
              size: 12,
              weight: FontWeight.w500,
              color: GlassPalette.textSub,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // ERROR CARD
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildErrorCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 16,
      bgColor: GlassPalette.red.withOpacity(0.2),
      borderColor: GlassPalette.red.withOpacity(0.6),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.7),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMsg!,
              style: GlassFont.body(
                size: 11,
                weight: FontWeight.w600,
                color: GlassPalette.white,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}