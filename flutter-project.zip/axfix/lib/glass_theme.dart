// glass_theme.dart
// ═══════════════════════════════════════════════════════════════════════════
// GLASSMORPHISM THEME + LIQUID NAVIGATION + GOOGLE FONTS
// Font: Orbitron (header/body) + Share Tech Mono (mono)
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ═══════════════════════════════════════════════════════════════════════════
// PALETTE
// ═══════════════════════════════════════════════════════════════════════════
class GlassPalette {
  static const bg         = Color(0xFF0A1628);
  static const bgDots     = Color(0xFFFFFFFF);
  static const surface    = Color(0x1AFFFFFF);
  static const surfaceAlt = Color(0x0DFFFFFF);
  static const border     = Color(0x33FFFFFF);
  static const borderLit  = Color(0x66FFFFFF);

  static const yellow     = Color(0xFFFFC107);
  static const navy       = Color(0xFF1E3A8A);
  static const teal       = Color(0xFF00E5FF);
  static const red        = Color(0xFFFF3D5A);
  static const redHot     = Color(0xFFFF1744);
  static const purple     = Color(0xFF9C27FF);
  static const blue       = Color(0xFF2AABEE);
  static const green      = Color(0xFF16A34A);
  static const orange     = Color(0xFFFF6D00);
  static const cyan       = Color(0xFF00E5FF);
  static const amber      = Color(0xFFFFC107);
  static const white      = Color(0xFFFFFFFF);
  static const black      = Color(0xFF000000);

  static const text       = Color(0xFFFFFFFF);
  static const textSub    = Color(0xCCFFFFFF);
  static const textDim    = Color(0x80FFFFFF);

  static const glassGrad = LinearGradient(
    colors: [Color(0x26FFFFFF), Color(0x0DFFFFFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const neonGlowBlue = BoxShadow(
    color: Color(0x662AABEE),
    blurRadius: 20,
    spreadRadius: 1,
  );

  static const neonGlowPurple = BoxShadow(
    color: Color(0x669C27FF),
    blurRadius: 20,
    spreadRadius: 1,
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// FONT — GOOGLE FONTS (Orbitron + Share Tech Mono)
// ═══════════════════════════════════════════════════════════════════════════
class GlassFont {
  /// Untuk header / judul / label — pakai Orbitron (futuristik)
  static TextStyle pixel({
    double size = 14,
    FontWeight weight = FontWeight.w700,
    Color color = GlassPalette.text,
    double letterSpacing = 1.5,
    double height = 1.2,
    List<Shadow>? shadows,
  }) {
    return GoogleFonts.orbitron(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
      shadows: shadows,
    );
  }

  /// Untuk kode / terminal / angka monospace — pakai Share Tech Mono
  static TextStyle mono({
    double size = 12,
    FontWeight weight = FontWeight.w500,
    Color color = GlassPalette.textSub,
    double height = 1.4,
    double letterSpacing = 0.5,
    List<Shadow>? shadows,
  }) {
    return GoogleFonts.shareTechMono(
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
      shadows: shadows,
    );
  }

  /// Untuk body text / paragraf — pakai Orbitron
  static TextStyle body({
    double size = 13,
    FontWeight weight = FontWeight.w500,
    Color color = GlassPalette.text,
    double height = 1.5,
    double letterSpacing = 0.3,
    List<Shadow>? shadows,
  }) {
    return GoogleFonts.orbitron(
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
      shadows: shadows,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS CARD
// ═══════════════════════════════════════════════════════════════════════════
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final Color? bgColor;
  final Color? borderColor;
  final double borderWidth;
  final Offset shadowOffset;
  final bool showShadow;
  final VoidCallback? onTap;
  final double blurAmount;
  final double radius;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.bgColor,
    this.borderColor,
    this.borderWidth = 1.5,
    this.shadowOffset = const Offset(0, 8),
    this.showShadow = true,
    this.onTap,
    this.blurAmount = 15,
    this.radius = 20,
  });

  @override
  Widget build(BuildContext context) {
    final card = Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: showShadow
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  offset: shadowOffset,
                  blurRadius: 20,
                  spreadRadius: 0,
                ),
              ]
            : null,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blurAmount, sigmaY: blurAmount),
          child: Container(
            decoration: BoxDecoration(
              gradient: bgColor == null ? GlassPalette.glassGrad : null,
              color: bgColor,
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: borderColor ?? GlassPalette.border,
                width: borderWidth,
              ),
            ),
            child: Padding(
              padding: padding ?? const EdgeInsets.all(16),
              child: child,
            ),
          ),
        ),
      ),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: card);
    }
    return card;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS FEATURE CARD
// ═══════════════════════════════════════════════════════════════════════════
class GlassFeatureCard extends StatelessWidget {
  final IconData icon;
  final Color iconBgColor;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final EdgeInsets? margin;

  const GlassFeatureCard({
    super.key,
    required this.icon,
    required this.iconBgColor,
    this.iconColor = GlassPalette.white,
    required this.title,
    required this.subtitle,
    this.onTap,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: margin,
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: iconBgColor.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border:
                  Border.all(color: iconBgColor.withOpacity(0.6), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: iconBgColor.withOpacity(0.4),
                  blurRadius: 15,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Icon(icon, color: iconColor, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: GlassFont.pixel(
                    size: 12,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    shadows: [
                      Shadow(
                        color: iconBgColor.withOpacity(0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w400,
                    color: GlassPalette.textSub,
                    height: 1.4,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class GlassButton extends StatefulWidget {
  final String text;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color bgColor;
  final Color textColor;
  final Color borderColor;
  final bool fullWidth;
  final EdgeInsets? padding;
  final double fontSize;
  final bool isLoading;
  final bool hasArrow;
  final double radius;

  const GlassButton({
    super.key,
    required this.text,
    this.icon,
    required this.onTap,
    this.bgColor = GlassPalette.yellow,
    this.textColor = GlassPalette.white,
    this.borderColor = GlassPalette.borderLit,
    this.fullWidth = true,
    this.padding,
    this.fontSize = 12,
    this.isLoading = false,
    this.hasArrow = false,
    this.radius = 16,
  });

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        if (!widget.isLoading) widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.radius),
            boxShadow: [
              BoxShadow(
                color: widget.bgColor.withOpacity(_pressed ? 0.3 : 0.5),
                blurRadius: _pressed ? 8 : 18,
                spreadRadius: 0,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(widget.radius),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      widget.bgColor.withOpacity(0.85),
                      widget.bgColor.withOpacity(0.55),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(widget.radius),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.25),
                    width: 1.2,
                  ),
                ),
                padding: widget.padding ??
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  mainAxisSize: widget.fullWidth
                      ? MainAxisSize.max
                      : MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.isLoading)
                      SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          color: widget.textColor,
                          strokeWidth: 2,
                        ),
                      )
                    else if (widget.icon != null)
                      Icon(widget.icon, color: widget.textColor, size: 18),
                    if (widget.icon != null || widget.isLoading)
                      const SizedBox(width: 10),
                    Flexible(
                      child: Text(
                        widget.text.toUpperCase(),
                        style: GlassFont.pixel(
                          size: widget.fontSize,
                          weight: FontWeight.w700,
                          color: widget.textColor,
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                    ),
                    if (widget.hasArrow) ...[
                      const Spacer(),
                      Icon(Icons.arrow_forward_ios_rounded,
                          color: widget.textColor, size: 14),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS BANNER
// ═══════════════════════════════════════════════════════════════════════════
class GlassBanner extends StatelessWidget {
  final IconData? icon;
  final Color? iconBgColor;
  final String title;
  final String? badgeText;
  final Color bgColor;
  final Color textColor;
  final Color badgeBgColor;
  final Color badgeTextColor;
  final EdgeInsets? margin;

  const GlassBanner({
    super.key,
    this.icon,
    this.iconBgColor,
    required this.title,
    this.badgeText,
    this.bgColor = GlassPalette.blue,
    this.textColor = GlassPalette.white,
    this.badgeBgColor = GlassPalette.white,
    this.badgeTextColor = GlassPalette.blue,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: margin,
      bgColor: bgColor.withOpacity(0.3),
      borderColor: Colors.white.withOpacity(0.3),
      borderWidth: 1.5,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      radius: 18,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: (iconBgColor ?? GlassPalette.yellow).withOpacity(0.3),
                shape: BoxShape.circle,
                border: Border.all(
                  color: (iconBgColor ?? GlassPalette.yellow)
                      .withOpacity(0.7),
                  width: 1.5,
                ),
              ),
              child: Icon(icon, color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 12),
          ],
          Text(
            title,
            style: GlassFont.pixel(
              size: 14,
              weight: FontWeight.w700,
              color: textColor,
              letterSpacing: 2,
              shadows: [
                Shadow(color: bgColor.withOpacity(0.6), blurRadius: 12),
              ],
            ),
          ),
          if (badgeText != null) ...[
            const SizedBox(width: 12),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: badgeBgColor.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: badgeBgColor.withOpacity(0.6), width: 1.2),
              ),
              child: Text(
                badgeText!,
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: badgeTextColor,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS SECTION TITLE
// ═══════════════════════════════════════════════════════════════════════════
class GlassSectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final Widget? trailing;

  const GlassSectionTitle({
    super.key,
    required this.icon,
    required this.title,
    this.color = GlassPalette.white,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: GlassPalette.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: GlassPalette.border, width: 1.2),
          ),
          child: Icon(icon, color: color, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          title.toUpperCase(),
          style: GlassFont.pixel(
            size: 11,
            weight: FontWeight.w700,
            color: GlassPalette.white,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  GlassPalette.borderLit,
                  GlassPalette.borderLit.withOpacity(0.1),
                ],
              ),
            ),
          ),
        ),
        if (trailing != null) ...[
          const SizedBox(width: 10),
          trailing!,
        ],
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS BADGE
// ═══════════════════════════════════════════════════════════════════════════
class GlassBadge extends StatelessWidget {
  final String text;
  final Color bgColor;
  final Color textColor;
  final Color? borderColor;

  const GlassBadge({
    super.key,
    required this.text,
    this.bgColor = GlassPalette.yellow,
    this.textColor = GlassPalette.white,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor.withOpacity(0.25),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: borderColor ?? bgColor.withOpacity(0.6),
          width: 1.2,
        ),
      ),
      child: Text(
        text.toUpperCase(),
        style: GlassFont.pixel(
          size: 8,
          weight: FontWeight.w700,
          color: textColor,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS INPUT
// ═══════════════════════════════════════════════════════════════════════════
class GlassInput extends StatelessWidget {
  final TextEditingController? controller;
  final String hint;
  final IconData? icon;
  final bool obscure;
  final TextInputType? keyboardType;
  final int maxLines;
  final Widget? suffix;

  const GlassInput({
    super.key,
    this.controller,
    required this.hint,
    this.icon,
    this.obscure = false,
    this.keyboardType,
    this.maxLines = 1,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1.2,
            ),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            maxLines: maxLines,
            style: GlassFont.body(
              size: 13,
              weight: FontWeight.w500,
              color: GlassPalette.white,
            ),
            cursorColor: GlassPalette.white,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: GlassFont.body(
                size: 12,
                weight: FontWeight.w400,
                color: GlassPalette.textDim,
              ),
              prefixIcon: icon != null
                  ? Icon(icon, color: GlassPalette.textSub, size: 18)
                  : null,
              suffixIcon: suffix,
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS BACKGROUND
// ═══════════════════════════════════════════════════════════════════════════
class GlassBg extends StatelessWidget {
  final Widget child;
  final String? bgAsset;
  const GlassBg({super.key, required this.child, this.bgAsset});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: bgAsset != null
              ? Image.asset(
                  bgAsset!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF0A1628),
                          Color(0xFF1A1F3A),
                          Color(0xFF0F0A28),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),
                )
              : Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFF0A1628),
                        Color(0xFF1A1F3A),
                        Color(0xFF0F0A28),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.55),
                  Colors.black.withOpacity(0.35),
                  Colors.black.withOpacity(0.7),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        Positioned(
          top: -100,
          right: -100,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  GlassPalette.blue.withOpacity(0.35),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -120,
          left: -120,
          child: Container(
            width: 350,
            height: 350,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  GlassPalette.purple.withOpacity(0.3),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS DIALOG
// ═══════════════════════════════════════════════════════════════════════════
class GlassDialog extends StatelessWidget {
  final String title;
  final String message;
  final IconData? icon;
  final Color? accentColor;
  final List<Widget>? actions;

  const GlassDialog({
    super.key,
    required this.title,
    required this.message,
    this.icon,
    this.accentColor,
    this.actions,
  });

  static Future<void> show(
    BuildContext context, {
    required String title,
    required String message,
    IconData? icon,
    Color? accentColor,
    List<Widget>? actions,
  }) {
    return showDialog(
      context: context,
      barrierColor: Colors.black54,
      builder: (_) => GlassDialog(
        title: title,
        message: message,
        icon: icon,
        accentColor: accentColor,
        actions: actions,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final color = accentColor ?? GlassPalette.blue;
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28),
      child: GlassCard(
        bgColor: Colors.white.withOpacity(0.1),
        borderColor: Colors.white.withOpacity(0.25),
        borderWidth: 1.5,
        shadowOffset: const Offset(0, 10),
        padding: const EdgeInsets.all(20),
        radius: 22,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(16),
                  border:
                      Border.all(color: color.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.5),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: Icon(icon, color: GlassPalette.white, size: 26),
              ),
              const SizedBox(height: 14),
            ],
            Text(
              title.toUpperCase(),
              style: GlassFont.pixel(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              message,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w400,
                color: GlassPalette.textSub,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            if (actions != null)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: actions!,
              )
            else
              GlassButton(
                text: 'OK',
                onTap: () => Navigator.pop(context),
                bgColor: color,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                fullWidth: false,
              ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 🌊 LIQUID NAVIGATION — FLOATING PILL GLASS
// ═══════════════════════════════════════════════════════════════════════════
class GlassLiquidNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<GlassLiquidNavItem> items;
  final Color accentColor;

  const GlassLiquidNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
    this.accentColor = GlassPalette.white,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Container(
          height: 72,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(36),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 25,
                offset: const Offset(0, 15),
                spreadRadius: 0,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(36),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.35),
                  borderRadius: BorderRadius.circular(36),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(items.length, (i) {
                    final active = i == currentIndex;
                    return _LiquidNavItemWidget(
                      item: items[i],
                      active: active,
                      accentColor: accentColor,
                      onTap: () => onTap(i),
                    );
                  }),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GlassLiquidNavItem {
  final IconData icon;
  final String label;
  final bool isCentral;

  const GlassLiquidNavItem({
    required this.icon,
    required this.label,
    this.isCentral = false,
  });
}

class _LiquidNavItemWidget extends StatefulWidget {
  final GlassLiquidNavItem item;
  final bool active;
  final Color accentColor;
  final VoidCallback onTap;

  const _LiquidNavItemWidget({
    required this.item,
    required this.active,
    required this.accentColor,
    required this.onTap,
  });

  @override
  State<_LiquidNavItemWidget> createState() => _LiquidNavItemWidgetState();
}

class _LiquidNavItemWidgetState extends State<_LiquidNavItemWidget> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(
          horizontal: widget.active ? 14 : 8,
          vertical: 8,
        ),
        transform: Matrix4.translationValues(0, _down ? 2 : 0, 0),
        child: widget.item.isCentral
            ? _buildCentralItem()
            : _buildNormalItem(),
      ),
    );
  }

  Widget _buildCentralItem() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: widget.active
              ? [GlassPalette.red, GlassPalette.redHot]
              : [GlassPalette.blue, GlassPalette.purple],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: (widget.active ? GlassPalette.red : GlassPalette.blue)
                .withOpacity(0.6),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
        border: Border.all(
          color: Colors.white.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Icon(
        widget.item.icon,
        color: Colors.white,
        size: 26,
      ),
    );
  }

  Widget _buildNormalItem() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      decoration: BoxDecoration(
        color: widget.active
            ? Colors.white.withOpacity(0.15)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        border: widget.active
            ? Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1.2,
              )
            : null,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOutCubic,
            width: widget.active ? 32 : 28,
            height: widget.active ? 32 : 28,
            decoration: BoxDecoration(
              color: widget.active ? Colors.white : Colors.transparent,
              shape: BoxShape.circle,
            ),
            child: Icon(
              widget.item.icon,
              color: widget.active
                  ? Colors.black
                  : Colors.white.withOpacity(0.75),
              size: widget.active ? 18 : 20,
            ),
          ),
          if (widget.active) ...[
            const SizedBox(width: 6),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Text(
                widget.item.label,
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}