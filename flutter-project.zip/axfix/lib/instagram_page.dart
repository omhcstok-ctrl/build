// instagram_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// INSTAGRAM DOWNLOADER — GLASSMORPHISM EDITION + FULLSCREEN
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'app_config.dart';
import 'glass_theme.dart';

class InstagramDownloaderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const InstagramDownloaderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<InstagramDownloaderPage> createState() =>
      _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  List<dynamic>? _mediaData;
  String? _errorMessage;

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _videoInitializing = false;

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();

    if (url.isEmpty) {
      setState(() {
        _errorMessage = 'URL Instagram tidak boleh kosong.';
        _mediaData = null;
      });
      return;
    }

    if (!url.contains('instagram.com') && !url.contains('instagr.am')) {
      setState(() {
        _errorMessage =
            'URL harus dari Instagram (instagram.com / instagr.am).';
        _mediaData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _videoInitializing = false;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final response = await http.post(
        Uri.parse(apiUrl('/api/ig/download')),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'url': url,
        }),
      ).timeout(const Duration(seconds: 45));

      if (response.statusCode != 200) {
        setState(() {
          _errorMessage =
              'Server error (${response.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(response.body);
      final bool isSuccess =
          json['status'] == true || json['success'] == true;

      if (isSuccess) {
        List<dynamic> parsedData = [];

        if (json['items'] is List) {
          parsedData = List<dynamic>.from(json['items']);
        } else if (json['data'] is List) {
          parsedData = List<dynamic>.from(json['data']);
        } else if (json['data'] is Map) {
          final mapData = Map<String, dynamic>.from(json['data']);
          if (mapData['urls'] is List) {
            parsedData = (mapData['urls'] as List)
                .map((u) => {'url': u.toString(), 'type': 'video'})
                .toList();
          } else if (mapData['url'] != null) {
            parsedData = [
              {
                'url': mapData['url'].toString(),
                'type': mapData['type'] ?? 'video',
              }
            ];
          } else {
            parsedData = [mapData];
          }
        } else if (json['url'] != null ||
            json['video'] != null ||
            json['image'] != null) {
          if (json['video'] != null) {
            parsedData.add(
                {'url': json['video'].toString(), 'type': 'video'});
          }
          if (json['images'] is List) {
            for (final img in (json['images'] as List)) {
              parsedData.add({'url': img.toString(), 'type': 'image'});
            }
          }
          if (parsedData.isEmpty && json['url'] != null) {
            parsedData
                .add({'url': json['url'].toString(), 'type': 'video'});
          }
        }

        setState(() {
          _mediaData = parsedData;
        });
        _initializeVideoPlayer();
      } else {
        final msg = json['message']?.toString() ??
            json['error']?.toString() ??
            'Gagal mengambil data Instagram.';
        setState(() {
          _errorMessage = msg;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String? _extractMediaUrl(int index) {
    if (_mediaData == null || _mediaData!.isEmpty) return null;
    if (index >= _mediaData!.length) return null;

    final item = _mediaData![index];
    if (item is Map) {
      return (item['url'] ?? item['src'] ?? item['link'] ?? '').toString();
    }
    return item.toString();
  }

  String _extractMediaType(int index) {
    if (_mediaData == null || index >= _mediaData!.length) return 'video';
    final item = _mediaData![index];
    if (item is Map) {
      return (item['type'] ?? 'video').toString().toLowerCase();
    }
    return 'video';
  }

  bool _isVideoType(int index) {
    final type = _extractMediaType(index);
    return type.contains('video') || type.contains('mp4') || type == 'reel';
  }

  void _initializeVideoPlayer() {
    if (_mediaData == null || _mediaData!.isEmpty) return;

    int videoIndex = -1;
    for (int i = 0; i < _mediaData!.length; i++) {
      if (_isVideoType(i)) {
        videoIndex = i;
        break;
      }
    }

    if (videoIndex == -1) {
      setState(() => _videoInitializing = false);
      return;
    }

    final videoUrl = _extractMediaUrl(videoIndex);
    if (videoUrl == null || videoUrl.isEmpty) {
      setState(() {
        _errorMessage = 'URL video tidak ditemukan di response API.';
      });
      return;
    }

    setState(() => _videoInitializing = true);

    _videoController = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _videoInitializing = false;
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            looping: false,
            showControls: true,
            materialProgressColors: ChewieProgressColors(
              playedColor: GlassPalette.blue,
              handleColor: GlassPalette.white,
              backgroundColor: Colors.white.withOpacity(0.15),
              bufferedColor: GlassPalette.textDim,
            ),
          );
        });
      }).catchError((err) {
        if (!mounted) return;
        setState(() {
          _videoInitializing = false;
          _errorMessage = 'Gagal load video: $err';
        });
      });
  }

  Future<void> _shareMedia(int index) async {
    final mediaUrl = _extractMediaUrl(index);
    if (mediaUrl == null || mediaUrl.isEmpty) return;

    try {
      final response = await http.get(Uri.parse(mediaUrl));
      final tempDir = await getTemporaryDirectory();
      final isVideo = _isVideoType(index);
      final ext = isVideo ? 'mp4' : 'jpg';
      final file = File(
        '${tempDir.path}/instagram_${DateTime.now().millisecondsSinceEpoch}.$ext',
      );
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Media dari Instagram',
      );
    } catch (e) {
      if (!mounted) return;
      GlassDialog.show(
        context,
        title: 'Share Gagal',
        message: 'Error sharing: $e',
        icon: Icons.error_rounded,
        accentColor: GlassPalette.red,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      // FULLSCREEN — edge to edge
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: GlassPalette.purple.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.purple.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.camera_alt_rounded,
                  color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'INSTAGRAM DL',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + kToolbarHeight + 16,
              bottom: MediaQuery.of(context).padding.bottom + 40,
              left: 16,
              right: 16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 16),
                _buildInputCard(),
                const SizedBox(height: 16),
                if (_errorMessage != null) ...[
                  _buildErrorCard(),
                  const SizedBox(height: 16),
                ],
                if (_mediaData != null && _mediaData!.isNotEmpty)
                  _buildResultCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.purple.withOpacity(0.25),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: GlassPalette.purple.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.purple.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.camera_alt_rounded,
                color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'INSTAGRAM DOWNLOADER',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Download Reel, Post, Story & Foto',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'MASUKKAN URL INSTAGRAM',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.white,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 10),
          GlassInput(
            controller: _urlController,
            hint: 'https://www.instagram.com/reel/xxx/',
            icon: Icons.link_rounded,
            keyboardType: TextInputType.url,
          ),
          const SizedBox(height: 14),
          GlassButton(
            text: _isLoading ? 'LOADING...' : 'DOWNLOAD',
            icon: _isLoading ? null : Icons.download_rounded,
            onTap: _isLoading ? null : _downloadInstagram,
            bgColor: GlassPalette.purple,
            textColor: GlassPalette.white,
            fullWidth: true,
            padding: const EdgeInsets.symmetric(vertical: 14),
            isLoading: _isLoading,
            fontSize: 11,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 16,
      bgColor: GlassPalette.red.withOpacity(0.2),
      borderColor: GlassPalette.red.withOpacity(0.6),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.7),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w600,
                color: GlassPalette.white,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    int videoIndex = -1;
    for (int i = 0; i < _mediaData!.length; i++) {
      if (_isVideoType(i)) {
        videoIndex = i;
        break;
      }
    }

    return Column(
      children: [
        GlassCard(
          borderWidth: 1.5,
          radius: 20,
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: GlassPalette.amber.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: GlassPalette.amber.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: Icon(
                      videoIndex >= 0
                          ? Icons.videocam_rounded
                          : Icons.photo_rounded,
                      color: GlassPalette.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          videoIndex >= 0
                              ? 'VIDEO DITEMUKAN'
                              : 'FOTO DITEMUKAN',
                          style: GlassFont.pixel(
                            size: 10,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                        Text(
                          '${_mediaData!.length} media',
                          style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w400,
                            color: GlassPalette.textSub,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GlassBadge(
                    text: videoIndex >= 0 ? 'VIDEO' : 'FOTO',
                    bgColor: videoIndex >= 0
                        ? GlassPalette.red
                        : GlassPalette.teal,
                    textColor: GlassPalette.white,
                  ),
                ],
              ),
              const SizedBox(height: 12),

              if (_chewieController != null &&
                  _videoController != null &&
                  _videoController!.value.isInitialized)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: AspectRatio(
                      aspectRatio: _videoController!.value.aspectRatio,
                      child: Chewie(controller: _chewieController!),
                    ),
                  ),
                )
              else if (videoIndex == -1)
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: _mediaData!.length,
                  itemBuilder: (context, index) {
                    final url = _extractMediaUrl(index);
                    if (url == null || url.isEmpty) {
                      return Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.broken_image_rounded,
                            color: GlassPalette.textDim),
                      );
                    }
                    return GestureDetector(
                      onTap: () => _shareMedia(index),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                            width: 1.5,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: CachedNetworkImage(
                            imageUrl: url,
                            fit: BoxFit.cover,
                            placeholder: (_, __) => Container(
                              color: Colors.white.withOpacity(0.06),
                              child: const Center(
                                child: CircularProgressIndicator(
                                  color: GlassPalette.white,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                            errorWidget: (_, __, ___) => Container(
                              color: Colors.white.withOpacity(0.06),
                              child: const Center(
                                child: Icon(Icons.broken_image_rounded,
                                    color: GlassPalette.textDim, size: 30),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                )
              else
                Container(
                  height: 220,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: GlassPalette.white,
                      strokeWidth: 3,
                    ),
                  ),
                ),

              const SizedBox(height: 14),
              GlassButton(
                text: videoIndex >= 0 ? 'SHARE VIDEO' : 'SHARE FOTO',
                icon: Icons.share_rounded,
                onTap: () => _shareMedia(videoIndex >= 0 ? videoIndex : 0),
                bgColor: GlassPalette.amber,
                textColor: GlassPalette.white,
                fullWidth: true,
                padding: const EdgeInsets.symmetric(vertical: 12),
                fontSize: 10,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        GlassCard(
          borderWidth: 1.5,
          radius: 16,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.check_circle_rounded,
                    color: GlassPalette.white, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Media berhasil di-load dari Instagram',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w600,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}