// nik_check.dart
// ═══════════════════════════════════════════════════════════════════════════
// NIK CHECKER — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'glass_theme.dart';

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage> {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  @override
  void dispose() {
    _nikController.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      setState(() {
        _errorMessage = "NIK tidak boleh kosong.";
        _data = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/nik-checker?nik=$nik");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() {
            _data = json['data'];
            _errorMessage = null;
          });
        } else {
          setState(() {
            _errorMessage = "Data tidak ditemukan atau NIK tidak valid.";
          });
        }
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data dari server.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    GlassDialog.show(
      context,
      title: 'Tersalin',
      message: '$label disalin ke clipboard',
      icon: Icons.copy_rounded,
      accentColor: GlassPalette.teal,
    );
  }

  Widget _infoRow({
    required String label,
    required String? value,
    bool showCopy = false,
    VoidCallback? onCopy,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.18),
          width: 1.2,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GlassFont.body(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: GlassFont.body(
                    size: 13,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                  ),
                ),
              ],
            ),
          ),
          if (showCopy && onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: GlassPalette.yellow.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: GlassPalette.yellow.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.copy,
                    color: GlassPalette.white, size: 16),
              ),
            ),
        ],
      ),
    );
  }

  Widget _categoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 16),
      borderWidth: 1.5,
      radius: 20,
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20),
              ),
              border: Border(
                bottom: BorderSide(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.7),
                      width: 1.2,
                    ),
                  ),
                  child: Icon(icon, color: GlassPalette.white, size: 16),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: GlassFont.pixel(
                    size: 9,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              // ═══ HEADER ═══
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.25),
                            width: 1.2,
                          ),
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: GlassPalette.white, size: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'NIK CHECK',
                      style: GlassFont.pixel(
                        size: 11,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // FORM CARD
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            GlassInput(
                              controller: _nikController,
                              hint: 'Masukkan NIK (16 digit)',
                              icon: Icons.badge_rounded,
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 16),
                            GlassButton(
                              text: _isLoading ? 'MEMPROSES...' : 'CEK NIK',
                              icon: _isLoading ? null : Icons.search,
                              isLoading: _isLoading,
                              onTap: _isLoading ? null : _checkNik,
                              bgColor: GlassPalette.yellow,
                              textColor: GlassPalette.black,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              fontSize: 10,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ERROR
                      if (_errorMessage != null)
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: GlassPalette.red.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: GlassPalette.red.withOpacity(0.6),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: GlassPalette.red.withOpacity(0.3),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: GlassPalette.red.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: GlassPalette.red.withOpacity(0.7),
                                    width: 1.2,
                                  ),
                                ),
                                child: const Icon(Icons.error_outline,
                                    color: GlassPalette.white, size: 16),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _errorMessage!,
                                  style: GlassFont.body(
                                    size: 12,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                      // RESULT CARDS
                      if (_data != null) ...[
                        _categoryCard(
                          title: 'IDENTITAS DIRI',
                          icon: Icons.person,
                          children: [
                            _infoRow(
                              label: "NIK",
                              value: _data!["nik"]?.toString(),
                              showCopy: true,
                              onCopy: () => _copyToClipboard(
                                  _data!["nik"]?.toString() ?? "", "NIK"),
                            ),
                            _infoRow(
                              label: "Nama Lengkap",
                              value: _data!["data"]["nama"]?.toString(),
                              showCopy: true,
                              onCopy: () => _copyToClipboard(
                                  _data!["data"]["nama"]?.toString() ?? "",
                                  "Nama"),
                            ),
                            _infoRow(
                              label: "Jenis Kelamin",
                              value: _data!["data"]["kelamin"]?.toString(),
                            ),
                            _infoRow(
                              label: "Tempat Lahir",
                              value:
                                  _data!["data"]["tempat_lahir"]?.toString(),
                              showCopy: true,
                              onCopy: () => _copyToClipboard(
                                  _data!["data"]["tempat_lahir"]?.toString() ??
                                      "",
                                  "Tempat Lahir"),
                            ),
                            _infoRow(
                              label: "Usia",
                              value: _data!["data"]["usia"]?.toString(),
                            ),
                          ],
                        ),
                        _categoryCard(
                          title: 'DATA DOMISILI',
                          icon: Icons.location_on,
                          children: [
                            _infoRow(
                                label: "Provinsi",
                                value: _data!["data"]["provinsi"]?.toString()),
                            _infoRow(
                                label: "Kabupaten/Kota",
                                value: _data!["data"]["kabupaten"]?.toString()),
                            _infoRow(
                                label: "Kecamatan",
                                value: _data!["data"]["kecamatan"]?.toString()),
                            _infoRow(
                                label: "Kelurahan/Desa",
                                value: _data!["data"]["kelurahan"]?.toString()),
                            _infoRow(
                              label: "Alamat Lengkap",
                              value: _data!["data"]["alamat"]?.toString(),
                              showCopy: true,
                              onCopy: () => _copyToClipboard(
                                  _data!["data"]["alamat"]?.toString() ?? "",
                                  "Alamat"),
                            ),
                            _infoRow(
                                label: "TPS",
                                value: _data!["data"]["tps"]?.toString()),
                          ],
                        ),
                        _categoryCard(
                          title: 'INFORMASI TAMBAHAN',
                          icon: Icons.info,
                          children: [
                            _infoRow(
                                label: "Zodiak",
                                value: _data!["data"]["zodiak"]?.toString()),
                            _infoRow(
                                label: "Ultah Mendatang",
                                value: _data!["data"]["ultah_mendatang"]
                                    ?.toString()),
                            _infoRow(
                                label: "Pasaran",
                                value: _data!["data"]["pasaran"]?.toString()),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}