import 'package:flutter/material.dart';

// ═══════════════════════════════════════════════════════════════════════════
// APP CONFIG
// ═══════════════════════════════════════════════════════════════════════════

const String kDomain = 'http://localhost';
const int    kPort   = 1300;

const String kBaseUrl = 'http://$kDomain:$kPort';
const String kWsUrl   = 'ws://$kDomain:$kPort';

const String kAppName    = 'ATOMIC PROJECT';
const String kAppVersion = '3.0';

const String kOwnerTelegram = 'axleyfaker';
const String kOwnerWhatsapp = '6285809493530';

// ═══════════════════════════════════════════════════════════════════════════
// 🎨 PALET WARNA — GLASSMORPHISM STYLE
// ═══════════════════════════════════════════════════════════════════════════

class SixEyesPalette {
  static const bg         = Color(0xFF0A1628);
  static const surface    = Color(0x1AFFFFFF);
  static const card       = Color(0x1AFFFFFF);
  static const cardAlt    = Color(0x0DFFFFFF);

  static const border     = Color(0x33FFFFFF);
  static const borderLit  = Color(0x66FFFFFF);
  static const glow       = Color(0xFF2AABEE);

  static const red        = Color(0xFFFF3D5A);
  static const redMid     = Color(0xFFFF3D5A);
  static const redLight   = Color(0xFFFF6B80);
  static const redFrost   = Color(0xFFFFB3C1);

  static const green      = Color(0xFF16A34A);
  static const greenDim   = Color(0xFF15803D);
  static const amber      = Color(0xFFFFC107);
  static const blue       = Color(0xFF2AABEE);
  static const purple     = Color(0xFF9C27FF);
  static const cyan       = Color(0xFF00E5FF);
  static const orange     = Color(0xFFFF6D00);

  static const text       = Color(0xFFFFFFFF);
  static const textSub    = Color(0xCCFFFFFF);
  static const textDim    = Color(0x80FFFFFF);
  static const white      = Color(0xFFFFFFFF);
  static const black      = Color(0xFF000000);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF2AABEE), Color(0xFF9C27FF), Color(0xFFFF3D5A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// 🎨 TC — ALIAS GLOBAL
// ═══════════════════════════════════════════════════════════════════════════
class TC {
  static Color get bg            => SixEyesPalette.bg;
  static Color get bg2           => SixEyesPalette.surface;
  static Color get surface       => SixEyesPalette.surface;
  static Color get surface2      => SixEyesPalette.cardAlt;
  static Color get border        => SixEyesPalette.border;
  static Color get borderLight   => SixEyesPalette.borderLit;
  static Color get accent        => SixEyesPalette.redMid;
  static Color get accentLight   => SixEyesPalette.redLight;
  static Color get textPrimary   => SixEyesPalette.text;
  static Color get textSecondary => SixEyesPalette.textSub;
  static Color get textMuted     => SixEyesPalette.textDim;
  static Color get highlight     => SixEyesPalette.blue;
  static Color get green         => SixEyesPalette.green;
  static Color get red           => SixEyesPalette.redMid;
  static Color get orange        => SixEyesPalette.orange;
  static Color get cyan          => SixEyesPalette.cyan;
  static Color get purple        => SixEyesPalette.purple;
  static Color get blue          => SixEyesPalette.blue;
  static bool get isLight        => false;
}

// ═══════════════════════════════════════════════════════════════════════════
// 🎨 AC — Legacy class
// ═══════════════════════════════════════════════════════════════════════════
class AC {
  static const bg       = SixEyesPalette.bg;
  static const surface  = SixEyesPalette.surface;
  static const surface2 = SixEyesPalette.cardAlt;
  static const border   = SixEyesPalette.border;
  static const borderL  = SixEyesPalette.borderLit;
  static const accent    = SixEyesPalette.redMid;
  static const accentP   = SixEyesPalette.redLight;
  static const highlight = SixEyesPalette.blue;
  static const red    = SixEyesPalette.redMid;
  static const green  = SixEyesPalette.green;
  static const orange = SixEyesPalette.orange;
  static const yellow = SixEyesPalette.amber;
  static const cyan   = SixEyesPalette.cyan;
  static const purple = SixEyesPalette.purple;
  static const blue   = SixEyesPalette.blue;
  static const textP = SixEyesPalette.text;
  static const textS = SixEyesPalette.textSub;
  static const textM = SixEyesPalette.textDim;
  static const white = SixEyesPalette.white;
}

// ═══════════════════════════════════════════════════════════════════════════
// HELPER — Bangun URL endpoint
// ═══════════════════════════════════════════════════════════════════════════
String apiUrl(String endpoint) {
  final cleanBase = kBaseUrl.endsWith('/')
      ? kBaseUrl.substring(0, kBaseUrl.length - 1)
      : kBaseUrl;
  final cleanEnd = endpoint.startsWith('/') ? endpoint : '/$endpoint';
  return '$cleanBase$cleanEnd';
}