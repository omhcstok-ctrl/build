// wifi_external.dart
// ═══════════════════════════════════════════════════════════════════════════
// WIFI EXTERNAL — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'glass_theme.dart';

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  Future<void> _loadPublicInfo() async {
    setState(() {
      isLoading = true;
    });

    try {
      final ipRes =
          await http.get(Uri.parse("https://api.ipify.org?format=json"));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http.get(Uri.parse(
          "http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  Future<void> _attackTarget() async {
    setState(() => isAttacking = true);
    final url = Uri.parse(
        "$kBaseUrl/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        _showAlert("Attack Sent", "WiFi attack sent to $publicIp");
      } else {
        _showAlert("Failed", "Server rejected request.");
      }
    } catch (e) {
      _showAlert("Error", "Network error: $e");
    } finally {
      setState(() => isAttacking = false);
    }
  }

  void _showAlert(String title, String message) {
    GlassDialog.show(
      context,
      title: title,
      message: message,
      icon: Icons.wifi_off_rounded,
      accentColor: GlassPalette.red,
    );
  }

  Widget _infoCard(String title, String value, IconData icon) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      borderWidth: 1.5,
      radius: 16,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.yellow.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.yellow.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.yellow.withOpacity(0.35),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Icon(icon, color: GlassPalette.white, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GlassFont.pixel(
                    size: 8,
                    weight: FontWeight.w700,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: GlassFont.body(
                    size: 13,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: GlassPalette.white))
                    : SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              "SYSTEM INFORMATION",
                              style: GlassFont.pixel(
                                size: 10,
                                weight: FontWeight.w700,
                                color: GlassPalette.text,
                              ),
                            ),
                            const SizedBox(height: 12),

                            _infoCard("IP Address", publicIp, Icons.language),
                            _infoCard("Region", region, Icons.map),
                            _infoCard("ASN", asn, Icons.storage),

                            const SizedBox(height: 20),

                            if (isVpn)
                              GlassCard(
                                borderWidth: 1.5,
                                radius: 20,
                                padding: const EdgeInsets.all(16),
                                bgColor: GlassPalette.red.withOpacity(0.15),
                                borderColor:
                                    GlassPalette.red.withOpacity(0.6),
                                child: Column(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: GlassPalette.red
                                            .withOpacity(0.25),
                                        borderRadius:
                                            BorderRadius.circular(14),
                                        border: Border.all(
                                          color: GlassPalette.red
                                              .withOpacity(0.7),
                                          width: 1.5,
                                        ),
                                      ),
                                      child: const Icon(
                                          Icons.warning_amber_rounded,
                                          color: GlassPalette.white,
                                          size: 32),
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      "Target berasal dari VPN/Hosting.\nSerangan dibatalkan.",
                                      textAlign: TextAlign.center,
                                      style: GlassFont.body(
                                        size: 12,
                                        weight: FontWeight.w700,
                                        color: GlassPalette.white,
                                        height: 1.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                            if (!isVpn)
                              GlassButton(
                                text: isAttacking
                                    ? 'ATTACKING...'
                                    : 'START KILL',
                                icon: Icons.wifi_off,
                                isLoading: isAttacking,
                                onTap: isAttacking ? null : _attackTarget,
                                bgColor: GlassPalette.red,
                                textColor: GlassPalette.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                                fontSize: 11,
                              ),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'WIFI EXTERNAL',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}