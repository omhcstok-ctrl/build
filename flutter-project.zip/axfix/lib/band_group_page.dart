// band_group_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// BAND GROUP — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'app_config.dart';
import 'glass_theme.dart';

const String _kBandProgressVideoAsset = 'assets/videos/progress_band.mp4';

class BandGroupPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const BandGroupPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    required this.listBug,
  });

  @override
  State<BandGroupPage> createState() => _BandGroupPageState();
}

class _BandGroupPageState extends State<BandGroupPage>
    with TickerProviderStateMixin {
  final _linkCtrl = TextEditingController();

  late AnimationController _slideController;
  late AnimationController _pulseController;
  late Animation<Offset> _slideAnimation;

  bool _isSending = false;
  String _senderType = 'private';
  String selectedBugId = 'lock_group';

  List<dynamic> _globalSenders = [];
  bool _loadingGlobal = false;
  bool _isOwner = false;

  VideoPlayerController? _bannerVideoController;
  Timer? _globalSenderTimer;

  Timer? _validateDebounce;
  bool _isValidatingLink = false;
  String _validationText = '';
  bool _linkValid = false;
  String? _groupName;
  String? _linkError;

  Completer<void>? _videoDoneCompleter;

  @override
  void initState() {
    super.initState();

    _slideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();
    _slideAnimation = Tween<Offset>(
            begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _slideController, curve: Curves.easeOutCubic));

    _pulseController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);

    _isOwner = widget.role.toLowerCase() == 'owner';

    _initBannerVideo();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchGlobalSenders();
    });

    _globalSenderTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchGlobalSenders(silent: true);
    });

    _linkCtrl.addListener(_onLinkChanged);
  }

  void _onLinkChanged() {
    final link = _linkCtrl.text.trim();

    if (link.isEmpty) {
      _validateDebounce?.cancel();
      if (mounted) {
        setState(() {
          _isValidatingLink = false;
          _validationText = '';
          _linkValid = false;
          _groupName = null;
          _linkError = null;
        });
      }
      return;
    }

    if (!link.contains('chat.whatsapp.com/')) {
      _validateDebounce?.cancel();
      if (mounted) {
        setState(() {
          _isValidatingLink = false;
          _validationText = '';
          _linkValid = false;
          _groupName = null;
          _linkError = 'Format link tidak valid';
        });
      }
      return;
    }

    _validateDebounce?.cancel();
    _validateDebounce = Timer(const Duration(milliseconds: 800), () {
      if (mounted) _validateLink(link);
    });
  }

  Future<void> _validateLink(String link) async {
    if (!mounted) return;

    setState(() {
      _isValidatingLink = true;
      _validationText = 'sedang memvalidasi link group..';
      _linkValid = false;
      _groupName = null;
      _linkError = null;
    });

    await Future.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;
    setState(() {
      _validationText = 'menghubungkan server..';
    });

    await Future.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;

    try {
      final encodedTarget = Uri.encodeComponent(link);
      final url =
          '$kBaseUrl/checkGroup?key=${widget.sessionKey}&target=$encodedTarget';

      final res =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));

      final body = res.body.trim();

      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        throw Exception('Server returned HTML');
      }

      final data = jsonDecode(body);

      if (data['valid'] == true) {
        setState(() {
          _validationText = 'success✅';
          _linkValid = true;
          _groupName = data['name']?.toString() ?? 'Group WhatsApp';
          _linkError = null;
        });
      } else {
        setState(() {
          _validationText = 'link tidak valid❌';
          _linkValid = false;
          _groupName = null;
          _linkError = data['message']?.toString() ?? 'Link tidak valid';
        });
      }
    } catch (e) {
      try {
        final fallback = await _fetchGroupNameFromWhatsApp(link);
        if (fallback != null) {
          setState(() {
            _validationText = 'success✅';
            _linkValid = true;
            _groupName = fallback;
            _linkError = null;
          });
        } else {
          setState(() {
            _validationText = 'gagal cek link❌';
            _linkValid = false;
            _groupName = null;
            _linkError = 'Gagal memvalidasi link';
          });
        }
      } catch (_) {
        setState(() {
          _validationText = 'gagal cek link❌';
          _linkValid = false;
          _groupName = null;
          _linkError = 'Gagal menghubungi server';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isValidatingLink = false;
        });
      }
    }
  }

  Future<String?> _fetchGroupNameFromWhatsApp(String link) async {
    try {
      final uri = Uri.parse(link);
      final code = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : '';
      if (code.isEmpty) return null;

      final res = await http.get(
        Uri.parse('https://chat.whatsapp.com/$code'),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
      ).timeout(const Duration(seconds: 12));

      final html = res.body;

      final match = RegExp(
        r'<meta\s+property="og:title"\s+content="([^"]+)"',
        caseSensitive: false,
      ).firstMatch(html);

      if (match != null && match.group(1) != null) {
        final raw = match.group(1)!;
        return raw
            .replaceAll('&amp;', '&')
            .replaceAll('&quot;', '"')
            .replaceAll('&#39;', "'")
            .replaceAll('&lt;', '<')
            .replaceAll('&gt;', '>');
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _pasteLink() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text?.trim() ?? '';
      if (text.isEmpty) {
        if (!mounted) return;
        GlassDialog.show(context,
            title: 'Error',
            message: 'Clipboard kosong!',
            icon: Icons.error_outline,
            accentColor: GlassPalette.red);
        return;
      }
      _linkCtrl.text = text;
      _validateDebounce?.cancel();
      if (mounted && text.contains('chat.whatsapp.com/')) {
        _validateLink(text);
      }
    } catch (_) {
      if (!mounted) return;
      GlassDialog.show(context,
          title: 'Error',
          message: 'Gagal mengambil dari clipboard.',
          icon: Icons.error_outline,
          accentColor: GlassPalette.red);
    }
  }

  void _initBannerVideo() {
    _bannerVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4');
    _bannerVideoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _bannerVideoController?.setLooping(true);
      _bannerVideoController?.play();
      _bannerVideoController?.setVolume(0);
    }).catchError((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _fetchGlobalSenders({bool silent = false}) async {
    if (!silent) setState(() => _loadingGlobal = true);
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/getPublicSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        if (!silent && mounted) setState(() => _loadingGlobal = false);
        return;
      }

      final d = jsonDecode(body);
      if (d['valid'] == true) {
        if (mounted) {
          setState(() {
            _globalSenders = List<dynamic>.from(d['senders'] ?? []);
            _isOwner = (d['isOwner'] == true) ||
                widget.role.toLowerCase() == 'owner';
          });
        }
      }
    } catch (_) {}
    if (!silent && mounted) setState(() => _loadingGlobal = false);
  }

  @override
  void dispose() {
    _validateDebounce?.cancel();
    _globalSenderTimer?.cancel();
    _linkCtrl.removeListener(_onLinkChanged);
    _linkCtrl.dispose();
    _slideController.dispose();
    _pulseController.dispose();
    _bannerVideoController?.dispose();
    super.dispose();
  }

  Future<void> _sendBandGroup() async {
    final link = _linkCtrl.text.trim();

    if (link.isEmpty) {
      GlassDialog.show(context,
          title: 'Error',
          message: 'Link group target tidak boleh kosong!',
          icon: Icons.error_outline,
          accentColor: GlassPalette.red);
      return;
    }
    if (!link.contains('chat.whatsapp.com/')) {
      GlassDialog.show(context,
          title: 'Error',
          message: 'Format link salah. Pastikan link dari WhatsApp Group.',
          icon: Icons.error_outline,
          accentColor: GlassPalette.red);
      return;
    }

    setState(() {
      _isSending = true;
    });

    try {
      final httpFuture = () async {
        final encodedTarget = Uri.encodeComponent(link);
        final url =
            '$kBaseUrl/sendBug?key=${widget.sessionKey}&target=$encodedTarget&bug=$selectedBugId&senderType=$_senderType';

        final res = await http
            .get(Uri.parse(url))
            .timeout(const Duration(seconds: 60));
        final data = jsonDecode(res.body);

        bool isSuccess = false;
        String msg = '';

        if (data['valid'] == false) {
          msg = data['message'] ?? 'Session Invalid.';
        } else if (data['cooldown'] == true) {
          msg = 'Cooldown: Tunggu ${data['wait']} detik.';
        } else if (data['sended'] == true) {
          isSuccess = true;
          msg = 'Band GB berhasil dikirim 🩸';
        } else {
          msg = data['message'] ?? 'Gagal mengirim band GB.';
        }

        return {'success': isSuccess, 'msg': msg};
      }();

      final results = await Future.wait([
        httpFuture,
        _showProgressDialog(),
      ]);

      final httpResult = results[0] as Map<String, dynamic>;
      final isSuccess = httpResult['success'] as bool;
      final msg = httpResult['msg'] as String;

      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));

      if (isSuccess) {
        _showSuccessDialog(msg);
        _linkCtrl.clear();
      } else {
        _showErrorDialog(msg);
      }
    } catch (e) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));
      _showErrorDialog('Gagal menghubungi server.');
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<void> _showProgressDialog() async {
    _videoDoneCompleter = Completer<void>();

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _ProgressVideoDialog(
        onVideoEnd: () {
          if (_videoDoneCompleter != null &&
              !_videoDoneCompleter!.isCompleted) {
            _videoDoneCompleter!.complete();
          }
        },
      ),
    );

    await _videoDoneCompleter!.future;
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _SuccessDialogCard(
        message: message,
        onClose: () => Navigator.of(context, rootNavigator: true).pop(),
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _ErrorDialogCard(
        message: message,
        onClose: () => Navigator.of(context, rootNavigator: true).pop(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBarCustom(),
              Expanded(
                child: SingleChildScrollView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildInfoBanner(),
                        const SizedBox(height: 18),
                        GlassSectionTitle(
                          icon: Icons.link_rounded,
                          title: 'Link Group Target',
                          color: GlassPalette.teal,
                        ),
                        const SizedBox(height: 10),
                        _buildLinkInput(),
                        const SizedBox(height: 8),
                        _buildLinkStatus(),
                        const SizedBox(height: 22),
                        GlassSectionTitle(
                          icon: Icons.dns_rounded,
                          title: 'Pilih Sender',
                          color: GlassPalette.teal,
                        ),
                        const SizedBox(height: 10),
                        _buildSenderSelector(),
                        const SizedBox(height: 24),
                        GlassButton(
                          text: _isSending ? 'SENDING...' : 'SEND BAND GB',
                          icon: _isSending ? null : Icons.block_rounded,
                          isLoading: _isSending,
                          onTap: _isSending ? null : _sendBandGroup,
                          bgColor: GlassPalette.red,
                          textColor: GlassPalette.white,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          fontSize: 12,
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarCustom() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.red.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'BAND GROUP',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: GlassPalette.teal,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      widget.role.toUpperCase(),
                      style: GlassFont.pixel(
                        size: 7,
                        weight: FontWeight.w700,
                        color: GlassPalette.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBanner() {
    return GlassCard(
      padding: EdgeInsets.zero,
      borderWidth: 1.5,
      radius: 22,
      child: SizedBox(
        height: 160,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_bannerVideoController != null &&
                  _bannerVideoController!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bannerVideoController!.value.size.width,
                    height: _bannerVideoController!.value.size.height,
                    child: VideoPlayer(_bannerVideoController!),
                  ),
                )
              else
                Container(color: Colors.white.withOpacity(0.1)),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.75),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 12,
                left: 12,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.7),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.red.withOpacity(0.5),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          color: GlassPalette.red,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'BAND GROUP',
                        style: GlassFont.pixel(
                          size: 8,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 14,
                left: 14,
                right: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'BAND / LOCK GROUP',
                      style: GlassFont.pixel(
                        size: 12,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Kirim band ke group WhatsApp via sender aktif',
                      style: GlassFont.body(
                          size: 11,
                          weight: FontWeight.w500,
                          color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLinkInput() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _linkCtrl,
            keyboardType: TextInputType.url,
            style: GlassFont.body(
              size: 13,
              weight: FontWeight.w600,
              color: GlassPalette.white,
            ),
            cursorColor: GlassPalette.white,
            maxLines: 3,
            minLines: 2,
            decoration: InputDecoration(
              hintText: 'https://chat.whatsapp.com/...',
              hintStyle: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim),
              prefixIcon: const Icon(Icons.link_rounded,
                  color: GlassPalette.white, size: 20),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _pasteLink,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.content_paste_rounded,
                          color: GlassPalette.white, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        'TEMPEL LINK GROUP',
                        style: GlassFont.pixel(
                          size: 9,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkStatus() {
    final bool showSpinner = _isValidatingLink;
    final bool showSuccess = !_isValidatingLink && _linkValid;
    final bool showError = !_isValidatingLink &&
        !_linkValid &&
        _linkError != null &&
        _linkCtrl.text.trim().isNotEmpty;

    if (!showSpinner && !showSuccess && !showError) {
      return const SizedBox.shrink();
    }

    String displayText = _validationText;
    Color textColor = GlassPalette.textSub;
    Color accentColor = GlassPalette.red;
    IconData? endIcon;

    if (showSpinner) {
      textColor = GlassPalette.textSub;
      accentColor = GlassPalette.blue;
    } else if (showSuccess) {
      textColor = GlassPalette.teal;
      accentColor = GlassPalette.teal;
      endIcon = Icons.check_circle_rounded;
    } else if (showError) {
      textColor = GlassPalette.red;
      accentColor = GlassPalette.red;
      endIcon = Icons.error_rounded;
      displayText = _linkError ?? 'link tidak valid';
    }

    return Padding(
      padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (showSpinner)
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor:
                        AlwaysStoppedAnimation<Color>(accentColor),
                  ),
                )
              else if (endIcon != null)
                Icon(endIcon, color: accentColor, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  displayText,
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
              ),
            ],
          ),
          if (showSuccess && _groupName != null && _groupName!.isNotEmpty) ...[
            const SizedBox(height: 6),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.groups_rounded,
                      color: GlassPalette.teal, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _groupName!,
                      style: GlassFont.body(
                        size: 12,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSenderSelector() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.dns_rounded,
                    color: GlassPalette.white, size: 18),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sender Type',
                      style: GlassFont.pixel(
                          size: 9,
                          weight: FontWeight.w700,
                          color: GlassPalette.white)),
                  Text('Pilih sumber nomor pengirim',
                      style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w400,
                          color: GlassPalette.textDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _senderTypeCard(
                  'Global',
                  'global',
                  Icons.language_rounded,
                  'Public Sender',
                  GlassPalette.teal,
                  senderCount: _globalSenders.length,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _senderTypeCard(
                  'Private',
                  'private',
                  Icons.person_rounded,
                  'Session pribadi',
                  GlassPalette.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.2,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _senderType == 'global'
                        ? GlassPalette.teal
                        : GlassPalette.blue,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  _senderType == 'global'
                      ? 'Public sender aktif'
                      : 'Private sender aktif',
                  style: GlassFont.body(
                      size: 11,
                      weight: FontWeight.w500,
                      color: GlassPalette.textSub),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _senderTypeCard(
    String label,
    String value,
    IconData icon,
    String sub,
    Color activeColor, {
    int? senderCount,
  }) {
    final bool isSel = _senderType == value;
    final bool isDisabled =
        value == 'global' && widget.role != 'owner' && widget.role != 'vip';
    final bool showCount = senderCount != null;

    return GestureDetector(
      onTap: isDisabled ? null : () => setState(() => _senderType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: isDisabled
              ? Colors.white.withOpacity(0.05)
              : isSel
                  ? activeColor.withOpacity(0.25)
                  : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDisabled
                ? Colors.white.withOpacity(0.1)
                : isSel
                    ? activeColor.withOpacity(0.7)
                    : Colors.white.withOpacity(0.15),
            width: isSel ? 1.5 : 1.2,
          ),
          boxShadow: isSel && !isDisabled
              ? [
                  BoxShadow(
                    color: activeColor.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isDisabled
                  ? GlassPalette.textDim
                  : (isSel ? GlassPalette.white : GlassPalette.textSub),
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: GlassFont.pixel(
                size: 9,
                weight: FontWeight.w700,
                color: isDisabled
                    ? GlassPalette.textDim
                    : (isSel ? GlassPalette.white : GlassPalette.textSub),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              isDisabled ? 'Khusus Owner / VIP' : sub,
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w400,
                color: isDisabled
                    ? GlassPalette.textDim
                    : (isSel ? GlassPalette.white : GlassPalette.textDim),
              ),
              textAlign: TextAlign.center,
            ),
            if (showCount && !isDisabled) ...[
              const SizedBox(height: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: senderCount! > 0
                      ? GlassPalette.blue.withOpacity(0.4)
                      : Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: senderCount > 0
                        ? GlassPalette.blue.withOpacity(0.6)
                        : Colors.white.withOpacity(0.15),
                    width: 1,
                  ),
                ),
                child: Text(
                  senderCount > 0 ? '$senderCount aktif' : 'tidak ada',
                  style: GlassFont.pixel(
                    size: 7,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PROGRESS VIDEO DIALOG — GLASS
// ═══════════════════════════════════════════════════════════════════════════
class _ProgressVideoDialog extends StatefulWidget {
  final VoidCallback? onVideoEnd;

  const _ProgressVideoDialog({this.onVideoEnd});

  @override
  State<_ProgressVideoDialog> createState() => _ProgressVideoDialogState();
}

class _ProgressVideoDialogState extends State<_ProgressVideoDialog> {
  VideoPlayerController? _ctrl;
  bool _ready = false;
  bool _endNotified = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final ctrl = VideoPlayerController.asset(_kBandProgressVideoAsset);
    _ctrl = ctrl;
    try {
      await ctrl.initialize();
      await ctrl.setLooping(false);
      await ctrl.setVolume(0);

      ctrl.addListener(_onVideoTick);

      await ctrl.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      if (mounted) setState(() => _ready = false);
      _notifyEnd();
    }
  }

  void _onVideoTick() {
    final ctrl = _ctrl;
    if (ctrl == null) return;
    if (!ctrl.value.isInitialized) return;

    if (ctrl.value.position >= ctrl.value.duration &&
        ctrl.value.duration.inMilliseconds > 0) {
      _notifyEnd();
    }
  }

  void _notifyEnd() {
    if (_endNotified) return;
    _endNotified = true;
    widget.onVideoEnd?.call();
  }

  @override
  void dispose() {
    _ctrl?.removeListener(_onVideoTick);
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: GlassPalette.red.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.block_rounded,
                      color: GlassPalette.white, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'MENGIRIM BAND GB...',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.2),
                    width: 1.2,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: _ready && _ctrl != null
                      ? FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _ctrl!.value.size.width,
                            height: _ctrl!.value.size.height,
                            child: VideoPlayer(_ctrl!),
                          ),
                        )
                      : const Center(
                          child: SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: GlassPalette.white,
                              strokeWidth: 2,
                            ),
                          ),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: GlassPalette.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Mohon tunggu, band GB sedang dikirim...',
                      style: GlassFont.body(
                        size: 11,
                        weight: FontWeight.w500,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SuccessDialogCard extends StatelessWidget {
  final String message;
  final VoidCallback onClose;

  const _SuccessDialogCard({
    required this.message,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.7),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.teal.withOpacity(0.6),
                    blurRadius: 25,
                  ),
                ],
              ),
              child: const Icon(Icons.check_circle_rounded,
                  color: GlassPalette.white, size: 44),
            ),
            const SizedBox(height: 20),
            Text(
              'SUKSES!',
              style: GlassFont.pixel(
                size: 16,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              height: 1,
              color: Colors.white.withOpacity(0.15),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w600,
                color: GlassPalette.textSub,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            GlassButton(
              text: 'CLOSE',
              icon: Icons.close_rounded,
              onTap: onClose,
              bgColor: GlassPalette.teal,
              textColor: GlassPalette.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              fontSize: 11,
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorDialogCard extends StatelessWidget {
  final String message;
  final VoidCallback onClose;

  const _ErrorDialogCard({
    required this.message,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.7),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.red.withOpacity(0.6),
                    blurRadius: 25,
                  ),
                ],
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: GlassPalette.white, size: 44),
            ),
            const SizedBox(height: 20),
            Text(
              'GAGAL!',
              style: GlassFont.pixel(
                size: 16,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              height: 1,
              color: Colors.white.withOpacity(0.15),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w600,
                color: GlassPalette.textSub,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            GlassButton(
              text: 'CLOSE',
              icon: Icons.close_rounded,
              onTap: onClose,
              bgColor: GlassPalette.red,
              textColor: GlassPalette.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              fontSize: 11,
            ),
          ],
        ),
      ),
    );
  }
}