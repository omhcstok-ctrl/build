// notification_service.dart
// ═══════════════════════════════════════════════════════════════════════════
// NOTIFICATION SERVICE — buat incoming call + general notif
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  Function(String? payload)? onNotificationTap;
  Function(String actionId, String? payload)? onNotificationAction;

  static const String channelIdCall = 'incoming_call_channel';
  static const String channelNameCall = 'Incoming Call';
  static const String channelIdGeneral = 'general_channel';
  static const String channelNameGeneral = 'General Notification';

  static const int notifIdIncomingCall = 1;
  static const int notifIdGeneral = 100;

  Future<void> init() async {
    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) {
        debugPrint(
            '[NOTIF] Tapped: ${response.payload} | Action: ${response.actionId}');

        final actionId = response.actionId ?? '';
        final payload = response.payload ?? '';

        if (actionId.isNotEmpty) {
          onNotificationAction?.call(actionId, payload);
        } else {
          onNotificationTap?.call(payload);
        }
      },
      onDidReceiveBackgroundNotificationResponse: _onBackgroundTap,
    );

    await _createAndroidChannels();
  }

  @pragma('vm:entry-point')
  static void _onBackgroundTap(NotificationResponse response) {
    debugPrint(
        '[NOTIF] Background tap: ${response.payload} | Action: ${response.actionId}');
  }

  Future<void> _createAndroidChannels() async {
    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin == null) return;

    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        channelIdCall,
        channelNameCall,
        description: 'Notifikasi panggilan masuk',
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
        enableLights: true,
        sound: RawResourceAndroidNotificationSound('ringtone'),
        ledColor: Color(0xFFFF3D5A),
      ),
    );

    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        channelIdGeneral,
        channelNameGeneral,
        description: 'Notifikasi umum',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );
  }

  Future<bool> requestPermission() async {
    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      final granted = await androidPlugin.requestNotificationsPermission();
      return granted ?? false;
    }
    return true;
  }

  Future<void> showIncomingCall({
    required String fromUser,
    required String callType,
    required String callId,
  }) async {
    final payload = jsonEncode({
      'type': 'incoming_call',
      'from': fromUser,
      'callType': callType,
      'callId': callId,
    });

    final title = callType == 'video' ? '📹 Video Call' : '📞 Panggilan Suara';
    final body = '$fromUser memanggil kamu...';

    final androidDetails = AndroidNotificationDetails(
      channelIdCall,
      channelNameCall,
      channelDescription: 'Notifikasi panggilan masuk',
      importance: Importance.max,
      priority: Priority.max,
      playSound: true,
      enableVibration: true,
      enableLights: true,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      visibility: NotificationVisibility.public,
      ongoing: true,
      autoCancel: false,
      timeoutAfter: 60000,
      color: const Color(0xFFFF3D5A),
      colorized: true,
      actions: <AndroidNotificationAction>[
        const AndroidNotificationAction(
          'accept_call',
          '✅ Terima',
          showsUserInterface: true,
          cancelNotification: true,
        ),
        const AndroidNotificationAction(
          'reject_call',
          '❌ Tolak',
          showsUserInterface: true,
          cancelNotification: true,
        ),
      ],
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'ringtone.aiff',
      interruptionLevel: InterruptionLevel.timeSensitive,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _plugin.show(
      notifIdIncomingCall,
      title,
      body,
      details,
      payload: payload,
    );
  }

  Future<void> cancelIncomingCall() async {
    await _plugin.cancel(notifIdIncomingCall);
  }

  Future<void> showGeneral({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      channelIdGeneral,
      channelNameGeneral,
      channelDescription: 'Notifikasi umum',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      color: const Color(0xFFFF3D5A),
      colorized: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _plugin.show(id, title, body, details, payload: payload);
  }

  Future<void> cancelGeneral(int id) async {
    await _plugin.cancel(id);
  }

  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }
}