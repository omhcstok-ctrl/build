// spam_ngl.dart
// ═══════════════════════════════════════════════════════════════════════════
// NGL SPAM — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'glass_theme.dart';

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  String statusLog = "";
  Timer? timer;

  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16))
        .join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        setState(() {
          counter++;
          statusLog = "[$counter] Pesan terkirim";
        });
      } else {
        setState(() {
          statusLog = "Ratelimit (${response.statusCode}), tunggu 5 detik...";
        });
        await Future.delayed(const Duration(seconds: 5));
      }
    } catch (e) {
      setState(() => statusLog = "Error: $e");
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();

    if (username.isEmpty || message.isEmpty) {
      setState(() => statusLog = "Harap isi username & pesan!");
      return;
    }

    setState(() {
      isRunning = true;
      counter = 0;
      statusLog = "▶ Mulai mengirim...";
    });

    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (isRunning) sendMessage(username, message);
    });
  }

  void stopLoop() {
    setState(() {
      isRunning = false;
      statusLog = "⏹ Dihentikan.";
    });
    timer?.cancel();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: GlassPalette.white, size: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'NGL AUTO SENDER',
                      style: GlassFont.pixel(
                        size: 11,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            GlassInput(
                              controller: usernameController,
                              hint: 'Username NGL',
                              icon: Icons.person,
                            ),
                            const SizedBox(height: 14),
                            GlassInput(
                              controller: messageController,
                              hint: 'Pesan',
                              icon: Icons.message,
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: GlassButton(
                              text: 'START',
                              icon: Icons.play_arrow,
                              onTap: isRunning ? null : startLoop,
                              bgColor: GlassPalette.teal,
                              textColor: GlassPalette.white,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              fontSize: 10,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: GlassButton(
                              text: 'STOP',
                              icon: Icons.stop,
                              onTap: isRunning ? stopLoop : null,
                              bgColor: GlassPalette.red,
                              textColor: GlassPalette.white,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 18,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  isRunning
                                      ? Icons.play_circle
                                      : Icons.info_outline,
                                  color: GlassPalette.white,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    statusLog.isEmpty
                                        ? "Siap memulai..."
                                        : statusLog,
                                    style: GlassFont.body(
                                      size: 12,
                                      weight: FontWeight.w600,
                                      color: GlassPalette.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if (counter > 0) ...[
                              const SizedBox(height: 12),
                              GlassBadge(
                                text: 'Total terkirim: $counter',
                                bgColor: GlassPalette.teal,
                                textColor: GlassPalette.white,
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}