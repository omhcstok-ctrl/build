// tiktok_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// TIKTOK DOWNLOADER — GLASSMORPHISM EDITION + FULLSCREEN
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'app_config.dart';
import 'glass_theme.dart';

class TiktokDownloaderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const TiktokDownloaderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _videoInitializing = false;

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();

    if (url.isEmpty) {
      setState(() {
        _errorMessage = 'URL TikTok tidak boleh kosong.';
        _videoData = null;
      });
      return;
    }

    if (!url.contains('tiktok.com') && !url.contains('vt.tiktok')) {
      setState(() {
        _errorMessage = 'URL harus dari TikTok (tiktok.com / vt.tiktok.com).';
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoInitializing = false;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final response = await http.post(
        Uri.parse(apiUrl('/api/tiktok/download')),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'url': url,
        }),
      ).timeout(const Duration(seconds: 45));

      print('[TIKTOK] Status: ${response.statusCode}');
      print('[TIKTOK] Body: ${response.body.substring(0, 300)}');

      if (response.statusCode != 200) {
        setState(() {
          _errorMessage =
              'Server error (${response.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(response.body);
      final bool isSuccess =
          json['status'] == true || json['success'] == true;

      if (isSuccess) {
        setState(() {
          _videoData = Map<String, dynamic>.from(json);
        });
        _initializeVideoPlayer();
      } else {
        final msg = json['message']?.toString() ??
            json['error']?.toString() ??
            'Gagal mengambil data TikTok.';
        setState(() {
          _errorMessage = msg;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String? _extractVideoUrl() {
    if (_videoData == null) return null;

    if (_videoData!['video_url'] != null) {
      return _videoData!['video_url'].toString();
    }
    if (_videoData!['video_urls'] is List &&
        (_videoData!['video_urls'] as List).isNotEmpty) {
      return _videoData!['video_urls'][0].toString();
    }
    if (_videoData!['urls'] is List &&
        (_videoData!['urls'] as List).isNotEmpty) {
      return _videoData!['urls'][0].toString();
    }
    if (_videoData!['url'] != null) return _videoData!['url'].toString();
    if (_videoData!['video'] != null) return _videoData!['video'].toString();
    if (_videoData!['play'] != null) return _videoData!['play'].toString();
    if (_videoData!['hdplay'] != null) return _videoData!['hdplay'].toString();
    if (_videoData!['videoUrl'] != null) {
      return _videoData!['videoUrl'].toString();
    }
    return null;
  }

  String _extractCreator() {
    if (_videoData == null) return 'Unknown';
    return (_videoData!['author_name'] ??
            _videoData!['author_username'] ??
            _videoData!['author']?['nickname'] ??
            _videoData!['author']?['unique_id'] ??
            _videoData!['metadata']?['creator'] ??
            _videoData!['creator'] ??
            'Unknown')
        .toString();
  }

  String _extractTitle() {
    if (_videoData == null) return 'TikTok Video';
    return (_videoData!['title'] ??
            _videoData!['caption'] ??
            _videoData!['metadata']?['title'] ??
            _videoData!['desc'] ??
            'TikTok Video')
        .toString();
  }

  String _extractCover() {
    if (_videoData == null) return '';
    return (_videoData!['thumbnail'] ??
            _videoData!['metadata']?['cover'] ??
            _videoData!['cover'] ??
            '')
        .toString();
  }

  void _initializeVideoPlayer() {
    final videoUrl = _extractVideoUrl();
    if (videoUrl == null || videoUrl.isEmpty) {
      setState(() {
        _errorMessage = 'URL video tidak ditemukan di response API.';
      });
      return;
    }

    setState(() {
      _videoInitializing = true;
    });

    _videoController = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _videoInitializing = false;
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            looping: false,
            showControls: true,
            materialProgressColors: ChewieProgressColors(
              playedColor: GlassPalette.red,
              handleColor: GlassPalette.amber,
              backgroundColor: GlassPalette.surfaceAlt,
              bufferedColor: GlassPalette.textDim,
            ),
          );
        });
      }).catchError((err) {
        if (!mounted) return;
        setState(() {
          _videoInitializing = false;
          _errorMessage = 'Gagal load video: $err';
        });
      });
  }

  Future<void> _shareVideo() async {
    final videoUrl = _extractVideoUrl();
    if (videoUrl == null || videoUrl.isEmpty) return;

    try {
      final response = await http.get(Uri.parse(videoUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File(
        '${tempDir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4',
      );
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Video TikTok dari: ${_extractCreator()}',
      );
    } catch (e) {
      if (!mounted) return;
      GlassDialog.show(
        context,
        title: 'Share Gagal',
        message: 'Error sharing: $e',
        icon: Icons.error_rounded,
        accentColor: GlassPalette.red,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      // FULLSCREEN — edge to edge
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.video_library_rounded,
                  color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'TIKTOK DL',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.text,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
      body: GlassBg(
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + kToolbarHeight + 16,
              bottom: MediaQuery.of(context).padding.bottom + 40,
              left: 16,
              right: 16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 16),
                _buildInputCard(),
                const SizedBox(height: 16),
                if (_errorMessage != null) ...[
                  _buildErrorCard(),
                  const SizedBox(height: 16),
                ],
                if (_videoData != null) _buildResultCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.amber.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: GlassPalette.amber.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.amber.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.download_rounded,
                color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TIKTOK DOWNLOADER',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Download video TikTok tanpa watermark',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'MASUKKAN URL TIKTOK',
            style: GlassFont.pixel(
              size: 9,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: TextField(
              controller: _urlController,
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w600,
                color: GlassPalette.text,
              ),
              cursorColor: GlassPalette.white,
              decoration: InputDecoration(
                hintText: 'https://vt.tiktok.com/xxx/',
                hintStyle: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim,
                ),
                prefixIcon: const Icon(Icons.link_rounded,
                    color: GlassPalette.white, size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GlassButton(
            text: _isLoading ? 'LOADING...' : 'DOWNLOAD',
            icon: _isLoading ? null : Icons.download_rounded,
            onTap: _isLoading ? null : _downloadTiktok,
            bgColor: GlassPalette.red,
            textColor: GlassPalette.white,
            fullWidth: true,
            padding: const EdgeInsets.symmetric(vertical: 14),
            isLoading: _isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: GlassPalette.red.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: GlassPalette.red.withOpacity(0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: GlassPalette.red.withOpacity(0.3),
            blurRadius: 15,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.7),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    final creator = _extractCreator();
    final title = _extractTitle();
    final cover = _extractCover();

    return Column(
      children: [
        GlassCard(
          borderWidth: 1.5,
          radius: 20,
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: GlassPalette.amber.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: GlassPalette.amber.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.person_rounded,
                        color: GlassPalette.white, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          creator.toUpperCase(),
                          style: GlassFont.pixel(
                            size: 9,
                            weight: FontWeight.w700,
                            color: GlassPalette.text,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          title,
                          style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w500,
                            color: GlassPalette.textSub,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (_chewieController != null &&
                  _videoController != null &&
                  _videoController!.value.isInitialized)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.25),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.blue.withOpacity(0.3),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: AspectRatio(
                      aspectRatio: _videoController!.value.aspectRatio,
                      child: Chewie(controller: _chewieController!),
                    ),
                  ),
                )
              else if (cover.isNotEmpty && _videoInitializing)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.25),
                      width: 1.5,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: AspectRatio(
                      aspectRatio: 9 / 16,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          CachedNetworkImage(
                            imageUrl: cover,
                            fit: BoxFit.cover,
                            placeholder: (_, __) => Container(
                              color: Colors.white.withOpacity(0.08),
                              child: const Center(
                                child: CircularProgressIndicator(
                                  color: GlassPalette.white,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                            errorWidget: (_, __, ___) => Container(
                              color: Colors.white.withOpacity(0.08),
                              child: const Center(
                                child: Icon(Icons.broken_image_rounded,
                                    color: GlassPalette.textDim, size: 40),
                              ),
                            ),
                          ),
                          Container(
                            color: Colors.black.withOpacity(0.5),
                            child: const Center(
                              child: SizedBox(
                                width: 40,
                                height: 40,
                                child: CircularProgressIndicator(
                                  color: GlassPalette.white,
                                  strokeWidth: 3,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else
                Container(
                  height: 220,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: GlassPalette.white,
                      strokeWidth: 3,
                    ),
                  ),
                ),
              const SizedBox(height: 14),
              GlassButton(
                text: 'SHARE VIDEO',
                icon: Icons.share_rounded,
                onTap: _shareVideo,
                bgColor: GlassPalette.amber,
                textColor: GlassPalette.black,
                fullWidth: true,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        GlassCard(
          borderWidth: 1.5,
          radius: 16,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: GlassPalette.cyan.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: GlassPalette.cyan.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.check_circle_rounded,
                    color: GlassPalette.white, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Video berhasil di-load dari TikTok',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w600,
                    color: GlassPalette.text,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}