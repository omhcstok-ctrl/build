// chat_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// CHAT PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'package:flutter/material.dart';
import 'app_config.dart';
import 'chat_service.dart';
import 'chat_room_page.dart';
import 'glass_theme.dart';

class ChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const ChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  late ChatService _chat;
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  List<ChatConversation> _conversations = [];
  bool _loading = true;
  Timer? _refreshTimer;

  final _searchCtrl = TextEditingController();
  Timer? _searchDebounce;
  List<ChatUser> _searchResults = [];
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _chat = ChatService(widget.sessionKey);

    _slideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700))
      ..forward();
    _slideAnimation = Tween<Offset>(
            begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _slideController, curve: Curves.easeOutCubic));

    _loadConversations();
    _searchCtrl.addListener(_onSearchChanged);

    _refreshTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (mounted && _searchCtrl.text.trim().isEmpty) {
        _loadConversations(silent: true);
      }
    });
  }

  void _onSearchChanged() {
    final q = _searchCtrl.text.trim();
    _searchDebounce?.cancel();
    if (q.isEmpty) {
      setState(() {
        _searchResults = [];
        _searching = false;
      });
      return;
    }
    if (q.length < 2) return;
    _searchDebounce = Timer(const Duration(milliseconds: 500), () async {
      if (mounted) setState(() => _searching = true);
      final res = await _chat.searchUser(q);
      if (mounted) {
        setState(() {
          _searchResults = res;
          _searching = false;
        });
      }
    });
  }

  Future<void> _loadConversations({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    final res = await _chat.listConversations();
    if (mounted) {
      setState(() {
        _conversations = res;
        _loading = false;
      });
    }
  }

  void _openChat(String withUser) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatRoomPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
          role: widget.role,
          withUser: withUser,
        ),
      ),
    ).then((_) => _loadConversations(silent: true));
  }

  @override
  void dispose() {
    _slideController.dispose();
    _refreshTimer?.cancel();
    _searchDebounce?.cancel();
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    super.dispose();
  }

  String _timeAgo(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final dt = DateTime.parse(iso).toLocal();
      final diff = DateTime.now().difference(dt);
      if (diff.inSeconds < 60) return 'baru';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m';
      if (diff.inHours < 24) return '${diff.inHours}j';
      if (diff.inDays < 7) return '${diff.inDays}h';
      return '${(diff.inDays / 7).floor()}mgg';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildSearchBar(),
              Expanded(
                child: _searchCtrl.text.trim().isNotEmpty
                    ? _buildSearchResults()
                    : _buildConversations(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'PRIVATE CHAT',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: GlassPalette.teal,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Chat antar member',
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w600,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              _searchCtrl.clear();
              _searchResults = [];
              _loadConversations();
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.refresh_rounded,
                  color: GlassPalette.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 16,
        padding: EdgeInsets.zero,
        child: TextField(
          controller: _searchCtrl,
          style: GlassFont.body(
            size: 13,
            weight: FontWeight.w700,
            color: GlassPalette.text,
          ),
          cursorColor: GlassPalette.white,
          decoration: InputDecoration(
            hintText: 'Cari username...',
            hintStyle: GlassFont.body(
                size: 12,
                weight: FontWeight.w600,
                color: GlassPalette.textDim),
            prefixIcon: const Icon(Icons.search_rounded,
                color: GlassPalette.white, size: 20),
            suffixIcon: _searchCtrl.text.isNotEmpty
                ? GestureDetector(
                    onTap: () => _searchCtrl.clear(),
                    child: const Icon(Icons.close_rounded,
                        color: GlassPalette.textDim, size: 20),
                  )
                : null,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    if (_searching) {
      return const Center(
        child: CircularProgressIndicator(color: GlassPalette.white),
      );
    }
    if (_searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off_rounded,
                size: 60, color: GlassPalette.textDim),
            const SizedBox(height: 12),
            Text(
              'User tidak ditemukan',
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w700,
                color: GlassPalette.textSub,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: _searchResults.length,
      itemBuilder: (_, i) {
        final u = _searchResults[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: GlassCard(
            onTap: () => _openChat(u.username),
            borderWidth: 1.5,
            radius: 16,
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _avatar(u.username, 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        u.username,
                        style: GlassFont.pixel(
                          size: 9,
                          weight: FontWeight.w700,
                          color: GlassPalette.text,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        u.role.toUpperCase(),
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w600,
                          color: GlassPalette.textSub,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chat_bubble_outline_rounded,
                    color: GlassPalette.textDim, size: 18),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildConversations() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: GlassPalette.white),
      );
    }
    if (_conversations.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: GlassPalette.blue.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(0.6),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: GlassPalette.blue.withOpacity(0.4),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const Icon(Icons.chat_bubble_rounded,
                    color: GlassPalette.white, size: 50),
              ),
              const SizedBox(height: 20),
              Text(
                'BELUM ADA CHAT',
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.text,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Cari user di kolom search di atas\nbuat mulai ngobrol',
                textAlign: TextAlign.center,
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w600,
                  color: GlassPalette.textSub,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _loadConversations(),
      color: GlassPalette.white,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: _conversations.length,
        itemBuilder: (_, i) {
          final c = _conversations[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GlassCard(
              onTap: () => _openChat(c.withUser),
              borderWidth: c.unread > 0 ? 2 : 1.5,
              radius: 16,
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _avatar(c.withUser, 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                c.withUser,
                                style: GlassFont.pixel(
                                  size: 9,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.text,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Text(
                              _timeAgo(c.lastTime),
                              style: GlassFont.body(
                                size: 9,
                                weight: FontWeight.w600,
                                color: GlassPalette.textDim,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                c.lastMessage ?? '-',
                                style: GlassFont.body(
                                  size: 11,
                                  weight: c.unread > 0
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                  color: c.unread > 0
                                      ? GlassPalette.text
                                      : GlassPalette.textSub,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (c.unread > 0) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 7, vertical: 3),
                                decoration: BoxDecoration(
                                  color: GlassPalette.red,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: GlassPalette.red.withOpacity(0.7),
                                    width: 1.2,
                                  ),
                                ),
                                child: Text(
                                  '${c.unread}',
                                  style: GlassFont.pixel(
                                    size: 7,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _avatar(String username, double radius) {
    final color = _colorFromString(username);
    return Container(
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(50),
        border: Border.all(
          color: Colors.white.withOpacity(0.25),
          width: 1.5,
        ),
      ),
      child: CircleAvatar(
        radius: radius,
        backgroundColor: color,
        child: Text(
          username.isNotEmpty ? username[0].toUpperCase() : '?',
          style: GlassFont.pixel(
            size: radius > 20 ? 12 : 9,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
    );
  }

  Color _colorFromString(String s) {
    final colors = [
      GlassPalette.red,
      GlassPalette.teal,
      GlassPalette.blue,
      GlassPalette.yellow,
      GlassPalette.orange,
      GlassPalette.purple,
    ];
    if (s.isEmpty) return colors[0];
    return colors[s.codeUnitAt(0) % colors.length];
  }
}