// bug_sender.dart
// ═══════════════════════════════════════════════════════════════════════════
// BUG SENDER — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'glass_theme.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  bool get _isOwner => widget.role.toLowerCase() == 'owner';
  bool get _isVip => widget.role.toLowerCase() == 'vip';
  bool get _canUsePublic => _isOwner || _isVip;

  List<dynamic> _privateSenders = [];
  List<dynamic> _publicSenders = [];
  bool _loadingPrivate = true;
  bool _loadingPublic = true;
  String? _errPrivate;
  String? _errPublic;

  final _numCtrl = TextEditingController();
  bool _addingPrivate = false;
  String? _pairingCode;

  String? _deleting;

  Timer? _publicRefreshTimer;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _fetchPrivate();
    _fetchPublic();
    _publicRefreshTimer = Timer.periodic(
        const Duration(seconds: 10), (_) => _fetchPublic());
  }

  @override
  void dispose() {
    _tab.dispose();
    _numCtrl.dispose();
    _publicRefreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchPrivate() async {
    setState(() {
      _loadingPrivate = true;
      _errPrivate = null;
    });
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/mySender?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        final conn = d['connections'];
        setState(() {
          if (conn is Map) {
            _privateSenders = List<dynamic>.from(conn['private'] ?? []);
          } else if (conn is List) {
            _privateSenders = List<dynamic>.from(conn);
          } else {
            _privateSenders = [];
          }
          _loadingPrivate = false;
        });
      } else {
        setState(() {
          _errPrivate = d['error'] ?? 'Gagal';
          _loadingPrivate = false;
        });
      }
    } catch (e) {
      setState(() {
        _errPrivate = e.toString();
        _loadingPrivate = false;
      });
    }
  }

  Future<void> _fetchPublic() async {
    setState(() {
      _loadingPublic = true;
      _errPublic = null;
    });
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/getPublicSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        setState(() {
          _publicSenders = List<dynamic>.from(d['senders'] ?? []);
          _loadingPublic = false;
        });
      } else {
        setState(() {
          _errPublic = d['message'] ?? 'Gagal';
          _loadingPublic = false;
        });
      }
    } catch (e) {
      setState(() {
        _errPublic = e.toString();
        _loadingPublic = false;
      });
    }
  }

  Future<void> _addPrivate() async {
    final num = _numCtrl.text.trim().replaceAll(RegExp(r'\D'), '');
    if (num.isEmpty) {
      _snack('Masukkan nomor WA dulu!', true);
      return;
    }
    setState(() {
      _addingPrivate = true;
      _pairingCode = null;
    });
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/getPairing?key=${widget.sessionKey}&number=$num'),
      ).timeout(const Duration(seconds: 20));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        setState(() => _pairingCode = d['pairingCode']?.toString() ?? '-');
        _numCtrl.clear();
        await Future.delayed(const Duration(seconds: 30));
        _fetchPrivate();
      } else {
        _snack(d['message'] ?? 'Gagal generate pairing code', true);
      }
    } catch (e) {
      _snack('Error: $e', true);
    }
    setState(() => _addingPrivate = false);
  }

  Future<void> _deletePrivate(String sessionName) async {
    setState(() => _deleting = sessionName);
    try {
      final res = await http.get(
        Uri.parse(
            '$kBaseUrl/deleteSender?key=${widget.sessionKey}&session=$sessionName'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        _snack('Sender dihapus', false);
        _fetchPrivate();
      } else {
        _snack(d['message'] ?? 'Gagal hapus', true);
      }
    } catch (e) {
      _snack('Error: $e', true);
    }
    setState(() => _deleting = null);
  }

  Future<void> _deletePublic(String sessionName) async {
    setState(() => _deleting = sessionName);
    try {
      final res = await http.get(
        Uri.parse(
            '$kBaseUrl/deletePublicSender?key=${widget.sessionKey}&session=$sessionName'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        _snack('Public sender dihapus', false);
        _fetchPublic();
      } else {
        _snack(d['message'] ?? 'Gagal hapus', true);
      }
    } catch (e) {
      _snack('Error: $e', true);
    }
    setState(() => _deleting = null);
  }

  Future<void> _togglePublic(String sessionName, bool makePublic) async {
    try {
      final res = await http.get(
        Uri.parse(
            '$kBaseUrl/setSenderPublic?key=${widget.sessionKey}&session=$sessionName&public=$makePublic'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      _snack(d['message'] ?? (makePublic ? 'Dijadikan public' : 'Dijadikan private'),
          !d['valid']);
      _fetchPrivate();
      _fetchPublic();
    } catch (e) {
      _snack('Error: $e', true);
    }
  }

  void _snack(String msg, bool isErr) {
    if (!mounted) return;
    GlassDialog.show(
      context,
      title: isErr ? 'Error' : 'Info',
      message: msg,
      icon: isErr
          ? Icons.error_outline_rounded
          : Icons.info_outline_rounded,
      accentColor: isErr ? GlassPalette.red : GlassPalette.teal,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: GlassCard(
                  padding: const EdgeInsets.all(4),
                  borderWidth: 1.5,
                  radius: 16,
                  child: Row(
                    children: [
                      _tabBtn('PRIVATE', Icons.lock_rounded, 0,
                          GlassPalette.red),
                      _tabBtn('PUBLIC', Icons.public_rounded, 1,
                          GlassPalette.blue),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Expanded(
                child: TabBarView(
                  controller: _tab,
                  children: [
                    _buildPrivateTab(),
                    _buildPublicTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addingPrivate ? null : _showAddDialog,
        backgroundColor: GlassPalette.blue.withOpacity(0.8),
        foregroundColor: GlassPalette.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: Colors.white.withOpacity(0.25),
            width: 1.2,
          ),
        ),
        icon: _addingPrivate
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    color: GlassPalette.white, strokeWidth: 2),
              )
            : const Icon(Icons.add_rounded, color: GlassPalette.white),
        label: Text(
          'Tambah Sender',
          style: GlassFont.pixel(
            size: 9,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'MANAGE SENDER',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Kelola nomor pengirim bug',
                  style: GlassFont.body(
                    size: 10,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabBtn(String label, IconData icon, int index, Color color) {
    final active = _tab.index == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab.index = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: active ? color.withOpacity(0.25) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: active ? color.withOpacity(0.7) : Colors.transparent,
              width: 1.2,
            ),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 12,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  color: active
                      ? GlassPalette.white
                      : GlassPalette.textDim,
                  size: 15),
              const SizedBox(width: 7),
              Text(
                label,
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: active
                      ? GlassPalette.white
                      : GlassPalette.textDim,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPrivateTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_pairingCode != null)
            GlassCard(
              margin: const EdgeInsets.only(bottom: 14),
              borderWidth: 1.5,
              radius: 20,
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.key_rounded,
                          color: GlassPalette.white, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        'PAIRING CODE',
                        style: GlassFont.pixel(
                          size: 10,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _pairingCode!,
                        style: GlassFont.pixel(
                          size: 18,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                          letterSpacing: 4,
                          shadows: const [
                            Shadow(
                                color: Color(0x662AABEE), blurRadius: 12),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                              ClipboardData(text: _pairingCode!));
                          _snack('Kode berhasil disalin!', false);
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: GlassPalette.blue.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: GlassPalette.blue.withOpacity(0.6),
                              width: 1.2,
                            ),
                          ),
                          child: const Icon(Icons.copy_rounded,
                              color: GlassPalette.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Masukkan kode ini di WhatsApp → Perangkat Tertaut',
                    style: GlassFont.body(
                      size: 11,
                      weight: FontWeight.w500,
                      color: GlassPalette.textSub,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () => setState(() => _pairingCode = null),
                    child: Text(
                      'Tutup',
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.red,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          Row(
            children: [
              Expanded(
                child: _statCard('${_privateSenders.length}', 'Private',
                    GlassPalette.red, Icons.lock_rounded),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _statCard('${_publicSenders.length}', 'Public',
                    GlassPalette.teal, Icons.public_rounded),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _statCard(
                    '${_privateSenders.where((s) => (s['status'] ?? '') == 'connected').length}',
                    'Active',
                    GlassPalette.blue,
                    Icons.check_circle_rounded),
              ),
            ],
          ),
          const SizedBox(height: 14),

          Row(
            children: [
              Text(
                'SENDER LIST',
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.textSub,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  setState(() => _loadingPrivate = true);
                  _fetchPrivate();
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      color: GlassPalette.white, size: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          if (_loadingPrivate)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: CircularProgressIndicator(color: GlassPalette.white),
              ),
            )
          else if (_errPrivate != null)
            _errorWidget(_errPrivate!, _fetchPrivate)
          else if (_privateSenders.isEmpty)
            _emptyWidget('Belum ada private sender', Icons.lock_outlined)
          else
            ..._privateSenders.map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _senderCard(s, isPublic: false),
                )),
        ],
      ),
    );
  }

  Widget _statCard(String value, String label, Color color, IconData icon) {
    return GlassCard(
      borderWidth: 1.5,
      radius: 16,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      child: Column(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(height: 6),
          Text(
            value,
            style: GlassFont.pixel(
              size: 12,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: GlassFont.body(
              size: 10,
              weight: FontWeight.w500,
              color: GlassPalette.textSub,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPublicTab() {
    if (!_canUsePublic) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: GlassCard(
            borderWidth: 1.5,
            radius: 22,
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: GlassPalette.red.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.6),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.red.withOpacity(0.5),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.lock_rounded,
                      color: GlassPalette.white, size: 42),
                ),
                const SizedBox(height: 20),
                Text(
                  'Akses Terbatas',
                  style: GlassFont.pixel(
                    size: 12,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Fitur Public Sender hanya tersedia\nuntuk akun Owner dan VIP.',
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.5),
                      width: 1.2,
                    ),
                  ),
                  child: Text(
                    'Hubungi reseller untuk upgrade akun',
                    style: GlassFont.body(
                      size: 11,
                      weight: FontWeight.w600,
                      color: GlassPalette.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            margin: const EdgeInsets.only(bottom: 14),
            borderWidth: 1.5,
            radius: 16,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Icon(Icons.info_rounded,
                    color: GlassPalette.teal, size: 16),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Sender public bisa dipakai semua user untuk kirim bug.',
                    style: GlassFont.body(
                      size: 11,
                      weight: FontWeight.w500,
                      color: GlassPalette.teal,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Text(
                'PUBLIC SENDERS',
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.textSub,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  setState(() => _loadingPublic = true);
                  _fetchPublic();
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      color: GlassPalette.white, size: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_loadingPublic)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: CircularProgressIndicator(color: GlassPalette.white),
              ),
            )
          else if (_errPublic != null)
            _errorWidget(_errPublic!, _fetchPublic)
          else if (_publicSenders.isEmpty)
            _emptyWidget('Belum ada public sender\nToggle dari tab Private',
                Icons.public_off_rounded)
          else
            ..._publicSenders.map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _senderCard(s, isPublic: true),
                )),
        ],
      ),
    );
  }

  Widget _senderCard(Map<String, dynamic> s, {required bool isPublic}) {
  final name = s['sessionName'] ?? s['number'] ?? 'Unknown';
  
  // ✅ FIX UTAMA: Baca field 'isActive' dari backend, bukan 'status'
  final isConn = s['isActive'] == true; 
  
  final owner = s['owner']?.toString();
  final deleting = _deleting == name;

  return GlassCard(
    borderWidth: 1.5,
    radius: 18,
    padding: const EdgeInsets.all(14),
    child: Column(
      children: [
        Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isConn
                    ? GlassPalette.teal.withOpacity(0.25)
                    : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isConn
                      ? GlassPalette.teal.withOpacity(0.6)
                      : Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: Icon(Icons.phone_android_rounded,
                  color: isConn
                      ? GlassPalette.white
                      : GlassPalette.textDim,
                  size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      GlassBadge(
                        text: isConn ? 'ONLINE' : 'OFFLINE',
                        bgColor: isConn
                            ? GlassPalette.teal
                            : Colors.white.withOpacity(0.15),
                        textColor: isConn
                            ? GlassPalette.white
                            : GlassPalette.textDim,
                      ),
                      if (isPublic && owner != null) ...[
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            'by $owner',
                            style: GlassFont.body(
                              size: 10,
                              weight: FontWeight.w500,
                              color: GlassPalette.textDim,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            if (deleting)
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                    color: GlassPalette.white, strokeWidth: 2),
              )
            else
              GestureDetector(
                onTap: () => _confirmDelete(name, isPublic),
                child: Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: GlassPalette.red.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.delete_outline_rounded,
                      color: GlassPalette.white, size: 16),
                ),
              ),
          ],
        ),
        if (!deleting && (!isPublic || _isOwner)) ...[
          const SizedBox(height: 12),
          Row(
            children: [
              if (!isPublic)
                Expanded(
                  child: GestureDetector(
                    onTap: () => _togglePublic(name, true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: BoxDecoration(
                        color: GlassPalette.teal.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: GlassPalette.teal.withOpacity(0.6),
                          width: 1.2,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.public_rounded,
                              color: GlassPalette.white, size: 13),
                          const SizedBox(width: 5),
                          Text(
                            'Set Public',
                            style: GlassFont.pixel(
                              size: 8,
                              weight: FontWeight.w700,
                              color: GlassPalette.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              if (_isOwner && isPublic)
                Expanded(
                  child: GestureDetector(
                    onTap: () => _togglePublic(name, false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: BoxDecoration(
                        color: GlassPalette.red.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: GlassPalette.red.withOpacity(0.6),
                          width: 1.2,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.lock_rounded,
                              color: GlassPalette.white, size: 13),
                          const SizedBox(width: 5),
                          Text(
                            'Set Private',
                            style: GlassFont.pixel(
                              size: 8,
                              weight: FontWeight.w700,
                              color: GlassPalette.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ],
    ),
  );
}

  void _confirmDelete(String name, bool isPublic) {
    GlassDialog.show(
      context,
      title: 'Hapus Sender?',
      message: '$name akan dihapus permanen.',
      icon: Icons.warning_amber_rounded,
      accentColor: GlassPalette.red,
      actions: [
        GlassButton(
          text: 'Batal',
          fullWidth: false,
          bgColor: Colors.white,
          onTap: () => Navigator.pop(context),
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        ),
        const SizedBox(width: 8),
        GlassButton(
          text: 'Hapus',
          fullWidth: false,
          bgColor: GlassPalette.red,
          textColor: GlassPalette.white,
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          onTap: () {
            Navigator.pop(context);
            if (isPublic) {
              _deletePublic(name);
            } else {
              _deletePrivate(name);
            }
          },
        ),
      ],
    );
  }

  void _showAddDialog() {
    _pairingCode = null;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: GlassCard(
          borderWidth: 1.5,
          radius: 22,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: GlassPalette.blue.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: GlassPalette.blue.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.add_circle_rounded,
                        color: GlassPalette.white, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Tambah Sender',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                'Masukkan nomor WA (dengan kode negara, tanpa +)',
                style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
              ),
              const SizedBox(height: 12),
              GlassInput(
                controller: _numCtrl,
                hint: 'Contoh: 628123456789',
                icon: Icons.phone_rounded,
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      text: 'Batal',
                      onTap: () => Navigator.pop(context),
                      bgColor: Colors.white,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: GlassButton(
                      text: 'Generate Pairing',
                      onTap: () {
                        Navigator.pop(context);
                        _addPrivate();
                      },
                      bgColor: GlassPalette.blue,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _emptyWidget(String msg, IconData icon) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
                child: Icon(icon, color: GlassPalette.textDim, size: 40),
              ),
              const SizedBox(height: 14),
              Text(
                msg,
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );

  Widget _errorWidget(String err, VoidCallback retry) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: GlassPalette.red.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: GlassPalette.red.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.error_outline_rounded,
                    color: GlassPalette.white, size: 40),
              ),
              const SizedBox(height: 12),
              Text(
                err,
                style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),
              GlassButton(
                text: 'Coba Lagi',
                fullWidth: false,
                onTap: retry,
                bgColor: GlassPalette.blue,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
            ],
          ),
        ),
      );
}