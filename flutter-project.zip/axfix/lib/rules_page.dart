// rules_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// RULES PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'glass_theme.dart';

class RulesPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const RulesPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<RulesPage> createState() => _RulesPageState();
}

class _RulesPageState extends State<RulesPage> {
  bool _isLoading = false;

  final List<Map<String, String>> _rules = [
    {
      'title': '1. Penggunaan yang Sah',
      'desc':
          'Aplikasi ini hanya untuk keperluan testing internal dan edukasi. Dilarang menyalahgunakan untuk kegiatan ilegal.',
    },
    {
      'title': '2. Larangan Spam',
      'desc':
          'Dilarang menggunakan fitur bug sender untuk spam ke nomor atau grup yang tidak bertanggung jawab.',
    },
    {
      'title': '3. Kerahasiaan Akun',
      'desc':
          'Jangan pernah bagikan session key, password, atau akses akun ke orang lain.',
    },
    {
      'title': '4. Larangan Jual Beli Ilegal',
      'desc':
          'Dilarang menjual akses aplikasi ini tanpa izin owner. Pelanggaran = banned permanen.',
    },
    {
      'title': '5. Tanggung Jawab User',
      'desc':
          'Semua tindakan yang lo lakukan menggunakan aplikasi ini adalah tanggung jawab lo sendiri.',
    },
    {
      'title': '6. Batasan Penggunaan',
      'desc':
          'Setiap user punya batasan jumlah request/hari. Penyalahgunaan limit = pembatasan.',
    },
    {
      'title': '7. Update & Perubahan',
      'desc': 'Rules ini bisa berubah sewaktu-waktu tanpa pemberitahuan.',
    },
    {
      'title': '8. Pelanggaran = Banned',
      'desc':
          'Segala bentuk pelanggaran akan mengakibatkan akun lo dibanned permanen.',
    },
  ];

  void _lanjutKeDashboard() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: GlassPalette.red.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: GlassPalette.red.withOpacity(0.6),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: GlassPalette.red.withOpacity(0.5),
                            blurRadius: 25,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.warning_amber_rounded,
                        color: GlassPalette.white,
                        size: 40,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'PERINGATAN & RULES',
                      style: GlassFont.pixel(
                        size: 12,
                        weight: FontWeight.w700,
                        color: GlassPalette.red,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: GlassPalette.red.withOpacity(0.6),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Baca dengan teliti sebelum melanjutkan',
                      style: GlassFont.body(
                        size: 11,
                        weight: FontWeight.w500,
                        color: GlassPalette.textSub,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: GlassPalette.blue.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: GlassPalette.blue.withOpacity(0.6),
                          width: 1.2,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.info_outline,
                              color: GlassPalette.white, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            'Wajib dibaca sebelum lanjut',
                            style: GlassFont.body(
                              size: 10,
                              weight: FontWeight.w600,
                              color: GlassPalette.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _rules.length,
                  itemBuilder: (context, index) {
                    final rule = _rules[index];
                    return GlassCard(
                      margin: const EdgeInsets.only(bottom: 12),
                      borderWidth: 1.5,
                      radius: 18,
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: GlassPalette.red,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color:
                                          GlassPalette.red.withOpacity(0.7),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  rule['title']!,
                                  style: GlassFont.pixel(
                                    size: 9,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.only(left: 20),
                            child: Text(
                              rule['desc']!,
                              style: GlassFont.body(
                                size: 11,
                                weight: FontWeight.w500,
                                color: GlassPalette.textSub,
                                height: 1.6,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    top: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: GlassButton(
                  text: _isLoading
                      ? 'LOADING...'
                      : 'SAYA SETUJU & LANJUTKAN',
                  icon: _isLoading ? null : Icons.check_circle_rounded,
                  isLoading: _isLoading,
                  onTap: _isLoading ? null : _lanjutKeDashboard,
                  bgColor: GlassPalette.blue,
                  textColor: GlassPalette.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}