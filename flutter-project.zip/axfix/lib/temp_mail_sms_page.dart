// temp_mail_sms_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// TEMP MAIL + SMS — GLASSMORPHISM EDITION
// Gabungan 2 fitur dalam 1 halaman pake TabController
// Endpoint: /api/tools/tempmail/create & /api/tools/tempmail/check
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'app_config.dart';
import 'glass_theme.dart';

class TempMailSmsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const TempMailSmsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<TempMailSmsPage> createState() => _TempMailSmsPageState();
}

class _TempMailSmsPageState extends State<TempMailSmsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  // ═══ STATE EMAIL ═══
  String? _emailAddress;
  String? _emailToken;
  List<dynamic> _emailMessages = [];
  bool _emailLoadingCreate = false;
  bool _emailLoadingCheck = false;
  String? _emailErrorCreate;
  String? _emailErrorCheck;

  // ═══ STATE SMS ═══
  String? _smsNumber;
  String? _smsToken;
  List<dynamic> _smsMessages = [];
  bool _smsLoadingCreate = false;
  bool _smsLoadingCheck = false;
  String? _smsErrorCreate;
  String? _smsErrorCheck;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 📧 EMAIL FUNCTIONS
  // ═════════════════════════════════════════════════════════════════════════
  Future<void> _createEmail() async {
    setState(() {
      _emailLoadingCreate = true;
      _emailErrorCreate = null;
      _emailAddress = null;
      _emailToken = null;
      _emailMessages = [];
      _emailErrorCheck = null;
    });

    try {
      final res = await http
          .post(
            Uri.parse(apiUrl('/api/tools/tempmail/create')),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'key': widget.sessionKey}),
          )
          .timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);

      if (d['success'] == true || d['status'] == true) {
        setState(() {
          _emailAddress = d['email'] ?? d['result']?['email'];
          _emailToken = d['token'] ?? d['result']?['token'];
          _emailLoadingCreate = false;
        });
        _copyToClipboard(_emailAddress ?? '', 'Email copied!');
      } else {
        setState(() {
          _emailErrorCreate =
              d['error'] ?? d['message'] ?? 'Gagal buat email';
          _emailLoadingCreate = false;
        });
      }
    } catch (e) {
      setState(() {
        _emailErrorCreate = 'Koneksi error: $e';
        _emailLoadingCreate = false;
      });
    }
  }

  Future<void> _checkEmail() async {
    if (_emailAddress == null) {
      setState(() => _emailErrorCheck = 'Generate email dulu');
      return;
    }

    setState(() {
      _emailLoadingCheck = true;
      _emailErrorCheck = null;
    });

    try {
      final res = await http
          .post(
            Uri.parse(apiUrl('/api/tools/tempmail/check')),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'email': _emailAddress,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);

      if (d['success'] == true || d['status'] == true) {
        final msgs = d['messages'] ?? d['result']?['messages'] ?? [];
        setState(() {
          _emailMessages = List<dynamic>.from(msgs);
          _emailLoadingCheck = false;
        });
      } else {
        setState(() {
          _emailErrorCheck = d['error'] ?? d['message'] ?? 'Gagal cek pesan';
          _emailLoadingCheck = false;
        });
      }
    } catch (e) {
      setState(() {
        _emailErrorCheck = 'Koneksi error: $e';
        _emailLoadingCheck = false;
      });
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 📱 SMS FUNCTIONS
  // ═════════════════════════════════════════════════════════════════════════
  Future<void> _createSms() async {
    setState(() {
      _smsLoadingCreate = true;
      _smsErrorCreate = null;
      _smsNumber = null;
      _smsToken = null;
      _smsMessages = [];
      _smsErrorCheck = null;
    });

    try {
      final res = await http
          .post(
            Uri.parse(apiUrl('/api/tools/sms/create')),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'key': widget.sessionKey}),
          )
          .timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);

      if (d['success'] == true || d['status'] == true) {
        setState(() {
          _smsNumber = d['number'] ?? d['result']?['number'] ?? d['phone'];
          _smsToken = d['token'] ?? d['result']?['token'];
          _smsLoadingCreate = false;
        });
        _copyToClipboard(_smsNumber ?? '', 'Nomor SMS copied!');
      } else {
        setState(() {
          _smsErrorCreate = d['error'] ?? d['message'] ?? 'Gagal buat nomor';
          _smsLoadingCreate = false;
        });
      }
    } catch (e) {
      setState(() {
        _smsErrorCreate = 'Koneksi error: $e';
        _smsLoadingCreate = false;
      });
    }
  }

  Future<void> _checkSms() async {
    if (_smsNumber == null) {
      setState(() => _smsErrorCheck = 'Generate nomor dulu');
      return;
    }

    setState(() {
      _smsLoadingCheck = true;
      _smsErrorCheck = null;
    });

    try {
      final res = await http
          .post(
            Uri.parse(apiUrl('/api/tools/sms/check')),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'number': _smsNumber,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);

      if (d['success'] == true || d['status'] == true) {
        final msgs = d['messages'] ?? d['result']?['messages'] ?? [];
        setState(() {
          _smsMessages = List<dynamic>.from(msgs);
          _smsLoadingCheck = false;
        });
      } else {
        setState(() {
          _smsErrorCheck = d['error'] ?? d['message'] ?? 'Gagal cek SMS';
          _smsLoadingCheck = false;
        });
      }
    } catch (e) {
      setState(() {
        _smsErrorCheck = 'Koneksi error: $e';
        _smsLoadingCheck = false;
      });
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ═════════════════════════════════════════════════════════════════════════
  void _copyToClipboard(String text, String message) {
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        message,
        style: GlassFont.body(
          size: 12,
          weight: FontWeight.w600,
          color: GlassPalette.bg,
        ),
      ),
      backgroundColor: GlassPalette.yellow,
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ));
  }

  String _formatTime(dynamic timestamp) {
    if (timestamp == null) return '-';
    try {
      final dt = DateTime.parse(timestamp.toString());
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return timestamp.toString();
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.mark_email_unread_rounded,
                  color: GlassPalette.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'TEMP MAIL & SMS',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.text,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: TabBar(
              controller: _tabCtrl,
              indicator: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.4),
                borderRadius: BorderRadius.circular(12),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: GlassPalette.white,
              unselectedLabelColor: GlassPalette.textDim,
              labelStyle: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w700,
              ),
              tabs: const [
                Tab(
                  icon: Icon(Icons.email_rounded, size: 18),
                  text: 'EMAIL',
                  height: 48,
                ),
                Tab(
                  icon: Icon(Icons.sms_rounded, size: 18),
                  text: 'SMS',
                  height: 48,
                ),
              ],
            ),
          ),
        ),
      ),
      body: GlassBg(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 60),
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _buildEmailTab(),
                _buildSmsTab(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // EMAIL TAB
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildEmailTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(
            icon: Icons.email_rounded,
            title: 'TEMP MAIL',
            subtitle: 'Email sementara buat verifikasi',
            color: GlassPalette.teal,
          ),
          const SizedBox(height: 16),
          _buildMainCard(
            isLoadingCreate: _emailLoadingCreate,
            isLoadingCheck: _emailLoadingCheck,
            errorCreate: _emailErrorCreate,
            errorCheck: _emailErrorCheck,
            address: _emailAddress,
            token: _emailToken,
            messages: _emailMessages,
            addressLabel: 'ALAMAT EMAIL',
            addressIcon: Icons.alternate_email_rounded,
            emptyIcon: Icons.mail_outline_rounded,
            onCreate: _createEmail,
            onCheck: _checkEmail,
            onCopy: () => _copyToClipboard(_emailAddress ?? '', 'Email copied!'),
            color: GlassPalette.teal,
            accent: GlassPalette.cyan,
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // SMS TAB
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildSmsTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(
            icon: Icons.sms_rounded,
            title: 'TEMP SMS',
            subtitle: 'Nomor virtual buat terima SMS',
            color: GlassPalette.orange,
          ),
          const SizedBox(height: 16),
          _buildMainCard(
            isLoadingCreate: _smsLoadingCreate,
            isLoadingCheck: _smsLoadingCheck,
            errorCreate: _smsErrorCreate,
            errorCheck: _smsErrorCheck,
            address: _smsNumber,
            token: _smsToken,
            messages: _smsMessages,
            addressLabel: 'NOMOR VIRTUAL',
            addressIcon: Icons.phone_rounded,
            emptyIcon: Icons.sms_outlined,
            onCreate: _createSms,
            onCheck: _checkSms,
            onCopy: () => _copyToClipboard(_smsNumber ?? '', 'Nomor copied!'),
            color: GlassPalette.orange,
            accent: GlassPalette.red,
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // HEADER CARD
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildHeader({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: color.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Icon(icon, color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w600,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // MAIN CARD
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildMainCard({
    required bool isLoadingCreate,
    required bool isLoadingCheck,
    required String? errorCreate,
    required String? errorCheck,
    required String? address,
    required String? token,
    required List<dynamic> messages,
    required String addressLabel,
    required IconData addressIcon,
    required IconData emptyIcon,
    required VoidCallback onCreate,
    required VoidCallback onCheck,
    required VoidCallback onCopy,
    required Color color,
    required Color accent,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // TOMBOL GENERATE
        GlassButton(
          text: isLoadingCreate ? 'GENERATING...' : 'GENERATE BARU',
          icon: isLoadingCreate ? null : Icons.add_circle_outline_rounded,
          isLoading: isLoadingCreate,
          onTap: isLoadingCreate ? null : onCreate,
          bgColor: color,
          textColor: GlassPalette.white,
          fullWidth: true,
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),

        const SizedBox(height: 14),

        if (errorCreate != null) ...[
          _buildErrorBox(errorCreate),
          const SizedBox(height: 14),
        ],

        if (address != null && address.isNotEmpty) ...[
          GlassCard(
            borderWidth: 1.5,
            radius: 20,
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(addressIcon, color: color, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      addressLabel,
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: SelectableText(
                          address,
                          style: GlassFont.body(
                            size: 14,
                            weight: FontWeight.w700,
                            color: GlassPalette.text,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: onCopy,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: color.withOpacity(0.6),
                              width: 1.2,
                            ),
                          ),
                          child: const Icon(Icons.copy_rounded,
                              color: GlassPalette.white, size: 16),
                        ),
                      ),
                    ],
                  ),
                ),
                if (token != null && token.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Token: $token',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w500,
                      color: GlassPalette.textDim,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),

          // TOMBOL CEK
          GlassButton(
            text: isLoadingCheck ? 'CHECKING...' : 'CEK PESAN MASUK',
            icon: isLoadingCheck ? null : Icons.refresh_rounded,
            isLoading: isLoadingCheck,
            onTap: isLoadingCheck ? null : onCheck,
            bgColor: accent,
            textColor: GlassPalette.white,
            fullWidth: true,
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
          const SizedBox(height: 14),

          if (errorCheck != null) ...[
            _buildErrorBox(errorCheck),
            const SizedBox(height: 14),
          ],

          // LIST PESAN
          GlassCard(
            borderWidth: 1.5,
            radius: 20,
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.inbox_rounded, color: color, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'PESAN MASUK (${messages.length})',
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (messages.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Column(
                      children: [
                        Icon(emptyIcon,
                            color: GlassPalette.textDim, size: 40),
                        const SizedBox(height: 8),
                        Text(
                          'Belum ada pesan masuk',
                          style: GlassFont.body(
                            size: 12,
                            weight: FontWeight.w600,
                            color: GlassPalette.textDim,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Klik CEK PESAN buat refresh',
                          style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w500,
                            color: GlassPalette.textDim,
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  ...messages.map((msg) => _buildMessageItem(msg, color)),
              ],
            ),
          ),
        ] else if (address == null && !isLoadingCreate) ...[
          GlassCard(
            borderWidth: 1.5,
            radius: 20,
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Icon(Icons.inbox_rounded,
                    color: GlassPalette.textDim, size: 50),
                const SizedBox(height: 12),
                Text(
                  'Belum ada $addressLabel',
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Klik GENERATE BARU buat mulai',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textDim,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // MESSAGE ITEM
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildMessageItem(dynamic msg, Color color) {
    String from = '-';
    String subject = '-';
    String body = '-';
    String time = '-';

    if (msg is Map) {
      from = (msg['from'] ?? msg['sender'] ?? msg['from_email'] ?? '-')
          .toString();
      subject = (msg['subject'] ?? msg['title'] ?? '-').toString();
      body = (msg['body'] ??
              msg['message'] ??
              msg['text'] ??
              msg['content'] ??
              '-')
          .toString();
      time = _formatTime(msg['time'] ??
          msg['date'] ??
          msg['created_at'] ??
          msg['timestamp']);
    } else {
      body = msg.toString();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.18),
          width: 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: color.withOpacity(0.6),
                    width: 1,
                  ),
                ),
                child: Text(
                  'DARI',
                  style: GlassFont.pixel(
                    size: 6,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  from,
                  style: GlassFont.body(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                time,
                style: GlassFont.body(
                  size: 9,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (subject != '-' && subject.isNotEmpty)
            Text(
              subject,
              style: GlassFont.pixel(
                size: 9,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1,
              ),
            ),
            child: SelectableText(
              body,
              style: GlassFont.body(
                size: 11,
                weight: FontWeight.w500,
                color: GlassPalette.text,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // ERROR BOX
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildErrorBox(String message) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: GlassPalette.red.withOpacity(0.2),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: GlassPalette.red.withOpacity(0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: GlassPalette.red.withOpacity(0.3),
            blurRadius: 15,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.3),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.7),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.error_outline_rounded,
                color: GlassPalette.white, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: GlassFont.body(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}