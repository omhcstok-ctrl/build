// menu_hub_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// MENU HUB PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'quick_menu_data.dart';
import 'glass_theme.dart';

class MenuHubPage extends StatefulWidget {
  final String title;
  final String subtitle;
  final IconData headerIcon;
  final Color headerColor;
  final List<QuickMenuItem> items;

  const MenuHubPage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.headerIcon,
    required this.headerColor,
    required this.items,
  });

  @override
  State<MenuHubPage> createState() => _MenuHubPageState();
}

class _MenuHubPageState extends State<MenuHubPage>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..forward();
    _slideAnimation = Tween<Offset>(
            begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _slideController, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    child: _buildGrid(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: widget.headerColor.withOpacity(0.25),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: widget.headerColor.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.headerColor.withOpacity(0.4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Icon(widget.headerIcon,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.title,
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: widget.headerColor,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        widget.subtitle,
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w500,
                          color: GlassPalette.textSub,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    if (widget.items.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.inbox_rounded,
                  color: GlassPalette.textDim, size: 60),
              const SizedBox(height: 12),
              Text(
                'Belum ada modul',
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.78,
      ),
      itemCount: widget.items.length,
      itemBuilder: (context, i) => _buildCard(widget.items[i]),
    );
  }

  Widget _buildCard(QuickMenuItem item) {
    final color = item.disabled ? GlassPalette.textDim : item.accent;

    return GlassCard(
      onTap: item.disabled ? null : item.onTap,
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: color.withOpacity(0.6),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Icon(
                  item.disabled ? Icons.lock_rounded : item.icon,
                  color: GlassPalette.white,
                  size: 22,
                ),
              ),
              const Spacer(),
              if (item.badge != null)
                GlassBadge(
                  text: item.badge!,
                  bgColor: item.badgeBg,
                  textColor: GlassPalette.white,
                ),
            ],
          ),
          const SizedBox(height: 12),

          Text(
            item.title,
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: item.disabled
                  ? GlassPalette.textDim
                  : GlassPalette.white,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),

          Text(
            item.sub,
            style: GlassFont.body(
              size: 10,
              weight: FontWeight.w500,
              color: item.disabled
                  ? GlassPalette.textDim
                  : GlassPalette.textSub,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),

          Container(
            height: 1,
            color: Colors.white.withOpacity(0.15),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: Text(
              item.desc,
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w400,
                color: item.disabled
                    ? GlassPalette.textDim
                    : GlassPalette.textSub,
                height: 1.3,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(height: 8),

          Wrap(
            spacing: 4,
            runSpacing: 4,
            children: item.tags.take(2).map((t) => Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.15),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item.disabled
                            ? Icons.lock_rounded
                            : Icons.check_circle_rounded,
                        color: color,
                        size: 9,
                      ),
                      const SizedBox(width: 3),
                      Text(
                        t,
                        style: GlassFont.body(
                          size: 8,
                          weight: FontWeight.w500,
                          color: GlassPalette.textSub,
                        ),
                      ),
                    ],
                  ),
                )).toList(),
          ),
          const SizedBox(height: 8),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: item.disabled
                  ? Colors.white.withOpacity(0.06)
                  : color.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: item.disabled
                    ? Colors.white.withOpacity(0.15)
                    : color.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  item.disabled
                      ? Icons.lock_rounded
                      : Icons.arrow_forward_rounded,
                  color: GlassPalette.white,
                  size: 12,
                ),
                const SizedBox(width: 6),
                Text(
                  item.disabled ? 'LOCKED' : 'START',
                  style: GlassFont.pixel(
                    size: 8,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}