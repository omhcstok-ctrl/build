// splash.dart
// ═══════════════════════════════════════════════════════════════════════════
// SPLASH — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';
import 'rules_page.dart';
import 'glass_theme.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  bool _fadeOutStarted = false;
  bool _videoReady = false;
  bool _skipped = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _videoController = VideoPlayerController.asset("assets/videos/load.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          if (!mounted || _skipped) return;
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (duration.inMilliseconds > 0 &&
              position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (duration.inMilliseconds > 0 && position >= duration) {
            _navigateToDashboard();
          }
        });
      }).catchError((_) {
        Future.delayed(const Duration(seconds: 2), _navigateToDashboard);
      });
  }

  void _skip() {
    if (_skipped) return;
    _skipped = true;
    _videoController.pause();
    _navigateToDashboard();
  }

  void _navigateToDashboard() {
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => RulesPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      body: Stack(
        alignment: Alignment.center,
        children: [
          if (_videoReady && _videoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(
              color: GlassPalette.bg,
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        color: GlassPalette.white,
                        strokeWidth: 3,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "Loading...",
                      style: GlassFont.pixel(
                        size: 10,
                        weight: FontWeight.w700,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ],
                ),
              ),
            ),

          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.7),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: const [0.5, 1.0],
                ),
              ),
            ),
          ),

          Positioned(
            bottom: 90,
            child: Column(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.7),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.blue.withOpacity(0.6),
                        blurRadius: 30,
                      ),
                    ],
                  ),
                  child: Text(
                    "ATOMIC",
                    style: GlassFont.pixel(
                      size: 18,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                      letterSpacing: 3,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  "System Initializing...",
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),

          Positioned(
            top: 48,
            right: 20,
            child: GestureDetector(
              onTap: _skip,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.25),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  children: [
                    Text(
                      "Skip",
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.skip_next_rounded,
                        color: GlassPalette.white, size: 16),
                  ],
                ),
              ),
            ),
          ),

          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(
                Tween(begin: 0.0, end: 1.0),
              ),
              child: Container(color: GlassPalette.bg),
            ),
        ],
      ),
    );
  }
}