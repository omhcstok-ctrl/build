// tools_gateway.dart
// ═══════════════════════════════════════════════════════════════════════════
// TOOLS GATEWAY — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'fake_dana.dart';
import 'temp_mail_sms_page.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'glass_theme.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _slideCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _slideCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _slideCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Column(
              children: [
                _buildAppBarCustom(),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(0, 14, 0, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: _buildHeader(),
                        ),
                        const SizedBox(height: 18),

                        // ─── Section 1: DDoS ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GlassSectionTitle(
                            icon: Icons.flash_on_rounded,
                            title: 'Atomic DDoS',
                            color: GlassPalette.red,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildHorizontalCards([
                          _ToolData(
                            icon: Icons.bolt_rounded,
                            title: 'Attack Panel',
                            sub: 'Network stress testing',
                            accent: GlassPalette.red,
                            onTap: () => _navTo(AttackPanel(
                                sessionKey: widget.sessionKey,
                                listDoos: widget.listDoos)),
                          ),
                          _ToolData(
                            icon: Icons.dns_rounded,
                            title: 'Manage Server',
                            sub: 'Kelola VPS & server',
                            accent: GlassPalette.orange,
                            onTap: () => _navTo(
                                ManageServerPage(keyToken: widget.sessionKey)),
                          ),
                        ]),

                        const SizedBox(height: 18),

                        // ─── Section 2: Network ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GlassSectionTitle(
                            icon: Icons.wifi_rounded,
                            title: 'Atomic Network',
                            color: GlassPalette.teal,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildHorizontalCards([
                          _ToolData(
                            icon: Icons.newspaper_rounded,
                            title: 'Spam NGL',
                            sub: 'Anonymous message',
                            accent: GlassPalette.orange,
                            onTap: () => _navTo(const NglPage()),
                          ),
                          _ToolData(
                            icon: Icons.wifi_off_rounded,
                            title: 'WiFi Killer',
                            sub: 'Internal network attack',
                            accent: GlassPalette.red,
                            onTap: () => _navTo(const WifiKillerPage()),
                          ),
                          if (widget.userRole == "vip" ||
                              widget.userRole == "owner" ||
                              widget.userRole == "highowner" ||
                              widget.userRole == "dev")
                            _ToolData(
                              icon: Icons.router_rounded,
                              title: 'WiFi External',
                              sub: 'External attack — VIP',
                              accent: GlassPalette.orange,
                              onTap: () => _navTo(WifiInternalPage(
                                  sessionKey: widget.sessionKey)),
                            ),
                        ]),

                        const SizedBox(height: 18),

                        // ─── Section 3: OSINT ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GlassSectionTitle(
                            icon: Icons.search_rounded,
                            title: 'Atomic OSINT',
                            color: GlassPalette.teal,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildHorizontalCards([
                          _ToolData(
                            icon: Icons.badge_rounded,
                            title: 'NIK Detail',
                            sub: 'Cek data NIK Indonesia',
                            accent: GlassPalette.teal,
                            onTap: () => _navTo(const NikCheckerPage()),
                          ),
                          _ToolData(
                            icon: Icons.domain_rounded,
                            title: 'Domain Check',
                            sub: 'Domain OSINT scanner',
                            accent: GlassPalette.blue,
                            onTap: () => _navTo(const DomainOsintPage()),
                          ),
                          _ToolData(
                            icon: Icons.phone_iphone_rounded,
                            title: 'Phone Lookup',
                            sub: 'Cek informasi nomor HP',
                            accent: GlassPalette.orange,
                            onTap: _showComingSoon,
                          ),
                        ]),

                        const SizedBox(height: 18),

                        // ─── Section 4: Downloader & AI ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GlassSectionTitle(
                            icon: Icons.download_rounded,
                            title: 'Downloader & Utility',
                            color: GlassPalette.red,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildHorizontalCards([
                          _ToolData(
                            icon: Icons.mark_email_unread_rounded,
                            title: 'Temp Mail & SMS',
                            sub: 'Email & nomor virtual',
                            accent: GlassPalette.teal,
                            onTap: () => _navTo(
                              TempMailSmsPage(
                                sessionKey: widget.sessionKey,
                                username: 'user',
                                role: widget.userRole,
                              ),
                            ),
                          ),
                          _ToolData(
                            icon: FontAwesomeIcons.tiktok,
                            title: 'TikTok Video',
                            sub: 'No watermark downloader',
                            accent: GlassPalette.red,
                            onTap: () => _navTo(
                              TiktokDownloaderPage(
                                sessionKey: widget.sessionKey,
                                username: 'user',
                                role: widget.userRole,
                              ),
                            ),
                          ),
                          _ToolData(
                            icon: FontAwesomeIcons.instagram,
                            title: 'Instagram Post',
                            sub: 'Download IG post/reels',
                            accent: GlassPalette.orange,
                            onTap: () => _navTo(
                              InstagramDownloaderPage(
                                sessionKey: widget.sessionKey,
                                username: 'user',
                                role: widget.userRole,
                              ),
                            ),
                          ),
                        ]),

                        const SizedBox(height: 18),

                        // ─── Section 5: Utilities ───
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GlassSectionTitle(
                            icon: Icons.build_rounded,
                            title: 'Atomic Utilities',
                            color: GlassPalette.blue,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildHorizontalCards([
                          _ToolData(
                            icon: Icons.qr_code_rounded,
                            title: 'Fake Dana Generator',
                            sub: 'Generate Fake Dana',
                            accent: GlassPalette.blue,
                            onTap: () => _navTo(
                              FakeDanaPage(
                                sessionKey: widget.sessionKey,
                                username: 'user',
                                role: widget.userRole,
                              ),
                            ),
                          ),
                          _ToolData(
                            icon: Icons.lan_rounded,
                            title: 'IP Scanner',
                            sub: 'Scan IP network',
                            accent: GlassPalette.teal,
                            onTap: _showComingSoon,
                          ),
                        ]),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarCustom() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          Text(
            'ATOMIC TOOLS',
            style: GlassFont.pixel(
              size: 12,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: GlassPalette.yellow.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.yellow.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: Text(
              widget.userRole.toUpperCase(),
              style: GlassFont.pixel(
                size: 7,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.yellow.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: GlassPalette.yellow.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.yellow.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.build_circle_rounded,
                color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ATOMIC TOOLS',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Manage & Monitor Assets',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w600,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalCards(List<_ToolData> tools) {
    return SizedBox(
      height: 210,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: tools.length,
        itemBuilder: (context, index) {
          final tool = tools[index];
          return Padding(
            padding:
                EdgeInsets.only(right: index < tools.length - 1 ? 12 : 0),
            child: _buildBannerCard(tool),
          );
        },
      ),
    );
  }

  Widget _buildBannerCard(_ToolData tool) {
    return GestureDetector(
      onTap: tool.onTap,
      child: GlassCard(
        borderWidth: 1.5,
        radius: 18,
        padding: EdgeInsets.zero,
        child: SizedBox(
          width: 175,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Strip warna atas
              Container(
                height: 4,
                decoration: BoxDecoration(
                  color: tool.accent,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(18),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: tool.accent.withOpacity(0.6),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: tool.accent.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: tool.accent.withOpacity(0.6),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: tool.accent.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Icon(tool.icon,
                          color: GlassPalette.white, size: 24),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      tool.title,
                      style: GlassFont.pixel(
                        size: 8,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      tool.sub,
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w600,
                        color: GlassPalette.textDim,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: tool.accent.withOpacity(0.25),
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(18),
                  ),
                  border: Border(
                    top: BorderSide(
                      color: tool.accent.withOpacity(0.5),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: tool.accent,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: tool.accent.withOpacity(0.6),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'OPEN',
                      style: GlassFont.pixel(
                        size: 7,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                    ),
                    const Spacer(),
                    const Icon(Icons.arrow_forward_rounded,
                        color: GlassPalette.white, size: 16),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _navTo(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _showComingSoon() {
    HapticFeedback.lightImpact();
    GlassDialog.show(
      context,
      title: 'Coming Soon',
      message: 'Feature Coming Soon!',
      icon: Icons.hourglass_top_rounded,
      accentColor: GlassPalette.yellow,
    );
  }
}

class _ToolData {
  final IconData icon;
  final String title;
  final String sub;
  final Color accent;
  final VoidCallback onTap;

  const _ToolData({
    required this.icon,
    required this.title,
    required this.sub,
    required this.accent,
    required this.onTap,
  });
}