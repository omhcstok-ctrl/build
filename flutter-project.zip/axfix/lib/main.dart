// main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'landing.dart';
import 'splash.dart';
import 'glass_theme.dart';          // 🔥 GANTI DARI retro_theme.dart
import 'notification_service.dart';
import 'foreground_service.dart';

// ═══════════════════════════════════════════════════════════════════════════
// GLOBAL THEME BUILDER — GLASS
// ═══════════════════════════════════════════════════════════════════════════
class _AppTheme {
  static ThemeData build() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: GlassPalette.bg,

      colorScheme: const ColorScheme.dark(
        brightness: Brightness.dark,
        primary: GlassPalette.blue,
        onPrimary: GlassPalette.white,
        secondary: GlassPalette.purple,
        onSecondary: GlassPalette.white,
        tertiary: GlassPalette.teal,
        onTertiary: GlassPalette.white,
        error: GlassPalette.red,
        onError: GlassPalette.white,
        surface: GlassPalette.surface,
        onSurface: GlassPalette.text,
        outline: GlassPalette.border,
      ),

      textTheme: TextTheme(
        displayLarge: GlassFont.pixel(size: 22, weight: FontWeight.w700),
        displayMedium: GlassFont.pixel(size: 18, weight: FontWeight.w700),
        displaySmall: GlassFont.pixel(size: 16, weight: FontWeight.w700),
        headlineLarge: GlassFont.pixel(size: 15, weight: FontWeight.w700),
        headlineMedium: GlassFont.pixel(size: 14, weight: FontWeight.w700),
        headlineSmall: GlassFont.pixel(size: 13, weight: FontWeight.w700),
        titleLarge: GlassFont.pixel(size: 12, weight: FontWeight.w700),
        titleMedium: GlassFont.pixel(size: 11, weight: FontWeight.w700),
        titleSmall: GlassFont.pixel(size: 10, weight: FontWeight.w700),
        bodyLarge: GlassFont.body(size: 14, weight: FontWeight.w500),
        bodyMedium: GlassFont.body(size: 13, weight: FontWeight.w500),
        bodySmall: GlassFont.body(size: 11, weight: FontWeight.w400),
        labelLarge: GlassFont.pixel(size: 10, weight: FontWeight.w700),
        labelMedium: GlassFont.pixel(size: 9, weight: FontWeight.w700),
        labelSmall: GlassFont.pixel(size: 8, weight: FontWeight.w700),
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: GlassPalette.text,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: GlassFont.pixel(
          size: 12,
          weight: FontWeight.w700,
          color: GlassPalette.text,
        ),
        iconTheme: const IconThemeData(color: GlassPalette.white, size: 22),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
        ),
      ),

      cardTheme: CardThemeData(
        color: GlassPalette.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: GlassPalette.border, width: 1.5),
        ),
        clipBehavior: Clip.antiAlias,
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all(GlassPalette.blue),
          foregroundColor: WidgetStateProperty.all(GlassPalette.white),
          elevation: WidgetStateProperty.all(0),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          textStyle: WidgetStateProperty.all(
            GlassFont.pixel(size: 11, weight: FontWeight.w700),
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.all(GlassPalette.white),
          side: WidgetStateProperty.all(
            const BorderSide(color: GlassPalette.border, width: 1.5),
          ),
          backgroundColor: WidgetStateProperty.all(GlassPalette.surface),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      ),

      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.all(GlassPalette.white),
          textStyle: WidgetStateProperty.all(
            GlassFont.pixel(size: 10, weight: FontWeight.w700),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white.withOpacity(0.08),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
              color: Colors.white.withOpacity(0.2), width: 1.2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
              color: Colors.white.withOpacity(0.2), width: 1.2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
              color: GlassPalette.blue.withOpacity(0.7), width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: GlassPalette.red, width: 1.5),
        ),
        labelStyle: GlassFont.body(
          size: 12,
          weight: FontWeight.w500,
          color: GlassPalette.textSub,
        ),
        hintStyle: GlassFont.body(
          size: 12,
          weight: FontWeight.w400,
          color: GlassPalette.textDim,
        ),
        prefixIconColor: GlassPalette.white,
        suffixIconColor: GlassPalette.white,
        floatingLabelStyle: GlassFont.pixel(
          size: 9,
          weight: FontWeight.w700,
          color: GlassPalette.white,
        ),
      ),

      dialogTheme: DialogThemeData(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        titleTextStyle: GlassFont.pixel(
          size: 12,
          weight: FontWeight.w700,
          color: GlassPalette.white,
        ),
        contentTextStyle: GlassFont.body(
          size: 12,
          weight: FontWeight.w500,
          color: GlassPalette.textSub,
        ),
      ),

      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Colors.transparent,
        modalBackgroundColor: Colors.transparent,
        elevation: 0,
        modalElevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        showDragHandle: false,
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: GlassPalette.surface,
        contentTextStyle: GlassFont.body(
          size: 12,
          weight: FontWeight.w500,
          color: GlassPalette.text,
        ),
        actionTextColor: GlassPalette.white,
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: GlassPalette.border, width: 1.2),
        ),
      ),

      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return GlassPalette.blue;
          return GlassPalette.white;
        }),
        trackColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected))
            return GlassPalette.blue.withOpacity(0.4);
          return Colors.white.withOpacity(0.15);
        }),
      ),

      sliderTheme: const SliderThemeData(
        activeTrackColor: GlassPalette.blue,
        inactiveTrackColor: Color(0x33FFFFFF),
        thumbColor: GlassPalette.white,
        overlayColor: Color(0x332AABEE),
        trackHeight: 4,
      ),

      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: GlassPalette.white,
        linearTrackColor: Color(0x33FFFFFF),
        circularTrackColor: Color(0x33FFFFFF),
      ),

      iconTheme: const IconThemeData(color: GlassPalette.white, size: 22),
      dividerTheme: const DividerThemeData(
        color: GlassPalette.border,
        thickness: 1,
        space: 1,
      ),
      drawerTheme: const DrawerThemeData(
        backgroundColor: GlassPalette.bg,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;
  Widget page;

  switch (settings.name) {
    case '/':
      page = const LandingPage();
      break;
    case '/login':
      page = const LoginPage();
      break;
    case '/splash':
      page = SplashScreen(
        username: args!['username'],
        password: args['password'],
        role: (args['role'] ?? '').toString(),
        sessionKey: args['key'],
        expiredDate: args['expiredDate'],
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news: List<dynamic>.from(args['news'] ?? []),
      );
      break;
    case '/dashboard':
      page = DashboardPage(
        username: args!['username'],
        password: args['password'],
        role: (args['role'] ?? '').toString(),
        sessionKey: args['key'],
        expiredDate: args['expiredDate'],
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news: List<dynamic>.from(args['news'] ?? []),
      );
      break;
    case '/home':
      page = HomePage(
        isGroup: false,
        username: args!['username'],
        password: args['password'],
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
        role: (args['role'] ?? '').toString(),
        expiredDate: args['expiredDate'],
        sessionKey: args['sessionKey'],
      );
      break;
    case '/seller':
      page = SellerPage(keyToken: args!['keyToken']);
      break;
    case '/admin':
      page = AdminPage(
        sessionKey: args!['sessionKey'] ?? '',
        role: (args['role'] ?? 'member').toString(),
      );
      break;
    default:
      page = const Scaffold(
        body: Center(child: Text('404 - Not Found')),
      );
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration: const Duration(milliseconds: 250),
    reverseTransitionDuration: const Duration(milliseconds: 200),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      return FadeTransition(
        opacity: animation,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.03, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(
              parent: animation, curve: Curves.easeOutCubic)),
          child: child,
        ),
      );
    },
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarDividerColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  try {
    await NotificationService().init();
    await NotificationService().requestPermission();
    debugPrint('[MAIN] Notification service initialized');

    NotificationService().onNotificationAction = (actionId, payload) async {
      debugPrint('[MAIN] 📞 Notif action: $actionId | payload: $payload');
      if (actionId == 'accept_call') {
        debugPrint('[MAIN] ✅ User accepted call from notif');
      } else if (actionId == 'reject_call') {
        debugPrint('[MAIN] ❌ User rejected call from notif');
      }
    };

    NotificationService().onNotificationTap = (payload) async {
      debugPrint('[MAIN] 📞 Notif tapped: $payload');
    };
  } catch (e) {
    debugPrint('[MAIN] Notification init error: $e');
  }

  try {
    await ForegroundService().init();
    debugPrint('[MAIN] Foreground service initialized');
  } catch (e) {
    debugPrint('[MAIN] Foreground service init error: $e');
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ATOMIC X PROJECT',
      theme: _AppTheme.build(),
      initialRoute: '/',
      onGenerateRoute: _generateRoute,
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(mq.textScaleFactor.clamp(0.85, 1.2)),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}