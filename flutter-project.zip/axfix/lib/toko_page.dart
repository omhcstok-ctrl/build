// toko_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// TOKO PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'glass_theme.dart';

class TokoConfig {
  static const String ownerTelegram = 'axleyfaker';
  static const String qrisImageUrl = 'https://files.catbox.moe/pfwvkf.jpg';
  static const String danaNumber = '085832132441';
  static const String danaOwnerName = 'yanzstore';

  static final List<Map<String, dynamic>> categories = [
    {
      'id': 'userbot',
      'name': 'USER BOT',
      'subtitle': 'Bot WhatsApp',
      'icon': Icons.smart_toy_rounded,
      'color': 0xFFE53935,
      'items': [
        {'name': 'Role Premium', 'price': 'Rp 1.000', 'desc': 'Akses role premium'},
        {'name': 'Role Reseller', 'price': 'Rp 3.000', 'desc': 'Bisa jual userbot premium'},
        {'name': 'Role Admin', 'price': 'Rp 5.000', 'desc': 'Bisa jual role reseller ke bawah'},
        {'name': 'Role Owner', 'price': 'Rp 7.000', 'desc': 'Bisa jual role admin ke bawah'},
        {'name': 'Role TK', 'price': 'Rp 9.000', 'desc': 'Bisa jual role owner ke bawah'},
        {'name': 'Role CEO', 'price': 'Rp 10.000', 'desc': 'Bisa jual all role'},
      ],
    },
    {
      'id': 'pt_function',
      'name': 'PT FUNCTION',
      'subtitle': 'Nanas Muda',
      'icon': Icons.functions_rounded,
      'color': 0xFF1E8A76,
      'items': [
        {'name': 'PT NanasMuda', 'price': 'Rp 20.000', 'desc': 'Function basic'},
        {'name': 'TK NanasMuda', 'price': 'Rp 35.000', 'desc': 'Function pro'},
        {'name': 'STAF NanasMuda', 'price': 'Rp 50.000', 'desc': 'Function ultra'},
        {'name': 'OWN NanasMuda', 'price': 'Rp 80.000', 'desc': 'Function paling gacor'},
      ],
    },
    {
      'id': 'apk_nightmare',
      'name': 'APK NIGHTMARE',
      'subtitle': 'Bug APK Nightmare',
      'icon': Icons.nightlight_round,
      'color': 0xFFE53935,
      'items': [
        {'name': 'Harian', 'price': 'Rp 2.000', 'desc': 'Akses 1 hari'},
        {'name': 'Full Up', 'price': 'Rp 20.000', 'desc': 'Full upgrade'},
        {'name': 'Reseller', 'price': 'Rp 30.000', 'desc': 'Bisa jual ulang'},
        {'name': 'Partner', 'price': 'Rp 50.000', 'desc': 'Akses partner'},
        {'name': 'Moderator', 'price': 'Rp 60.000', 'desc': 'Akses moderasi'},
      ],
    },
    {
      'id': 'apk_vanatic',
      'name': 'APK VANATIC',
      'subtitle': 'Bug APK Vanatic',
      'icon': Icons.local_fire_department_rounded,
      'color': 0xFFFF6D00,
      'items': [
        {'name': 'Permanent', 'price': 'Rp 20.000', 'desc': 'Akses selamanya'},
        {'name': 'VIP', 'price': 'Rp 30.000', 'desc': 'Akses VIP'},
        {'name': 'Reseller', 'price': 'Rp 35.000', 'desc': 'Bisa jual ulang'},
        {'name': 'Partner', 'price': 'Rp 50.000', 'desc': 'Akses partner'},
        {'name': 'MOD', 'price': 'Rp 65.000', 'desc': 'Akses moderasi'},
        {'name': 'Owner', 'price': 'Rp 85.000', 'desc': 'Akses owner'},
        {'name': 'HighOwn', 'price': 'Rp 100.000', 'desc': 'Akses high owner'},
      ],
    },
    {
      'id': 'panel_ptero',
      'name': 'PANEL PTERODACTYL',
      'subtitle': 'Legal Hosting',
      'icon': Icons.dns_rounded,
      'color': 0xFF16A34A,
      'items': [
        {'name': 'Reseller', 'price': 'Rp 5.000', 'desc': 'Akses reseller panel'},
        {'name': 'Admin Panel', 'price': 'Rp 8.000', 'desc': 'Akses admin panel'},
        {'name': 'Partner Panel', 'price': 'Rp 12.000', 'desc': 'Akses partner panel'},
        {'name': 'Owner Panel', 'price': 'Rp 15.000', 'desc': 'Akses owner panel'},
        {'name': 'TK Panel', 'price': 'Rp 18.000', 'desc': 'Akses TK panel'},
        {'name': 'CEO Panel', 'price': 'Rp 20.000', 'desc': 'Akses CEO panel'},
        {'name': 'Assistant Panel', 'price': 'Rp 25.000', 'desc': 'Akses assistant panel'},
      ],
    },
  ];
}

class TokoPage extends StatefulWidget {
  final String? sessionKey;
  final String? username;
  final String? role;

  const TokoPage({
    super.key,
    this.sessionKey,
    this.username,
    this.role,
  });

  @override
  State<TokoPage> createState() => _TokoPageState();
}

class _TokoPageState extends State<TokoPage> with TickerProviderStateMixin {
  String _selectedCategoryId = 'userbot';
  late AnimationController _fadeCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  Map<String, dynamic> get _selectedCategory =>
      TokoConfig.categories.firstWhere((c) => c['id'] == _selectedCategoryId);

  Color _hexToColor(int hex) => Color(hex);

  Future<void> _openTelegram(String productName, String price) async {
    final text = Uri.encodeComponent(
      'Halo Owner, saya mau beli:\n\n'
      '📦 Produk: $productName\n'
      '💰 Harga: $price\n'
      '👤 Username: ${widget.username ?? "-"}\n'
      '🔑 Session: ${widget.sessionKey ?? "-"}\n\n'
      'Mohon info pembayaran & proses selanjutnya 🙏',
    );
    final url =
        Uri.parse('https://t.me/${TokoConfig.ownerTelegram}?text=$text');
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  Future<void> _openTelegramChat() async {
    final url = Uri.parse('https://t.me/${TokoConfig.ownerTelegram}');
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  Future<void> _copyToClipboard(String text, String label) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    GlassDialog.show(
      context,
      title: 'Tersalin',
      message: '$label disalin!',
      icon: Icons.copy_rounded,
      accentColor: GlassPalette.teal,
    );
  }

  void _showPaymentDialog(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildPaymentSheet(product),
    );
  }

  Widget _buildPaymentSheet(Map<String, dynamic> product) {
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (_, scrollCtrl) => Container(
        decoration: BoxDecoration(
          color: GlassPalette.bg.withOpacity(0.98),
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(28),
          ),
          border: Border(
            top: BorderSide(
              color: Colors.white.withOpacity(0.2),
              width: 1.5,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 30,
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 12),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: GlassPalette.blue.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: GlassPalette.blue.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.payment_rounded,
                        color: GlassPalette.white, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'PEMBAYARAN',
                          style: GlassFont.pixel(
                            size: 10,
                            weight: FontWeight.w700,
                            color: GlassPalette.text,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          product['name'] ?? '',
                          style: GlassFont.body(
                            size: 11,
                            weight: FontWeight.w600,
                            color: GlassPalette.textSub,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded,
                        color: GlassPalette.textSub),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            Expanded(
              child: ListView(
                controller: scrollCtrl,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  _infoCard(
                    icon: Icons.shopping_bag_rounded,
                    label: 'Produk',
                    value: product['name'] ?? '-',
                    color: GlassPalette.teal,
                  ),
                  const SizedBox(height: 8),
                  _infoCard(
                    icon: Icons.attach_money_rounded,
                    label: 'Harga',
                    value: product['price'] ?? '-',
                    color: GlassPalette.red,
                  ),
                  if (product['desc'] != null) ...[
                    const SizedBox(height: 8),
                    _infoCard(
                      icon: Icons.info_outline_rounded,
                      label: 'Deskripsi',
                      value: product['desc'] ?? '-',
                      color: GlassPalette.textSub,
                    ),
                  ],
                  const SizedBox(height: 20),
                  _sectionTitle('💳 QRIS'),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.2,
                      ),
                    ),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: CachedNetworkImage(
                            imageUrl: TokoConfig.qrisImageUrl,
                            width: 220,
                            height: 220,
                            fit: BoxFit.contain,
                            placeholder: (_, __) => Container(
                              width: 220,
                              height: 220,
                              color: Colors.white.withOpacity(0.06),
                              child: const Center(
                                child: CircularProgressIndicator(
                                  color: GlassPalette.white,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                            errorWidget: (_, __, ___) => Container(
                              width: 220,
                              height: 220,
                              color: Colors.white.withOpacity(0.06),
                              child: const Center(
                                child: Icon(Icons.broken_image_rounded,
                                    color: GlassPalette.textDim, size: 50),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Scan QRIS di atas untuk bayar',
                          style: GlassFont.body(
                            size: 11,
                            weight: FontWeight.w600,
                            color: GlassPalette.textSub,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _sectionTitle('💰 DANA'),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Nomor DANA',
                                  style: GlassFont.body(
                                    size: 10,
                                    weight: FontWeight.w600,
                                    color: GlassPalette.textDim,
                                  )),
                              const SizedBox(height: 4),
                              Text(
                                TokoConfig.danaNumber,
                                style: GlassFont.pixel(
                                  size: 12,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.text,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'a.n. ${TokoConfig.danaOwnerName}',
                                style: GlassFont.body(
                                  size: 10,
                                  weight: FontWeight.w600,
                                  color: GlassPalette.textSub,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _copyToClipboard(
                              TokoConfig.danaNumber, 'Nomor DANA'),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: GlassPalette.yellow.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: GlassPalette.yellow.withOpacity(0.6),
                                width: 1.2,
                              ),
                            ),
                            child: const Icon(Icons.copy_rounded,
                                color: GlassPalette.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  _sectionTitle('📩 KONFIRMASI'),
                  const SizedBox(height: 10),
                  GlassButton(
                    text: 'KIRIM BUKTI KE OWNER',
                    icon: Icons.receipt_long_rounded,
                    onTap: () {
                      Navigator.pop(context);
                      _openTelegram(
                          product['name'] ?? '-', product['price'] ?? '-');
                    },
                    bgColor: GlassPalette.yellow,
                    textColor: GlassPalette.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    fontSize: 10,
                  ),
                  const SizedBox(height: 10),
                  GlassButton(
                    text: 'CHAT OWNER',
                    icon: Icons.chat_bubble_rounded,
                    onTap: () {
                      Navigator.pop(context);
                      _openTelegramChat();
                    },
                    bgColor: GlassPalette.teal,
                    textColor: GlassPalette.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    fontSize: 10,
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline_rounded,
                            color: GlassPalette.white, size: 16),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Setelah bayar, kirim bukti transfer ke owner lewat Telegram untuk diproses.',
                            style: GlassFont.body(
                              size: 10,
                              weight: FontWeight.w600,
                              color: GlassPalette.textSub,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: GlassPalette.red,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: GlassFont.pixel(
            size: 10,
            weight: FontWeight.w700,
            color: GlassPalette.text,
          ),
        ),
      ],
    );
  }

  Widget _infoCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1.2,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: color.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: Icon(icon, color: GlassPalette.white, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w600,
                      color: GlassPalette.textDim,
                    )),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeCtrl,
            child: Column(
              children: [
                _buildHeader(),
                _buildCategoryRow(),
                const SizedBox(height: 12),
                Expanded(child: _buildProductGrid()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.25),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.storefront_rounded,
                color: GlassPalette.white, size: 16),
          ),
          const SizedBox(width: 10),
          Text(
            'TOKO',
            style: GlassFont.pixel(
              size: 11,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _openTelegramChat,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: GlassPalette.yellow.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.yellow.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.support_agent_rounded,
                  color: GlassPalette.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryRow() {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: TokoConfig.categories.length,
        itemBuilder: (_, i) {
          final cat = TokoConfig.categories[i];
          final isActive = cat['id'] == _selectedCategoryId;
          final color = _hexToColor(cat['color'] as int);

          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
              onTap: () {
                setState(() => _selectedCategoryId = cat['id'] as String);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                width: 120,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isActive
                      ? color.withOpacity(0.25)
                      : Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isActive
                        ? color.withOpacity(0.7)
                        : Colors.white.withOpacity(0.2),
                    width: isActive ? 1.8 : 1.2,
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: color.withOpacity(0.4),
                            blurRadius: 15,
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      cat['icon'] as IconData,
                      color: isActive
                          ? GlassPalette.white
                          : GlassPalette.textSub,
                      size: 24,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      cat['name'] as String,
                      style: GlassFont.pixel(
                        size: 7,
                        weight: FontWeight.w700,
                        color: isActive
                            ? GlassPalette.white
                            : GlassPalette.textSub,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${(cat['items'] as List).length} item',
                      style: GlassFont.body(
                        size: 8,
                        weight: FontWeight.w600,
                        color: isActive
                            ? GlassPalette.white
                            : GlassPalette.textDim,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductGrid() {
    final cat = _selectedCategory;
    final items = cat['items'] as List;
    final color = _hexToColor(cat['color'] as int);

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.82,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final item = items[i] as Map;
        return _buildProductCard(item, color, cat);
      },
    );
  }

  Widget _buildProductCard(Map item, Color color, Map cat) {
    return GestureDetector(
      onTap: () => _showPaymentDialog({
        'name': item['name'],
        'price': item['price'],
        'desc': item['desc'],
      }),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 18,
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: color.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: Icon(cat['icon'] as IconData,
                      color: GlassPalette.white, size: 18),
                ),
                const Spacer(),
                GlassBadge(
                  text: 'NEW',
                  bgColor: GlassPalette.yellow,
                  textColor: GlassPalette.white,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              item['name'] ?? '-',
              style: GlassFont.pixel(
                size: 8,
                weight: FontWeight.w700,
                color: GlassPalette.text,
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              item['desc'] ?? '',
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w600,
                color: GlassPalette.textDim,
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const Spacer(),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: color.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: Text(
                item['price'] ?? '-',
                style: GlassFont.pixel(
                  size: 8,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: GlassPalette.yellow.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: GlassPalette.yellow.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shopping_cart_rounded,
                      color: GlassPalette.white, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    'BELI',
                    style: GlassFont.pixel(
                      size: 8,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}