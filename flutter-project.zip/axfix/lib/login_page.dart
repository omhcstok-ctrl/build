// login_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// LOGIN PAGE — GLASSMORPHISM EDITION
// Husky Mascot + Glass UI + Same Logic As Original
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dashboard_page.dart';
import 'splash.dart';
import 'glass_theme.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _loading = false;
  bool _obscure = true;
  bool _rememberMe = false;
  String? _androidId;

  /// 🔥 BACKGROUND ASSET — SAMA KAYA LANDING
  static const String kBgAsset = 'assets/images/bg_glass.jpg';

  /// 🔥 NOMOR WHATSAPP UNTUK TOMBOL WA
  static const String kWhatsappNumber = '6285809493530';

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;
  late AnimationController _eyeBlinkCtrl;

  late Animation<double> _fade;
  late Animation<Offset> _slide;
  late Animation<double> _logoGlow;
  late Animation<double> _btnPulse;
  late Animation<double> _shake;
  late Animation<double> _eyeBlink;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.04)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    // Husky blink animation
    _eyeBlinkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _eyeBlink = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.05), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 0.05, end: 1.0), weight: 1),
    ]).animate(
        CurvedAnimation(parent: _eyeBlinkCtrl, curve: Curves.easeInOut));

    _startBlinkLoop();

    _entranceCtrl.forward();
    _initLogin();
  }

  void _startBlinkLoop() {
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      _eyeBlinkCtrl.forward(from: 0).then((_) {
        if (!mounted) return;
        _startBlinkLoop();
      });
    });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    _eyeBlinkCtrl.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<String> _getAndroidId() async {
    try {
      final di = DeviceInfoPlugin();
      final info = await di.androidInfo;
      return info.id;
    } catch (_) {
      return 'unknown_device';
    }
  }

  Future<void> _initLogin() async {
    _androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');
    if (savedUser != null && savedPass != null && savedKey != null) {
      setState(() {
        _userCtrl.text = savedUser;
        _passCtrl.text = savedPass;
        _rememberMe = true;
      });
      try {
        final res = await http.get(Uri.parse(
                '$kBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'))
            .timeout(const Duration(seconds: 10));
        final d = jsonDecode(res.body);
        if (d['valid'] == true && mounted) {
          _navDashboard(d);
          return;
        }
      } catch (_) {}
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/validate'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'username': _userCtrl.text.trim(),
          'password': _passCtrl.text.trim(),
          'androidId': _androidId ?? 'unknown',
        },
      ).timeout(const Duration(seconds: 15));

      final d = jsonDecode(res.body);
      if (!mounted) return;

      if (d['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showPopup('Access Expired', 'Akses kamu sudah habis. Hubungi admin.',
            GlassPalette.red);
      } else if (d['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        _showPopup('Login Gagal', 'Username atau password salah.',
            GlassPalette.red);
      } else {
        final prefs = await SharedPreferences.getInstance();
        if (_rememberMe) {
          prefs.setString('username', _userCtrl.text.trim());
          prefs.setString('password', _passCtrl.text.trim());
          prefs.setString('key', d['key'] ?? '');
        } else {
          await prefs.remove('username');
          await prefs.remove('password');
          await prefs.remove('key');
        }
        _navDashboard(d);
      }
    } catch (e) {
      _shakeCtrl.forward(from: 0);
      String msg = 'Gagal konek ke server. Cek koneksi internet.';
      if (e.toString().contains('timeout')) msg = 'Server timeout. Coba lagi.';
      _showPopup('Error', msg, GlassPalette.red);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _navDashboard(Map d) {
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (_) => SplashScreen(
                  username: d['username'] ?? '',
                  password: d['password'] ?? '',
                  role: d['role'] ?? 'member',
                  sessionKey: d['key'] ?? '',
                  expiredDate: d['expiredDate'] ?? '',
                  listBug: List<Map<String, dynamic>>.from((d['listBug'] ?? [])
                      .map((e) =>
                          Map<String, dynamic>.from(e is Map ? e : {}))),
                  listDoos: List<Map<String, dynamic>>.from(
                      (d['listDoos'] ?? [])
                          .map((e) =>
                              Map<String, dynamic>.from(e is Map ? e : {}))),
                  news: List<dynamic>.from(d['news'] ?? []),
                )));
  }

  void _showPopup(String title, String msg, Color color) {
    GlassDialog.show(
      context,
      title: title,
      message: msg,
      icon: Icons.warning_rounded,
      accentColor: color,
    );
  }

  void _forgotPassword() async {
    final uri = Uri.parse('https://t.me/axleyfaker');
    if (await canLaunchUrl(uri)) {
      launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  /// 🔥 BUKA WHATSAPP LANGSUNG KE NOMOR 6285809493530
  Future<void> _openWhatsapp() async {
    // Coba buka via app WhatsApp dulu (deep link)
    final waApp = Uri.parse('whatsapp://send?phone=$kWhatsappNumber');
    // Fallback ke web wa.me
    final waWeb = Uri.parse('https://wa.me/$kWhatsappNumber');

    try {
      if (await canLaunchUrl(waApp)) {
        await launchUrl(waApp, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(waWeb)) {
        await launchUrl(waWeb, mode: LaunchMode.externalApplication);
      } else {
        if (!mounted) return;
        GlassDialog.show(
          context,
          title: 'Gagal',
          message:
              'Gagal buka WhatsApp.\nPastikan WhatsApp udah terinstall di HP lu.',
          icon: Icons.error_outline_rounded,
          accentColor: GlassPalette.red,
        );
      }
    } catch (_) {
      if (!mounted) return;
      GlassDialog.show(
        context,
        title: 'Gagal',
        message: 'Gagal buka WhatsApp.',
        icon: Icons.error_outline_rounded,
        accentColor: GlassPalette.red,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      resizeToAvoidBottomInset: true,
      body: GlassBg(
        bgAsset: kBgAsset,
        child: SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Center(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildHusky(),
                      const SizedBox(height: 16),
                      _buildHeading(),
                      const SizedBox(height: 24),
                      AnimatedBuilder(
                        animation: _shake,
                        builder: (_, child) => Transform.translate(
                          offset: Offset(_shake.value, 0),
                          child: child,
                        ),
                        child: _buildForm(),
                      ),
                      const SizedBox(height: 20),
                      _buildFooter(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // HUSKY MASCOT — CustomPaint, animated blink
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildHusky() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => SizedBox(
        width: 160,
        height: 160,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Glow behind
            Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue
                        .withOpacity(0.3 + _logoGlow.value * 0.3),
                    blurRadius: 30 + _logoGlow.value * 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
            // Husky drawing
            AnimatedBuilder(
              animation: _eyeBlink,
              builder: (_, __) => CustomPaint(
                size: const Size(150, 150),
                painter: _HuskyPainter(eyeOpenFactor: _eyeBlink.value),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeading() {
    return Column(
      children: [
        Text(
          'ATOMIC',
          textAlign: TextAlign.center,
          style: GlassFont.pixel(
            size: 28,
            weight: FontWeight.w900,
            color: GlassPalette.blue,
            letterSpacing: 4,
            height: 1.1,
            shadows: [
              Shadow(
                color: GlassPalette.blue.withOpacity(0.7),
                blurRadius: 18,
              ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Welcome back. Your Atomic is keeping watch.',
          textAlign: TextAlign.center,
          style: GlassFont.body(
            size: 11,
            weight: FontWeight.w500,
            color: GlassPalette.textDim,
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 26,
      padding: const EdgeInsets.all(22),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            _GlassLoginField(
              controller: _userCtrl,
              label: 'Username',
              hint: 'Masukkan username',
              icon: Icons.person_outline_rounded,
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Username tidak boleh kosong'
                  : null,
            ),
            const SizedBox(height: 14),
            _GlassLoginField(
              controller: _passCtrl,
              label: 'Password',
              hint: 'Masukkan password',
              icon: Icons.lock_outline_rounded,
              obscure: _obscure,
              onToggleObscure: () => setState(() => _obscure = !_obscure),
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Password tidak boleh kosong'
                  : null,
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                GestureDetector(
                  onTap: () =>
                      setState(() => _rememberMe = !_rememberMe),
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: _rememberMe
                              ? GlassPalette.blue
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                            color: _rememberMe
                                ? GlassPalette.blue
                                : Colors.white.withOpacity(0.4),
                            width: 1.5,
                          ),
                        ),
                        child: _rememberMe
                            ? const Icon(Icons.check,
                                color: GlassPalette.white, size: 13)
                            : null,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Remember me',
                        style: GlassFont.body(
                          size: 11,
                          weight: FontWeight.w500,
                          color: GlassPalette.textSub,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _forgotPassword,
                  child: Text(
                    'Forgot password?',
                    style: GlassFont.body(
                      size: 11,
                      weight: FontWeight.w600,
                      color: GlassPalette.blue,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _GlassLoginButton(
              isLoading: _loading,
              pulseAnim: _btnPulse,
              onTap: _login,
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.12),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    'or continue with',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w500,
                      color: GlassPalette.textDim,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                // 🔥 TOMBOL WHATSAPP — ganti tombol Google
                Expanded(
                  child: _socialBtn(
                    'WhatsApp',
                    Icons.chat_rounded,
                    _openWhatsapp,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _socialBtn(
                    'Telegram',
                    Icons.telegram,
                    () => _openUrl('https://t.me/axleyfaker'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    try {
      if (await canLaunchUrl(uri)) {
        launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  Widget _socialBtn(String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: GlassPalette.white, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: GlassFont.body(
                size: 11,
                weight: FontWeight.w600,
                color: GlassPalette.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        GestureDetector(
          onTap: _forgotPassword,
          child: RichText(
            text: TextSpan(children: [
              TextSpan(
                text: 'Belum punya Akun? ',
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim,
                ),
              ),
              TextSpan(
                text: 'Beli Disini',
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w700,
                  color: GlassPalette.blue,
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.shield_outlined,
                color: GlassPalette.white, size: 14),
            const SizedBox(width: 8),
            Text(
              'Secure Login · Encrypted Connection',
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w500,
                color: GlassPalette.textDim,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS LOGIN FIELD
// ═══════════════════════════════════════════════════════════════════════════
class _GlassLoginField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _GlassLoginField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_GlassLoginField> createState() => _GlassLoginFieldState();
}

class _GlassLoginFieldState extends State<_GlassLoginField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            widget.label,
            style: GlassFont.body(
              size: 11,
              weight: FontWeight.w600,
              color: GlassPalette.textSub,
            ),
          ),
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _focused
                  ? GlassPalette.blue.withOpacity(0.8)
                  : Colors.white.withOpacity(0.2),
              width: _focused ? 1.5 : 1.2,
            ),
            boxShadow: _focused
                ? [
                    BoxShadow(
                      color: GlassPalette.blue.withOpacity(0.35),
                      blurRadius: 15,
                    ),
                  ]
                : null,
          ),
          child: TextFormField(
            controller: widget.controller,
            focusNode: _focus,
            obscureText: widget.obscure,
            validator: widget.validator,
            style: GlassFont.body(
              size: 13,
              weight: FontWeight.w600,
              color: GlassPalette.text,
            ),
            cursorColor: GlassPalette.blue,
            decoration: InputDecoration(
              hintText: widget.hint,
              hintStyle: GlassFont.body(
                size: 12,
                weight: FontWeight.w400,
                color: GlassPalette.textDim,
              ),
              prefixIcon: Icon(widget.icon,
                  color: GlassPalette.white.withOpacity(0.7), size: 18),
              suffixIcon: widget.onToggleObscure != null
                  ? GestureDetector(
                      onTap: widget.onToggleObscure,
                      child: Icon(
                        widget.obscure
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: GlassPalette.white.withOpacity(0.7),
                        size: 18,
                      ),
                    )
                  : null,
              errorStyle: GlassFont.body(
                size: 10,
                weight: FontWeight.w600,
                color: GlassPalette.red,
              ),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS LOGIN BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _GlassLoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _GlassLoginButton({
    required this.isLoading,
    required this.pulseAnim,
    required this.onTap,
  });

  @override
  State<_GlassLoginButton> createState() => _GlassLoginButtonState();
}

class _GlassLoginButtonState extends State<_GlassLoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          height: 54,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [GlassPalette.blue, GlassPalette.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: GlassPalette.blue
                    .withOpacity(_down ? 0.3 : 0.55),
                blurRadius: _down ? 10 : 22,
                spreadRadius: 0,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: Center(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  child: widget.isLoading
                      ? const SizedBox(
                          key: ValueKey('loading'),
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: GlassPalette.white),
                        )
                      : Row(
                          key: const ValueKey('idle'),
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.fingerprint_rounded,
                                color: GlassPalette.white, size: 20),
                            const SizedBox(width: 10),
                            Text(
                              'SIGN IN',
                              style: GlassFont.pixel(
                                size: 12,
                                weight: FontWeight.w700,
                                color: GlassPalette.white,
                                letterSpacing: 2,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// HUSKY PAINTER — digambar pakai CustomPaint
// ═══════════════════════════════════════════════════════════════════════════
class _HuskyPainter extends CustomPainter {
  final double eyeOpenFactor; // 1.0 = open, 0.05 = blink

  _HuskyPainter({required this.eyeOpenFactor});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final w = size.width;
    final h = size.height;

    // ── Base circle (head) ──
    final headPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF1E293B),
          Color(0xFF0F172A),
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(cx, cy),
        radius: w * 0.42,
      ));

    // ── Ears ──
    final earPaint = Paint()..color = const Color(0xFF1E293B);

    // Left ear
    final leftEar = Path()
      ..moveTo(cx - w * 0.36, cy - h * 0.20)
      ..lineTo(cx - w * 0.42, cy - h * 0.46)
      ..lineTo(cx - w * 0.22, cy - h * 0.34)
      ..close();
    canvas.drawPath(leftEar, earPaint);

    // Right ear
    final rightEar = Path()
      ..moveTo(cx + w * 0.36, cy - h * 0.20)
      ..lineTo(cx + w * 0.42, cy - h * 0.46)
      ..lineTo(cx + w * 0.22, cy - h * 0.34)
      ..close();
    canvas.drawPath(rightEar, earPaint);

    // Inner ears (pink)
    final innerEarPaint = Paint()..color = const Color(0xFFFFB3C1);
    final leftInner = Path()
      ..moveTo(cx - w * 0.34, cy - h * 0.22)
      ..lineTo(cx - w * 0.38, cy - h * 0.40)
      ..lineTo(cx - w * 0.25, cy - h * 0.32)
      ..close();
    canvas.drawPath(leftInner, innerEarPaint);

    final rightInner = Path()
      ..moveTo(cx + w * 0.34, cy - h * 0.22)
      ..lineTo(cx + w * 0.38, cy - h * 0.40)
      ..lineTo(cx + w * 0.25, cy - h * 0.32)
      ..close();
    canvas.drawPath(rightInner, innerEarPaint);

    // ── Head circle ──
    canvas.drawCircle(Offset(cx, cy), w * 0.40, headPaint);

    // ── Face white mask ──
    final facePaint = Paint()..color = const Color(0xFFF5F5F5);
    final facePath = Path()
      ..addOval(Rect.fromCenter(
        center: Offset(cx, cy + h * 0.02),
        width: w * 0.55,
        height: h * 0.45,
      ));
    canvas.drawPath(facePath, facePaint);

    // ── Dark patches around eyes (husky mask) ──
    final patchPaint = Paint()..color = const Color(0xFF1E293B);

    // Left eye patch
    final leftPatch = Path()
      ..addOval(Rect.fromCenter(
        center: Offset(cx - w * 0.14, cy - h * 0.03),
        width: w * 0.20,
        height: h * 0.20,
      ));
    canvas.drawPath(leftPatch, patchPaint);

    // Right eye patch
    final rightPatch = Path()
      ..addOval(Rect.fromCenter(
        center: Offset(cx + w * 0.14, cy - h * 0.03),
        width: w * 0.20,
        height: h * 0.20,
      ));
    canvas.drawPath(rightPatch, patchPaint);

    // ── Eyes (with blink factor) ──
    final eyeY = cy - h * 0.03;
    final eyeRadius = w * 0.045;
    final eyeHeight = eyeRadius * eyeOpenFactor;

    // Eye whites
    final eyeWhitePaint = Paint()..color = Colors.white;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx - w * 0.14, eyeY),
        width: eyeRadius * 2,
        height: eyeHeight * 2,
      ),
      eyeWhitePaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx + w * 0.14, eyeY),
        width: eyeRadius * 2,
        height: eyeHeight * 2,
      ),
      eyeWhitePaint,
    );

    // Pupils (only if eye is open enough)
    if (eyeOpenFactor > 0.3) {
      final pupilPaint = Paint()..color = const Color(0xFF0F172A);
      final pupilRadius = eyeRadius * 0.55;

      canvas.drawCircle(
        Offset(cx - w * 0.14, eyeY),
        pupilRadius,
        pupilPaint,
      );
      canvas.drawCircle(
        Offset(cx + w * 0.14, eyeY),
        pupilRadius,
        pupilPaint,
      );

      // Eye shine
      final shinePaint = Paint()..color = Colors.white;
      canvas.drawCircle(
        Offset(cx - w * 0.14 + pupilRadius * 0.4,
            eyeY - pupilRadius * 0.4),
        pupilRadius * 0.35,
        shinePaint,
      );
      canvas.drawCircle(
        Offset(cx + w * 0.14 + pupilRadius * 0.4,
            eyeY - pupilRadius * 0.4),
        pupilRadius * 0.35,
        shinePaint,
      );
    }

    // ── Nose ──
    final nosePaint = Paint()..color = const Color(0xFF0F172A);
    final nosePath = Path()
      ..moveTo(cx - w * 0.035, cy + h * 0.08)
      ..lineTo(cx + w * 0.035, cy + h * 0.08)
      ..lineTo(cx, cy + h * 0.115)
      ..close();
    canvas.drawPath(nosePath, nosePaint);

    // ── Mouth ──
    final mouthPaint = Paint()
      ..color = const Color(0xFF0F172A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round;

    final mouthPath = Path()
      ..moveTo(cx, cy + h * 0.115)
      ..lineTo(cx, cy + h * 0.14)
      ..moveTo(cx - w * 0.06, cy + h * 0.155)
      ..quadraticBezierTo(
          cx, cy + h * 0.185, cx + w * 0.06, cy + h * 0.155);
    canvas.drawPath(mouthPath, mouthPaint);

    // ── Cheek blush (orange) ──
    final blushPaint = Paint()..color = const Color(0xFFFF9800).withOpacity(0.55);
    canvas.drawCircle(
      Offset(cx - w * 0.24, cy + h * 0.08),
      w * 0.045,
      blushPaint,
    );
    canvas.drawCircle(
      Offset(cx + w * 0.24, cy + h * 0.08),
      w * 0.045,
      blushPaint,
    );

    // ── Paw marks on eyes (like reference) ──
    final pawPaint = Paint()..color = const Color(0xFFB3E5FC);

    // Left paw
    _drawPaw(canvas, Offset(cx - w * 0.14, eyeY), w * 0.07, pawPaint);
    // Right paw
    _drawPaw(canvas, Offset(cx + w * 0.14, eyeY), w * 0.07, pawPaint);
  }

  void _drawPaw(Canvas canvas, Offset center, double size, Paint paint) {
    // Main pad
    canvas.drawCircle(center.translate(0, size * 0.15), size * 0.45, paint);
    // 4 toe pads
    canvas.drawCircle(
        center.translate(-size * 0.4, -size * 0.25), size * 0.22, paint);
    canvas.drawCircle(
        center.translate(-size * 0.13, -size * 0.4), size * 0.22, paint);
    canvas.drawCircle(
        center.translate(size * 0.13, -size * 0.4), size * 0.22, paint);
    canvas.drawCircle(
        center.translate(size * 0.4, -size * 0.25), size * 0.22, paint);
  }

  @override
  bool shouldRepaint(_HuskyPainter old) =>
      old.eyeOpenFactor != eyeOpenFactor;
}