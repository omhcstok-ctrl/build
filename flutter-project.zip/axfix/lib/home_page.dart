// home_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// HOME PAGE — GLASSMORPHISM EDITION (BUG ATTACK)
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'glass_theme.dart';

const String _kProgressVideoAsset = 'assets/videos/progress_bug.mp4';

class HomePage extends StatefulWidget {
  final bool isGroup;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const HomePage({
    super.key,
    required this.isGroup,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final linkController = TextEditingController();

  late AnimationController _slideController;
  late AnimationController _pulseController;
  late Animation<Offset> _slideAnimation;

  String selectedBugId = '';
  String _senderType = 'private';
  bool _isSending = false;
  bool _isNomorMode = true;
  bool _is3DNeo = false;

  List<dynamic> _globalSenders = [];
  bool _loadingGlobal = false;
  bool _isOwner = false;

  List<Map<String, dynamic>> _myGroups = [];
  List<Map<String, dynamic>> _filteredGroups = [];
  bool _loadingGroups = false;
  bool _botOnline = false;
  String _groupsError = '';
  String _selectedGroupName = '';
  String _selectedGroupId = '';
  final TextEditingController _groupSearchCtrl = TextEditingController();

  VideoPlayerController? _bannerVideoController;
  Timer? _globalSenderTimer;

  Completer<void>? _videoDoneCompleter;

  String _countryCode = '+62';
  String _countryFlag = '🇮🇩';

  @override
  void initState() {
    super.initState();
    _isNomorMode = !widget.isGroup;

    _slideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();
    _slideAnimation = Tween<Offset>(
            begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _slideController, curve: Curves.easeOutCubic));

    _pulseController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);

    _isOwner = widget.role.toLowerCase() == 'owner';

    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'];

    _initBannerVideo();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchGlobalSenders();
      if (!_isNomorMode) _fetchMyGroups();
    });

    _globalSenderTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) _fetchGlobalSenders(silent: true);
    });

    _groupSearchCtrl.addListener(() {
      final q = _groupSearchCtrl.text.toLowerCase().trim();
      setState(() {
        if (q.isEmpty) {
          _filteredGroups = List.from(_myGroups);
        } else {
          _filteredGroups = _myGroups.where((g) {
            final name = (g['name'] ?? '').toString().toLowerCase();
            final id = (g['id'] ?? '').toString().toLowerCase();
            return name.contains(q) || id.contains(q);
          }).toList();
        }
      });
    });
  }

  void _toggle3DNeo() {
    HapticFeedback.mediumImpact();
    setState(() => _is3DNeo = !_is3DNeo);
  }

  void _initBannerVideo() {
    _bannerVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4');
    _bannerVideoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _bannerVideoController?.setLooping(true);
      _bannerVideoController?.play();
      _bannerVideoController?.setVolume(0);
    }).catchError((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _fetchGlobalSenders({bool silent = false}) async {
    if (!silent) setState(() => _loadingGlobal = true);
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/getPublicSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        if (!silent && mounted) setState(() => _loadingGlobal = false);
        return;
      }

      final d = jsonDecode(body);
      if (d['valid'] == true) {
        if (mounted) {
          setState(() {
            _globalSenders = List<dynamic>.from(d['senders'] ?? []);
            _isOwner = (d['isOwner'] == true) ||
                widget.role.toLowerCase() == 'owner';
          });
        }
      }
    } catch (_) {}
    if (!silent && mounted) setState(() => _loadingGlobal = false);
  }

  Future<void> _fetchMyGroups() async {
    setState(() {
      _loadingGroups = true;
      _groupsError = '';
    });

    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/myGroups?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 20));

      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        if (!mounted) return;
        setState(() {
          _loadingGroups = false;
          _groupsError = 'Server error. Endpoint /myGroups belum aktif.';
        });
        return;
      }

      final d = jsonDecode(body);

      if (d['valid'] == true) {
        final raw = d['groups'];
        final groups = <Map<String, dynamic>>[];
        if (raw is List) {
          for (final g in raw) {
            if (g is Map) groups.add(Map<String, dynamic>.from(g));
          }
        }

        if (!mounted) return;
        setState(() {
          _myGroups = groups;
          _filteredGroups = List.from(groups);
          _botOnline = d['botOnline'] == true;
          _loadingGroups = false;
          _groupsError = '';
        });

        if (groups.isEmpty) {
          if (!_botOnline) {
            _groupsError = 'Bot tidak terhubung. Hubungkan bot dulu.';
          } else {
            _groupsError = 'Belum ada group yang bot join.';
          }
        }
      } else {
        if (!mounted) return;
        setState(() {
          _loadingGroups = false;
          _groupsError = d['message'] ?? 'Gagal fetch group';
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingGroups = false;
        _groupsError = 'Koneksi error: ${e.toString().split('\n').first}';
      });
    }
  }

  @override
  void dispose() {
    _globalSenderTimer?.cancel();
    _slideController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    linkController.dispose();
    _groupSearchCtrl.dispose();
    _bannerVideoController?.dispose();
    super.dispose();
  }

  Future<void> _sendBugNomor() async {
    final target = targetController.text.trim();
    if (target.isEmpty) {
      GlassDialog.show(context,
          title: 'Error',
          message: 'Nomor target tidak boleh kosong!',
          icon: Icons.error_outline,
          accentColor: GlassPalette.red);
      return;
    }

    setState(() {
      _isSending = true;
    });

    try {
      final httpFuture = () async {
        final cleanNum = target.replaceAll(RegExp(r'\D'), '');
        final finalTarget = '$_countryCode$cleanNum';

        final url =
            '$kBaseUrl/sendBug?key=${widget.sessionKey}&target=$finalTarget&bug=$selectedBugId&senderType=$_senderType';

        final res = await http.get(Uri.parse(url));
        final data = jsonDecode(res.body);

        bool isSuccess = false;
        String msg = '';

        if (data['cooldown'] == true) {
          msg = 'Cooldown: Tunggu ${data['wait']} detik.';
        } else if (data['valid'] == false) {
          msg = 'Sesi Invalid.';
        } else if (data['sended'] == false) {
          msg = 'Gagal: Server Maintenance.';
        } else {
          isSuccess = true;
          msg = 'Bug berhasil dikirim ke $finalTarget!';
        }

        return {'success': isSuccess, 'msg': msg};
      }();

      final results = await Future.wait([
        httpFuture,
        _showProgressDialog(),
      ]);

      final httpResult = results[0] as Map<String, dynamic>;
      final isSuccess = httpResult['success'] as bool;
      final msg = httpResult['msg'] as String;

      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));

      if (isSuccess) {
        _showSuccessDialog(msg);
        targetController.clear();
      } else {
        _showErrorDialog(msg);
      }
    } catch (_) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));
      _showErrorDialog('Gagal menghubungi server.');
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<void> _sendBugGroup() async {
    if (_selectedGroupId.isEmpty) {
      GlassDialog.show(context,
          title: 'Error',
          message: 'Pilih group dulu!',
          icon: Icons.error_outline,
          accentColor: GlassPalette.red);
      return;
    }

    final target = _selectedGroupId;

    setState(() {
      _isSending = true;
    });

    try {
      final httpFuture = () async {
        final encodedTarget = Uri.encodeComponent(target);
        final url =
            '$kBaseUrl/sendBug?key=${widget.sessionKey}&target=$encodedTarget&bug=$selectedBugId&senderType=$_senderType';

        final res = await http.get(Uri.parse(url));
        final data = jsonDecode(res.body);

        bool isSuccess = false;
        String msg = '';

        if (data['valid'] == false) {
          msg = data['message'] ?? 'Session Invalid.';
        } else if (data['cooldown'] == true) {
          msg = 'Cooldown: Tunggu ${data['wait']} detik.';
        } else if (data['sended'] == true) {
          isSuccess = true;
          msg = 'Bug berhasil dikirim ke Group!';
        } else {
          msg = data['message'] ?? 'Gagal mengirim bug.';
        }

        return {'success': isSuccess, 'msg': msg};
      }();

      final results = await Future.wait([
        httpFuture,
        _showProgressDialog(),
      ]);

      final httpResult = results[0] as Map<String, dynamic>;
      final isSuccess = httpResult['success'] as bool;
      final msg = httpResult['msg'] as String;

      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));

      if (isSuccess) {
        _showSuccessDialog(msg);
      } else {
        _showErrorDialog(msg);
      }
    } catch (_) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      await Future.delayed(const Duration(milliseconds: 300));
      _showErrorDialog('Gagal menghubungi server.');
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<void> _showProgressDialog() async {
    _videoDoneCompleter = Completer<void>();

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _ProgressVideoDialog(
        onVideoEnd: () {
          if (_videoDoneCompleter != null &&
              !_videoDoneCompleter!.isCompleted) {
            _videoDoneCompleter!.complete();
          }
        },
      ),
    );

    await _videoDoneCompleter!.future;
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _SuccessDialogCard(
        message: message,
        onClose: () => Navigator.of(context, rootNavigator: true).pop(),
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      useRootNavigator: true,
      builder: (_) => _ErrorDialogCard(
        message: message,
        onClose: () => Navigator.of(context, rootNavigator: true).pop(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBarCustom(),
              Expanded(
                child: SingleChildScrollView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildProfileCardWithVideo(),
                        const SizedBox(height: 18),
                        _buildModeButtons(),
                        const SizedBox(height: 18),
                        if (_isNomorMode) ...[
                          GlassSectionTitle(
                            icon: Icons.phone_android_rounded,
                            title: 'Target Number',
                            color: GlassPalette.teal,
                          ),
                          const SizedBox(height: 10),
                          _buildCountryPhoneInput(),
                          const SizedBox(height: 22),
                        ] else ...[
                          GlassSectionTitle(
                            icon: Icons.groups_rounded,
                            title: 'Pilih Group',
                            color: GlassPalette.teal,
                          ),
                          const SizedBox(height: 10),
                          _buildGroupButton(),
                          const SizedBox(height: 22),
                        ],
                        GlassSectionTitle(
                          icon: Icons.bug_report_rounded,
                          title: 'Pilih Bug',
                          color: GlassPalette.red,
                        ),
                        const SizedBox(height: 10),
                        _buildBugSelectionCards(),
                        const SizedBox(height: 24),
                        _buildSenderSelector(),
                        const SizedBox(height: 24),
                        _buildSendButton(
                          onPressed:
                              _isNomorMode ? _sendBugNomor : _sendBugGroup,
                          label: _isNomorMode
                              ? 'Send Bug'
                              : 'Send Bug Group',
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarCustom() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'BUG ATTACK',
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: GlassPalette.teal,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      widget.role.toUpperCase(),
                      style: GlassFont.pixel(
                        size: 7,
                        weight: FontWeight.w700,
                        color: GlassPalette.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _toggle3DNeo,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: _is3DNeo
                    ? GlassPalette.red.withOpacity(0.3)
                    : GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _is3DNeo
                      ? GlassPalette.red.withOpacity(0.7)
                      : GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (_is3DNeo ? GlassPalette.red : GlassPalette.blue)
                        .withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.view_in_ar_rounded,
                    color: GlassPalette.white,
                    size: 14,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '3D',
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCardWithVideo() {
    return GlassCard(
      padding: EdgeInsets.zero,
      borderWidth: 1.5,
      radius: 22,
      child: SizedBox(
        height: 200,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_bannerVideoController != null &&
                  _bannerVideoController!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _bannerVideoController!.value.size.width,
                    height: _bannerVideoController!.value.size.height,
                    child: VideoPlayer(_bannerVideoController!),
                  ),
                )
              else
                Container(color: Colors.white.withOpacity(0.1)),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.75),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 12,
                left: 12,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.7),
                      width: 1.2,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          color: GlassPalette.red,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'PROFILE',
                        style: GlassFont.pixel(
                          size: 8,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 14,
                left: 14,
                right: 14,
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: GlassPalette.blue.withOpacity(0.3),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: GlassPalette.blue.withOpacity(0.7),
                          width: 1.5,
                        ),
                      ),
                      child: const CircleAvatar(
                        radius: 22,
                        backgroundColor: Colors.transparent,
                        child: Icon(Icons.person,
                            color: GlassPalette.white, size: 22),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                            width: 1.2,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    widget.username.toUpperCase(),
                                    style: GlassFont.pixel(
                                      size: 10,
                                      weight: FontWeight.w700,
                                      color: GlassPalette.white,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Container(
                                  padding: const EdgeInsets.all(1.5),
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFF2196F3),
                                  ),
                                  child: const Icon(Icons.check,
                                      color: Colors.white, size: 9),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: GlassPalette.red.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                  color:
                                      GlassPalette.red.withOpacity(0.7),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                widget.role.toUpperCase(),
                                style: GlassFont.pixel(
                                  size: 7,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeButtons() {
    return Row(
      children: [
        Expanded(
          child: _modeBtn(
            label: 'BUG NOMOR',
            icon: Icons.phone_android_rounded,
            active: _isNomorMode,
            accentColor: GlassPalette.red,
            onTap: () => setState(() {
              _isNomorMode = true;
              final wabugs = widget.listBug
                  .where((b) =>
                      b['is_group'] == false || b['is_group'] == null)
                  .toList();
              if (wabugs.isNotEmpty) selectedBugId = wabugs[0]['bug_id'];
            }),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _modeBtn(
            label: 'BUG GROUP',
            icon: Icons.group_add_rounded,
            active: !_isNomorMode,
            accentColor: GlassPalette.purple,
            onTap: () => setState(() {
              _isNomorMode = false;
              final grpbugs =
                  widget.listBug.where((b) => b['is_group'] == true).toList();
              if (grpbugs.isNotEmpty) selectedBugId = grpbugs[0]['bug_id'];
              if (_myGroups.isEmpty) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _fetchMyGroups();
                });
              }
            }),
          ),
        ),
      ],
    );
  }

  Widget _modeBtn({
    required String label,
    required IconData icon,
    required bool active,
    required Color accentColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: active
              ? accentColor.withOpacity(0.25)
              : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: active
                ? accentColor.withOpacity(0.7)
                : Colors.white.withOpacity(0.15),
            width: active ? 1.5 : 1.2,
          ),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: accentColor.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: active ? GlassPalette.white : GlassPalette.textDim,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: GlassFont.pixel(
                size: 9,
                weight: FontWeight.w700,
                color: active ? GlassPalette.white : GlassPalette.textDim,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCountryPhoneInput() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1.2,
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _showCountryPicker,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: const BorderRadius.horizontal(
                    left: Radius.circular(14)),
                border: Border(
                  right: BorderSide(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_countryFlag, style: const TextStyle(fontSize: 20)),
                  const SizedBox(width: 6),
                  Text(
                    _countryCode,
                    style: GlassFont.pixel(
                      size: 11,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.arrow_drop_down_rounded,
                      color: GlassPalette.white, size: 20),
                ],
              ),
            ),
          ),
          Expanded(
            child: TextField(
              controller: targetController,
              keyboardType: TextInputType.phone,
              style: GlassFont.body(
                size: 15,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
              cursorColor: GlassPalette.white,
              decoration: InputDecoration(
                hintText: '81234567890',
                hintStyle: GlassFont.body(
                  size: 14,
                  weight: FontWeight.w500,
                  color: GlassPalette.textDim,
                ),
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showCountryPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: GlassPalette.bg.withOpacity(0.95),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'PILIH NEGARA',
              style: GlassFont.pixel(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
            const SizedBox(height: 20),
            _countryOption('🇮🇩', '+62', 'Indonesia'),
            _countryOption('🇲🇾', '+60', 'Malaysia'),
            _countryOption('🇸🇬', '+65', 'Singapore'),
            _countryOption('🇹🇭', '+66', 'Thailand'),
            _countryOption('🇻🇳', '+84', 'Vietnam'),
            _countryOption('🇵🇭', '+63', 'Philippines'),
            _countryOption('🇮🇳', '+91', 'India'),
            _countryOption('🇺🇸', '+1', 'United States'),
          ],
        ),
      ),
    );
  }

  Widget _countryOption(String flag, String code, String name) {
    final active = _countryCode == code;
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        setState(() {
          _countryFlag = flag;
          _countryCode = code;
        });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: active
              ? GlassPalette.blue.withOpacity(0.3)
              : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: active
                ? GlassPalette.blue.withOpacity(0.7)
                : Colors.white.withOpacity(0.15),
            width: active ? 1.5 : 1.2,
          ),
        ),
        child: Row(
          children: [
            Text(flag, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                name,
                style: GlassFont.body(
                  size: 14,
                  weight: FontWeight.w600,
                  color: GlassPalette.white,
                ),
              ),
            ),
            Text(
              code,
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
            if (active) ...[
              const SizedBox(width: 8),
              const Icon(Icons.check_circle_rounded,
                  color: GlassPalette.white, size: 18),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildGroupButton() {
    final hasSelected = _selectedGroupName.isNotEmpty;
    return GestureDetector(
      onTap: _openGroupPicker,
      child: GlassCard(
        borderWidth: 1.5,
        radius: 18,
        bgColor: hasSelected
            ? GlassPalette.teal.withOpacity(0.2)
            : null,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: hasSelected
                    ? GlassPalette.teal.withOpacity(0.3)
                    : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: hasSelected
                      ? GlassPalette.teal.withOpacity(0.7)
                      : Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: Icon(
                hasSelected
                    ? Icons.check_circle_rounded
                    : Icons.touch_app_rounded,
                color: GlassPalette.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasSelected
                        ? _selectedGroupName
                        : 'Klik untuk pilih group',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hasSelected
                        ? 'Tap untuk ganti group'
                        : 'Pilih dari daftar group bot',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w400,
                      color: GlassPalette.textSub,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    hasSelected ? 'GANTI' : 'PILIH',
                    style: GlassFont.pixel(
                      size: 8,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.arrow_forward_ios_rounded,
                      color: GlassPalette.white, size: 10),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openGroupPicker() {
    _fetchMyGroups();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              decoration: BoxDecoration(
                color: GlassPalette.bg.withOpacity(0.95),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(28)),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.5,
                ),
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Colors.white.withOpacity(0.15),
                          width: 1.2,
                        ),
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                            width: 40,
                            height: 4,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(2),
                            )),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color:
                                    GlassPalette.teal.withOpacity(0.25),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: GlassPalette.teal
                                      .withOpacity(0.6),
                                  width: 1.2,
                                ),
                              ),
                              child: const Icon(Icons.groups_rounded,
                                  color: GlassPalette.white, size: 18),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'PILIH GROUP',
                                    style: GlassFont.pixel(
                                      size: 11,
                                      weight: FontWeight.w700,
                                      color: GlassPalette.white,
                                    ),
                                  ),
                                  Text(
                                    'Pilih group untuk kirim bug',
                                    style: GlassFont.body(
                                      size: 10,
                                      weight: FontWeight.w400,
                                      color: GlassPalette.textDim,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            GlassBadge(
                              text: _botOnline ? 'LIVE' : 'OFF',
                              bgColor: _botOnline
                                  ? GlassPalette.teal
                                  : GlassPalette.red,
                              textColor: GlassPalette.white,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.2),
                              width: 1.2,
                            ),
                          ),
                          child: TextField(
                            controller: _groupSearchCtrl,
                            onChanged: (_) => setSheetState(() {}),
                            style: GlassFont.body(
                              size: 13,
                              weight: FontWeight.w500,
                              color: GlassPalette.white,
                            ),
                            cursorColor: GlassPalette.white,
                            decoration: InputDecoration(
                              hintText: 'Cari group...',
                              hintStyle: GlassFont.body(
                                size: 12,
                                weight: FontWeight.w400,
                                color: GlassPalette.textDim,
                              ),
                              border: InputBorder.none,
                              icon: const Icon(Icons.search_rounded,
                                  color: GlassPalette.white, size: 18),
                              contentPadding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _loadingGroups
                        ? const Center(
                            child: CircularProgressIndicator(
                                color: GlassPalette.white))
                        : _groupsError.isNotEmpty
                            ? _buildSheetError(setSheetState)
                            : _filteredGroups.isEmpty
                                ? _buildSheetEmpty()
                                : ListView.builder(
                                    padding: const EdgeInsets.all(16),
                                    itemCount: _filteredGroups.length,
                                    itemBuilder: (_, i) => Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: _buildGroupSheetItem(
                                          _filteredGroups[i]),
                                    ),
                                  ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(
                          color: Colors.white.withOpacity(0.15),
                          width: 1.2,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        GlassBadge(
                          text: '${_filteredGroups.length} group',
                          bgColor: GlassPalette.teal,
                          textColor: GlassPalette.white,
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () async {
                            setSheetState(() => _loadingGroups = true);
                            await _fetchMyGroups();
                            setSheetState(() {});
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: GlassPalette.blue.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color:
                                    GlassPalette.blue.withOpacity(0.6),
                                width: 1.2,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.refresh_rounded,
                                    color: GlassPalette.white, size: 14),
                                const SizedBox(width: 6),
                                Text(
                                  'Refresh',
                                  style: GlassFont.pixel(
                                    size: 8,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildGroupSheetItem(Map<String, dynamic> g) {
    final id = (g['id'] ?? '').toString();
    final name = (g['name'] ?? 'Tanpa Nama').toString();
    final memberCount = g['memberCount'] ?? 0;
    final isAdmin = g['isAdmin'] == true;
    final senders = g['senders'];
    final senderCount = senders is List ? senders.length : 1;
    final isSelected = _selectedGroupId == id;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedGroupId = id;
          _selectedGroupName = name;
          linkController.text = id;
        });
        Navigator.pop(context);
      },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? GlassPalette.teal.withOpacity(0.25)
              : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected
                ? GlassPalette.teal.withOpacity(0.7)
                : Colors.white.withOpacity(0.15),
            width: isSelected ? 1.5 : 1.2,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: GlassPalette.teal.withOpacity(0.4),
                    blurRadius: 15,
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: isSelected
                    ? GlassPalette.teal.withOpacity(0.3)
                    : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? GlassPalette.teal.withOpacity(0.7)
                      : Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: Icon(
                isSelected ? Icons.check_circle_rounded : Icons.groups_rounded,
                color: GlassPalette.white,
                size: 22,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.people_rounded,
                          color: GlassPalette.textDim, size: 11),
                      const SizedBox(width: 3),
                      Text(
                        '$memberCount',
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w500,
                          color: GlassPalette.textDim,
                        ),
                      ),
                      if (isAdmin) ...[
                        const SizedBox(width: 8),
                        GlassBadge(
                          text: 'ADMIN',
                          bgColor: GlassPalette.teal,
                          textColor: GlassPalette.white,
                        ),
                      ],
                      if (senderCount > 1) ...[
                        const SizedBox(width: 8),
                        GlassBadge(
                          text: '$senderCount SENDER',
                          bgColor: GlassPalette.orange,
                          textColor: GlassPalette.white,
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSheetEmpty() {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.groups_outlined,
                  color: GlassPalette.textDim, size: 42),
            ),
            const SizedBox(height: 16),
            Text(
              'Belum ada group',
              style: GlassFont.pixel(
                size: 11,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              _botOnline
                  ? 'Bot belum join group apapun'
                  : 'Bot belum terhubung ke WhatsApp',
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w500,
                color: GlassPalette.textDim,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSheetError(StateSetter setSheetState) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.2),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.6),
                  width: 1.5,
                ),
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: GlassPalette.white, size: 42),
            ),
            const SizedBox(height: 16),
            Text(
              _groupsError,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w500,
                color: GlassPalette.textSub,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            GlassButton(
              text: 'Coba Lagi',
              fullWidth: false,
              icon: Icons.refresh_rounded,
              onTap: () async {
                setSheetState(() => _loadingGroups = true);
                await _fetchMyGroups();
                setSheetState(() {});
              },
              bgColor: GlassPalette.blue,
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredBugs {
    return widget.listBug.where((b) {
      final ig = b['is_group'];
      if (ig == null) return true;
      return _isNomorMode ? ig == false : ig == true;
    }).toList();
  }

  Widget _buildBugSelectionCards() {
    if (_filteredBugs.isEmpty) {
      return GlassCard(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Text(
            'Tidak ada bug tersedia',
            style: GlassFont.body(
              size: 12,
              weight: FontWeight.w500,
              color: GlassPalette.textDim,
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: 140,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _filteredBugs.length,
        padding: const EdgeInsets.symmetric(horizontal: 2),
        itemBuilder: (context, index) {
          final bug = _filteredBugs[index];
          final isSel = selectedBugId == bug['bug_id'];
          final bugName = bug['bug_name']?.toString() ?? 'Bug';

          final colors = [
            GlassPalette.red,
            GlassPalette.teal,
            GlassPalette.orange,
            GlassPalette.purple,
            GlassPalette.blue,
            GlassPalette.amber,
          ];
          final color = colors[index % colors.length];

          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
              onTap: () => setState(() => selectedBugId = bug['bug_id']!),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: isSel
                      ? color.withOpacity(0.3)
                      : Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSel
                        ? color.withOpacity(0.8)
                        : Colors.white.withOpacity(0.15),
                    width: isSel ? 1.5 : 1.2,
                  ),
                  boxShadow: isSel
                      ? [
                          BoxShadow(
                            color: color.withOpacity(0.5),
                            blurRadius: 15,
                          ),
                        ]
                      : null,
                ),
                child: SizedBox(
                  width: 130,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: color.withOpacity(0.6),
                            width: 1.2,
                          ),
                        ),
                        child: const Icon(Icons.shield_rounded,
                            color: GlassPalette.white, size: 22),
                      ),
                      const Spacer(),
                      Text(
                        bugName.toUpperCase(),
                        style: GlassFont.pixel(
                          size: 9,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      if (isSel)
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: GlassPalette.amber,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: GlassPalette.amber
                                        .withOpacity(0.7),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'AKTIF',
                              style: GlassFont.pixel(
                                size: 7,
                                weight: FontWeight.w700,
                                color: GlassPalette.amber,
                              ),
                            ),
                          ],
                        )
                      else
                        Text(
                          'TAP PILIH',
                          style: GlassFont.pixel(
                            size: 7,
                            weight: FontWeight.w700,
                            color: GlassPalette.textDim,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSenderSelector() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 18,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.dns_rounded,
                    color: GlassPalette.white, size: 18),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sender Type',
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                  Text(
                    'Pilih sumber nomor pengirim',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w400,
                      color: GlassPalette.textDim,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _senderTypeCard(
                  'Global',
                  'public',
                  Icons.language_rounded,
                  'Public Sender',
                  GlassPalette.teal,
                  senderCount: _globalSenders.length,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _senderTypeCard(
                  'Private',
                  'private',
                  Icons.person_rounded,
                  'Session pribadi',
                  GlassPalette.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.2,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _senderType == 'public'
                        ? GlassPalette.teal
                        : GlassPalette.blue,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  _senderType == 'public'
                      ? 'Public sender aktif'
                      : 'Private sender aktif',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _senderTypeCard(
    String label,
    String value,
    IconData icon,
    String sub,
    Color activeColor, {
    int? senderCount,
  }) {
    final bool isSel = _senderType == value;
    final bool isDisabled =
        value == 'public' && widget.role != 'owner' && widget.role != 'vip';
    final bool showCount = senderCount != null;

    return GestureDetector(
      onTap: isDisabled ? null : () => setState(() => _senderType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: isDisabled
              ? Colors.white.withOpacity(0.04)
              : isSel
                  ? activeColor.withOpacity(0.25)
                  : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDisabled
                ? Colors.white.withOpacity(0.08)
                : isSel
                    ? activeColor.withOpacity(0.7)
                    : Colors.white.withOpacity(0.15),
            width: isSel ? 1.5 : 1.2,
          ),
          boxShadow: isSel && !isDisabled
              ? [
                  BoxShadow(
                    color: activeColor.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isDisabled
                  ? GlassPalette.textDim
                  : GlassPalette.white,
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: GlassFont.pixel(
                size: 9,
                weight: FontWeight.w700,
                color: isDisabled
                    ? GlassPalette.textDim
                    : GlassPalette.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              isDisabled ? 'Owner / VIP' : sub,
              style: GlassFont.body(
                size: 10,
                weight: FontWeight.w400,
                color: isDisabled
                    ? GlassPalette.textDim
                    : GlassPalette.textDim,
              ),
              textAlign: TextAlign.center,
            ),
            if (showCount && !isDisabled) ...[
              const SizedBox(height: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: senderCount! > 0
                      ? GlassPalette.blue.withOpacity(0.4)
                      : Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: senderCount > 0
                        ? GlassPalette.blue.withOpacity(0.6)
                        : Colors.white.withOpacity(0.15),
                    width: 1,
                  ),
                ),
                child: Text(
                  senderCount > 0 ? '$senderCount aktif' : 'tidak ada',
                  style: GlassFont.pixel(
                    size: 7,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton({
    required VoidCallback onPressed,
    required String label,
  }) {
    return GlassButton(
      text: label,
      icon: Icons.rocket_launch_rounded,
      onTap: _isSending ? null : onPressed,
      bgColor: GlassPalette.blue,
      textColor: GlassPalette.white,
      padding: const EdgeInsets.symmetric(vertical: 18),
      fontSize: 12,
    );
  }
}

class _ProgressVideoDialog extends StatefulWidget {
  final VoidCallback? onVideoEnd;
  const _ProgressVideoDialog({this.onVideoEnd});
  @override
  State<_ProgressVideoDialog> createState() => _ProgressVideoDialogState();
}

class _ProgressVideoDialogState extends State<_ProgressVideoDialog> {
  VideoPlayerController? _ctrl;
  bool _ready = false;
  bool _endNotified = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final ctrl = VideoPlayerController.asset(_kProgressVideoAsset);
    _ctrl = ctrl;
    try {
      await ctrl.initialize();
      await ctrl.setLooping(false);
      await ctrl.setVolume(0);
      ctrl.addListener(_onVideoTick);
      await ctrl.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      if (mounted) setState(() => _ready = false);
      _notifyEnd();
    }
  }

  void _onVideoTick() {
    final ctrl = _ctrl;
    if (ctrl == null) return;
    if (!ctrl.value.isInitialized) return;

    if (ctrl.value.position >= ctrl.value.duration &&
        ctrl.value.duration.inMilliseconds > 0) {
      _notifyEnd();
    }
  }

  void _notifyEnd() {
    if (_endNotified) return;
    _endNotified = true;
    widget.onVideoEnd?.call();
  }

  @override
  void dispose() {
    _ctrl?.removeListener(_onVideoTick);
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.rocket_launch_rounded,
                      color: GlassPalette.white, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'MENGIRIM BUG...',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.2),
                    width: 1.2,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: _ready && _ctrl != null
                      ? FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _ctrl!.value.size.width,
                            height: _ctrl!.value.size.height,
                            child: VideoPlayer(_ctrl!),
                          ),
                        )
                      : const Center(
                          child: SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: GlassPalette.white,
                              strokeWidth: 2,
                            ),
                          ),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: GlassPalette.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Mohon tunggu, bug sedang dikirim...',
                      style: GlassFont.body(
                        size: 11,
                        weight: FontWeight.w500,
                        color: GlassPalette.textSub,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SuccessDialogCard extends StatelessWidget {
  final String message;
  final VoidCallback onClose;
  const _SuccessDialogCard({required this.message, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.7),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.teal.withOpacity(0.6),
                    blurRadius: 25,
                  ),
                ],
              ),
              child: const Icon(Icons.check_circle_rounded,
                  color: GlassPalette.white, size: 44),
            ),
            const SizedBox(height: 20),
            Text(
              'SUKSES!',
              style: GlassFont.pixel(
                size: 16,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Container(height: 1, color: Colors.white.withOpacity(0.15)),
            const SizedBox(height: 12),
            Text(
              message,
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w600,
                color: GlassPalette.textSub,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            GlassButton(
              text: 'CLOSE',
              icon: Icons.close_rounded,
              onTap: onClose,
              bgColor: GlassPalette.teal,
              textColor: GlassPalette.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              fontSize: 11,
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorDialogCard extends StatelessWidget {
  final String message;
  final VoidCallback onClose;
  const _ErrorDialogCard({required this.message, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: GlassPalette.red.withOpacity(0.25),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: GlassPalette.red.withOpacity(0.7),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.red.withOpacity(0.6),
                    blurRadius: 25,
                  ),
                ],
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: GlassPalette.white, size: 44),
            ),
            const SizedBox(height: 20),
            Text(
              'GAGAL!',
              style: GlassFont.pixel(
                size: 16,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Container(height: 1, color: Colors.white.withOpacity(0.15)),
            const SizedBox(height: 12),
            Text(
              message,
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w600,
                color: GlassPalette.textSub,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            GlassButton(
              text: 'CLOSE',
              icon: Icons.close_rounded,
              onTap: onClose,
              bgColor: GlassPalette.red,
              textColor: GlassPalette.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              fontSize: 11,
            ),
          ],
        ),
      ),
    );
  }
}