// change_password.dart
// ═══════════════════════════════════════════════════════════════════════════
// CHANGE PASSWORD — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("All fields are required");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("New password doesn't match confirmation");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$kBaseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password changed successfully", isSuccess: true);
      } else {
        _showMessage(data['message'] ?? "Failed to change password");
      }
    } catch (e) {
      _showMessage("Server error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    GlassDialog.show(
      context,
      title: isSuccess ? 'Success' : 'Info',
      message: msg,
      icon: isSuccess
          ? Icons.check_circle_rounded
          : Icons.info_outline_rounded,
      accentColor: isSuccess ? GlassPalette.teal : GlassPalette.blue,
    );
  }

  @override
  void dispose() {
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: GlassPalette.white, size: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'CHANGE PASSWORD',
                      style: GlassFont.pixel(
                        size: 11,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.5),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.lock_reset,
                            color: GlassPalette.white, size: 46),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'CHANGE PASSWORD',
                        style: GlassFont.pixel(
                          size: 12,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Update your account security',
                        style: GlassFont.body(
                          size: 11,
                          weight: FontWeight.w500,
                          color: GlassPalette.textSub,
                        ),
                      ),
                      const SizedBox(height: 30),
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 22,
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            GlassInput(
                              controller: oldPassCtrl,
                              hint: 'Old Password',
                              icon: Icons.lock_outline_rounded,
                              obscure: true,
                            ),
                            const SizedBox(height: 14),
                            GlassInput(
                              controller: newPassCtrl,
                              hint: 'New Password',
                              icon: Icons.lock_reset_rounded,
                              obscure: true,
                            ),
                            const SizedBox(height: 14),
                            GlassInput(
                              controller: confirmPassCtrl,
                              hint: 'Confirm Password',
                              icon: Icons.check_circle_outline_rounded,
                              obscure: true,
                            ),
                            const SizedBox(height: 22),
                            GlassButton(
                              text: isLoading
                                  ? 'LOADING...'
                                  : 'CHANGE PASSWORD',
                              icon: isLoading
                                  ? null
                                  : Icons.security_rounded,
                              isLoading: isLoading,
                              onTap: isLoading ? null : _changePassword,
                              bgColor: GlassPalette.blue,
                              textColor: GlassPalette.white,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16),
                              fontSize: 11,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}