// call_screen.dart
// ═══════════════════════════════════════════════════════════════════════════
// CALL SCREEN — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'call_service.dart';
import 'glass_theme.dart';

class CallScreen extends StatefulWidget {
  final CallService callService;
  final String peerUsername;
  final CallType callType;
  final bool isIncoming;

  const CallScreen({
    super.key,
    required this.callService,
    required this.peerUsername,
    required this.callType,
    required this.isIncoming,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  Timer? _uiTicker;

  @override
  void initState() {
    super.initState();

    WakelockPlus.enable();

    widget.callService.onStateChanged = (state) {
      if (mounted) setState(() {});
    };
    widget.callService.onDurationTick = (duration) {
      if (mounted) setState(() {});
    };
    widget.callService.onRemoteStream = (stream) {
      if (mounted) setState(() {});
    };
    widget.callService.onCallEnded = () {
      if (mounted) _handleCallEnded();
    };

    _uiTicker = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _uiTicker?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  Future<void> _handleCallEnded() async {
    if (!mounted) return;
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  String _formatDuration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final s = d.inSeconds % 60;
    if (h > 0) {
      return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  String _stateLabel(CallState state) {
    switch (state) {
      case CallState.idle:
        return 'Idle';
      case CallState.calling:
        return 'Memanggil...';
      case CallState.ringing:
        return 'Berdering...';
      case CallState.connecting:
        return 'Menghubungkan...';
      case CallState.connected:
        return _formatDuration(widget.callService.callDuration);
      case CallState.reconnecting:
        return 'Koneksi terputus...';
      case CallState.ended:
        return 'Panggilan berakhir';
      case CallState.failed:
        return 'Panggilan gagal';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.callType == CallType.video;
    final state = widget.callService.state;

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await _confirmEndCall();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Stack(
            children: [
              if (isVideo && state != CallState.ended)
                _buildVideoLayer()
              else
                _buildAudioLayer(),

              if (widget.callService.isScreenSharing)
                Positioned(
                  top: 20,
                  left: 20,
                  child: _glassChip(
                    icon: Icons.screen_share_rounded,
                    label: 'SHARE SCREEN',
                    color: GlassPalette.teal,
                  ),
                ),

              Positioned(
                top: 20,
                right: 20,
                child: _glassChip(
                  icon: isVideo
                      ? Icons.videocam_rounded
                      : Icons.phone_rounded,
                  label: isVideo ? 'VIDEO CALL' : 'AUDIO CALL',
                  color: GlassPalette.blue,
                ),
              ),

              if (isVideo && state != CallState.ended)
                Positioned(
                  top: 60,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: _glassChip(
                      icon: state == CallState.connected
                          ? Icons.timer_rounded
                          : Icons.phone_in_talk_rounded,
                      label: _stateLabel(state),
                      color: state == CallState.connected
                          ? GlassPalette.teal
                          : GlassPalette.blue,
                    ),
                  ),
                ),

              Positioned(
                bottom: 30,
                left: 0,
                right: 0,
                child: _buildControls(isVideo),
              ),

              if (state == CallState.ended || state == CallState.failed)
                _buildEndedOverlay(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _glassChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: color.withOpacity(0.25),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: color.withOpacity(0.6),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 15,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: GlassPalette.white, size: 16),
              const SizedBox(width: 6),
              Text(
                label,
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoLayer() {
    return Stack(
      children: [
        Positioned.fill(
          child: widget.callService.remoteStream != null
              ? RTCVideoView(
                  widget.callService.remoteRenderer,
                  objectFit:
                      RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  mirror: false,
                )
              : Container(
                  color: Colors.black,
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            color: GlassPalette.teal.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: GlassPalette.teal.withOpacity(0.7),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: GlassPalette.teal.withOpacity(0.6),
                                blurRadius: 30,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              widget.peerUsername.isNotEmpty
                                  ? widget.peerUsername[0].toUpperCase()
                                  : '?',
                              style: GlassFont.pixel(
                                size: 40,
                                weight: FontWeight.w900,
                                color: GlassPalette.white,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          widget.peerUsername,
                          style: GlassFont.pixel(
                            size: 14,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _stateLabel(widget.callService.state),
                          style: GlassFont.body(
                            size: 12,
                            weight: FontWeight.w500,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),

        Positioned(
          top: 100,
          right: 20,
          child: GestureDetector(
            onTap: () {},
            child: Container(
              width: 110,
              height: 160,
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: widget.callService.localStream != null
                    ? RTCVideoView(
                        widget.callService.localRenderer,
                        objectFit: RTCVideoViewObjectFit
                            .RTCVideoViewObjectFitCover,
                        mirror: widget.callService.isFrontCamera,
                      )
                    : Container(
                        color: Colors.grey[900],
                        child: const Center(
                          child: Icon(Icons.videocam_off_rounded,
                              color: Colors.white54, size: 32),
                        ),
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAudioLayer() {
    final state = widget.callService.state;

    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                color: GlassPalette.teal.withOpacity(0.25),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(
                  color: GlassPalette.teal.withOpacity(0.7),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.teal.withOpacity(0.6),
                    blurRadius: 40,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  widget.peerUsername.isNotEmpty
                      ? widget.peerUsername[0].toUpperCase()
                      : '?',
                  style: GlassFont.pixel(
                    size: 56,
                    weight: FontWeight.w900,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              widget.peerUsername,
              style: GlassFont.pixel(
                size: 18,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
            ),
            const SizedBox(height: 12),
            _glassChip(
              icon: state == CallState.connected
                  ? Icons.timer_rounded
                  : Icons.phone_in_talk_rounded,
              label: _stateLabel(state),
              color: state == CallState.connected
                  ? GlassPalette.teal
                  : GlassPalette.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControls(bool isVideo) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _controlBtn(
                icon: widget.callService.micEnabled
                    ? Icons.mic_rounded
                    : Icons.mic_off_rounded,
                label: widget.callService.micEnabled ? 'Mute' : 'Unmute',
                active: !widget.callService.micEnabled,
                onTap: () async {
                  await widget.callService.toggleMic();
                  setState(() {});
                },
              ),
              _controlBtn(
                icon: widget.callService.speakerOn
                    ? Icons.volume_up_rounded
                    : Icons.volume_down_rounded,
                label: 'Speaker',
                active: widget.callService.speakerOn,
                onTap: () async {
                  await widget.callService.toggleSpeaker();
                  setState(() {});
                },
              ),
              if (isVideo)
                _controlBtn(
                  icon: widget.callService.cameraEnabled
                      ? Icons.videocam_rounded
                      : Icons.videocam_off_rounded,
                  label: 'Camera',
                  active: !widget.callService.cameraEnabled,
                  onTap: () async {
                    await widget.callService.toggleCamera();
                    setState(() {});
                  },
                ),
              if (isVideo)
                _controlBtn(
                  icon: Icons.flip_camera_android_rounded,
                  label: 'Flip',
                  active: false,
                  onTap: () async {
                    await widget.callService.switchCamera();
                    setState(() {});
                  },
                ),
            ],
          ),

          const SizedBox(height: 16),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _controlBtn(
                icon: widget.callService.isScreenSharing
                    ? Icons.stop_screen_share_rounded
                    : Icons.screen_share_rounded,
                label: widget.callService.isScreenSharing
                    ? 'Stop Share'
                    : 'Share',
                active: widget.callService.isScreenSharing,
                onTap: () async {
                  if (widget.callService.isScreenSharing) {
                    await widget.callService.stopScreenShare();
                  } else {
                    await widget.callService.startScreenShare();
                  }
                  setState(() {});
                },
              ),
              _endCallBtn(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _controlBtn({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: active
                      ? GlassPalette.blue.withOpacity(0.4)
                      : Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: active
                        ? GlassPalette.blue.withOpacity(0.7)
                        : Colors.white.withOpacity(0.25),
                    width: 1.2,
                  ),
                  boxShadow: active
                      ? [
                          BoxShadow(
                            color: GlassPalette.blue.withOpacity(0.5),
                            blurRadius: 15,
                          ),
                        ]
                      : null,
                ),
                child: Icon(
                  icon,
                  color: GlassPalette.white,
                  size: 24,
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: GlassFont.pixel(
              size: 8,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _endCallBtn() {
    return GestureDetector(
      onTap: _confirmEndCall,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  GlassPalette.red.withOpacity(0.85),
                  GlassPalette.redHot.withOpacity(0.75),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.red.withOpacity(0.6),
                  blurRadius: 20,
                ),
              ],
            ),
            child: const Icon(
              Icons.call_end_rounded,
              color: GlassPalette.white,
              size: 32,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'END CALL',
            style: GlassFont.pixel(
              size: 8,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmEndCall() async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.5,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: GlassPalette.red.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: GlassPalette.red.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.call_end_rounded,
                        color: GlassPalette.white, size: 32),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'AKHIRI PANGGILAN?',
                    style: GlassFont.pixel(
                      size: 11,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: GlassButton(
                          text: 'BATAL',
                          onTap: () => Navigator.pop(context, false),
                          bgColor: Colors.white,
                          textColor: GlassPalette.white,
                          padding:
                              const EdgeInsets.symmetric(vertical: 12),
                          fontSize: 9,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GlassButton(
                          text: 'AKHIRI',
                          onTap: () => Navigator.pop(context, true),
                          bgColor: GlassPalette.red,
                          textColor: GlassPalette.white,
                          padding:
                              const EdgeInsets.symmetric(vertical: 12),
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    if (result == true) {
      await widget.callService.endCall();
    }
  }

  Widget _buildEndedOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.9),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.25),
                        width: 1.5,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          widget.callService.state == CallState.failed
                              ? Icons.error_rounded
                              : Icons.call_end_rounded,
                          color: widget.callService.state == CallState.failed
                              ? GlassPalette.red
                              : GlassPalette.white,
                          size: 56,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          widget.callService.state == CallState.failed
                              ? 'PANGGILAN GAGAL'
                              : 'PANGGILAN BERAKHIR',
                          style: GlassFont.pixel(
                            size: 12,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Durasi: ${_formatDuration(widget.callService.callDuration)}',
                          style: GlassFont.body(
                            size: 12,
                            weight: FontWeight.w500,
                            color: GlassPalette.textSub,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}