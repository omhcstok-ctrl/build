// seller_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// SELLER PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();
  bool loading = false;

  Future<void> _create() async {
    final u = _newUser.text.trim();
    final p = _newPass.text.trim();
    final d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      return _alert("Semua field wajib diisi");
    }
    setState(() => loading = true);
    final res = await http.get(Uri.parse(
        "$kBaseUrl/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
    final data = jsonDecode(res.body);
    if (data['created'] == true) {
      _alert("Akun berhasil dibuat!");
      _newUser.clear();
      _newPass.clear();
      _days.clear();
    } else {
      _alert("${data['message'] ?? 'Gagal membuat akun.'}");
    }
    setState(() => loading = false);
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim();
    final d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) return _alert("Username dan durasi wajib diisi");
    setState(() => loading = true);
    final res = await http.get(Uri.parse(
        "$kBaseUrl/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
    final data = jsonDecode(res.body);
    if (data['edited'] == true) {
      _alert("Durasi berhasil diperbarui.");
      _editUser.clear();
      _editDays.clear();
    } else {
      _alert("${data['message'] ?? 'Gagal mengubah durasi.'}");
    }
    setState(() => loading = false);
  }

  void _alert(String msg) {
    GlassDialog.show(
      context,
      title: 'Info',
      message: msg,
      icon: Icons.info_outline_rounded,
      accentColor: GlassPalette.yellow,
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: GlassPalette.blue.withOpacity(0.25),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: GlassPalette.blue.withOpacity(0.6),
              width: 1.2,
            ),
          ),
          child: Icon(icon, color: GlassPalette.white, size: 14),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: GlassFont.pixel(
            size: 9,
            weight: FontWeight.w700,
            color: GlassPalette.text,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // BUAT AKUN BARU
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _sectionTitle("Buat Akun Baru", Icons.person_add),
                            const SizedBox(height: 16),
                            GlassInput(
                              controller: _newUser,
                              hint: "Username",
                              icon: Icons.person_outline,
                            ),
                            const SizedBox(height: 12),
                            GlassInput(
                              controller: _newPass,
                              hint: "Password",
                              icon: Icons.lock_outline,
                              obscure: true,
                            ),
                            const SizedBox(height: 12),
                            GlassInput(
                              controller: _days,
                              hint: "Durasi (hari)",
                              icon: Icons.calendar_today,
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 16),
                            GlassButton(
                              text: loading ? 'LOADING...' : 'BUAT AKUN',
                              icon: loading ? null : Icons.person_add,
                              isLoading: loading,
                              onTap: loading ? null : _create,
                              bgColor: GlassPalette.teal,
                              textColor: GlassPalette.white,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              fontSize: 10,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // UBAH DURASI
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _sectionTitle("Ubah Durasi", Icons.edit_calendar),
                            const SizedBox(height: 16),
                            GlassInput(
                              controller: _editUser,
                              hint: "Username",
                              icon: Icons.person_outline,
                            ),
                            const SizedBox(height: 12),
                            GlassInput(
                              controller: _editDays,
                              hint: "Tambah Durasi (hari)",
                              icon: Icons.calendar_today,
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 16),
                            GlassButton(
                              text: loading ? 'LOADING...' : 'UBAH DURASI',
                              icon: loading ? null : Icons.edit,
                              isLoading: loading,
                              onTap: loading ? null : _edit,
                              bgColor: GlassPalette.yellow,
                              textColor: GlassPalette.black,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              fontSize: 10,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // INFO
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            const Icon(Icons.info,
                                color: GlassPalette.white, size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                "Gunakan panel ini untuk mengelola akun reseller Anda",
                                style: GlassFont.body(
                                  size: 11,
                                  weight: FontWeight.w600,
                                  color: GlassPalette.textSub,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'RESELLER PANEL',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}