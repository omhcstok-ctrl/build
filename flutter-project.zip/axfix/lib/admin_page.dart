// admin_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// ADMIN PAGE — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

const List<String> ALL_ROLES = [
  'member', 'vip', 'reseller', 'partner',
  'moderator', 'owner', 'highowner', 'dev',
];

final Map<String, List<String>> CAN_CREATE = {
  'dev': ['member', 'vip', 'reseller', 'partner', 'moderator', 'owner', 'highowner'],
  'highowner': ['member', 'vip', 'reseller', 'partner', 'moderator', 'owner'],
  'owner': ['member', 'vip', 'reseller', 'partner', 'moderator'],
  'moderator': ['member', 'vip', 'reseller', 'partner'],
  'partner': ['member', 'vip', 'reseller'],
  'reseller': ['member', 'vip'],
  'vip': [],
  'member': [],
};

final Map<String, List<String>> CAN_DELETE = {
  'dev': ['member', 'vip', 'reseller', 'partner', 'moderator', 'owner'],
  'highowner': ['member', 'vip', 'reseller', 'partner', 'moderator', 'owner'],
  'owner': ['member', 'vip', 'reseller', 'partner', 'moderator'],
  'moderator': ['member', 'vip', 'reseller', 'partner'],
  'partner': ['member', 'vip', 'reseller'],
  'reseller': ['member'],
  'vip': [],
  'member': [],
};

class AdminPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const AdminPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage>
    with SingleTickerProviderStateMixin {
  late String sessionKey;
  String role = 'member';

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  String selectedRoleFilter = 'member';

  int currentPage = 1;
  int itemsPerPage = 10;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';

  bool isLoading = false;

  late AnimationController _animController;
  late Animation<double> _fadeAnimation;

  List<String> get _allowedCreateRoles => CAN_CREATE[role.toLowerCase()] ?? [];
  List<String> get _allowedDeleteRoles => CAN_DELETE[role.toLowerCase()] ?? [];
  bool get _canCreateAnything => _allowedCreateRoles.isNotEmpty;
  bool get _canDeleteAnything => _allowedDeleteRoles.isNotEmpty;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    role = widget.role;

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnimation =
        CurvedAnimation(parent: _animController, curve: Curves.easeOut);

    if (_allowedCreateRoles.isNotEmpty) {
      newUserRole = _allowedCreateRoles.first;
    }
    if (_allowedDeleteRoles.isNotEmpty) {
      selectedRoleFilter = _allowedDeleteRoles.first;
    } else {
      selectedRoleFilter = role;
    }

    _fetchUsers();
  }

  @override
  void dispose() {
    _animController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/listUsers?key=$sessionKey'),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['authorized'] == true) {
          setState(() {
            fullUserList = data['users'] ?? [];
            _filterAndPaginate();
          });
        } else {
          _showSnack("Error: ${data['message'] ?? 'Akses ditolak.'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Gagal memuat data user: $e");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRoleFilter).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (start >= filteredList.length) return [];
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages =>
      filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _showSnack("Masukkan username!");
      return;
    }

    final target = fullUserList.firstWhere(
      (u) =>
          (u['username'] ?? '').toString().toLowerCase() ==
          username.toLowerCase(),
      orElse: () => null,
    );
    if (target == null) {
      _showSnack("User '$username' tidak ditemukan.");
      return;
    }

    final targetRole = (target['role'] ?? 'member').toString().toLowerCase();
    if (!_allowedDeleteRoles.contains(targetRole)) {
      _showSnack("Kamu tidak bisa menghapus user role '$targetRole'.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$kBaseUrl/deleteUser?key=$sessionKey&username=$username'),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['deleted'] == true) {
          _showSnack("User '$username' dihapus!", isSuccess: true);
          deleteController.clear();
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    if (!_canCreateAnything) {
      _showSnack("Role kamu tidak bisa membuat akun.");
      return;
    }

    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showSnack("Semua field wajib diisi!");
      return;
    }

    if (int.tryParse(day) == null) {
      _showSnack("Days harus berupa angka!");
      return;
    }

    if (!_allowedCreateRoles.contains(newUserRole)) {
      _showSnack("Kamu tidak bisa membuat role '$newUserRole'.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$kBaseUrl/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole',
      );
      final res = await http.get(url);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data['created'] == true) {
          _showSnack(
              "Akun '$username' (role: $newUserRole) berhasil dibuat!",
              isSuccess: true);
          createUsernameController.clear();
          createPasswordController.clear();
          createDayController.clear();
          newUserRole = _allowedCreateRoles.first;
          _fetchUsers();
        } else {
          _showSnack("Gagal: ${data['message'] ?? 'Unknown error'}");
        }
      } else {
        _showSnack("Server error: ${res.statusCode}");
      }
    } catch (e) {
      _showSnack("Error koneksi: $e");
    }
    setState(() => isLoading = false);
  }

  void _showSnack(String msg, {bool isSuccess = false}) {
    if (!mounted) return;
    GlassDialog.show(
      context,
      title: isSuccess ? 'Sukses' : 'Info',
      message: msg,
      icon: isSuccess
          ? Icons.check_circle_outline_rounded
          : Icons.info_outline_rounded,
      accentColor: isSuccess ? GlassPalette.teal : GlassPalette.blue,
    );
  }

  Color _roleColor(String r) {
    switch (r) {
      case 'dev':
        return GlassPalette.red;
      case 'highowner':
        return GlassPalette.orange;
      case 'owner':
        return GlassPalette.blue;
      case 'moderator':
        return GlassPalette.teal;
      case 'partner':
        return GlassPalette.orange;
      case 'reseller':
        return GlassPalette.purple;
      case 'vip':
        return GlassPalette.red;
      default:
        return GlassPalette.textSub;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          GlassBg(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 20),

                      if (_canCreateAnything) ...[
                        GlassSectionTitle(
                          icon: Icons.person_add_alt_1,
                          title: 'Create New User',
                          color: GlassPalette.teal,
                        ),
                        const SizedBox(height: 10),
                        _buildCreateUserCard(),
                        const SizedBox(height: 24),
                      ] else ...[
                        _buildInfoBanner(
                            "Role kamu tidak bisa membuat akun",
                            Icons.block_rounded,
                            GlassPalette.red),
                        const SizedBox(height: 24),
                      ],

                      if (_canDeleteAnything) ...[
                        GlassSectionTitle(
                          icon: Icons.delete_forever_rounded,
                          title: 'Delete User',
                          color: GlassPalette.red,
                        ),
                        const SizedBox(height: 10),
                        _buildDeleteUserCard(),
                        const SizedBox(height: 24),
                      ] else ...[
                        _buildInfoBanner(
                            "Role kamu tidak bisa menghapus akun",
                            Icons.block_rounded,
                            GlassPalette.red),
                        const SizedBox(height: 24),
                      ],

                      GlassSectionTitle(
                        icon: Icons.storage_rounded,
                        title: 'Database Users',
                        color: GlassPalette.blue,
                      ),
                      const SizedBox(height: 10),
                      _buildUserListSection(),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (isLoading)
            Container(
              color: Colors.black54,
              child: const Center(
                child: CircularProgressIndicator(color: GlassPalette.white),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 22,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.blue.withOpacity(0.5),
                  blurRadius: 15,
                ),
              ],
            ),
            child: const Icon(Icons.admin_panel_settings_rounded,
                color: GlassPalette.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "ADMIN PANEL",
                  style: GlassFont.pixel(
                    size: 12,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _roleColor(role).withOpacity(0.3),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _roleColor(role).withOpacity(0.7),
                          width: 1.2,
                        ),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: GlassFont.pixel(
                          size: 7,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _canCreateAnything || _canDeleteAnything
                            ? "Manage Access & Users"
                            : "View Only Mode",
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w500,
                          color: GlassPalette.textDim,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBanner(String msg, IconData icon, Color color) {
    return GlassCard(
      borderWidth: 1.5,
      radius: 18,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              msg,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w700,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateUserCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 22,
      padding: const EdgeInsets.all(18),
      child: Column(
        children: [
          GlassInput(
            controller: createUsernameController,
            hint: 'Username',
            icon: Icons.person_outline_rounded,
          ),
          const SizedBox(height: 14),
          GlassInput(
            controller: createPasswordController,
            hint: 'Password',
            icon: Icons.lock_outline_rounded,
            obscure: true,
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: GlassInput(
                  controller: createDayController,
                  hint: 'Days',
                  icon: Icons.calendar_today_rounded,
                  keyboardType: TextInputType.number,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: _buildDropdown(
                  newUserRole,
                  (val) => setState(() => newUserRole = val!),
                  _allowedCreateRoles,
                  labelPrefix: "Role: ",
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          GlassButton(
            text: 'CREATE USER',
            icon: Icons.add_circle_outline_rounded,
            onTap: _createAccount,
            bgColor: GlassPalette.teal,
            textColor: GlassPalette.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            fontSize: 11,
          ),
        ],
      ),
    );
  }

  Widget _buildDeleteUserCard() {
    return GlassCard(
      borderWidth: 1.5,
      radius: 22,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.red.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.red.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: GlassPalette.white, size: 14),
              ),
              const SizedBox(width: 10),
              Text(
                "DANGER ZONE",
                style: GlassFont.pixel(
                  size: 9,
                  weight: FontWeight.w700,
                  color: GlassPalette.red,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: GlassInput(
                  controller: deleteController,
                  hint: "Username to Delete",
                  icon: Icons.delete_outline_rounded,
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _deleteUser,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: GlassPalette.red.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.7),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.red.withOpacity(0.5),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.delete_forever_rounded,
                      color: GlassPalette.white, size: 22),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUserListSection() {
    return Column(
      children: [
        GlassCard(
          borderWidth: 1.5,
          radius: 16,
          padding: EdgeInsets.zero,
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: GlassPalette.bg,
              value: selectedRoleFilter,
              isExpanded: true,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              icon: const Icon(Icons.filter_list, color: GlassPalette.white),
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
              items:
                  (_allowedDeleteRoles.isNotEmpty ? _allowedDeleteRoles : ALL_ROLES)
                      .map((r) {
                return DropdownMenuItem(
                  value: r,
                  child: Text(
                    "Filter: ${r.toUpperCase()}",
                    style: GlassFont.body(
                      size: 12,
                      weight: FontWeight.w700,
                      color: GlassPalette.text,
                    ),
                  ),
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedRoleFilter = val!;
                  _filterAndPaginate();
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 14),
        if (filteredList.isEmpty)
          GlassCard(
            borderWidth: 1.5,
            radius: 18,
            padding: const EdgeInsets.all(30),
            child: Column(
              children: [
                const Icon(Icons.person_off_rounded,
                    color: GlassPalette.textDim, size: 40),
                const SizedBox(height: 10),
                Text(
                  "Tidak ada user role '$selectedRoleFilter'",
                  style: GlassFont.body(
                    size: 12,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
              ],
            ),
          )
        else
          ..._getCurrentPageData().map((u) => _buildUserItem(u)),
        const SizedBox(height: 16),
        if (totalPages > 1) _buildPagination(),
      ],
    );
  }

  Widget _buildUserItem(Map user) {
    final userRole = (user['role'] ?? 'member').toString().toLowerCase();
    final canDelete = _allowedDeleteRoles.contains(userRole);

    return GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      borderWidth: 1.5,
      radius: 16,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _roleColor(userRole).withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _roleColor(userRole).withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.person_rounded,
                color: GlassPalette.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username']?.toString() ?? 'Unknown',
                  style: GlassFont.pixel(
                    size: 10,
                    weight: FontWeight.w700,
                    color: GlassPalette.text,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    GlassBadge(
                      text: userRole.toUpperCase(),
                      bgColor: _roleColor(userRole),
                      textColor: GlassPalette.white,
                    ),
                    const SizedBox(width: 6),
                    Flexible(
                      child: GlassBadge(
                        text:
                            "Exp: ${user['expiredDate']?.toString() ?? 'N/A'}",
                        bgColor: Colors.white.withOpacity(0.1),
                        textColor: GlassPalette.textSub,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (canDelete)
            GestureDetector(
              onTap: () {
                deleteController.text = user['username']?.toString() ?? '';
                _showSnack(
                    "Username diisi. Klik tombol hapus di Danger Zone.");
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: GlassPalette.red.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.red.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: const Icon(Icons.delete_outline_rounded,
                    color: GlassPalette.white, size: 16),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: isActive
                    ? GlassPalette.blue.withOpacity(0.6)
                    : Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isActive
                      ? GlassPalette.blue
                      : Colors.white.withOpacity(0.2),
                  width: 1.2,
                ),
              ),
              child: Center(
                child: Text(
                  "$page",
                  style: GlassFont.pixel(
                    size: 9,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildDropdown(
    String val,
    Function(String?) onChanged,
    List<String> options, {
    String labelPrefix = "",
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1.2,
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          dropdownColor: GlassPalette.bg,
          value: val,
          isExpanded: true,
          icon: const Icon(Icons.arrow_drop_down, color: GlassPalette.white),
          style: GlassFont.body(
            size: 12,
            weight: FontWeight.w700,
            color: GlassPalette.text,
          ),
          items: options.map((r) {
            return DropdownMenuItem(
              value: r,
              child: Text(
                "$labelPrefix${r.toUpperCase()}",
                style: GlassFont.body(
                  size: 12,
                  weight: FontWeight.w700,
                  color: GlassPalette.text,
                ),
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}