// musik_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// MUSIK PAGE (Smoty Play) — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'glass_theme.dart';

class MusikPage extends StatefulWidget {
  final AudioPlayer? sharedPlayer;
  final int? initialTrack;
  const MusikPage({super.key, this.sharedPlayer, this.initialTrack});
  @override
  State<MusikPage> createState() => _MusikPageState();
}

class _MusikPageState extends State<MusikPage>
    with SingleTickerProviderStateMixin {
  late AudioPlayer _player;
  final _searchCtrl = TextEditingController();

  bool _playing = false;
  bool _shuffle = false;
  bool _repeat = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;

  List<Map<String, dynamic>> _results = [];
  bool _searching = false;
  String _errMsg = '';

  Map<String, dynamic>? _nowPlaying;

  @override
  void initState() {
    super.initState();
    _player = widget.sharedPlayer ?? AudioPlayer();
    _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playing = s == PlayerState.playing);
    });
    _player.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _dur = d);
    });
    _player.onPlayerComplete.listen((_) => _nextTrack());
    _search('top hits 2024');
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    if (widget.sharedPlayer == null) _player.dispose();
    super.dispose();
  }

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) return;
    setState(() {
      _searching = true;
      _errMsg = '';
    });
    try {
      final url = Uri.parse(
          'https://itunes.apple.com/search?term=${Uri.encodeComponent(query)}&media=music&limit=25&entity=song');
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final list = (data['results'] as List).map((t) => {
            'title': t['trackName'] ?? '',
            'artist': t['artistName'] ?? '',
            'album': t['collectionName'] ?? '',
            'img': t['artworkUrl100'] ?? '',
            'preview': t['previewUrl'] ?? '',
            'itunesUrl': t['trackViewUrl'] ?? '',
          }).where((t) => (t['preview'] as String).isNotEmpty).toList();
      setState(() {
        _results = list;
        _searching = false;
      });
    } catch (e) {
      setState(() {
        _errMsg = 'Gagal cari: $e';
        _searching = false;
      });
    }
  }

  Future<void> _play(Map<String, dynamic> track) async {
    final url = track['preview'] as String;
    if (url.isEmpty) {
      _snack('Preview tidak tersedia');
      return;
    }
    setState(() {
      _nowPlaying = track;
      _pos = Duration.zero;
    });
    await _player.stop();
    await _player.play(UrlSource(url));
  }

  void _togglePlay() {
    if (_playing) {
      _player.pause();
    } else if (_nowPlaying != null) {
      _player.resume();
    }
  }

  void _nextTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx =
        _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    int next;
    if (_shuffle) {
      do {
        next = Random().nextInt(_results.length);
      } while (next == idx && _results.length > 1);
    } else if (_repeat) {
      next = idx;
    } else {
      next = (idx + 1) % _results.length;
    }
    _play(_results[next]);
  }

  void _prevTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx =
        _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    _play(_results[(idx - 1 + _results.length) % _results.length]);
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: GlassFont.body(size: 12, color: GlassPalette.white)),
      backgroundColor: GlassPalette.red.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.music_note_rounded,
                        color: GlassPalette.white, size: 20),
                    const SizedBox(width: 10),
                    Text('Smoty Play',
                        style: GlassFont.pixel(
                            size: 13,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                            letterSpacing: 1.5)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: GlassPalette.blue.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: GlassPalette.blue.withOpacity(0.6),
                          width: 1.2,
                        ),
                      ),
                      child: Text('30s Preview',
                          style: GlassFont.body(
                              size: 10,
                              weight: FontWeight.w500,
                              color: GlassPalette.white)),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                            width: 1.2,
                          ),
                        ),
                        child: TextField(
                          controller: _searchCtrl,
                          onSubmitted: (v) => _search(v),
                          style: GlassFont.body(
                              size: 13,
                              weight: FontWeight.w500,
                              color: GlassPalette.white),
                          cursorColor: GlassPalette.white,
                          decoration: InputDecoration(
                            hintText: 'Cari lagu, artis, album...',
                            hintStyle: GlassFont.body(
                                size: 12,
                                weight: FontWeight.w400,
                                color: GlassPalette.textDim),
                            prefixIcon: const Icon(Icons.search_rounded,
                                color: GlassPalette.white, size: 18),
                            border: InputBorder.none,
                            contentPadding:
                                const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () => _search(_searchCtrl.text),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                        ),
                        child: const Icon(Icons.search_rounded,
                            color: GlassPalette.white, size: 18),
                      ),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
                child: SizedBox(
                  height: 28,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      'Top Hits',
                      'Lo-Fi',
                      'Pop',
                      'Hip-Hop',
                      'R&B',
                      'Electronic',
                      'Acoustic',
                      'K-Pop',
                      'Indonesia',
                    ]
                        .map((g) => GestureDetector(
                              onTap: () {
                                _searchCtrl.text = g;
                                _search(g);
                              },
                              child: Container(
                                margin: const EdgeInsets.only(right: 6),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.15),
                                    width: 1.2,
                                  ),
                                ),
                                child: Text(g,
                                    style: GlassFont.body(
                                        size: 11,
                                        weight: FontWeight.w500,
                                        color: GlassPalette.textSub)),
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ),

              if (_nowPlaying != null) _buildNowPlaying(),

              Expanded(
                child: _searching
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: GlassPalette.white))
                    : _errMsg.isNotEmpty
                        ? Center(
                            child: Text(_errMsg,
                                style: GlassFont.body(
                                    size: 12,
                                    weight: FontWeight.w500,
                                    color: GlassPalette.textSub)))
                        : _results.isEmpty
                            ? Center(
                                child: Text('Cari lagu favoritmu',
                                    style: GlassFont.body(
                                        size: 12,
                                        weight: FontWeight.w500,
                                        color: GlassPalette.textSub)))
                            : ListView.builder(
                                padding: const EdgeInsets.fromLTRB(
                                    14, 8, 14, 100),
                                itemCount: _results.length,
                                itemBuilder: (_, i) {
                                  final t = _results[i];
                                  final isPlaying = _nowPlaying != null &&
                                      _nowPlaying!['title'] == t['title'] &&
                                      _playing;
                                  return GestureDetector(
                                    onTap: () => _play(t),
                                    child: Container(
                                      margin:
                                          const EdgeInsets.only(bottom: 8),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 10),
                                      decoration: BoxDecoration(
                                        color: isPlaying
                                            ? GlassPalette.blue
                                                .withOpacity(0.2)
                                            : Colors.white
                                                .withOpacity(0.06),
                                        borderRadius:
                                            BorderRadius.circular(14),
                                        border: Border.all(
                                          color: isPlaying
                                              ? GlassPalette.blue
                                                  .withOpacity(0.6)
                                              : Colors.white
                                                  .withOpacity(0.15),
                                          width: 1.2,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: t['img'] != ''
                                                ? Image.network(
                                                    t['img'] as String,
                                                    width: 46,
                                                    height: 46,
                                                    fit: BoxFit.cover,
                                                    errorBuilder:
                                                        (_, __, ___) =>
                                                            Container(
                                                      width: 46,
                                                      height: 46,
                                                      color: Colors.white
                                                          .withOpacity(0.1),
                                                      child: const Icon(
                                                          Icons
                                                              .music_note_rounded,
                                                          color: GlassPalette
                                                              .textDim,
                                                          size: 20),
                                                    ),
                                                  )
                                                : Container(
                                                    width: 46,
                                                    height: 46,
                                                    color: Colors.white
                                                        .withOpacity(0.1),
                                                    child: const Icon(
                                                        Icons
                                                            .music_note_rounded,
                                                        color: GlassPalette
                                                            .textDim,
                                                        size: 20),
                                                  ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  t['title'] as String,
                                                  style: GlassFont.body(
                                                      size: 13,
                                                      weight: FontWeight.w700,
                                                      color: GlassPalette
                                                          .white),
                                                  maxLines: 1,
                                                  overflow: TextOverflow
                                                      .ellipsis,
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  t['artist'] as String,
                                                  style: GlassFont.body(
                                                      size: 11,
                                                      weight: FontWeight.w400,
                                                      color: GlassPalette
                                                          .textSub),
                                                  maxLines: 1,
                                                  overflow: TextOverflow
                                                      .ellipsis,
                                                ),
                                              ],
                                            ),
                                          ),
                                          if (isPlaying)
                                            const Icon(
                                                Icons.graphic_eq_rounded,
                                                color: GlassPalette.white,
                                                size: 20)
                                          else
                                            const Icon(
                                                Icons
                                                    .play_circle_outline_rounded,
                                                color: GlassPalette.textDim,
                                                size: 20),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNowPlaying() {
    final t = _nowPlaying!;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: GlassPalette.blue.withOpacity(0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: GlassPalette.blue.withOpacity(0.4),
            blurRadius: 20,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: t['img'] != ''
                    ? Image.network(t['img'] as String,
                        width: 52,
                        height: 52,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                              width: 52,
                              height: 52,
                              color: Colors.white.withOpacity(0.1),
                              child: const Icon(Icons.music_note_rounded,
                                  color: GlassPalette.textDim),
                            ))
                    : Container(
                        width: 52,
                        height: 52,
                        color: Colors.white.withOpacity(0.1),
                        child: const Icon(Icons.music_note_rounded,
                            color: GlassPalette.textDim),
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t['title'] as String,
                        style: GlassFont.body(
                            size: 13,
                            weight: FontWeight.w700,
                            color: GlassPalette.white),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    Text(t['artist'] as String,
                        style: GlassFont.body(
                            size: 11,
                            weight: FontWeight.w400,
                            color: GlassPalette.textSub),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _shuffle = !_shuffle),
                    child: Icon(Icons.shuffle_rounded,
                        color: _shuffle
                            ? GlassPalette.teal
                            : GlassPalette.textDim,
                        size: 18),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _prevTrack,
                    child: const Icon(Icons.skip_previous_rounded,
                        color: GlassPalette.white, size: 22),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: _togglePlay,
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: GlassPalette.teal.withOpacity(0.3),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: GlassPalette.teal.withOpacity(0.7),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: GlassPalette.teal.withOpacity(0.5),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Icon(
                        _playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        color: GlassPalette.white,
                        size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: _nextTrack,
                    child: const Icon(Icons.skip_next_rounded,
                        color: GlassPalette.white, size: 22),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => setState(() => _repeat = !_repeat),
                    child: Icon(Icons.repeat_rounded,
                        color: _repeat
                            ? GlassPalette.teal
                            : GlassPalette.textDim,
                        size: 18),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: GlassPalette.teal,
              inactiveTrackColor: Colors.white.withOpacity(0.15),
              thumbColor: GlassPalette.white,
              thumbShape:
                  const RoundSliderThumbShape(enabledThumbRadius: 5),
              overlayShape: SliderComponentShape.noThumb,
              trackHeight: 2,
            ),
            child: Slider(
              value: _dur.inSeconds > 0
                  ? (_pos.inSeconds / _dur.inSeconds).clamp(0.0, 1.0)
                  : 0.0,
              onChanged: (v) {
                if (_dur.inSeconds > 0) {
                  _player.seek(
                      Duration(seconds: (v * _dur.inSeconds).toInt()));
                }
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_fmt(_pos),
                  style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w500,
                      color: GlassPalette.textDim)),
              Text(_fmt(_dur),
                  style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w500,
                      color: GlassPalette.textDim)),
            ],
          ),
        ],
      ),
    );
  }
}