// dashboard_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// DASHBOARD PAGE — GLASSMORPHISM + LIQUID NAV + BG IMAGE + ORBIT QUICK CARDS
// + FIX: Auto-fetch setelah WS ready & card jadwal sholat live
// + FIX: Orbit card berputar mengelilingi pusat (seperti planet)
// + FIX: Statistik (online, sesi, expired, jadwal sholat) langsung muncul saat masuk
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'app_config.dart';
import 'dracin_page.dart';
import 'change_password.dart';
import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'control_panel.dart';
import 'device_permission.dart';
import 'device_dashboard.dart';
import 'musik_page.dart';
import 'ai_chat_page.dart';
import 'alight_motion_page.dart';
import 'band_group_page.dart';
import 'status_page.dart';
import 'status_viewer.dart';
import 'chat_page.dart';
import 'quick_menu_data.dart';
import 'menu_hub_page.dart';
import 'toko_page.dart';
import 'jadwal_sholat_page.dart';
import 'glass_theme.dart';

// ═══════════════════════════════════════════════════════════════════════════
// GLOBAL PALETTE ALIAS
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg         = GlassPalette.bg;
  static const surface    = GlassPalette.surface;
  static const card       = GlassPalette.surface;
  static const cardAlt    = GlassPalette.surfaceAlt;
  static const border     = GlassPalette.border;
  static const borderLit  = GlassPalette.borderLit;
  static const red        = GlassPalette.red;
  static const redMid     = GlassPalette.red;
  static const redLight   = GlassPalette.redHot;
  static const redFrost   = GlassPalette.redHot;
  static const green      = GlassPalette.green;
  static const greenDim   = GlassPalette.green;
  static const amber      = GlassPalette.amber;
  static const blue       = GlassPalette.blue;
  static const purple     = GlassPalette.purple;
  static const cyan       = GlassPalette.cyan;
  static const orange     = GlassPalette.orange;
  static const text       = GlassPalette.text;
  static const textSub    = GlassPalette.textSub;
  static const textDim    = GlassPalette.textDim;
  static const white      = GlassPalette.white;

  static const LinearGradient btnGrad = LinearGradient(
    colors: [GlassPalette.blue, GlassPalette.purple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class AppColors {
  static Color get bg => _C.bg;
  static Color get surface => _C.surface;
  static Color get surface2 => _C.cardAlt;
  static Color get border => _C.border;
  static Color get borderLight => _C.borderLit;
  static Color get accent => _C.blue;
  static Color get textPrimary => _C.text;
  static Color get textSec => _C.textSub;
  static Color get textSecondary => _C.textSub;
  static Color get textMuted => _C.textDim;
  static Color get white => _C.text;
  static Color get dimWhite => _C.textSub;
  static Color get highlight => _C.blue;
  static Color get fabBg => _C.cardAlt;
  static Color get neon => _C.blue;
  static Color get green => _C.green;
  static Color get red => _C.redMid;
  static Color get orange => _C.orange;
  static Color get purple => _C.purple;
  static Color get blue => _C.blue;
  static Color get cyan => _C.cyan;
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer':
    case 'dev':
      return const Color(0xFF16A34A);
    case 'owner':
    case 'highowner':
      return const Color(0xFFFFC107);
    case 'moderator':
      return const Color(0xFF16A34A);
    case 'partner':
      return const Color(0xFF9C27FF);
    case 'admin':
      return _C.redMid;
    case 'reseller':
      return _C.green;
    case 'vip':
      return const Color(0xFF9C27FF);
    default:
      return _C.redMid;
  }
}

const String kProfileCardImageUrl = 'https://files.catbox.moe/zpba9i.png';
const String kDashboardBgAsset = 'assets/images/bg_glass.jpg';
const String kProfileCardBgAsset = 'assets/images/profile_card_bg.jpg';

final GlobalKey<DashboardPageState> dashboardNavKey =
    GlobalKey<DashboardPageState>();

// ═══════════════════════════════════════════════════════════════════════════
// 🌍 ORBIT CARD WRAPPER (ring berputar di sekeliling card)
// ═══════════════════════════════════════════════════════════════════════════
class _OrbitCardWrapper extends StatefulWidget {
  final Widget child;
  final Color accent;
  final Duration duration;

  const _OrbitCardWrapper({
    required this.child,
    required this.accent,
    this.duration = const Duration(seconds: 8),
  });

  @override
  State<_OrbitCardWrapper> createState() => _OrbitCardWrapperState();
}

class _OrbitCardWrapperState extends State<_OrbitCardWrapper>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: widget.duration,
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final w = constraints.maxWidth;
          final h = constraints.maxHeight;

          return Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _ctrl,
                    builder: (_, __) => Transform.rotate(
                      angle: _ctrl.value * 2 * math.pi,
                      child: CustomPaint(
                        painter: _OrbitRingPainter(
                          color: widget.accent,
                          strokeWidth: 1.4,
                          opacity: 0.35,
                          dashCount: 36,
                          dashRatio: 0.5,
                          padding: 2,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _ctrl,
                    builder: (_, __) => Transform.rotate(
                      angle: -_ctrl.value * 2 * math.pi * 0.7,
                      child: CustomPaint(
                        painter: _OrbitRingPainter(
                          color: widget.accent,
                          strokeWidth: 1,
                          opacity: 0.18,
                          dashCount: 60,
                          dashRatio: 0.3,
                          padding: -6,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _ctrl,
                    builder: (_, __) {
                      final angle = _ctrl.value * 2 * math.pi;
                      return Stack(
                        children: [
                          _buildOrbitDot(
                            centerW: w,
                            centerH: h,
                            angle: angle,
                            radiusPadding: -8,
                            dotSize: 6,
                            color: widget.accent,
                            glowStrength: 0.6,
                          ),
                          _buildOrbitDot(
                            centerW: w,
                            centerH: h,
                            angle: angle + (2 * math.pi / 3),
                            radiusPadding: -8,
                            dotSize: 5,
                            color: widget.accent,
                            glowStrength: 0.45,
                          ),
                          _buildOrbitDot(
                            centerW: w,
                            centerH: h,
                            angle: angle + (4 * math.pi / 3),
                            radiusPadding: -8,
                            dotSize: 5,
                            color: widget.accent,
                            glowStrength: 0.45,
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
              widget.child,
            ],
          );
        },
      ),
    );
  }

  Widget _buildOrbitDot({
    required double centerW,
    required double centerH,
    required double angle,
    required double radiusPadding,
    required double dotSize,
    required Color color,
    required double glowStrength,
  }) {
    final cx = centerW / 2;
    final cy = centerH / 2;
    final rx = (centerW / 2) + radiusPadding;
    final ry = (centerH / 2) + radiusPadding;

    final x = cx + rx * math.cos(angle);
    final y = cy + ry * math.sin(angle);

    return Positioned(
      left: x - dotSize / 2,
      top: y - dotSize / 2,
      child: Container(
        width: dotSize,
        height: dotSize,
        decoration: BoxDecoration(
          color: color.withOpacity(0.9),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(glowStrength),
              blurRadius: 8,
              spreadRadius: 1,
            ),
            BoxShadow(
              color: color.withOpacity(glowStrength * 0.5),
              blurRadius: 14,
              spreadRadius: 2,
            ),
          ],
        ),
      ),
    );
  }
}

class _OrbitRingPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double opacity;
  final int dashCount;
  final double dashRatio;
  final double padding;

  _OrbitRingPainter({
    required this.color,
    this.strokeWidth = 1.2,
    this.opacity = 0.35,
    this.dashCount = 36,
    this.dashRatio = 0.5,
    this.padding = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    final rect = Rect.fromLTWH(
      padding,
      padding,
      size.width - (padding * 2),
      size.height - (padding * 2),
    );

    final dashAngle = (2 * math.pi) / dashCount;
    final dashLength = dashAngle * dashRatio;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * dashAngle;
      canvas.drawArc(rect, startAngle, dashLength, false, paint);
    }

    final glowPaint = Paint()
      ..color = color.withOpacity(opacity * 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth * 2.5
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    canvas.drawArc(rect, 0, 2 * math.pi, false, glowPaint);
  }

  @override
  bool shouldRepaint(_OrbitRingPainter old) =>
      old.color != color ||
      old.opacity != opacity ||
      old.strokeWidth != strokeWidth ||
      old.dashCount != dashCount ||
      old.padding != padding;
}

// ═══════════════════════════════════════════════════════════════════════════
// 🪐 ORBITING PLANETS — TAP BERFUNGSI SAAT BERPUTAR (TANPA BERHENTI)
// ═══════════════════════════════════════════════════════════════════════════
class _OrbitingPlanets extends StatefulWidget {
  final double orbitRadius;
  final double cardSize;
  final List<_OrbitMenuItem> items;
  final Widget Function(_OrbitMenuItem item, int index) builder;

  const _OrbitingPlanets({
    required this.orbitRadius,
    required this.cardSize,
    required this.items,
    required this.builder,
  });

  @override
  State<_OrbitingPlanets> createState() => _OrbitingPlanetsState();
}

class _OrbitingPlanetsState extends State<_OrbitingPlanets>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    // 20 detik per putaran
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Total area yang dibutuhkan untuk orbit
    final totalSize = (widget.orbitRadius * 2) + widget.cardSize;
    final center = totalSize / 2;

    return SizedBox(
      width: totalSize,
      height: totalSize,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (context, _) {
          return Stack(
            clipBehavior: Clip.none,
            children: List.generate(widget.items.length, (index) {
              // Hitung sudut orbit
              final baseAngle = (2 * math.pi / widget.items.length) * index;
              final angle = baseAngle + (_ctrl.value * 2 * math.pi);

              // Hitung posisi X dan Y
              final x = center + (widget.orbitRadius * math.cos(angle));
              final y = center + (widget.orbitRadius * math.sin(angle));

              // Gunakan Positioned agar hit-test area ikut berpindah!
              return Positioned(
                left: x - (widget.cardSize / 2),
                top: y - (widget.cardSize / 2),
                width: widget.cardSize,
                height: widget.cardSize,
                child: widget.builder(widget.items[index], index),
              );
            }),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 🌍 ORBIT MENU ITEM — DATA UNTUK CARD BULAT
// ═══════════════════════════════════════════════════════════════════════════
class _OrbitMenuItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Color badgeBg;
  final String badge;
  final int itemCount;
  final VoidCallback onTap;

  const _OrbitMenuItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.badgeBg,
    required this.badge,
    required this.itemCount,
    required this.onTap,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => DashboardPageState();
}

class DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  bool _is3DNeo = false;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late WebSocketChannel channel;
  VideoPlayerController? _videoController;
  VideoPlayerController? _bannerVideoController;

  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _musicPlaying = false;
  int _currentTrack = 0;

  Timer? _expiryTicker;
  Timer? _statusTicker;
  Timer? _onlineTicker;
  Timer? _sessionTicker;

  String _expiredShort = '--';

  int _onlineUsers = 0;
  int _totalUsers = 0;
  int _mySessionCount = 0;

  bool _onlineLoaded = false;
  bool _sessionLoaded = false;

  bool _wsReady = false;
  bool _initialFetchDone = false;

  List<dynamic> _statusUsers = [];

  String _broadcastMessage = '';
  String _broadcastFrom = '';
  String _broadcastTime = '';
  bool _hasBroadcast = false;
  Timer? _broadcastTicker;
  late AnimationController _broadcastCtrl;
  late Animation<double> _broadcastAnim;

  // 🔥 JADWAL SHOLAT
  String _nextSholatName = '--';
  String _nextSholatTime = '--:--';
  String _kotaSholat = '--';
  bool _jadwalLoaded = false;
  bool _jadwalLoading = false;

  final List<String> _bannerImages = [
    'https://files.catbox.moe/w9sva8.jpg',
    'https://files.catbox.moe/72ltbn.jpg',
    'https://files.catbox.moe/ujl9vh.jpg',
    'https://files.catbox.moe/mvwsn1.jpg',
  ];

  final List<Map<String, String>> _playlist = [
    {
      'title': 'Lo-Fi Chill',
      'artist': 'axleyatomic BGM',
      'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
    },
    {
      'title': 'Dark Ambience',
      'artist': 'axleyatomic BGM',
      'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'
    },
    {
      'title': 'Night Drive',
      'artist': 'axleyatomic BGM',
      'url': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'
    },
  ];

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  bool _bugPressed = false;

  bool get _canAccessAdminPage {
    const allowedRoles = [
      'reseller',
      'partner',
      'moderator',
      'owner',
      'highowner',
      'dev'
    ];
    return allowedRoles.contains(role.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    // ─── ANIMASI ───
    _fadeCtrl = AnimationController(
        duration: const Duration(milliseconds: 600), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);

    _broadcastCtrl = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    )..repeat(reverse: true);
    _broadcastAnim = Tween<double>(begin: -0.02, end: 0.02).animate(
        CurvedAnimation(parent: _broadcastCtrl, curve: Curves.easeInOut));

    // ─── VIDEO ───
    _initializeVideo();
    _initializeBannerVideo();
    _initMusicListeners();

    // 🔥 FIX UTAMA: EXPIRY LANGSUNG HITUNG DULU (SYNC) ───
    _updateRemaining();
    _startExpiryTicker();

    // 🔥 FIX UTAMA: BOOTSTRAP PARALEL (SEMUA FETCH JALAN BARENG) ───
    _selectedPage = _buildDashboardHome();
    _bootstrapAllData();

    // ─── TICKERS ───
    _onlineTicker = Timer.periodic(const Duration(seconds: 15),
        (_) => _fetchOnlineUsers().catchError((_) {}));
    _sessionTicker = Timer.periodic(const Duration(seconds: 15),
        (_) => _fetchMySession().catchError((_) {}));
    _statusTicker = Timer.periodic(const Duration(seconds: 30),
        (_) => _fetchStatusPreview().catchError((_) {}));
    _broadcastTicker = Timer.periodic(const Duration(seconds: 20),
        (_) => _fetchBroadcast().catchError((_) {}));

    // ─── ANDROID ID + WS ───
    _initAndroidIdAndConnect();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 🚀 BOOTSTRAP: SEMUA DATA FETCH PARALEL, GAK SALING NUNGGU
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _bootstrapAllData() async {
    // Pre-load SharedPreferences biar gak blocking di tengah
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedKota = prefs.getString('jadwal_sholat_kota');
      if (savedKota != null && savedKota.isNotEmpty) {
        if (mounted) {
          setState(() {
            _kotaSholat = savedKota[0].toUpperCase() + savedKota.substring(1);
          });
        }
      }
    } catch (_) {}

    // Fetch semua paralel — siapa cepat, dia tampil duluan
    await Future.wait([
      _fetchOnlineUsers().catchError((_) {}),
      _fetchMySession().catchError((_) {}),
      _fetchStatusPreview().catchError((_) {}),
      _fetchBroadcast().catchError((_) {}),
      _fetchJadwalSholat().catchError((_) {}),
    ]);

    // Kalau ada yang masih kosong setelah 3 detik, retry sekali
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;

    final needRetry = <Future>[];
    if (!_onlineLoaded) needRetry.add(_fetchOnlineUsers().catchError((_) {}));
    if (!_sessionLoaded) needRetry.add(_fetchMySession().catchError((_) {}));
    if (!_jadwalLoaded) needRetry.add(_fetchJadwalSholat().catchError((_) {}));

    if (needRetry.isNotEmpty) {
      await Future.wait(needRetry);
    }

    _initialFetchDone = true;
  }

  void _toggle3DNeo() {
    setState(() => _is3DNeo = !_is3DNeo);
  }

  void simulateHomeTap() {
    _onNavTapped(0);
    _refreshAll();
  }

  void _refreshAll() {
    _fetchOnlineUsers().catchError((_) {});
    _fetchMySession().catchError((_) {});
    _fetchStatusPreview().catchError((_) {});
    _fetchJadwalSholat().catchError((_) {});
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/onlineUsers'))
          .timeout(const Duration(seconds: 10));
      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        if (mounted) setState(() => _onlineLoaded = true);
        return;
      }
      final data = jsonDecode(body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _onlineUsers = int.tryParse(data['online']?.toString() ?? '0') ?? 0;
          _totalUsers = int.tryParse(data['total']?.toString() ?? '0') ?? 0;
          _onlineLoaded = true;
        });
        print('[DASH] Online users: $_onlineUsers / $_totalUsers');
      } else {
        if (mounted) setState(() => _onlineLoaded = true);
      }
    } catch (e) {
      print('[DASH] Fetch online error: $e');
      if (mounted) setState(() => _onlineLoaded = true);
    }
  }

  Future<void> _fetchMySession() async {
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/sender/session?key=$sessionKey'))
          .timeout(const Duration(seconds: 10));
      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        if (mounted) setState(() => _sessionLoaded = true);
        return;
      }
      final data = jsonDecode(body);
      if (mounted) {
        setState(() {
          _mySessionCount = int.tryParse((data['session'] ??
                      data['sessions'] ??
                      data['count'] ??
                      '0')
                  .toString()) ??
              0;
          _sessionLoaded = true;
        });
        print('[DASH] My session: $_mySessionCount');
      }
    } catch (e) {
      print('[DASH] Fetch session error: $e');
      if (mounted) setState(() => _sessionLoaded = true);
    }
  }

  Future<void> _fetchStatusPreview() async {
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/status/list?key=$sessionKey'))
          .timeout(const Duration(seconds: 10));
      final rawBody = res.body.trim();
      if (rawBody.startsWith('<!DOCTYPE') || rawBody.startsWith('<html>')) {
        return;
      }
      final data = jsonDecode(rawBody);
      if (data['valid'] == true && mounted) {
        final raw = data['statuses'];
        List<dynamic> parsed = [];
        if (raw is List) parsed = raw;
        else if (raw is Map) parsed = raw.values.toList();

        parsed = parsed.where((e) {
          if (e is! Map) return false;
          final s = e['statuses'];
          return s is List && s.isNotEmpty;
        }).map((e) {
          final m = Map<String, dynamic>.from(e as Map);
          m['username'] =
              (m['username'] ?? m['user'] ?? 'Unknown').toString();
          final hu = m['has_unviewed'];
          m['has_unviewed'] =
              hu == true || hu == 1 || hu == '1' || hu == 'true';
          return m;
        }).toList();
        setState(() => _statusUsers = parsed);
      }
    } catch (_) {}
  }

  Future<void> _fetchBroadcast() async {
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/broadcast/latest?key=$sessionKey'))
          .timeout(const Duration(seconds: 10));
      final body = res.body.trim();
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) return;
      final data = jsonDecode(body);
      if (data['valid'] == true && mounted) {
        final has = data['has_broadcast'] == true;
        setState(() {
          _hasBroadcast = has;
          _broadcastMessage = (data['message'] ?? '').toString();
          _broadcastFrom = (data['from'] ?? 'owner').toString();
          _broadcastTime = (data['time'] ?? '').toString();
        });
      }
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════════════════
  // 🕌 FETCH JADWAL SHOLAT
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _fetchJadwalSholat() async {
    if (_jadwalLoading) return;
    _jadwalLoading = true;

    try {
      final prefs = await SharedPreferences.getInstance();
      final savedKota = prefs.getString('jadwal_sholat_kota') ?? 'jakarta';

      // 🔥 FIX: Tampilkan placeholder kota dulu
      if (mounted && !_jadwalLoaded) {
        setState(() {
          _kotaSholat = savedKota[0].toUpperCase() + savedKota.substring(1);
          _nextSholatName = 'Memuat...';
          _nextSholatTime = '--:--';
        });
      }

      print('[DASH] Fetch jadwal sholat untuk: $savedKota');

      final searchUrl = Uri.parse(
        'https://api.myquran.com/v2/sholat/kota/cari/${Uri.encodeComponent(savedKota.toLowerCase())}',
      );
      final searchRes = await http
          .get(searchUrl)
          .timeout(const Duration(seconds: 10));

      if (searchRes.statusCode != 200) return;

      final searchJson = jsonDecode(searchRes.body);
      if (searchJson['status'] != true ||
          searchJson['data'] == null ||
          (searchJson['data'] as List).isEmpty) {
        return;
      }

      final kotaData = (searchJson['data'] as List).first;
      final kotaId = kotaData['id']?.toString() ?? '';
      final kotaNama = kotaData['lokasi']?.toString() ?? savedKota;

      if (kotaId.isEmpty) return;

      final now = DateTime.now();
      final year = now.year.toString();
      final month = now.month.toString().padLeft(2, '0');
      final day = now.day.toString().padLeft(2, '0');

      final jadwalUrl = Uri.parse(
        'https://api.myquran.com/v2/sholat/jadwal/$kotaId/$year/$month/$day',
      );
      final jadwalRes = await http
          .get(jadwalUrl)
          .timeout(const Duration(seconds: 10));

      if (jadwalRes.statusCode != 200) return;

      final jadwalJson = jsonDecode(jadwalRes.body);
      if (jadwalJson['status'] != true || jadwalJson['data'] == null) return;

      final data = jadwalJson['data'];
      final jadwalData = data['jadwal'] ?? {};

      final sholatList = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
      final currentMinutes = now.hour * 60 + now.minute;

      String nextName = 'Subuh';
      String nextTime = jadwalData['subuh']?.toString() ?? '--:--';
      bool found = false;

      for (final s in sholatList) {
        final time = jadwalData[s.toLowerCase()]?.toString();
        if (time == null) continue;
        final parts = time.split(':');
        if (parts.length != 2) continue;
        final h = int.tryParse(parts[0]) ?? 0;
        final m = int.tryParse(parts[1]) ?? 0;
        final sholatMinutes = h * 60 + m;
        if (sholatMinutes > currentMinutes) {
          nextName = s;
          nextTime = time;
          found = true;
          break;
        }
      }

      if (!found) {
        nextName = 'Subuh';
        nextTime = jadwalData['subuh']?.toString() ?? '--:--';
      }

      if (!mounted) return;
      setState(() {
        _kotaSholat = kotaNama;
        _nextSholatName = nextName;
        _nextSholatTime = nextTime;
        _jadwalLoaded = true;
      });

      print(
          '[DASH] Jadwal sholat loaded: $_nextSholatName $_nextSholatTime ($kotaNama)');
    } catch (e) {
      print('[DASH] Fetch jadwal sholat error: $e');
      if (mounted) {
        setState(() {
          _nextSholatName = 'Subuh';
          _nextSholatTime = '--:--';
          if (_kotaSholat.isEmpty || _kotaSholat == '--') {
            _kotaSholat = 'Jakarta';
          }
          _jadwalLoaded = true;
        });
      }
    } finally {
      _jadwalLoading = false;
    }
  }

  void _startExpiryTicker() {
    _updateRemaining();
    _expiryTicker = Timer.periodic(
        const Duration(seconds: 1), (_) => _updateRemaining());
  }

  void _updateRemaining() {
    try {
      final expiry = DateTime.parse(expiredDate);
      final now = DateTime.now();
      final diff = expiry.difference(now);

      if (diff.isNegative) {
        if (!mounted) return;
        setState(() => _expiredShort = 'EXPIRED');
        _expiryTicker?.cancel();
        return;
      }

      final days = diff.inDays;
      final hours = diff.inHours % 24;
      final mins = diff.inMinutes % 60;

      // 🔥 FIX: Format lebih pendek biar muat di card kecil
      String short;
      if (days > 0) {
        short = '${days}D ${hours}H';
      } else if (hours > 0) {
        short = '${hours}H ${mins}M';
      } else {
        short = '${mins}M';
      }

      if (!mounted) return;
      if (_expiredShort != short) {
        setState(() => _expiredShort = short);
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _expiredShort = '--');
    }
  }

  void _initMusicListeners() {
    _audioPlayer.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _musicPlaying = s == PlayerState.playing);
    });
  }

  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _videoController?.setLooping(true);
      _videoController?.play();
      _videoController?.setVolume(0);
    }).catchError((_) {
      if (mounted) setState(() {});
    });
  }

  void _initializeBannerVideo() {
    _bannerVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4');
    _bannerVideoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _bannerVideoController?.setLooping(true);
      _bannerVideoController?.play();
      _bannerVideoController?.setVolume(0);
    }).catchError((_) {
      if (mounted) setState(() {});
    });
  }

  void _pauseBannerVideo() {
    if (_bannerVideoController != null &&
        _bannerVideoController!.value.isInitialized &&
        _bannerVideoController!.value.isPlaying) {
      _bannerVideoController!.pause();
    }
  }

  void _playBannerVideo() {
    if (_bannerVideoController != null &&
        _bannerVideoController!.value.isInitialized) {
      _bannerVideoController!.play();
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id;
    } catch (_) {
      androidId = 'unknown';
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(kWsUrl));
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId
      }));
      channel.sink.add(jsonEncode({"type": "stats"}));

      channel.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);

            if (data['type'] == 'myInfo' && data['valid'] == true) {
              print('[DASH] WS session valid — force refresh all');
              _wsReady = true;
              if (mounted) {
                // 🔥 FIX: Re-fetch paksa setelah WS ready
                Future.wait([
                  _fetchOnlineUsers().catchError((_) {}),
                  _fetchMySession().catchError((_) {}),
                  _fetchStatusPreview().catchError((_) {}),
                  _fetchBroadcast().catchError((_) {}),
                  _fetchJadwalSholat().catchError((_) {}),
                ]);
              }
            }

            if (data['type'] == 'myInfo' && data['valid'] == false) {
              _handleInvalidSession("Session invalid, please re-login.");
            }
          } catch (_) {}
        },
        onError: (e) {
          print('[DASH] WS error: $e');
        },
        onDone: () {
          print('[DASH] WS closed');
        },
      );

      Future.delayed(const Duration(seconds: 3), () {
        if (!mounted) return;
        if (!_wsReady) {
          print('[DASH] WS timeout — force refresh');
          _fetchOnlineUsers().catchError((_) {});
          _fetchMySession().catchError((_) {});
        }
      });
    } catch (e) {
      print('[DASH] WS connect error: $e');
    }
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    GlassDialog.show(
      context,
      title: 'Session Expired',
      message: message,
      icon: Icons.warning_rounded,
      accentColor: GlassPalette.red,
      actions: [
        GlassButton(
          text: 'OK',
          fullWidth: false,
          onTap: () => Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (r) => false,
          ),
          bgColor: GlassPalette.blue,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        ),
      ],
    );
  }

  void _onNavTapped(int index) {
    if (index == 0) {
      _playBannerVideo();
      _refreshAll();
    } else {
      _pauseBannerVideo();
    }

    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildDashboardHome();
          break;
        case 1:
          _selectedPage = TokoPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          );
          break;
        case 2:
          _selectedPage = HomePage(
            isGroup: false,
            username: username,
            password: password,
            sessionKey: sessionKey,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
          );
          break;
        case 3:
          _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos,
          );
          break;
        case 4:
          _selectedPage = DeviceDashboardPage(
            username: username,
            role: role,
            sessionKey: sessionKey,
          );
          break;
      }
    });
  }

  void _navigateToSellerPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey)),
    );
  }

  @override
  void dispose() {
    _expiryTicker?.cancel();
    _statusTicker?.cancel();
    _onlineTicker?.cancel();
    _sessionTicker?.cancel();
    try {
      channel.sink.close(status.goingAway);
    } catch (_) {}
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _videoController?.dispose();
    _bannerVideoController?.dispose();
    _audioPlayer.dispose();
    _broadcastTicker?.cancel();
    _broadcastCtrl.dispose();
    super.dispose();
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD HOME
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildDashboardHome() {
    return GlassBg(
      bgAsset: kDashboardBgAsset,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 130),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: MediaQuery.of(context).padding.top + kToolbarHeight + 12,
            ),
            _buildBroadcastBanner(),
            _buildVideoCard(),
            const SizedBox(height: 16),
            _buildProfileCard(),
            const SizedBox(height: 16),
            _buildStatusRow(),
            const SizedBox(height: 16),
            _buildBannerImageScroll(),
            const SizedBox(height: 20),
            _buildJadwalSholatSection(),
            const SizedBox(height: 20),
            _buildQuickActionsHeader(),
            const SizedBox(height: 12),
            _buildQuickCategoriesGrid(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GlassCard(
        padding: EdgeInsets.zero,
        borderWidth: 1.5,
        radius: 22,
        child: SizedBox(
          height: 180,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_bannerVideoController != null &&
                    _bannerVideoController!.value.isInitialized)
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bannerVideoController!.value.size.width,
                      height: _bannerVideoController!.value.size.height,
                      child: VideoPlayer(_bannerVideoController!),
                    ),
                  )
                else
                  Container(color: GlassPalette.surfaceAlt),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.6),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: GlassPalette.red.withOpacity(0.7),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: GlassPalette.red.withOpacity(0.5),
                          blurRadius: 15,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: GlassPalette.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'LIVE BANNER',
                          style: GlassFont.pixel(
                            size: 9,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 12,
                  left: 14,
                  right: 14,
                  child: Row(
                    children: [
                      const Icon(Icons.videocam_rounded,
                          color: Colors.white, size: 14),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'ATOMIC X PROJECT — BANNER',
                          style: GlassFont.pixel(
                            size: 10,
                            weight: FontWeight.w700,
                            color: Colors.white,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBroadcastBanner() {
    if (!_hasBroadcast || _broadcastMessage.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: AnimatedBuilder(
        animation: _broadcastAnim,
        builder: (context, child) {
          return Transform.rotate(angle: _broadcastAnim.value, child: child);
        },
        child: GlassCard(
          borderWidth: 1.5,
          radius: 20,
          bgColor: Colors.white.withOpacity(0.08),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: GlassPalette.red.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: GlassPalette.red.withOpacity(0.6),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: GlassPalette.red.withOpacity(0.4),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const Icon(Icons.campaign_rounded,
                    color: GlassPalette.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        GlassBadge(
                          text: '📢 BROADCAST',
                          bgColor: GlassPalette.red,
                          textColor: GlassPalette.white,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'dari ${_broadcastFrom.toUpperCase()}',
                          style: GlassFont.body(
                            size: 9,
                            weight: FontWeight.w500,
                            color: GlassPalette.textDim,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _broadcastMessage,
                      style: GlassFont.body(
                        size: 12,
                        weight: FontWeight.w700,
                        color: GlassPalette.text,
                        height: 1.4,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  kProfileCardBgAsset,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          GlassPalette.blue.withOpacity(0.25),
                          GlassPalette.purple.withOpacity(0.25),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.6),
                        Colors.black.withOpacity(0.4),
                        Colors.black.withOpacity(0.75),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Welcome back!! Ahlan WaSahlan',
                                style: GlassFont.body(
                                  size: 11,
                                  weight: FontWeight.w500,
                                  color: GlassPalette.textSub,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      username.isEmpty
                                          ? 'GUEST'
                                          : username.toUpperCase(),
                                      style: GlassFont.pixel(
                                        size: 13,
                                        weight: FontWeight.w700,
                                        color: GlassPalette.white,
                                        letterSpacing: 1,
                                        shadows: [
                                          Shadow(
                                            color: GlassPalette.blue
                                                .withOpacity(0.6),
                                            blurRadius: 10,
                                          ),
                                        ],
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.all(2),
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color(0xFF2196F3),
                                    ),
                                    child: const Icon(Icons.check,
                                        color: Colors.white, size: 11),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color:
                                      _roleColor(role).withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color:
                                        _roleColor(role).withOpacity(0.7),
                                    width: 1.2,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _roleColor(role)
                                          .withOpacity(0.4),
                                      blurRadius: 12,
                                    ),
                                  ],
                                ),
                                child: Text(
                                  role.isEmpty
                                      ? 'MEMBER'
                                      : role.toUpperCase(),
                                  style: GlassFont.pixel(
                                    size: 9,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        SizedBox(
                          width: 100,
                          height: 100,
                          child: CachedNetworkImage(
                            imageUrl: kProfileCardImageUrl,
                            fit: BoxFit.contain,
                            fadeInDuration:
                                const Duration(milliseconds: 200),
                            placeholder: (_, __) => const SizedBox(
                              width: 100,
                              height: 100,
                              child: Center(
                                child: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    color: GlassPalette.white,
                                    strokeWidth: 2,
                                  ),
                                ),
                              ),
                            ),
                            errorWidget: (_, __, ___) => const SizedBox(
                              width: 100,
                              height: 100,
                              child: Center(
                                child: Icon(Icons.broken_image_rounded,
                                    color: GlassPalette.textDim, size: 30),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _profileStatItem(
                            label: 'ONLINE',
                            value: '$_onlineUsers',
                            sub: '/ $_totalUsers',
                            icon: Icons.people_alt_rounded,
                            color: GlassPalette.teal,
                            loading: !_onlineLoaded,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _profileStatItem(
                            label: 'SESI',
                            value: '$_mySessionCount',
                            sub: 'aktif',
                            icon: Icons.layers_rounded,
                            color: GlassPalette.blue,
                            loading: !_sessionLoaded,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _profileStatItem(
                            label: 'EXPIRED',
                            value: _expiredShort,
                            sub: 'sisa',
                            icon: Icons.timer_rounded,
                            color: GlassPalette.red,
                            loading:
                                _expiredShort == '--' || _expiredShort.isEmpty,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _profileStatItem({
    required String label,
    required String value,
    required String sub,
    required IconData icon,
    required Color color,
    bool loading = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: color.withOpacity(0.5),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 12,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 13),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  label,
                  style: GlassFont.pixel(
                    size: 7,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          if (loading)
            Container(
              width: 40,
              height: 12,
              decoration: BoxDecoration(
                color: color.withOpacity(0.25),
                borderRadius: BorderRadius.circular(4),
              ),
            )
          else
            Text(
              value,
              style: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          Text(
            sub,
            style: GlassFont.body(
              size: 8,
              weight: FontWeight.w400,
              color: GlassPalette.textDim,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 22,
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: GlassPalette.red.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: GlassPalette.red.withOpacity(0.6),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: GlassPalette.red.withOpacity(0.4),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.auto_awesome,
                          color: GlassPalette.white, size: 12),
                      const SizedBox(width: 6),
                      Text(
                        'ATOMIC X GRAM',
                        style: GlassFont.pixel(
                          size: 9,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _fetchStatusPreview(),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.refresh_rounded,
                        color: GlassPalette.white, size: 16),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                children: [
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => StatusPage(
                          username: username,
                          sessionKey: sessionKey,
                          role: role,
                        ),
                      ),
                    ).then((_) => _fetchStatusPreview()),
                    child: Container(
                      width: 74,
                      margin: const EdgeInsets.only(right: 12),
                      child: Column(
                        children: [
                          Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              color: GlassPalette.blue.withOpacity(0.25),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: GlassPalette.blue.withOpacity(0.7),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: GlassPalette.blue.withOpacity(0.5),
                                  blurRadius: 15,
                                ),
                              ],
                            ),
                            child: const Icon(Icons.add,
                                color: GlassPalette.white, size: 32),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Buat',
                            style: GlassFont.body(
                              size: 11,
                              weight: FontWeight.w700,
                              color: GlassPalette.white,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                  ..._statusUsers.map((dynamic user) {
                    if (user is! Map) return const SizedBox.shrink();
                    final u = Map<String, dynamic>.from(user);
                    final hasUnviewed = u['has_unviewed'] == true;
                    final statuses = (u['statuses'] as List?) ?? [];
                    if (statuses.isEmpty) return const SizedBox.shrink();

                    final latest =
                        Map<String, dynamic>.from(statuses[0] as Map);
                    final uName = (u['username'] ?? 'Unknown').toString();
                    final imgUrl = (latest['image'] ?? '').toString();

                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => StatusViewer(
                              statuses: _statusUsers,
                              initialIndex: _statusUsers.indexOf(user),
                              sessionKey: sessionKey,
                              username: username,
                            ),
                          ),
                        ).then((_) => _fetchStatusPreview());
                      },
                      child: Container(
                        width: 74,
                        margin: const EdgeInsets.only(right: 12),
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(2.5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.1),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: hasUnviewed
                                      ? GlassPalette.red
                                      : GlassPalette.border,
                                  width: 2.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: (hasUnviewed
                                            ? GlassPalette.red
                                            : GlassPalette.blue)
                                        .withOpacity(0.5),
                                    blurRadius: 12,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(50),
                                child: CircleAvatar(
                                  radius: 26,
                                  backgroundColor:
                                      Colors.white.withOpacity(0.1),
                                  backgroundImage: imgUrl.isNotEmpty
                                      ? CachedNetworkImageProvider(imgUrl)
                                      : null,
                                  child: imgUrl.isEmpty
                                      ? const Icon(Icons.person,
                                          color: GlassPalette.textDim,
                                          size: 24)
                                      : null,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              uName,
                              style: GlassFont.body(
                                size: 10,
                                weight: hasUnviewed
                                    ? FontWeight.w900
                                    : FontWeight.w500,
                                color: hasUnviewed
                                    ? GlassPalette.white
                                    : GlassPalette.textDim,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBannerImageScroll() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GlassSectionTitle(
            icon: Icons.collections_rounded,
            title: 'Gallery',
            color: GlassPalette.blue,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _bannerImages.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => Dialog(
                        backgroundColor: Colors.transparent,
                        insetPadding: const EdgeInsets.all(20),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.network(
                            _bannerImages[index],
                            fit: BoxFit.contain,
                            loadingBuilder: (_, child, progress) {
                              if (progress == null) return child;
                              return Container(
                                height: 300,
                                color: Colors.white.withOpacity(0.1),
                                child: const Center(
                                  child: CircularProgressIndicator(
                                      color: GlassPalette.white),
                                ),
                              );
                            },
                            errorBuilder: (_, __, ___) => Container(
                              height: 300,
                              color: Colors.white.withOpacity(0.1),
                              child: const Center(
                                child: Icon(Icons.broken_image_rounded,
                                    color: GlassPalette.textDim, size: 50),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  child: GlassCard(
                    padding: EdgeInsets.zero,
                    borderWidth: 1.5,
                    radius: 20,
                    child: SizedBox(
                      width: 140,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            Image.network(
                              _bannerImages[index],
                              fit: BoxFit.cover,
                              loadingBuilder: (_, child, progress) {
                                if (progress == null) return child;
                                return Container(
                                  color: Colors.white.withOpacity(0.1),
                                  child: const Center(
                                    child: SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                        color: GlassPalette.white,
                                        strokeWidth: 2,
                                      ),
                                    ),
                                  ),
                                );
                              },
                              errorBuilder: (_, __, ___) => Container(
                                color: Colors.white.withOpacity(0.1),
                                child: const Center(
                                  child: Icon(Icons.broken_image_rounded,
                                      color: GlassPalette.textDim,
                                      size: 30),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.transparent,
                                      Colors.black.withOpacity(0.6),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              top: 8,
                              left: 8,
                              child: GlassBadge(
                                text: '#${index + 1}',
                                bgColor: GlassPalette.blue,
                                textColor: GlassPalette.white,
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              left: 10,
                              right: 10,
                              child: Row(
                                children: [
                                  const Icon(Icons.image_rounded,
                                      color: Colors.white70, size: 12),
                                  const SizedBox(width: 5),
                                  Expanded(
                                    child: Text(
                                      'Tap to view',
                                      style: GlassFont.body(
                                        size: 10,
                                        weight: FontWeight.w500,
                                        color: Colors.white70,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 🕌 JADWAL SHOLAT SECTION
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildJadwalSholatSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const JadwalSholatPage(),
            ),
          ).then((_) {
            _fetchJadwalSholat().catchError((_) {});
          });
        },
        child: GlassCard(
          borderWidth: 1.5,
          radius: 20,
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: GlassPalette.teal.withOpacity(0.5),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.mosque_rounded,
                  color: GlassPalette.white,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'JADWAL SHOLAT',
                          style: GlassFont.pixel(
                            size: 10,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(
                                color: GlassPalette.teal.withOpacity(0.5),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        if (_jadwalLoaded)
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: GlassPalette.teal,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: GlassPalette.teal.withOpacity(0.7),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Text(
                          _nextSholatName.toUpperCase(),
                          style: GlassFont.pixel(
                            size: 12,
                            weight: FontWeight.w700,
                            color: GlassPalette.teal,
                            shadows: [
                              Shadow(
                                color: GlassPalette.teal.withOpacity(0.6),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _nextSholatTime,
                          style: GlassFont.pixel(
                            size: 14,
                            weight: FontWeight.w900,
                            color: GlassPalette.white,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      _jadwalLoaded
                          ? '📍 $_kotaSholat • Tap untuk detail'
                          : 'Memuat jadwal...',
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w500,
                        color: GlassPalette.textDim,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.6),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'BUKA',
                      style: GlassFont.pixel(
                        size: 7,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(
                      Icons.arrow_forward_rounded,
                      color: GlassPalette.white,
                      size: 12,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionsHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GlassSectionTitle(
        icon: Icons.grid_view_rounded,
        title: 'Menu Utama',
        color: GlassPalette.blue,
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 🌍 QUICK ACTIONS - ORBIT STYLE (BERPUTAR MENGELILINGI PUSAT)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildQuickCategoriesGrid() {
    final items = [
      _OrbitMenuItem(
        title: 'TOOLS MENU',
        subtitle: 'AI, Tools, Chat & Utility',
        icon: Icons.grid_view_rounded,
        accent: GlassPalette.teal,
        badgeBg: GlassPalette.teal,
        badge: '5 MODUL',
        itemCount: 5,
        onTap: () => _openHub(
          title: 'TOOLS MENU',
          subtitle: 'AI, Tools, Chat & Utility',
          icon: Icons.grid_view_rounded,
          color: GlassPalette.teal,
          items: _itemsTools(),
        ),
      ),
      _OrbitMenuItem(
        title: 'ATOMIC BUGS',
        subtitle: 'Band, Sender & Raid',
        icon: Icons.bug_report_rounded,
        accent: GlassPalette.red,
        badgeBg: GlassPalette.red,
        badge: '4 MODUL',
        itemCount: 4,
        onTap: () => _openHub(
          title: 'ATOMIC BUGS',
          subtitle: 'Band, Sender & Raid Group',
          icon: Icons.bug_report_rounded,
          color: GlassPalette.red,
          items: _itemsBugs(),
        ),
      ),
      _OrbitMenuItem(
        title: 'ATOMIC X RAT',
        subtitle: 'Device & Control',
        icon: Icons.security_rounded,
        accent: GlassPalette.purple,
        badgeBg: GlassPalette.purple,
        badge: '3 MODUL',
        itemCount: 3,
        onTap: () => _openHub(
          title: 'ATOMIC X RAT',
          subtitle: 'Device, Control & Security',
          icon: Icons.security_rounded,
          color: GlassPalette.purple,
          items: _itemsRat(),
        ),
      ),
      _OrbitMenuItem(
        title: 'CREATE AKUN',
        subtitle: _canAccessAdminPage
            ? 'Manage user & create'
            : 'Perlu akses khusus',
        icon: Icons.person_add_alt_1_rounded,
        accent: _canAccessAdminPage
            ? GlassPalette.orange
            : GlassPalette.textDim,
        badgeBg: _canAccessAdminPage
            ? GlassPalette.orange
            : GlassPalette.textDim,
        badge: _canAccessAdminPage ? 'ADMIN' : 'LOCKED',
        itemCount: 1,
        onTap: () => _openHub(
          title: 'CREATE AKUN',
          subtitle: _canAccessAdminPage
              ? 'Manage user & create akun'
              : 'Perlu akses Owner / Admin',
          icon: Icons.person_add_alt_1_rounded,
          color: _canAccessAdminPage
              ? GlassPalette.orange
              : GlassPalette.textDim,
          items: _itemsCreate(),
        ),
      ),
    ];

    const double orbitRadius = 118.0;
    const double cardSize = 108.0;
    const double centerSize = 62.0;
    const double totalSize = (orbitRadius * 2) + cardSize + 30;

    return Center(
      child: SizedBox(
        width: totalSize,
        height: totalSize,
        child: Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            // ─── Cincin orbit luar tipis ───
            Container(
              width: (orbitRadius * 2) + 45,
              height: (orbitRadius * 2) + 45,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.05),
                  width: 1,
                ),
              ),
            ),
            // ─── Lingkaran orbit utama ───
            Container(
              width: orbitRadius * 2,
              height: orbitRadius * 2,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.12),
                  width: 1.5,
                ),
              ),
            ),
            // ─── Planet induk (pusat) ───
            Container(
              width: centerSize,
              height: centerSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: GlassPalette.blue.withOpacity(0.18),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.55),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.45),
                    blurRadius: 25,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: const Icon(Icons.rocket_launch_rounded,
                  color: GlassPalette.white, size: 28),
            ),
            // ─── Card berputar mengelilingi pusat ───
            _OrbitingPlanets(
              orbitRadius: orbitRadius,
              cardSize: cardSize,
              items: items,
              builder: (item, index) => _buildOrbitCardItem(item),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrbitCardItem(_OrbitMenuItem item) {
    return GestureDetector(
      onTap: item.onTap,
      child: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              item.accent.withOpacity(0.35),
              Colors.white.withOpacity(0.05),
            ],
            radius: 0.9,
          ),
          border: Border.all(
            color: item.accent.withOpacity(0.75),
            width: 1.8,
          ),
          boxShadow: [
            BoxShadow(
              color: item.accent.withOpacity(0.5),
              blurRadius: 20,
              spreadRadius: 2,
            ),
            BoxShadow(
              color: item.accent.withOpacity(0.25),
              blurRadius: 35,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: item.accent.withOpacity(0.35),
                shape: BoxShape.circle,
                border: Border.all(
                  color: item.accent.withOpacity(0.85),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: item.accent.withOpacity(0.6),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Icon(item.icon, color: GlassPalette.white, size: 20),
            ),
            const SizedBox(height: 6),
            Text(
              item.title,
              textAlign: TextAlign.center,
              style: GlassFont.pixel(
                size: 8,
                weight: FontWeight.w700,
                color: GlassPalette.white,
                shadows: [
                  Shadow(
                    color: item.accent.withOpacity(0.8),
                    blurRadius: 6,
                  ),
                ],
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              '${item.itemCount} modul',
              style: GlassFont.body(
                size: 7,
                weight: FontWeight.w400,
                color: GlassPalette.textSub,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openHub({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required List<QuickMenuItem> items,
  }) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MenuHubPage(
          title: title,
          subtitle: subtitle,
          headerIcon: icon,
          headerColor: color,
          items: items,
        ),
      ),
    );
  }

  List<QuickMenuItem> _itemsTools() => [
        QuickMenuItem(
          icon: Icons.psychology_rounded,
          title: 'ATOMIC AI',
          sub: 'Chat AI Cerdas',
          desc: 'Tanya apa aja, dijawab cerdas & cepat',
          tags: ['AI', 'Cerdas', 'Gratis'],
          badge: 'AI',
          badgeBg: GlassPalette.blue,
          accent: GlassPalette.blue,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AiChatPage(
                username: username,
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.auto_awesome_motion_rounded,
          title: 'CREATE AM',
          sub: 'Verifikasi & Aktivasi',
          desc: 'Aktivasi akun Alight Motion pake link',
          tags: ['Cepat', 'Auto', 'Gratis'],
          badge: 'NEW',
          badgeBg: GlassPalette.yellow,
          accent: GlassPalette.yellow,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AlightMotionPage(
                username: username,
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.build_rounded,
          title: 'TOOLS GATEWAY',
          sub: 'Semua Tools',
          desc: 'Akses semua tools tersedia',
          tags: ['Lengkap', 'Powerful', 'Cepat'],
          badge: 'HOT',
          badgeBg: GlassPalette.red,
          accent: GlassPalette.teal,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ToolsPage(
                sessionKey: sessionKey,
                userRole: role,
                listDoos: listDoos,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.badge_rounded,
          title: 'NIK CHECK',
          sub: 'Cek Data NIK',
          desc: 'Cek data NIK Indonesia',
          tags: ['Cepat', 'Akurat', 'Lengkap'],
          badge: 'NEW',
          badgeBg: GlassPalette.teal,
          accent: GlassPalette.teal,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NikCheckerPage()),
          ),
        ),
        QuickMenuItem(
          icon: Icons.chat_bubble_rounded,
          title: 'PRIVATE CHAT',
          sub: 'Chat antar member',
          desc: 'Chat, kirim foto, video, voice note',
          tags: ['Chat', 'Realtime', 'Media'],
          badge: 'NEW',
          badgeBg: GlassPalette.teal,
          accent: GlassPalette.teal,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChatPage(
                username: username,
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          ),
        ),
      ];

  List<QuickMenuItem> _itemsBugs() => [
        QuickMenuItem(
          icon: Icons.block_rounded,
          title: 'BAND GROUP',
          sub: 'Kirim Band ke Group',
          desc: 'Kirim band ke group WhatsApp target',
          tags: ['Group', 'Power', 'Danger'],
          badge: 'DANGER',
          badgeBg: GlassPalette.red,
          accent: GlassPalette.red,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BandGroupPage(
                username: username,
                sessionKey: sessionKey,
                role: role,
                listBug: listBug,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.bug_report_rounded,
          title: 'BUG SENDER',
          sub: 'Sender Mengirim Bug',
          desc: 'Gunakan langsung dengan cepat',
          tags: ['Mudah', 'Function', 'Gacor'],
          badge: 'HOT',
          badgeBg: GlassPalette.red,
          accent: GlassPalette.red,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.phone_android_rounded,
          title: 'BUG NOMOR',
          sub: 'Hanya Bug',
          desc: 'Kirim bug ke nomor WA langsung',
          tags: ['Cepat', 'Akurat', 'Aman'],
          badge: 'HOT',
          badgeBg: GlassPalette.red,
          accent: GlassPalette.orange,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => HomePage(
                isGroup: false,
                username: username,
                password: password,
                sessionKey: sessionKey,
                listBug: listBug,
                role: role,
                expiredDate: expiredDate,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.groups_rounded,
          title: 'BUG GROUP',
          sub: 'Hanya Bug',
          desc: 'Raid grup WhatsApp dengan cepat',
          tags: ['Group', 'Cepat', 'Efektif'],
          badge: 'HOT',
          badgeBg: GlassPalette.red,
          accent: GlassPalette.purple,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => HomePage(
                isGroup: true,
                username: username,
                password: password,
                sessionKey: sessionKey,
                listBug: listBug,
                role: role,
                expiredDate: expiredDate,
              ),
            ),
          ),
        ),
      ];

  List<QuickMenuItem> _itemsRat() => [
        QuickMenuItem(
          icon: Icons.devices_rounded,
          title: 'DEVICE DASHBOARD',
          sub: 'Kontrol Device',
          desc: 'Remote device via RAT',
          tags: ['RAT', 'Kontrol', 'Aman'],
          badge: 'NEW',
          badgeBg: GlassPalette.purple,
          accent: GlassPalette.purple,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DeviceDashboardPage(
                username: username,
                role: role,
                sessionKey: sessionKey,
              ),
            ),
          ),
        ),
        QuickMenuItem(
          icon: Icons.security_rounded,
          title: 'CONTROL CENTER',
          sub: 'Panel Kontrol',
          desc: 'Kontrol sistem dari sini',
          tags: ['Admin', 'Power', 'Full'],
          badge: 'NEW',
          badgeBg: GlassPalette.purple,
          accent: GlassPalette.teal,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ControlCenterPage()),
          ),
        ),
        QuickMenuItem(
          icon: Icons.lock_clock_rounded,
          title: 'GANTI PASSWORD',
          sub: 'Ubah Password',
          desc: 'Ganti password akun lo',
          tags: ['Aman', 'Mudah', 'Cepat'],
          badge: 'NEW',
          badgeBg: GlassPalette.yellow,
          accent: GlassPalette.orange,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChangePasswordPage(
                username: username,
                sessionKey: sessionKey,
              ),
            ),
          ),
        ),
      ];

  List<QuickMenuItem> _itemsCreate() => [
        QuickMenuItem(
          icon: Icons.admin_panel_settings_rounded,
          title: 'ADMIN PANEL',
          sub: _canAccessAdminPage ? 'Manage User' : 'Akses Terbatas',
          desc: _canAccessAdminPage
              ? 'Manage user & create akun'
              : 'Perlu akses Owner / Admin buat buka',
          tags: _canAccessAdminPage
              ? ['Owner', 'Full', 'Power']
              : ['Locked', 'Owner Only'],
          badge: _canAccessAdminPage ? 'ADMIN' : 'LOCK',
          badgeBg: _canAccessAdminPage
              ? GlassPalette.red
              : GlassPalette.textDim,
          accent: _canAccessAdminPage
              ? GlassPalette.orange
              : GlassPalette.textDim,
          disabled: !_canAccessAdminPage,
          onTap: () {
            if (_canAccessAdminPage) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AdminPage(
                    sessionKey: sessionKey,
                    role: role,
                  ),
                ),
              );
            } else {
              GlassDialog.show(
                context,
                title: 'Akses Ditolak',
                message:
                    'Kamu belum di-add sebagai Admin/Owner.\nHubungi Owner buat minta akses.',
                icon: Icons.lock_rounded,
                accentColor: GlassPalette.red,
              );
            }
          },
        ),
      ];

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      automaticallyImplyLeading: false,
      leading: Builder(
        builder: (ctx) => GestureDetector(
          onTap: () => Scaffold.of(ctx).openDrawer(),
          child: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.menu_rounded,
                color: GlassPalette.white, size: 20),
          ),
        ),
      ),
      titleSpacing: 0,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Text(
              "Hai, $username",
              style: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 1,
            height: 16,
            color: Colors.white.withOpacity(0.3),
          ),
          const SizedBox(width: 8),
          const _AtomicXProjectLogo(),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () {
            setState(() {
              _selectedPage = MusikPage(
                  sharedPlayer: _audioPlayer, initialTrack: _currentTrack);
              _bottomNavIndex = 0;
            });
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.2,
              ),
            ),
            child: Icon(
              _musicPlaying
                  ? Icons.music_note_rounded
                  : Icons.music_off_rounded,
              color: GlassPalette.white,
              size: 18,
            ),
          ),
        ),
        GestureDetector(
          onTap: _showLogoutDialog,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: GlassPalette.red.withOpacity(0.25),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: GlassPalette.red.withOpacity(0.6),
                width: 1.2,
              ),
            ),
            child: const Icon(Icons.logout_rounded,
                color: GlassPalette.white, size: 18),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomNav() {
    return GlassLiquidNav(
      currentIndex: _bottomNavIndex,
      onTap: _onNavTapped,
      items: const [
        GlassLiquidNavItem(
          icon: Icons.home_rounded,
          label: 'Home',
        ),
        GlassLiquidNavItem(
          icon: Icons.storefront_rounded,
          label: 'Toko',
        ),
        GlassLiquidNavItem(
          icon: Icons.bug_report_rounded,
          label: 'Bug',
          isCentral: true,
        ),
        GlassLiquidNavItem(
          icon: Icons.build_circle_outlined,
          label: 'Tools',
        ),
        GlassLiquidNavItem(
          icon: Icons.computer_rounded,
          label: 'RAT',
        ),
      ],
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      child: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.55),
              border: Border(
                right: BorderSide(
                  color: Colors.white.withOpacity(0.15),
                  width: 1.2,
                ),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  height: 180,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.white.withOpacity(0.15),
                        width: 1.2,
                      ),
                    ),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (_videoController != null &&
                          _videoController!.value.isInitialized)
                        FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _videoController!.value.size.width,
                            height: _videoController!.value.size.height,
                            child: VideoPlayer(_videoController!),
                          ),
                        )
                      else
                        Container(
                          color: Colors.white.withOpacity(0.05),
                          child: const Center(
                            child: CircularProgressIndicator(
                                color: GlassPalette.white, strokeWidth: 2),
                          ),
                        ),
                      Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.transparent, Colors.black87],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 16,
                        right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "ATOMIC X PROJECT",
                              style: GlassFont.pixel(
                                size: 13,
                                weight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 2,
                                shadows: const [
                                  Shadow(
                                      color: Color(0x662AABEE),
                                      blurRadius: 12),
                                ],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Powerful Bug Sender Tool",
                              style: GlassFont.body(
                                size: 11,
                                weight: FontWeight.w400,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.white.withOpacity(0.15),
                        width: 1.2,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.7),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.5),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.person_rounded,
                            color: GlassPalette.white, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username,
                              style: GlassFont.pixel(
                                size: 11,
                                weight: FontWeight.w700,
                                color: GlassPalette.white,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: _roleColor(role).withOpacity(0.3),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color:
                                      _roleColor(role).withOpacity(0.7),
                                  width: 1.2,
                                ),
                              ),
                              child: Text(
                                role.toUpperCase(),
                                style: GlassFont.pixel(
                                  size: 7,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    children: [
                      if (role.toLowerCase() == "owner" ||
                          role.toLowerCase() == "reseller" ||
                          role.toLowerCase() == "vip")
                        _drawerItem(Icons.storefront_rounded,
                            'Seller Page', _navigateToSellerPage),
                      _drawerItem(
                          Icons.lock_clock_rounded, 'Ganti Password', () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChangePasswordPage(
                                username: username,
                                sessionKey: sessionKey),
                          ),
                        );
                      }),
                      _drawerItem(Icons.badge_rounded, 'NIK Check', () {
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const NikCheckerPage()));
                      }),
                      _drawerItem(
                          Icons.bug_report_rounded, 'Bug Sender', () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BugSenderPage(
                                sessionKey: sessionKey,
                                username: username,
                                role: role),
                          ),
                        );
                      }),
                      _drawerItem(
                          Icons.music_note_rounded, 'Music Player', () {
                        Navigator.pop(context);
                        setState(() {
                          _selectedPage = MusikPage(
                              sharedPlayer: _audioPlayer,
                              initialTrack: _currentTrack);
                          _bottomNavIndex = 0;
                        });
                      }),
                      _drawerItem(
                          Icons.camera_alt_rounded, 'ATOMIC X GRAM', () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => StatusPage(
                                username: username,
                                sessionKey: sessionKey,
                                role: role),
                          ),
                        ).then((_) => _fetchStatusPreview());
                      }),
                      _drawerItem(
                          Icons.mosque_rounded, 'Jadwal Sholat', () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const JadwalSholatPage(),
                          ),
                        ).then((_) => _fetchJadwalSholat().catchError((_) {}));
                      }),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Container(
                          height: 1,
                          color: Colors.white.withOpacity(0.15),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: GlassPalette.red.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: GlassPalette.red.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.red.withOpacity(0.4),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: ListTile(
                          leading: const Icon(Icons.logout_rounded,
                              color: GlassPalette.white, size: 20),
                          title: Text(
                            'Logout',
                            style: GlassFont.pixel(
                              size: 10,
                              weight: FontWeight.w700,
                              color: GlassPalette.white,
                            ),
                          ),
                          onTap: () {
                            Navigator.pop(context);
                            _showLogoutDialog();
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                      Center(
                        child: Column(
                          children: [
                            Text(
                              "CREDITS",
                              style: GlassFont.pixel(
                                size: 9,
                                weight: FontWeight.w700,
                                color: GlassPalette.textDim,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "@axleyfaker [ Developer ]",
                              style: GlassFont.body(
                                size: 10,
                                weight: FontWeight.w500,
                                color: GlassPalette.textDim,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "@maklowhampsss [ CHANNEL ]",
                              style: GlassFont.body(
                                size: 10,
                                weight: FontWeight.w500,
                                color: GlassPalette.textDim,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      child: ListTile(
        dense: true,
        leading: Icon(icon, color: GlassPalette.white, size: 19),
        title: Text(
          title,
          style: GlassFont.body(
            size: 12,
            weight: FontWeight.w500,
            color: GlassPalette.white,
          ),
        ),
        trailing: const Icon(Icons.arrow_forward_ios_rounded,
            color: GlassPalette.textDim, size: 12),
        onTap: onTap,
      ),
    );
  }

  void _showLogoutDialog() {
    GlassDialog.show(
      context,
      title: 'Logout',
      message: 'Yakin ingin logout?',
      icon: Icons.logout_rounded,
      accentColor: GlassPalette.red,
      actions: [
        GlassButton(
          text: 'Batal',
          fullWidth: false,
          bgColor: Colors.white,
          onTap: () => Navigator.pop(context),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        ),
        const SizedBox(width: 8),
        GlassButton(
          text: 'Logout',
          fullWidth: false,
          bgColor: GlassPalette.red,
          textColor: GlassPalette.white,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          onTap: () async {
            Navigator.pop(context);
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (!mounted) return;
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (r) => false,
            );
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBody: true,
      extendBodyBehindAppBar: true,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: _selectedPage,
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// KARAKTER AYUNAN
// ═══════════════════════════════════════════════════════════════════════════
class _KarakterAyunanDashboard extends StatefulWidget {
  final String imageUrl;
  final double size;

  const _KarakterAyunanDashboard({
    required this.imageUrl,
    this.size = 160,
  });

  @override
  State<_KarakterAyunanDashboard> createState() =>
      _KarakterAyunanDashboardState();
}

class _KarakterAyunanDashboardState extends State<_KarakterAyunanDashboard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _swingAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    )..repeat(reverse: true);

    _swingAnim = Tween<double>(begin: -0.14, end: 0.14).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, child) {
        return Transform.rotate(
          angle: _swingAnim.value,
          alignment: Alignment.topCenter,
          child: child,
        );
      },
      child: Image.network(
        widget.imageUrl,
        width: widget.size,
        height: widget.size,
        fit: BoxFit.contain,
        loadingBuilder: (_, child, progress) {
          if (progress == null) return child;
          return SizedBox(
            width: widget.size,
            height: widget.size,
            child: const Center(
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    color: GlassPalette.white, strokeWidth: 2),
              ),
            ),
          );
        },
        errorBuilder: (_, __, ___) => SizedBox(
          width: widget.size,
          height: widget.size,
          child: const Center(
            child: Icon(Icons.broken_image_rounded,
                color: GlassPalette.textDim, size: 30),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NAV BAR ITEM (legacy)
// ═══════════════════════════════════════════════════════════════════════════
class _NavBarItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _NavBarItem({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  State<_NavBarItem> createState() => _NavBarItemState();
}

class _NavBarItemState extends State<_NavBarItem> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.active
        ? GlassPalette.white
        : GlassPalette.textDim;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        transform:
            Matrix4.translationValues(_down ? 2 : 0, _down ? 2 : 0, 0),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: BoxDecoration(
          color: widget.active
              ? Colors.white.withOpacity(0.15)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: widget.active
                ? Colors.white.withOpacity(0.3)
                : Colors.transparent,
            width: 1.2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon, color: color, size: 20),
            const SizedBox(height: 3),
            Text(
              widget.label,
              style: GlassFont.pixel(
                size: 8,
                weight: FontWeight.w700,
                color: color,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NewsMedia
// ═══════════════════════════════════════════════════════════════════════════
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.white.withOpacity(0.1),
        child:
            const Icon(Icons.broken_image, color: GlassPalette.textDim),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ATOMIC X PROJECT — Logo AppBar
// ═══════════════════════════════════════════════════════════════════════════
class _AtomicXProjectLogo extends StatelessWidget {
  const _AtomicXProjectLogo();

  @override
  Widget build(BuildContext context) {
    const Color atomicColor = GlassPalette.blue;
    const Color xColor = GlassPalette.red;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1.2,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Transform(
            transform: Matrix4.skewX(-0.25),
            alignment: Alignment.center,
            child: Text(
              'ATOMIC',
              style: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w900,
                color: atomicColor,
                letterSpacing: 1.2,
                shadows: [
                  Shadow(
                    color: atomicColor.withOpacity(0.6),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 4),
          Transform(
            transform: Matrix4.skewX(-0.25),
            alignment: Alignment.center,
            child: Text(
              'X PROJECT',
              style: GlassFont.pixel(
                size: 10,
                weight: FontWeight.w900,
                color: xColor,
                letterSpacing: 1.2,
                shadows: [
                  Shadow(
                    color: xColor.withOpacity(0.6),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}