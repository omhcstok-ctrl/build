// landing.dart
// ═══════════════════════════════════════════════════════════════════════════
// LANDING PAGE — GLASSMORPHISM EDITION + FULL SCREEN
// + FIX: Tombol MASUK di fingerprint entry page dihapus
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_config.dart';
import 'glass_theme.dart';

// ═══════════════════════════════════════════════════════════════════════════
// PALETTE — GLASS
// ═══════════════════════════════════════════════════════════════════════════
class _C {
  static const bg = GlassPalette.bg;
  static const bg2 = GlassPalette.surface;
  static const surface = GlassPalette.surface;
  static const card = GlassPalette.surface;
  static const cardAlt = GlassPalette.surfaceAlt;
  static const border = GlassPalette.border;
  static const borderMid = GlassPalette.borderLit;
  static const red = GlassPalette.red;
  static const redMid = GlassPalette.red;
  static const redLight = GlassPalette.redHot;
  static const text = GlassPalette.text;
  static const textSub = GlassPalette.textSub;
  static const textDim = GlassPalette.textDim;
  static const white = GlassPalette.white;
  static const green = GlassPalette.teal;
  static const tele = Color(0xFF2AABEE);
  static const blue = GlassPalette.blue;
  static const purple = GlassPalette.purple;
  static const cyan = GlassPalette.cyan;
}

// ═══════════════════════════════════════════════════════════════════════════
// LANDING PAGE
// ═══════════════════════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  static const String kOwnerTelegram = 'axleyfaker';
  static const String kBotTelegram = 'projectatomic_bot';
  static const String kOwnerWhatsapp = '6285809493530';

  static const String kBgAsset = 'assets/images/bg_glass.jpg';

  bool _fingerprintDone = false;
  int _currentCard = 0;

  bool _serverTrialEnabled = true;

  late VideoPlayerController _vidCtrl;
  bool _videoReady = false;

  final _trialUserCtrl = TextEditingController();
  final _trialPassCtrl = TextEditingController();
  final _trialPassCtrl2 = TextEditingController();
  bool _trialLoading = false;
  bool _trialObscure = true;

  late AnimationController _cardAnimCtrl;
  late Animation<double> _cardFade;

  @override
  void initState() {
    super.initState();

    // FULLSCREEN — immersive
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarDividerColor: Colors.transparent,
    ));

    _cardAnimCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _cardFade =
        CurvedAnimation(parent: _cardAnimCtrl, curve: Curves.easeOut);
    _cardAnimCtrl.forward();

    _vidCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _vidCtrl.setLooping(true);
        _vidCtrl.setVolume(0);
        _vidCtrl.play();
      }).catchError((e) {
        if (mounted) setState(() => _videoReady = false);
      });
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: GlassPalette.bg,
      systemNavigationBarIconBrightness: Brightness.light,
    ));

    _vidCtrl.dispose();
    _cardAnimCtrl.dispose();
    _trialUserCtrl.dispose();
    _trialPassCtrl.dispose();
    _trialPassCtrl2.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  Future<void> _openTelegram(String message, {String? username}) async {
    final target = username ?? kOwnerTelegram;
    final encoded = Uri.encodeComponent(message);
    final tgUri = Uri.parse('https://t.me/$target?text=$encoded');
    final tgApp = Uri.parse('tg://resolve?domain=$target');
    try {
      if (await canLaunchUrl(tgApp)) {
        await launchUrl(tgApp, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(tgUri)) {
        await launchUrl(tgUri, mode: LaunchMode.externalApplication);
      } else {
        _showErr('Gagal buka Telegram. Pastikan Telegram terinstall.');
      }
    } catch (_) {
      _showErr('Gagal buka Telegram.');
    }
  }

  void _nextCard() {
    if (_currentCard < 2) {
      setState(() => _currentCard++);
      _cardAnimCtrl.forward(from: 0);
    } else {
      Navigator.pushNamed(context, '/login');
    }
  }

  void _prevCard() {
    if (_currentCard > 0) {
      setState(() => _currentCard--);
      _cardAnimCtrl.forward(from: 0);
    }
  }

  void _showErr(String msg) {
    GlassDialog.show(
      context,
      title: 'Error',
      message: msg,
      icon: Icons.warning_amber_rounded,
      accentColor: GlassPalette.red,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_fingerprintDone) {
      return _FingerprintEntryPage(
        videoController: _vidCtrl,
        videoReady: _videoReady,
        onScanComplete: () {
          setState(() => _fingerprintDone = true);
          _cardAnimCtrl.forward(from: 0);
        },
        onTrialTap: _showTrialSheet,
        onBuyTap: () => _openTelegram('', username: kBotTelegram),
      );
    }

    return Scaffold(
      backgroundColor: GlassPalette.bg,
      // FULLSCREEN — konten sampai ke status bar & navbar
      extendBody: true,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: kBgAsset,
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: FadeTransition(
            opacity: _cardFade,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0.15, 0),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(
                      parent: anim, curve: Curves.easeOutCubic)),
                  child: child,
                ),
              ),
              child: _buildCurrentCard(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentCard() {
    switch (_currentCard) {
      case 0:
        return _buildWelcomeCard(key: const ValueKey('welcome'));
      case 1:
        return _buildOwnerCard(key: const ValueKey('owner'));
      case 2:
        return _buildThanksCard(key: const ValueKey('thanks'));
      default:
        return const SizedBox();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // CARD 1 — WELCOME
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildWelcomeCard({Key? key}) {
    return SingleChildScrollView(
      key: key,
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: MediaQuery.of(context).padding.bottom + 20,
        left: 24,
        right: 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _progressBadge(1),
          const SizedBox(height: 30),
          _pulsingHexagon(),
          const SizedBox(height: 30),
          _ShimmerText(
            text: 'SELAMAT DATANG',
            style: GlassFont.pixel(
              size: 20,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 3,
              height: 1.2,
            ),
            delay: const Duration(milliseconds: 200),
          ),
          const SizedBox(height: 14),
          _ScaleBounce(
            delay: const Duration(milliseconds: 500),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: Text(
                'KE ATOMIC X PROJECT',
                style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          GlassCard(
            borderWidth: 1.5,
            radius: 22,
            padding: const EdgeInsets.all(20),
            child: _TypewriterText(
              text: 'Halo, Sobat ATOMIC! 👋\n\n'
                  'Senang banget kamu udah mampir ke aplikasi kami. '
                  'Semoga hari kamu cerah dan semua urusan lancar ya. '
                  'Jangan ragu buat explore semua fitur yang udah kami '
                  'siapin buat kamu. Selamat mencoba! ✨',
              style: GlassFont.body(
                size: 13,
                weight: FontWeight.w500,
                color: GlassPalette.textSub,
                height: 1.7,
              ),
              charDelay: const Duration(milliseconds: 25),
            ),
          ),
          const SizedBox(height: 34),
          _buildNextButton(label: 'Lanjut', onTap: _nextCard),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // CARD 2 — OWNER
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildOwnerCard({Key? key}) {
    return SingleChildScrollView(
      key: key,
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: MediaQuery.of(context).padding.bottom + 20,
        left: 24,
        right: 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _progressBadge(2),
          const SizedBox(height: 30),
          _pulsingIcon(Icons.person_rounded),
          const SizedBox(height: 30),
          _FadeSlideIn(
            delay: const Duration(milliseconds: 200),
            child: Text(
              'MEET THE DEVELOPER',
              textAlign: TextAlign.center,
              style: GlassFont.pixel(
                size: 14,
                weight: FontWeight.w700,
                color: GlassPalette.text,
                letterSpacing: 2,
                height: 1.4,
                shadows: const [
                  Shadow(color: Color(0x662AABEE), blurRadius: 12),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          _ScaleBounce(
            delay: const Duration(milliseconds: 500),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.7),
                  width: 1.2,
                ),
                boxShadow: const [
                  BoxShadow(color: Color(0x442AABEE), blurRadius: 15),
                ],
              ),
              child: Text(
                'OWNER ATOMIC',
                style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          GlassCard(
            borderWidth: 1.5,
            radius: 22,
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                _StaggeredFade(
                  delay: const Duration(milliseconds: 0),
                  child: _dataRow(Icons.person_rounded, 'Nama', 'Axley'),
                ),
                _divider(),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 150),
                  child: _dataRow(Icons.phone_rounded, 'WhatsApp',
                      '+62 858-0949-3530'),
                ),
                _divider(),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 300),
                  child: _dataRow(
                      FontAwesomeIcons.telegram, 'Telegram', '@axleyfaker'),
                ),
                _divider(),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 450),
                  child: _dataRow(
                      Icons.location_on_rounded, 'Lokasi', 'Indonesia 🇮🇩'),
                ),
                _divider(),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 600),
                  child: _dataRow(Icons.workspace_premium_rounded, 'Role',
                      'Owner & Developer'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          _StaggeredFade(
            delay: const Duration(milliseconds: 750),
            child: Row(
              children: [
                Expanded(
                  child: _socialBtn(
                    FontAwesomeIcons.telegram,
                    'Telegram',
                    _C.tele,
                    () => _openUrl('https://t.me/$kOwnerTelegram'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _socialBtn(
                    FontAwesomeIcons.whatsapp,
                    'WhatsApp',
                    _C.green,
                    () => _openUrl('https://wa.me/$kOwnerWhatsapp'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          _buildNavRow(onBack: _prevCard, onNext: _nextCard),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // CARD 3 — TERIMA KASIH
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildThanksCard({Key? key}) {
    return SingleChildScrollView(
      key: key,
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: MediaQuery.of(context).padding.bottom + 20,
        left: 24,
        right: 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _progressBadge(3),
          const SizedBox(height: 30),
          _pulsingIcon(Icons.star_rounded, rotate: true),
          const SizedBox(height: 30),
          _GradientFlowText(
            text: 'TERIMA KASIH',
            colors: const [
              GlassPalette.blue,
              GlassPalette.purple,
              GlassPalette.cyan,
              GlassPalette.blue,
            ],
            style: GlassFont.pixel(
              size: 18,
              weight: FontWeight.w700,
              letterSpacing: 3,
              height: 1.3,
            ),
            delay: const Duration(milliseconds: 200),
          ),
          const SizedBox(height: 14),
          _ScaleBounce(
            delay: const Duration(milliseconds: 500),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: GlassPalette.purple.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.purple.withOpacity(0.7),
                  width: 1.2,
                ),
                boxShadow: const [
                  BoxShadow(color: Color(0x669C27FF), blurRadius: 15),
                ],
              ),
              child: Text(
                'From Axley 💙',
                style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          _RotateIn(
            delay: const Duration(milliseconds: 600),
            child: GlassCard(
              borderWidth: 1.5,
              radius: 22,
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    '"Jangan takut mencoba hal baru,\n'
                    'karena di setiap langkah ada\n'
                    'pelajaran yang berharga."',
                    textAlign: TextAlign.center,
                    style: GlassFont.body(
                      size: 13,
                      weight: FontWeight.w500,
                      color: GlassPalette.text,
                      height: 1.7,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '— Axley',
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.textSub,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          GlassCard(
            borderWidth: 1.5,
            radius: 22,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _StaggeredFade(
                  delay: const Duration(milliseconds: 800),
                  child: Text(
                    'Terima kasih banyak ya udah mempercayai aplikasi '
                    'yang saya buat.',
                    style: GlassFont.body(
                      size: 12,
                      weight: FontWeight.w400,
                      color: GlassPalette.textSub,
                      height: 1.6,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 1000),
                  child: Text(
                    'Semoga aplikasi ini bisa bantu aktivitas kamu '
                    'sehari-hari. Kalau ada kendala atau pertanyaan, '
                    'jangan ragu hubungi saya ya.',
                    style: GlassFont.body(
                      size: 12,
                      weight: FontWeight.w400,
                      color: GlassPalette.textSub,
                      height: 1.6,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _StaggeredFade(
                  delay: const Duration(milliseconds: 1200),
                  child: Text(
                    'Selamat menggunakan & semoga sukses selalu! ✨',
                    style: GlassFont.body(
                      size: 12,
                      weight: FontWeight.w700,
                      color: GlassPalette.text,
                      height: 1.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          _GlowButton(
            label: 'Lanjut Login',
            icon: Icons.login_rounded,
            onTap: _nextCard,
          ),
          const SizedBox(height: 12),
          _buildBackButton(onTap: _prevCard),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // WIDGET HELPERS
  // ═══════════════════════════════════════════════════════════════════════
  Widget _progressBadge(int n) {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: GlassPalette.blue.withOpacity(0.25),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: GlassPalette.blue.withOpacity(0.6),
            width: 1.2,
          ),
          boxShadow: const [
            BoxShadow(color: Color(0x442AABEE), blurRadius: 12),
          ],
        ),
        child: Text(
          '$n / 3',
          style: GlassFont.pixel(
            size: 9,
            weight: FontWeight.w700,
            color: GlassPalette.white,
          ),
        ),
      ),
    );
  }

  Widget _pulsingHexagon() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.3, end: 1.0),
      duration: const Duration(seconds: 2),
      curve: Curves.easeInOut,
      builder: (_, v, __) => Container(
        width: 110,
        height: 110,
        decoration: BoxDecoration(
          color: GlassPalette.blue.withOpacity(0.15 + v * 0.15),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: GlassPalette.blue.withOpacity(0.5 + v * 0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: GlassPalette.blue.withOpacity(0.3 + v * 0.3),
              blurRadius: 20 + v * 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: const Icon(Icons.hexagon_rounded,
            color: GlassPalette.white, size: 60),
      ),
    );
  }

  Widget _pulsingIcon(IconData icon, {bool rotate = false}) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.3, end: 1.0),
      duration: const Duration(seconds: 2),
      curve: Curves.easeInOut,
      builder: (_, v, __) => Transform.rotate(
        angle: rotate ? v * 0.15 : 0,
        child: Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            color: GlassPalette.purple.withOpacity(0.15 + v * 0.15),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: GlassPalette.purple.withOpacity(0.5 + v * 0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: GlassPalette.purple.withOpacity(0.3 + v * 0.3),
                blurRadius: 20 + v * 20,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Icon(icon, color: GlassPalette.white, size: 50),
        ),
      ),
    );
  }

  Widget _dataRow(dynamic icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          icon is IconData
              ? Icon(icon, color: GlassPalette.white, size: 18)
              : FaIcon(icon as IconData,
                  color: GlassPalette.white, size: 16),
          const SizedBox(width: 14),
          Text(
            label,
            style: GlassFont.body(
              size: 12,
              weight: FontWeight.w500,
              color: GlassPalette.textSub,
            ),
          ),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() => Container(
        height: 1,
        color: Colors.white.withOpacity(0.1),
      );

  Widget _socialBtn(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: color.withOpacity(0.5),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.35),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: color, size: 17),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNextButton(
      {required String label, required VoidCallback onTap}) {
    return GlassButton(
      text: label,
      icon: Icons.arrow_forward_rounded,
      onTap: onTap,
      bgColor: GlassPalette.blue,
      textColor: GlassPalette.white,
      padding: const EdgeInsets.symmetric(vertical: 16),
      fontSize: 12,
    );
  }

  Widget _buildBackButton({required VoidCallback onTap}) {
    return GlassButton(
      text: 'Balik',
      icon: Icons.arrow_back_rounded,
      onTap: onTap,
      bgColor: Colors.white,
      textColor: GlassPalette.white,
      padding: const EdgeInsets.symmetric(vertical: 14),
      fontSize: 11,
    );
  }

  Widget _buildNavRow(
      {required VoidCallback onBack, required VoidCallback onNext}) {
    return Row(
      children: [
        Expanded(
          child: GlassButton(
            text: 'Balik',
            icon: Icons.arrow_back_rounded,
            onTap: onBack,
            bgColor: Colors.white,
            textColor: GlassPalette.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            fontSize: 10,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 2,
          child: GlassButton(
            text: 'Lanjut',
            icon: Icons.arrow_forward_rounded,
            onTap: onNext,
            bgColor: GlassPalette.blue,
            textColor: GlassPalette.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // TRIAL SHEET
  // ═══════════════════════════════════════════════════════════════════════
  void _showTrialSheet() {
    _trialUserCtrl.clear();
    _trialPassCtrl.clear();
    _trialPassCtrl2.clear();
    setState(() => _trialLoading = false);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildTrialSheet(),
    );
  }

  Widget _buildTrialSheet() {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border(
                top: BorderSide(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.5,
                ),
              ),
            ),
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 18),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.card_giftcard_rounded,
                          color: GlassPalette.white, size: 22),
                      const SizedBox(width: 10),
                      Text(
                        'FREE TRIAL 1 HARI',
                        style: GlassFont.pixel(
                          size: 12,
                          weight: FontWeight.w700,
                          color: GlassPalette.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.15),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: GlassPalette.blue.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: GlassPalette.blue.withOpacity(0.5),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline_rounded,
                            color: GlassPalette.white, size: 16),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Bikin akun trial gratis, aktif 1 hari. Fitur terbatas.',
                            style: GlassFont.body(
                              size: 11,
                              weight: FontWeight.w500,
                              color: GlassPalette.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  GlassInput(
                    controller: _trialUserCtrl,
                    hint: 'Username (min 4 karakter)',
                    icon: Icons.person_outline_rounded,
                  ),
                  const SizedBox(height: 12),
                  GlassInput(
                    controller: _trialPassCtrl,
                    hint: 'Password (min 6 karakter)',
                    icon: Icons.lock_outline_rounded,
                    obscure: _trialObscure,
                    suffix: IconButton(
                      icon: Icon(
                        _trialObscure
                            ? Icons.visibility_off
                            : Icons.visibility,
                        color: GlassPalette.white,
                        size: 18,
                      ),
                      onPressed: () =>
                          setState(() => _trialObscure = !_trialObscure),
                    ),
                  ),
                  const SizedBox(height: 12),
                  GlassInput(
                    controller: _trialPassCtrl2,
                    hint: 'Konfirmasi Password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _trialObscure,
                  ),
                  const SizedBox(height: 20),
                  GlassButton(
                    text: _trialLoading ? 'LOADING...' : 'BUAT AKUN TRIAL',
                    icon: _trialLoading ? null : Icons.rocket_launch_rounded,
                    isLoading: _trialLoading,
                    onTap: _trialLoading ? null : _submitTrial,
                    bgColor: GlassPalette.blue,
                    textColor: GlassPalette.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    fontSize: 11,
                  ),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 8),
                      child: Text(
                        'Tutup',
                        style: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w600,
                          color: GlassPalette.textDim,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _submitTrial() async {
    final u = _trialUserCtrl.text.trim();
    final p = _trialPassCtrl.text.trim();
    final p2 = _trialPassCtrl2.text.trim();

    if (u.length < 4) {
      _showErr('Username minimal 4 karakter.');
      return;
    }
    if (p.length < 6) {
      _showErr('Password minimal 6 karakter.');
      return;
    }
    if (p != p2) {
      _showErr('Konfirmasi password tidak cocok.');
      return;
    }
    if (!RegExp(r'^[a-zA-Z0-9_]+$').hasMatch(u)) {
      _showErr('Username hanya boleh huruf, angka, dan underscore.');
      return;
    }

    setState(() => _trialLoading = true);

    if (_serverTrialEnabled) {
      try {
        final deviceInfo = await DeviceInfoPlugin().androidInfo;
        final androidId = deviceInfo.id;

        final res = await http.post(
          Uri.parse('$kBaseUrl/createTrial'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'username': u,
            'password': p,
            'androidId': androidId,
            'role': 'trial',
            'duration': 1,
            'version': '3.0',
          }),
        ).timeout(const Duration(seconds: 15));

        Map<String, dynamic>? data;
        try {
          data = jsonDecode(res.body);
        } catch (_) {
          data = null;
        }

        if (data != null && data['valid'] == true) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('username', data['username'] ?? u);
          await prefs.setString('password', data['password'] ?? p);

          if (!mounted) return;
          Navigator.pop(context);
          _showSuccessDialog(
            title: 'Trial Berhasil Dibuat!',
            username: data['username'] ?? u,
            password: data['password'] ?? p,
            expiredDate: data['expiredDate'] ?? '-',
            message:
                data['message'] ?? 'Akun trial aktif 1 hari. Silakan login.',
          );
          return;
        } else if (data != null && data['valid'] == false) {
          final msg = data['message'] ?? 'Gagal membuat trial. Coba lagi nanti.';
          if (!mounted) return;
          Navigator.pop(context);
          _showErr(msg);
          return;
        }
      } catch (_) {}
    }

    try {
      final msg = 'Halo min, saya mau daftar FREE TRIAL 1 HARI di ATOMIC.\n\n'
          'Username: $u\n'
          'Password: $p\n\n'
          'Mohon dibuatkan akun trial 🙏';
      final encoded = Uri.encodeComponent(msg);
      final tgUri = Uri.parse('https://t.me/$kOwnerTelegram?text=$encoded');
      final tgApp = Uri.parse('tg://resolve?domain=$kOwnerTelegram');

      if (!mounted) return;
      Navigator.pop(context);

      if (await canLaunchUrl(tgApp)) {
        await launchUrl(tgApp, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(tgUri)) {
        await launchUrl(tgUri, mode: LaunchMode.externalApplication);
      } else {
        _showErr('Gagal buka Telegram. Pastikan Telegram terinstall.');
      }
    } catch (_) {
      if (!mounted) return;
      Navigator.pop(context);
      _showErr('Gagal konek ke server & gagal buka Telegram.');
    } finally {
      if (mounted) setState(() => _trialLoading = false);
    }
  }

  void _showSuccessDialog({
    required String title,
    required String username,
    required String password,
    required String expiredDate,
    required String message,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: GlassCard(
          borderWidth: 1.5,
          shadowOffset: const Offset(0, 10),
          padding: const EdgeInsets.all(22),
          radius: 22,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  color: GlassPalette.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: GlassPalette.teal.withOpacity(0.7),
                    width: 1.5,
                  ),
                  boxShadow: const [
                    BoxShadow(color: Color(0x6600E5FF), blurRadius: 20),
                  ],
                ),
                child: const Icon(Icons.check_circle_rounded,
                    color: GlassPalette.white, size: 36),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                  letterSpacing: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                message,
                style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w500,
                  color: GlassPalette.textSub,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
                child: Column(
                  children: [
                    _infoRow('Username', username),
                    const SizedBox(height: 8),
                    _infoRow('Password', password),
                    const SizedBox(height: 8),
                    _infoRow('Expired', expiredDate),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              GlassButton(
                text: 'LOGIN SEKARANG',
                icon: Icons.login_rounded,
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/login');
                },
                bgColor: GlassPalette.blue,
                textColor: GlassPalette.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                fontSize: 11,
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Tutup',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w600,
                    color: GlassPalette.textDim,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      children: [
        Text(
          label,
          style: GlassFont.body(
            size: 11,
            weight: FontWeight.w500,
            color: GlassPalette.textDim,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: GlassFont.body(
            size: 12,
            weight: FontWeight.w700,
            color: GlassPalette.text,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// FINGERPRINT ENTRY PAGE — FULLSCREEN
// ═══════════════════════════════════════════════════════════════════════════
class _FingerprintEntryPage extends StatefulWidget {
  final VideoPlayerController videoController;
  final bool videoReady;
  final VoidCallback onScanComplete;
  final VoidCallback onTrialTap;
  final VoidCallback onBuyTap;

  const _FingerprintEntryPage({
    required this.videoController,
    required this.videoReady,
    required this.onScanComplete,
    required this.onTrialTap,
    required this.onBuyTap,
  });

  @override
  State<_FingerprintEntryPage> createState() => _FingerprintEntryPageState();
}

class _FingerprintEntryPageState extends State<_FingerprintEntryPage>
    with TickerProviderStateMixin {
  bool _scanning = false;
  bool _scanSuccess = false;
  bool _isTouching = false;

  late AnimationController _scanLineCtrl;
  late Animation<double> _scanLineAnim;
  late AnimationController _ringCtrl;
  late AnimationController _rippleCtrl;

  @override
  void initState() {
    super.initState();
    _scanLineCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _scanLineAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanLineCtrl, curve: Curves.easeInOut),
    );

    _ringCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat();

    _rippleCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat();
  }

  @override
  void dispose() {
    _scanLineCtrl.dispose();
    _ringCtrl.dispose();
    _rippleCtrl.dispose();
    super.dispose();
  }

  void _startScan() {
    if (_scanning || _scanSuccess) return;
    setState(() {
      _scanning = true;
      _scanSuccess = false;
      _isTouching = true;
    });
    _scanLineCtrl.reset();
    _scanLineCtrl.forward().then((_) {
      if (_isTouching && _scanning && mounted) {
        setState(() {
          _scanSuccess = true;
          _scanning = false;
          _isTouching = false;
        });
        Future.delayed(
            const Duration(milliseconds: 1000), widget.onScanComplete);
      }
    });
  }

  void _cancelScan() {
    if (_scanning && !_scanSuccess) {
      setState(() {
        _scanning = false;
        _isTouching = false;
      });
      _scanLineCtrl.stop();
      _scanLineCtrl.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final topPadding = mediaQuery.padding.top;
    final bottomPadding = mediaQuery.padding.bottom;

    return Scaffold(
      backgroundColor: GlassPalette.bg,
      // FULLSCREEN — edge to edge
      extendBody: true,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: _LandingPageState.kBgAsset,
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: topPadding + 12,
              bottom: bottomPadding + 12,
              left: 22,
              right: 22,
            ),
            child: Column(
              children: [
                GlassCard(
                  padding: EdgeInsets.zero,
                  borderWidth: 1.5,
                  radius: 20,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: _buildVideo(),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                // ═══ TOMBOL TRANSPARAN ═══
                _glassActionBtn(
                  label: 'FREE TRIAL 1 HARI',
                  icon: Icons.card_giftcard_rounded,
                  onTap: widget.onTrialTap,
                ),
                const SizedBox(height: 12),
                _glassActionBtn(
                  label: 'BELI AKSES',
                  icon: Icons.shopping_bag_outlined,
                  onTap: widget.onBuyTap,
                ),
                const SizedBox(height: 36),
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: GlassPalette.blue.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: GlassPalette.blue.withOpacity(0.6),
                      width: 1.5,
                    ),
                    boxShadow: const [
                      BoxShadow(color: Color(0x662AABEE), blurRadius: 20),
                    ],
                  ),
                  child: const Icon(Icons.lock_outline_rounded,
                      size: 42, color: GlassPalette.white),
                ),
                const SizedBox(height: 20),
                Text(
                  'Verifikasi Sidik Jari',
                  style: GlassFont.pixel(
                    size: 14,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1.5,
                    shadows: const [
                      Shadow(color: Color(0x662AABEE), blurRadius: 12),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'ATOMIC X PROJECT • Sistem Digital',
                  style: GlassFont.body(
                    size: 11,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                ),
                const SizedBox(height: 30),
                GestureDetector(
                  onTapDown: (_) => _startScan(),
                  onTapUp: (_) => _cancelScan(),
                  onTapCancel: _cancelScan,
                  child: _buildFingerprint(),
                ),
                const SizedBox(height: 18),
                _buildStatusText(),
                if (_scanning) ...[
                  const SizedBox(height: 16),
                  _buildScanEffect(),
                ],
                if (_scanSuccess) ...[
                  const SizedBox(height: 16),
                  _buildSuccessEffect(),
                ],
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVideo() {
    if (!widget.videoReady || !widget.videoController.value.isInitialized) {
      return Container(
        color: Colors.white.withOpacity(0.05),
        child: const Center(
          child: CircularProgressIndicator(
              color: GlassPalette.white, strokeWidth: 2),
        ),
      );
    }
    return FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(
        width: widget.videoController.value.size.width,
        height: widget.videoController.value.size.height,
        child: VideoPlayer(widget.videoController),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // TOMBOL TRANSPARAN (GLASS STYLE)
  // ═══════════════════════════════════════════════════════════════════════
  Widget _glassActionBtn({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: GlassPalette.white, size: 18),
                const SizedBox(width: 10),
                Text(
                  label.toUpperCase(),
                  style: GlassFont.pixel(
                    size: 11,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                    letterSpacing: 1.5,
                    shadows: [
                      Shadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFingerprint() {
    return Stack(
      alignment: Alignment.center,
      children: [
        if (_scanning)
          AnimatedBuilder(
            animation: _rippleCtrl,
            builder: (_, __) {
              final size = 80 + _rippleCtrl.value * 60;
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(
                        0.5 * (1 - _rippleCtrl.value)),
                    width: 2,
                  ),
                ),
              );
            },
          ),
        if (_scanning)
          AnimatedBuilder(
            animation: _rippleCtrl,
            builder: (_, __) {
              final size = 80 + _rippleCtrl.value * 100;
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: GlassPalette.purple.withOpacity(
                        0.3 * (1 - _rippleCtrl.value)),
                    width: 1.5,
                  ),
                ),
              );
            },
          ),
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            color: _scanSuccess
                ? GlassPalette.teal.withOpacity(0.3)
                : GlassPalette.blue.withOpacity(0.25),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: _scanSuccess
                  ? GlassPalette.teal.withOpacity(0.8)
                  : GlassPalette.blue.withOpacity(0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _scanSuccess
                    ? GlassPalette.teal.withOpacity(0.6)
                    : GlassPalette.blue.withOpacity(0.5),
                blurRadius: 25,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Icon(
            _scanSuccess ? Icons.check_circle : Icons.fingerprint,
            color: GlassPalette.white,
            size: 50,
          ),
        ),
      ],
    );
  }

  Widget _buildScanEffect() {
    return Column(
      children: [
        Container(
          width: 180,
          height: 6,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(3),
            border: Border.all(
                color: Colors.white.withOpacity(0.2), width: 1),
          ),
          child: AnimatedBuilder(
            animation: _scanLineAnim,
            builder: (_, __) => FractionallySizedBox(
              heightFactor: 1,
              widthFactor: _scanLineAnim.value,
              alignment: Alignment.centerLeft,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  gradient: const LinearGradient(
                    colors: [GlassPalette.blue, GlassPalette.purple],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSuccessEffect() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      builder: (_, v, __) => Container(
        width: 180,
        height: 6,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
              color: Colors.white.withOpacity(0.2), width: 1),
        ),
        child: FractionallySizedBox(
          heightFactor: 1,
          widthFactor: v,
          alignment: Alignment.centerLeft,
          child: Container(
            decoration: BoxDecoration(
              color: GlassPalette.teal,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusText() {
    String text;
    if (_scanSuccess) {
      text = '✓ Scan Berhasil!';
    } else if (_scanning) {
      text = 'Memindai...';
    } else {
      text = 'Sentuh layar untuk memindai';
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Text(
        text,
        key: ValueKey(text),
        style: GlassFont.body(
          size: 13,
          weight: FontWeight.w700,
          color: _scanSuccess ? GlassPalette.teal : GlassPalette.white,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ANIMATED TEXT WIDGETS
// ═══════════════════════════════════════════════════════════════════════════

class _TypewriterText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final Duration charDelay;

  const _TypewriterText({
    required this.text,
    required this.style,
    this.charDelay = const Duration(milliseconds: 30),
  });

  @override
  State<_TypewriterText> createState() => _TypewriterTextState();
}

class _TypewriterTextState extends State<_TypewriterText> {
  String _displayed = '';
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTyping();
  }

  void _startTyping() {
    int i = 0;
    _timer = Timer.periodic(widget.charDelay, (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (i < widget.text.length) {
        setState(() => _displayed = widget.text.substring(0, i + 1));
        i++;
      } else {
        t.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Text(_displayed, style: widget.style);
  }
}

class _ShimmerText extends StatefulWidget {
  final String text;
  final TextStyle style;
  final Duration delay;

  const _ShimmerText({
    required this.text,
    required this.style,
    this.delay = Duration.zero,
  });

  @override
  State<_ShimmerText> createState() => _ShimmerTextState();
}

class _ShimmerTextState extends State<_ShimmerText>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.repeat();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => ShaderMask(
        shaderCallback: (bounds) => LinearGradient(
          colors: const [
            GlassPalette.blue,
            GlassPalette.cyan,
            GlassPalette.purple,
            GlassPalette.blue,
          ],
          stops: [
            (_ctrl.value - 0.3).clamp(0.0, 1.0),
            _ctrl.value.clamp(0.0, 1.0),
            (_ctrl.value + 0.15).clamp(0.0, 1.0),
            (_ctrl.value + 0.3).clamp(0.0, 1.0),
          ],
        ).createShader(bounds),
        child: Text(widget.text,
            style: widget.style.copyWith(color: Colors.white),
            textAlign: TextAlign.center),
      ),
    );
  }
}

class _GradientFlowText extends StatefulWidget {
  final String text;
  final List<Color> colors;
  final TextStyle style;
  final Duration delay;

  const _GradientFlowText({
    required this.text,
    required this.colors,
    required this.style,
    this.delay = Duration.zero,
  });

  @override
  State<_GradientFlowText> createState() => _GradientFlowTextState();
}

class _GradientFlowTextState extends State<_GradientFlowText>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.repeat();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => ShaderMask(
        shaderCallback: (bounds) => LinearGradient(
          colors: widget.colors,
          stops: const [0.0, 0.3, 0.6, 1.0],
          begin: Alignment(-1.0 + _ctrl.value * 2, 0),
          end: Alignment(1.0 + _ctrl.value * 2, 0),
        ).createShader(bounds),
        child: Text(
          widget.text,
          style: widget.style.copyWith(color: Colors.white),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _FadeSlideIn extends StatefulWidget {
  final Widget child;
  final Duration delay;

  const _FadeSlideIn({required this.child, this.delay = Duration.zero});

  @override
  State<_FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<_FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

class _ScaleBounce extends StatefulWidget {
  final Widget child;
  final Duration delay;

  const _ScaleBounce({required this.child, this.delay = Duration.zero});

  @override
  State<_ScaleBounce> createState() => _ScaleBounceState();
}

class _ScaleBounceState extends State<_ScaleBounce>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _scale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut),
    );
    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(scale: _scale, child: widget.child);
  }
}

class _StaggeredFade extends StatefulWidget {
  final Widget child;
  final Duration delay;

  const _StaggeredFade({required this.child, this.delay = Duration.zero});

  @override
  State<_StaggeredFade> createState() => _StaggeredFadeState();
}

class _StaggeredFadeState extends State<_StaggeredFade>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0.2, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

class _RotateIn extends StatefulWidget {
  final Widget child;
  final Duration delay;

  const _RotateIn({required this.child, this.delay = Duration.zero});

  @override
  State<_RotateIn> createState() => _RotateInState();
}

class _RotateInState extends State<_RotateIn>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    Future.delayed(widget.delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, child) => Opacity(
        opacity: _ctrl.value,
        child: Transform.rotate(
          angle: (1 - _ctrl.value) * -0.1,
          child: child,
        ),
      ),
      child: widget.child,
    );
  }
}

class _GlowButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _GlowButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_GlowButton> createState() => _GlowButtonState();
}

class _GlowButtonState extends State<_GlowButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => GlassButton(
        text: widget.label,
        icon: widget.icon,
        onTap: widget.onTap,
        bgColor: GlassPalette.blue,
        textColor: GlassPalette.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
        fontSize: 12,
      ),
    );
  }
}