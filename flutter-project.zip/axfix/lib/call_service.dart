// call_service.dart
// ═══════════════════════════════════════════════════════════════════════════
// CALL SERVICE — WebRTC CORE LOGIC
// Audio Call + Video Call + Screen Share
// FIXED: pending SDP offer + acceptIncomingCall
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'app_config.dart';

enum CallState {
  idle,
  calling,
  ringing,
  connecting,
  connected,
  reconnecting,
  ended,
  failed,
}

enum CallType { audio, video }

class CallService {
  final String sessionKey;
  final String myUsername;

  CallState _state = CallState.idle;
  CallType _callType = CallType.audio;
  String? _peerUsername;
  String? _callId;

  String? _pendingSdpOffer;
  String? _pendingFromUser;

  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  MediaStream? _remoteStream;
  MediaStream? _screenStream;

  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();

  bool _micEnabled = true;
  bool _cameraEnabled = true;
  bool _speakerOn = false;
  bool _isScreenSharing = false;
  bool _isFrontCamera = true;

  DateTime? _callStartTime;
  Duration _callDuration = Duration.zero;
  Timer? _durationTimer;

  WebSocketChannel? _wsChannel;
  StreamSubscription? _wsSub;

  Function(CallState)? onStateChanged;
  Function(MediaStream?)? onRemoteStream;
  Function(Duration)? onDurationTick;
  VoidCallback? onCallEnded;
  Function(String)? onIncomingCall;

  static const Map<String, dynamic> _iceServers = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
      {'urls': 'stun:stun2.l.google.com:19302'},
      {'urls': 'stun:stun3.l.google.com:19302'},
      {
        'urls': 'turn:global.relay.metered.ca:80',
        'username': '76a657e5b7f5ca9898f13317',
        'credential': '7VxILMu0HBhQHWDI',
      },
      {
        'urls': 'turn:global.relay.metered.ca:443',
        'username': '76a657e5b7f5ca9898f13317',
        'credential': '7VxILMu0HBhQHWDI',
      },
      {
        'urls': 'turn:global.relay.metered.ca:443?transport=tcp',
        'username': '76a657e5b7f5ca9898f13317',
        'credential': '7VxILMu0HBhQHWDI',
      },
    ],
    'sdpSemantics': 'unified-plan',
    'iceCandidatePoolSize': 10,
  };

  CallService({
    required this.sessionKey,
    required this.myUsername,
  });

  CallState get state => _state;
  CallType get callType => _callType;
  String? get peerUsername => _peerUsername;
  String? get callId => _callId;
  Duration get callDuration => _callDuration;
  bool get micEnabled => _micEnabled;
  bool get cameraEnabled => _cameraEnabled;
  bool get speakerOn => _speakerOn;
  bool get isScreenSharing => _isScreenSharing;
  bool get isFrontCamera => _isFrontCamera;
  MediaStream? get localStream => _localStream;
  MediaStream? get remoteStream => _remoteStream;

  Future<void> init() async {
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    debugPrint('[CALL] Initialized');
  }

  void connectWebSocket() {
    try {
      _wsChannel = WebSocketChannel.connect(Uri.parse(kWsUrl));

      _wsChannel!.sink.add(jsonEncode({
        'type': 'auth',
        'key': sessionKey,
      }));

      _wsSub = _wsChannel!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            _handleWsEvent(data);
          } catch (e) {
            debugPrint('[CALL] WS parse error: $e');
          }
        },
        onError: (e) => debugPrint('[CALL] WS error: $e'),
        onDone: () => debugPrint('[CALL] WS closed'),
      );

      debugPrint('[CALL] WebSocket connected');
    } catch (e) {
      debugPrint('[CALL] WS connect error: $e');
    }
  }

  void _handleWsEvent(Map<String, dynamic> data) {
    final type = data['type'];

    switch (type) {
      case 'call_incoming':
        _peerUsername = data['from'];
        _callType = data['callType'] == 'video' ? CallType.video : CallType.audio;
        _callId = data['callId'];

        _pendingSdpOffer = data['sdp'];
        _pendingFromUser = data['from'];

        _setState(CallState.ringing);
        onIncomingCall?.call(jsonEncode(data));
        break;

      case 'call_accepted':
        _handleCallAccepted(data['sdp']);
        break;

      case 'call_rejected':
        _handleCallRejected();
        break;

      case 'call_ended':
        _handleCallEnded();
        break;

      case 'call_ice':
        _handleRemoteIce(data['candidate']);
        break;

      default:
        debugPrint('[CALL] Unknown event: $type');
    }
  }

  Future<void> startCall({
    required String toUsername,
    required CallType type,
  }) async {
    try {
      _peerUsername = toUsername;
      _callType = type;
      _callId = 'call_${DateTime.now().millisecondsSinceEpoch}';

      _setState(CallState.calling);

      await _createPeerConnection();
      await _getUserMedia();

      final offer = await _peerConnection!.createOffer();
      await _peerConnection!.setLocalDescription(offer);

      _wsChannel!.sink.add(jsonEncode({
        'type': 'call_offer',
        'key': sessionKey,
        'to': toUsername,
        'sdp': offer.sdp,
        'sdpType': offer.type,
        'callType': type == CallType.video ? 'video' : 'audio',
        'callId': _callId,
      }));

      debugPrint('[CALL] Offer sent to $toUsername');
    } catch (e) {
      debugPrint('[CALL] startCall error: $e');
      _setState(CallState.failed);
      onCallEnded?.call();
    }
  }

  Future<void> acceptCall({
    required String fromUsername,
    required String sdpOffer,
    required CallType type,
  }) async {
    try {
      _peerUsername = fromUsername;
      _callType = type;
      _setState(CallState.connecting);

      await _createPeerConnection();
      await _getUserMedia();

      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(sdpOffer, 'offer'),
      );

      final answer = await _peerConnection!.createAnswer();
      await _peerConnection!.setLocalDescription(answer);

      _wsChannel!.sink.add(jsonEncode({
        'type': 'call_answer',
        'key': sessionKey,
        'to': fromUsername,
        'sdp': answer.sdp,
        'sdpType': answer.type,
        'callId': _callId,
      }));

      debugPrint('[CALL] Answer sent to $fromUsername');
    } catch (e) {
      debugPrint('[CALL] acceptCall error: $e');
      _setState(CallState.failed);
      onCallEnded?.call();
    }
  }

  Future<void> acceptIncomingCall() async {
    if (_pendingSdpOffer == null || _pendingFromUser == null) {
      debugPrint('[CALL] No pending offer to accept');
      _setState(CallState.failed);
      onCallEnded?.call();
      return;
    }

    await acceptCall(
      fromUsername: _pendingFromUser!,
      sdpOffer: _pendingSdpOffer!,
      type: _callType,
    );

    _pendingSdpOffer = null;
    _pendingFromUser = null;
  }

  Future<void> rejectCall() async {
    _wsChannel?.sink.add(jsonEncode({
      'type': 'call_reject',
      'key': sessionKey,
      'to': _peerUsername,
      'callId': _callId,
    }));
    await _cleanup();
    _setState(CallState.ended);
    onCallEnded?.call();
  }

  Future<void> endCall() async {
    try {
      _wsChannel?.sink.add(jsonEncode({
        'type': 'call_end',
        'key': sessionKey,
        'to': _peerUsername,
        'callId': _callId,
      }));
    } catch (_) {}

    await _cleanup();
    _setState(CallState.ended);
    onCallEnded?.call();
  }

  Future<void> _handleCallAccepted(String? sdp) async {
    try {
      if (sdp == null || sdp.isEmpty) return;
      await _peerConnection?.setRemoteDescription(
        RTCSessionDescription(sdp, 'answer'),
      );
      _setState(CallState.connecting);
    } catch (e) {
      debugPrint('[CALL] handleAccepted error: $e');
    }
  }

  void _handleCallRejected() {
    debugPrint('[CALL] Rejected by peer');
    _cleanup();
    _setState(CallState.ended);
    onCallEnded?.call();
  }

  void _handleCallEnded() {
    debugPrint('[CALL] Ended by peer');
    _cleanup();
    _setState(CallState.ended);
    onCallEnded?.call();
  }

  Future<void> _handleRemoteIce(dynamic candidate) async {
    try {
      if (candidate == null || _peerConnection == null) return;
      final c = RTCIceCandidate(
        candidate['candidate'],
        candidate['sdpMid'],
        candidate['sdpMLineIndex'],
      );
      await _peerConnection!.addCandidate(c);
    } catch (e) {
      debugPrint('[CALL] handleRemoteIce error: $e');
    }
  }

  Future<void> _createPeerConnection() async {
    _peerConnection = await createPeerConnection(_iceServers, {
      'mandatory': {},
      'optional': [
        {'DtlsSrtpKeyAgreement': true},
      ],
    });

    _peerConnection!.onIceCandidate = (candidate) {
      if (candidate.candidate != null) {
        _wsChannel?.sink.add(jsonEncode({
          'type': 'call_ice',
          'key': sessionKey,
          'to': _peerUsername,
          'candidate': {
            'candidate': candidate.candidate,
            'sdpMid': candidate.sdpMid,
            'sdpMLineIndex': candidate.sdpMLineIndex,
          },
          'callId': _callId,
        }));
      }
    };

    _peerConnection!.onAddStream = (stream) {
      _remoteStream = stream;
      remoteRenderer.srcObject = stream;
      onRemoteStream?.call(stream);
    };

    _peerConnection!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        _remoteStream = event.streams[0];
        remoteRenderer.srcObject = _remoteStream;
        onRemoteStream?.call(_remoteStream);
      }
    };

    _peerConnection!.onConnectionState = (state) {
      switch (state) {
        case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
          _setState(CallState.connected);
          _startDurationTimer();
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateConnecting:
          _setState(CallState.connecting);
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
          _setState(CallState.reconnecting);
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
          _setState(CallState.failed);
          onCallEnded?.call();
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateClosed:
          _setState(CallState.ended);
          break;
        default:
          break;
      }
    };

    _peerConnection!.onIceConnectionState = (state) {
      debugPrint('[CALL] ICE state: $state');
    };
  }

  Future<void> _getUserMedia() async {
    final isVideo = _callType == CallType.video;

    final constraints = {
      'audio': true,
      'video': isVideo
          ? {
              'facingMode': 'user',
              'width': {'ideal': 640},
              'height': {'ideal': 480},
              'frameRate': {'ideal': 30},
            }
          : false,
    };

    _localStream = await navigator.mediaDevices.getUserMedia(constraints);

    for (final track in _localStream!.getTracks()) {
      await _peerConnection!.addTrack(track, _localStream!);
    }

    if (isVideo) {
      localRenderer.srcObject = _localStream;
    }
  }

  Future<void> toggleMic() async {
    if (_localStream == null) return;
    for (final track in _localStream!.getAudioTracks()) {
      track.enabled = !_micEnabled;
    }
    _micEnabled = !_micEnabled;
  }

  Future<void> toggleCamera() async {
    if (_localStream == null) return;
    for (final track in _localStream!.getVideoTracks()) {
      track.enabled = !_cameraEnabled;
    }
    _cameraEnabled = !_cameraEnabled;
  }

  Future<void> switchCamera() async {
    if (_localStream == null) return;
    final videoTracks = _localStream!.getVideoTracks();
    if (videoTracks.isEmpty) return;

    try {
      await Helper.switchCamera(videoTracks.first);
      _isFrontCamera = !_isFrontCamera;
    } catch (e) {
      debugPrint('[CALL] switchCamera error: $e');
    }
  }

  Future<void> toggleSpeaker() async {
    _speakerOn = !_speakerOn;
    try {
      await Helper.setSpeakerphoneOn(_speakerOn);
    } catch (e) {
      debugPrint('[CALL] toggleSpeaker error: $e');
    }
  }

  Future<void> startScreenShare() async {
    try {
      _screenStream = await navigator.mediaDevices.getDisplayMedia({
        'video': true,
        'audio': false,
      });

      if (_peerConnection == null) return;

      final senders = await _peerConnection!.getSenders();
      RTCRtpSender? videoSender;
      for (final s in senders) {
        if (s.track?.kind == 'video') {
          videoSender = s;
          break;
        }
      }

      if (videoSender != null && _screenStream!.getVideoTracks().isNotEmpty) {
        await videoSender.replaceTrack(_screenStream!.getVideoTracks().first);
      }

      localRenderer.srcObject = _screenStream;
      _isScreenSharing = true;
    } catch (e) {
      debugPrint('[CALL] startScreenShare error: $e');
    }
  }

  Future<void> stopScreenShare() async {
    try {
      if (_screenStream != null) {
        for (final t in _screenStream!.getTracks()) {
          await t.stop();
        }
        _screenStream = null;
      }

      if (_peerConnection == null || _localStream == null) return;

      final senders = await _peerConnection!.getSenders();
      RTCRtpSender? videoSender;
      for (final s in senders) {
        if (s.track?.kind == 'video') {
          videoSender = s;
          break;
        }
      }

      if (videoSender != null && _localStream!.getVideoTracks().isNotEmpty) {
        await videoSender.replaceTrack(_localStream!.getVideoTracks().first);
      }

      localRenderer.srcObject = _localStream;
      _isScreenSharing = false;
    } catch (e) {
      debugPrint('[CALL] stopScreenShare error: $e');
    }
  }

  void _startDurationTimer() {
    _callStartTime = DateTime.now();
    _callDuration = Duration.zero;

    _durationTimer?.cancel();
    _durationTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_callStartTime == null) return;
      _callDuration = DateTime.now().difference(_callStartTime!);
      onDurationTick?.call(_callDuration);
    });
  }

  void _stopDurationTimer() {
    _durationTimer?.cancel();
    _durationTimer = null;
    _callStartTime = null;
    _callDuration = Duration.zero;
  }

  void _setState(CallState newState) {
    _state = newState;
    onStateChanged?.call(newState);
  }

  Future<void> _cleanup() async {
    _stopDurationTimer();

    try {
      if (_localStream != null) {
        for (final t in _localStream!.getTracks()) {
          await t.stop();
        }
        _localStream = null;
      }
    } catch (_) {}

    try {
      if (_screenStream != null) {
        for (final t in _screenStream!.getTracks()) {
          await t.stop();
        }
        _screenStream = null;
      }
    } catch (_) {}

    try {
      await _peerConnection?.close();
      _peerConnection = null;
    } catch (_) {}

    localRenderer.srcObject = null;
    remoteRenderer.srcObject = null;

    _micEnabled = true;
    _cameraEnabled = true;
    _speakerOn = false;
    _isScreenSharing = false;
    _isFrontCamera = true;
    _callId = null;

    _pendingSdpOffer = null;
    _pendingFromUser = null;
  }

  Future<void> dispose() async {
    await _cleanup();
    await _wsSub?.cancel();
    try {
      await _wsChannel?.sink.close();
    } catch (_) {}
    localRenderer.dispose();
    remoteRenderer.dispose();
  }
}