// device_dashboard.dart
// ═══════════════════════════════════════════════════════════════════════════
// DEVICE DASHBOARD — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'device_permission.dart';
import 'control_panel.dart';
import 'glass_theme.dart';

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });
  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  Timer? _timer;

  bool get _isOwner => widget.role.toLowerCase() == 'owner';

  @override
  void initState() {
    super.initState();
    _loadDevices();
    _timer =
        Timer.periodic(const Duration(seconds: 5), (_) => _loadDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadDevices() async {
    if (!mounted) return;
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/api/devices'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;

      if (res.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error ${res.statusCode}';
        });
        return;
      }

      final body = jsonDecode(res.body);
      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Error';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);

      if (!_isOwner) {
        try {
          final permRes = await http.get(Uri.parse(
              '$kBaseUrl/devicePerms?key=${widget.sessionKey}&username=${Uri.encodeComponent(widget.username)}'));
          if (permRes.statusCode == 200) {
            final permData = jsonDecode(permRes.body);
            if (permData['valid'] == true && permData['approved'] == true) {
              if (permData['allDevices'] != true) {
                final allowedIds =
                    List<String>.from(permData['devices'] ?? []);
                devices = devices
                    .where((d) => allowedIds.contains(d['id']))
                    .toList();
              }
            } else {
              devices = [];
            }
          } else {
            devices = [];
          }
        } catch (_) {
          devices = [];
        }
      }

      if (mounted) {
        setState(() {
          _devices = devices;
          _loading = false;
          _errorMsg = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
        });
      }
    }
  }

  int get _active => _devices.where((d) => d['online'] == true).length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              if (_errorMsg != null)
                _banner(Icons.error_rounded, _errorMsg!, GlassPalette.red),

              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
                child: Row(
                  children: [
                    Text(
                      'CONNECTED DEVICES',
                      style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.textSub,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _loading = true;
                          _errorMsg = null;
                        });
                        _loadDevices();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                        ),
                        child: const Icon(Icons.refresh_rounded,
                            color: GlassPalette.white, size: 16),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (_isOwner)
                      GestureDetector(
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DevicePermissionManagerPage(
                                sessionKey: widget.sessionKey,
                                allDevices: _devices,
                              ),
                            ),
                          );
                          _loadDevices();
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: GlassPalette.red.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: GlassPalette.red.withOpacity(0.6),
                              width: 1.2,
                            ),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.manage_accounts_rounded,
                                  color: GlassPalette.white, size: 13),
                              const SizedBox(width: 5),
                              Text(
                                'Kelola Akses',
                                style: GlassFont.pixel(
                                  size: 8,
                                  weight: FontWeight.w700,
                                  color: GlassPalette.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),

              Expanded(
                child: _loading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: GlassPalette.white))
                    : _devices.isEmpty
                        ? _buildEmptyState()
                        : GridView.builder(
                            padding:
                                const EdgeInsets.fromLTRB(14, 4, 14, 100),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 8,
                              mainAxisSpacing: 8,
                              childAspectRatio: 0.75,
                            ),
                            itemCount: _devices.length,
                            itemBuilder: (ctx, i) => _buildDeviceCard(i),
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _statBox('ONLINE', '$_active', GlassPalette.teal),
              const Spacer(),
              Column(
                children: [
                  Text(
                    'DEVICE DASHBOARD',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '@user',
                    style: GlassFont.body(
                      size: 10,
                      weight: FontWeight.w500,
                      color: GlassPalette.textSub,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              _statBox('TOTAL', '${_devices.length}', GlassPalette.red),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.blue.withOpacity(0.5),
                  blurRadius: 25,
                ),
              ],
            ),
            child: const Icon(Icons.devices_other_rounded,
                color: GlassPalette.white, size: 52),
          ),
          const SizedBox(height: 14),
          Text(
            'NO DEVICES',
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.textSub,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Belum ada device terhubung',
            style: GlassFont.body(
              size: 11,
              weight: FontWeight.w500,
              color: GlassPalette.textDim,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 40),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.2,
              ),
            ),
            child: Column(
              children: [
                const Icon(Icons.info_outline_rounded,
                    color: GlassPalette.white, size: 20),
                const SizedBox(height: 8),
                Text(
                  'Cara hubungkan device:',
                  style: GlassFont.pixel(
                    size: 9,
                    weight: FontWeight.w700,
                    color: GlassPalette.white,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '1. Install APK target di HP korban\n'
                  '2. Buka APK → izinkan permission\n'
                  '3. Device OTOMATIS muncul di sini',
                  style: GlassFont.body(
                    size: 10,
                    weight: FontWeight.w500,
                    color: GlassPalette.textSub,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(int i) {
    final d = _devices[i];
    final on = d['online'] == true;
    final sc = on ? GlassPalette.teal : GlassPalette.red;

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ControlCenterPage(
            targetDevice: d,
            role: widget.role,
          ),
        ),
      ),
      child: GlassCard(
        borderWidth: 1.5,
        radius: 16,
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Icon(Icons.phone_android_rounded,
                    color: GlassPalette.white, size: 13),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  decoration: BoxDecoration(
                    color: sc.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: sc.withOpacity(0.7),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    on ? 'ON' : 'OFF',
                    style: GlassFont.pixel(
                      size: 6,
                      weight: FontWeight.w700,
                      color: GlassPalette.white,
                    ),
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              d['model'] ?? 'Unknown',
              style: GlassFont.pixel(
                size: 7,
                weight: FontWeight.w700,
                color: GlassPalette.white,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              d['id'] ?? '-',
              style: GlassFont.body(
                size: 8,
                weight: FontWeight.w500,
                color: GlassPalette.textSub,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const Spacer(),
            Row(
              children: [
                const Icon(Icons.battery_charging_full_rounded,
                    color: GlassPalette.white, size: 10),
                const SizedBox(width: 2),
                Text(
                  '${d['battery'] ?? '?'}%',
                  style: GlassFont.body(
                    size: 8,
                    weight: FontWeight.w600,
                    color: GlassPalette.white,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _banner(IconData icon, String msg, Color c) => Container(
        margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: c.withOpacity(0.2),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: c.withOpacity(0.6),
            width: 1.2,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: c, size: 14),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                msg,
                style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w600,
                  color: c,
                ),
              ),
            ),
          ],
        ),
      );

  Widget _statBox(String l, String v, Color c) => Column(
        children: [
          Text(
            l,
            style: GlassFont.pixel(
              size: 8,
              weight: FontWeight.w700,
              color: GlassPalette.textSub,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            v,
            style: GlassFont.pixel(
              size: 15,
              weight: FontWeight.w700,
              color: c,
              shadows: [
                Shadow(
                  color: c.withOpacity(0.6),
                  blurRadius: 10,
                ),
              ],
            ),
          ),
        ],
      );
}