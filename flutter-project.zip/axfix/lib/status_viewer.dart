// status_viewer.dart
// ═══════════════════════════════════════════════════════════════════════════
// STATUS VIEWER — GLASSMORPHISM EDITION
// Render 3 tipe status (image, video, text) + Reply & Reaction
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'app_config.dart';
import 'chat_service.dart';

class _C {
  static const redMid   = Color(0xFFDC2626);
  static const redLight = Color(0xFFEF4444);
  static const textP    = Color(0xFFFFFFFF);
  static const textSub  = Color(0xFFE0E0E0);
  static const textDim  = Color(0xFF9E9E9E);
}

class StatusViewer extends StatefulWidget {
  final List<dynamic> statuses;
  final int initialIndex;
  final String sessionKey;
  final String username;

  const StatusViewer({
    super.key,
    required this.statuses,
    required this.initialIndex,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StatusViewer> createState() => _StatusViewerState();
}

class _StatusViewerState extends State<StatusViewer> {
  int _userIndex = 0;
  int _statusIndex = 0;
  Timer? _progressTimer;
  Timer? _imageTimeoutTimer;
  Timer? _videoLoadTimeout;
  double _progress = 0.0;
  bool _imageReady = false;
  bool _isDialogOpen = false;
  bool _videoError = false;

  late ChatService _chatService;

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void initState() {
    super.initState();
    _userIndex = widget.initialIndex;

    if (_userIndex < 0 || _userIndex >= widget.statuses.length) {
      _userIndex = 0;
    }

    _chatService = ChatService(widget.sessionKey);

    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _startProgress();
    });

    _startImageTimeout();
    _markCurrentViewed();
    _initMediaForCurrent();
  }

  void _startImageTimeout() {
    _imageTimeoutTimer?.cancel();
    _imageTimeoutTimer = Timer(const Duration(seconds: 20), () {
      if (mounted && !_imageReady) {
        debugPrint('[ATOMIC-X] Image timeout 20s — skip');
        setState(() => _imageReady = true);
      }
    });
  }

  void _startProgress() {
    _progressTimer?.cancel();
    _progress = 0.0;

    final currentStatus = _getCurrentStatus();
    final type = (currentStatus?['type'] ?? 'image').toString();

    double increment = 0.01;
    if (type == 'text') increment = 0.0125;

    _progressTimer = Timer.periodic(const Duration(milliseconds: 50), (t) {
      if (!mounted) return;
      if (!_imageReady) return;
      if (_isDialogOpen) return;
      if (type == 'video') return;

      setState(() {
        _progress += increment;
        if (_progress >= 1.0) {
          _nextStatus();
        }
      });
    });
  }

  dynamic _getCurrentStatus() {
    try {
      final user = widget.statuses[_userIndex];
      final statuses = (user['statuses'] as List).cast<Map>();
      if (_statusIndex < statuses.length) {
        return statuses[_statusIndex];
      }
    } catch (_) {}
    return null;
  }

  void _markCurrentViewed() {
    try {
      final user = widget.statuses[_userIndex];
      final statuses = (user['statuses'] as List).cast<Map>();
      if (_statusIndex < statuses.length) {
        _markViewed(statuses[_statusIndex]['id'].toString());
      }
    } catch (_) {}
  }

  void _nextStatus() {
    _disposeVideo();

    try {
      final user = widget.statuses[_userIndex];
      final statuses = (user['statuses'] as List).cast<Map>();

      if (_statusIndex < statuses.length - 1) {
        setState(() {
          _statusIndex++;
          _progress = 0.0;
          _imageReady = false;
          _videoError = false;
        });
        _startImageTimeout();
        _markViewed(statuses[_statusIndex]['id'].toString());
        _initMediaForCurrent();
      } else {
        if (_userIndex < widget.statuses.length - 1) {
          setState(() {
            _userIndex++;
            _statusIndex = 0;
            _progress = 0.0;
            _imageReady = false;
            _videoError = false;
          });
          _startImageTimeout();
          final newUser = widget.statuses[_userIndex];
          final newStatuses = (newUser['statuses'] as List).cast<Map>();
          if (newStatuses.isNotEmpty) {
            _markViewed(newStatuses[0]['id'].toString());
          }
          _initMediaForCurrent();
        } else {
          if (mounted) Navigator.pop(context);
        }
      }
    } catch (_) {
      if (mounted) Navigator.pop(context);
    }
  }

  void _prevStatus() {
    _disposeVideo();

    try {
      if (_statusIndex > 0) {
        setState(() {
          _statusIndex--;
          _progress = 0.0;
          _imageReady = false;
          _videoError = false;
        });
        _startImageTimeout();
        _initMediaForCurrent();
      } else {
        if (_userIndex > 0) {
          setState(() {
            _userIndex--;
            final prevUser = widget.statuses[_userIndex];
            final prevStatuses = (prevUser['statuses'] as List).cast<Map>();
            _statusIndex = prevStatuses.length - 1;
            _progress = 0.0;
            _imageReady = false;
            _videoError = false;
          });
          _startImageTimeout();
          _initMediaForCurrent();
        }
      }
    } catch (_) {}
  }

  void _initMediaForCurrent() {
    final status = _getCurrentStatus();
    if (status == null) return;
    final type = (status['type'] ?? 'image').toString();

    if (type == 'video') {
      final videoUrl = _fixImageUrl((status['image'] ?? '').toString());
      if (videoUrl.isEmpty) {
        debugPrint('[ATOMIC-X] [VIDEO] URL kosong, skip');
        if (mounted) setState(() => _imageReady = true);
        return;
      }

      debugPrint('[ATOMIC-X] [VIDEO] Loading: $videoUrl');

      try {
        _videoController = VideoPlayerController.networkUrl(
          Uri.parse(videoUrl),
          httpHeaders: {
            'Accept-Ranges': 'bytes',
            'Range': 'bytes=0-',
            'User-Agent': 'AtomicXGram/1.0',
            'Cache-Control': 'no-cache',
          },
        );
      } catch (e) {
        debugPrint('[ATOMIC-X] [VIDEO] Controller error: $e');
        if (mounted) setState(() {
          _imageReady = true;
          _videoError = true;
        });
        return;
      }

      bool initialized = false;
      _videoLoadTimeout?.cancel();
      _videoLoadTimeout = Timer(const Duration(seconds: 30), () {
        if (!mounted || initialized) return;
        debugPrint('[ATOMIC-X] [VIDEO] Timeout 30s — skip ke next status');
        setState(() {
          _imageReady = true;
          _videoError = true;
        });
      });

      _videoController!.initialize().then((_) {
        initialized = true;
        _videoLoadTimeout?.cancel();
        if (!mounted) return;

        debugPrint('[ATOMIC-X] [VIDEO] Initialized! Duration: ${_videoController!.value.duration}');

        final aspectRatio = _videoController!.value.aspectRatio > 0
            ? _videoController!.value.aspectRatio
            : 16 / 9;

        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: false,
          allowFullScreen: false,
          allowMuting: false,
          showOptions: false,
          aspectRatio: aspectRatio,
          errorBuilder: (context, errorMessage) {
            debugPrint('[ATOMIC-X] [VIDEO] Chewie error: $errorMessage');
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline,
                      color: Colors.white54, size: 60),
                  const SizedBox(height: 10),
                  const Text(
                    'Gagal play video',
                    style: TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                  const SizedBox(height: 5),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Text(
                      errorMessage.length > 100
                          ? errorMessage.substring(0, 100)
                          : errorMessage,
                      style: const TextStyle(
                          color: Colors.white38, fontSize: 9),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            );
          },
        );

        _startVideoProgress();
        setState(() => _imageReady = true);
      }).catchError((err) {
        initialized = true;
        _videoLoadTimeout?.cancel();
        debugPrint('[ATOMIC-X] [VIDEO] Initialize error: $err');
        if (mounted) {
          setState(() {
            _imageReady = true;
            _videoError = true;
          });
        }
      });
    } else if (type == 'image') {
      // handled by CachedNetworkImage
    } else if (type == 'text') {
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) setState(() => _imageReady = true);
      });
    }
  }

  void _startVideoProgress() {
    if (_videoController == null) return;
    _progressTimer?.cancel();
    _progress = 0.0;

    final duration = _videoController!.value.duration;
    if (duration.inMilliseconds <= 0) return;

    _progressTimer = Timer.periodic(const Duration(milliseconds: 50), (t) {
      if (!mounted) return;
      if (_isDialogOpen) return;
      if (_videoController == null) return;

      final pos = _videoController!.value.position;
      final dur = _videoController!.value.duration;
      if (dur.inMilliseconds <= 0) return;

      setState(() {
        _progress = (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0);
      });

      if (_videoController!.value.position >= _videoController!.value.duration) {
        _nextStatus();
      }
    });
  }

  void _disposeVideo() {
    _videoLoadTimeout?.cancel();
    try {
      _chewieController?.dispose();
      _videoController?.dispose();
    } catch (_) {}
    _chewieController = null;
    _videoController = null;
  }

  Future<void> _markViewed(String statusId) async {
    try {
      await http.post(
        Uri.parse('$kBaseUrl/status/view'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'status_id': statusId,
        }),
      ).timeout(const Duration(seconds: 10));
    } catch (_) {}
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    _imageTimeoutTimer?.cancel();
    _videoLoadTimeout?.cancel();
    _disposeVideo();
    super.dispose();
  }

  String _fixImageUrl(String raw) {
    if (raw.isEmpty) return '';
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }
    final base = kBaseUrl.endsWith('/')
        ? kBaseUrl.substring(0, kBaseUrl.length - 1)
        : kBaseUrl;
    final path = raw.startsWith('/') ? raw : '/$raw';
    return '$base$path';
  }

  Color _hexToColor(String hex) {
    try {
      final clean = hex.replaceAll('#', '');
      return Color(int.parse('FF$clean', radix: 16));
    } catch (_) {
      return const Color(0xFF1A1A1A);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // REPLY DIALOG — GLASS STYLE
  // ═══════════════════════════════════════════════════════════════════════
  void _showReplyDialog() {
    final user = widget.statuses[_userIndex];
    final statuses = (user['statuses'] as List).cast<Map>();
    final status = statuses[_statusIndex];
    final statusOwner = (user['username'] ?? '').toString();
    final type = (status['type'] ?? 'image').toString();
    final caption = type == 'text'
        ? (status['text'] ?? '').toString()
        : (status['caption'] ?? '').toString();
    final statusId = (status['id'] ?? '').toString();

    setState(() => _isDialogOpen = true);
    final ctrl = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogCtx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: const Color(0xFF0A1628).withOpacity(0.95),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 30,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _C.redMid.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _C.redMid.withOpacity(0.6),
                        width: 1.2,
                      ),
                    ),
                    child: const Icon(Icons.reply_rounded,
                        color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Balas Status',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'ke $statusOwner',
                          style: const TextStyle(
                            color: _C.textSub,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              if (caption.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: _C.redMid.withOpacity(0.4),
                      width: 1.2,
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.image_rounded,
                          color: _C.redMid, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          caption,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _C.textSub,
                            fontSize: 11,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              TextField(
                controller: ctrl,
                maxLines: 3,
                minLines: 2,
                autofocus: true,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                cursorColor: _C.redMid,
                decoration: InputDecoration(
                  hintText: 'Tulis balasan...',
                  hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.08),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: _C.redMid.withOpacity(0.5),
                      width: 1.2,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _C.redLight, width: 1.8),
                  ),
                  contentPadding: const EdgeInsets.all(12),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(dialogCtx);
                        setState(() => _isDialogOpen = false);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.25),
                            width: 1.2,
                          ),
                        ),
                        child: const Center(
                          child: Text(
                            'Batal',
                            style: TextStyle(
                              color: _C.textSub,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        final text = ctrl.text.trim();
                        if (text.isEmpty) return;
                        Navigator.pop(dialogCtx);
                        setState(() => _isDialogOpen = false);
                        await _sendReply(
                            statusOwner, text, statusId, caption);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: _C.redMid.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.25),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _C.redMid.withOpacity(0.5),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.send_rounded,
                                  color: Colors.white, size: 16),
                              SizedBox(width: 6),
                              Text(
                                'Kirim',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ).then((_) {
      if (mounted) setState(() => _isDialogOpen = false);
    });
  }

  // ═══════════════════════════════════════════════════════════════════════
  // REACTION PICKER — GLASS STYLE
  // ═══════════════════════════════════════════════════════════════════════
  void _showReactionPicker() {
    final user = widget.statuses[_userIndex];
    final statuses = (user['statuses'] as List).cast<Map>();
    final status = statuses[_statusIndex];
    final statusOwner = (user['username'] ?? '').toString();
    final type = (status['type'] ?? 'image').toString();
    final caption = type == 'text'
        ? (status['text'] ?? '').toString()
        : (status['caption'] ?? '').toString();
    final statusId = (status['id'] ?? '').toString();

    setState(() => _isDialogOpen = true);

    final emojis = ['❤️', '😂', '😮', '😢', '👍', '🔥', '👏', '💯'];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (sheetCtx) => Container(
        margin: const EdgeInsets.all(14),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF0A1628).withOpacity(0.95),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 30,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.redMid.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: _C.redMid.withOpacity(0.6),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(Icons.favorite_rounded,
                      color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Kasih Reaksi',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'ke status $statusOwner',
                        style: const TextStyle(
                          color: _C.textSub,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(sheetCtx),
                  child: const Icon(Icons.close_rounded,
                      color: Colors.white70, size: 22),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 14,
              runSpacing: 14,
              alignment: WrapAlignment.center,
              children: emojis.map((e) => GestureDetector(
                onTap: () async {
                  Navigator.pop(sheetCtx);
                  setState(() => _isDialogOpen = false);
                  await _sendReaction(statusOwner, e, statusId, caption);
                },
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: _C.redMid.withOpacity(0.5),
                      width: 1.2,
                    ),
                  ),
                  child: Center(
                    child: Text(e, style: const TextStyle(fontSize: 26)),
                  ),
                ),
              )).toList(),
            ),
          ],
        ),
      ),
    ).then((_) {
      if (mounted) setState(() => _isDialogOpen = false);
    });
  }

  Future<void> _sendReply(
    String statusOwner,
    String replyText,
    String statusId,
    String statusPreview,
  ) async {
    try {
      final ok = await _chatService.replyStatus(
        statusOwner: statusOwner,
        replyText: replyText,
        statusId: statusId,
        statusPreview: statusPreview,
      );
      if (!mounted) return;
      _showSnack(ok
          ? 'Balasan terkirim ke chat $statusOwner'
          : 'Gagal kirim balasan',
          ok);
    } catch (e) {
      if (!mounted) return;
      _showSnack('Error: $e', false);
    }
  }

  Future<void> _sendReaction(
    String statusOwner,
    String emoji,
    String statusId,
    String statusPreview,
  ) async {
    try {
      final ok = await _chatService.reactStatus(
        statusOwner: statusOwner,
        emoji: emoji,
        statusId: statusId,
        statusPreview: statusPreview,
      );
      if (!mounted) return;
      _showSnack(ok
          ? 'Reaction $emoji terkirim ke chat $statusOwner'
          : 'Gagal kirim reaction',
          ok);
    } catch (e) {
      if (!mounted) return;
      _showSnack('Error: $e', false);
    }
  }

  void _showSnack(String msg, bool success) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              success ? Icons.check_circle_rounded : Icons.error_rounded,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(color: Colors.white, fontSize: 13),
              ),
            ),
          ],
        ),
        backgroundColor:
            success ? const Color(0xFF16A34A) : _C.redMid,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.statuses.isEmpty ||
        _userIndex < 0 ||
        _userIndex >= widget.statuses.length) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text('Tidak ada status',
              style: TextStyle(color: Colors.white54, fontSize: 13)),
        ),
      );
    }

    final user = widget.statuses[_userIndex];
    final statuses = (user['statuses'] as List?)?.cast<Map>() ?? [];
    if (statuses.isEmpty ||
        _statusIndex < 0 ||
        _statusIndex >= statuses.length) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text('Status kosong',
              style: TextStyle(color: Colors.white54, fontSize: 13)),
        ),
      );
    }

    final status = statuses[_statusIndex];
    final size = MediaQuery.of(context).size;
    final type = (status['type'] ?? 'image').toString();
    final isMyStatus = (user['username'] ?? '').toString().toLowerCase() ==
        widget.username.toLowerCase();

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapUp: (details) {
          if (_isDialogOpen) return;
          final x = details.globalPosition.dx;
          if (x < size.width / 2) {
            _prevStatus();
          } else {
            _nextStatus();
          }
        },
        child: Stack(children: [
          Positioned.fill(child: _buildStatusContent(status, type)),

          Positioned(
            top: 40, left: 10, right: 10,
            child: Column(children: [
              Row(children: List.generate(statuses.length, (i) {
                return Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    height: 3,
                    decoration: BoxDecoration(
                      color: i < _statusIndex
                          ? _C.redMid
                          : i == _statusIndex
                              ? _C.redMid.withOpacity(_progress.clamp(0.0, 1.0))
                              : Colors.white38,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                );
              })),
              const SizedBox(height: 10),
              Row(children: [
                const CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.person, color: Colors.white, size: 18),
                ),
                const SizedBox(width: 8),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(user['username'] ?? 'Unknown',
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 13)),
                      Text(_timeAgo((status['created_at'] ?? '').toString()),
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 11)),
                    ])),
                IconButton(
                  icon: const Icon(Icons.close_rounded, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ]),
            ]),
          ),

          if (type != 'text' &&
              (status['caption'] ?? '').toString().isNotEmpty)
            Positioned(
              bottom: isMyStatus ? 40 : 110, left: 20, right: 20,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: _C.redMid.withOpacity(0.4),
                    width: 1.2,
                  ),
                ),
                child: Text(
                  status['caption'] ?? '',
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ),
            ),

          if (!isMyStatus)
            Positioned(
              bottom: 40,
              left: 20,
              right: 20,
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _showReplyDialog,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.4),
                            width: 1.2,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.reply_rounded,
                                color: Colors.white, size: 18),
                            SizedBox(width: 8),
                            Text(
                              'Balas',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: _showReactionPicker,
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _C.redMid.withOpacity(0.7),
                          width: 1.8,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _C.redMid.withOpacity(0.4),
                            blurRadius: 15,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.favorite_rounded,
                          color: _C.redLight, size: 22),
                    ),
                  ),
                ],
              ),
            ),
        ]),
      ),
    );
  }

  Widget _buildStatusContent(Map status, String type) {
    if (type == 'text') {
      final text = (status['text'] ?? '').toString();
      final bgColor = (status['bgColor'] ?? '#1A1A1A').toString();

      return Container(
        color: _hexToColor(bgColor),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                text,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      );
    }

    if (type == 'video') {
      if (_videoError) {
        return Container(
          color: Colors.black,
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.videocam_off_rounded,
                    color: Colors.white54, size: 80),
                SizedBox(height: 16),
                Text(
                  'Video tidak bisa diputar',
                  style: TextStyle(color: Colors.white54, fontSize: 14),
                ),
                SizedBox(height: 8),
                Text(
                  'Cek koneksi atau coba lagi nanti',
                  style: TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
        );
      }

      if (_videoController != null &&
          _videoController!.value.isInitialized &&
          _chewieController != null) {
        return Center(
          child: AspectRatio(
            aspectRatio: _videoController!.value.aspectRatio > 0
                ? _videoController!.value.aspectRatio
                : 16 / 9,
            child: Chewie(controller: _chewieController!),
          ),
        );
      }

      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: _C.redMid),
            SizedBox(height: 16),
            Text(
              'Memuat video...',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      );
    }

    final imgUrl = _fixImageUrl((status['image'] ?? '').toString());
    if (imgUrl.isEmpty) {
      return const Center(
        child: Icon(Icons.broken_image_rounded,
            color: Colors.white24, size: 80),
      );
    }

    return CachedNetworkImage(
      imageUrl: imgUrl,
      fit: BoxFit.contain,
      fadeInDuration: const Duration(milliseconds: 200),
      placeholder: (_, __) => const Center(
        child: CircularProgressIndicator(color: _C.redMid),
      ),
      imageBuilder: (context, imageProvider) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && !_imageReady) {
            setState(() => _imageReady = true);
          }
        });
        return Image(image: imageProvider, fit: BoxFit.contain);
      },
      errorWidget: (_, __, ___) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && !_imageReady) {
            setState(() => _imageReady = true);
          }
        });
        return Container(
          color: Colors.black,
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image_rounded,
                    color: Colors.white24, size: 80),
                SizedBox(height: 12),
                Text('Gambar tidak tersedia',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
        );
      },
    );
  }

  String _timeAgo(String iso) {
    try {
      if (iso.isEmpty) return '';
      final dt = DateTime.parse(iso);
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
      if (diff.inHours < 24) return '${diff.inHours}j lalu';
      return '${diff.inDays}h lalu';
    } catch (_) {
      return '';
    }
  }
}