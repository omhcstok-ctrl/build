// alight_motion_page.dart
// ═══════════════════════════════════════════════════════════════════════════
// ALIGHT MOTION — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'glass_theme.dart';

class AlightMotionPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const AlightMotionPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<AlightMotionPage> createState() => _AlightMotionPageState();
}

class _AlightMotionPageState extends State<AlightMotionPage> {
  int _step = 1;
  final _emailCtrl = TextEditingController();
  final _linkCtrl = TextEditingController();
  bool _loading = false;
  String _resultMessage = '';
  bool _isSuccess = false;

  Future<void> _sendEmail() async {
    final email = _emailCtrl.text.trim();

    if (email.isEmpty) {
      _showSnack('Email wajib diisi', isError: true);
      return;
    }
    if (!email.contains('@') || !email.contains('.')) {
      _showSnack('Format email salah', isError: true);
      return;
    }

    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/am/send-email'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'email': email,
        }),
      ).timeout(const Duration(seconds: 70));

      final data = jsonDecode(res.body);

      if (res.statusCode == 200 && data['success'] == true) {
        setState(() {
          _loading = false;
          _step = 2;
        });
        _showSnack('Email terkirim! Cek inbox / SPAM lu.');
      } else {
        setState(() => _loading = false);
        final err = (data['error'] ?? 'Error ${res.statusCode}').toString();
        _showSnack(err, isError: true);
      }
    } catch (e) {
      setState(() => _loading = false);
      _showSnack('Gagal konek ke server.', isError: true);
    }
  }

  Future<void> _verifikasi() async {
    final email = _emailCtrl.text.trim();
    final link = _linkCtrl.text.trim();

    if (link.isEmpty) {
      _showSnack('Link verifikasi wajib diisi', isError: true);
      return;
    }
    if (!link.contains('http')) {
      _showSnack('Format link salah (harus http/https)', isError: true);
      return;
    }

    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/api/am/verif2'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'email': email,
          'link': link,
        }),
      ).timeout(const Duration(seconds: 100));

      final data = jsonDecode(res.body);

      if (res.statusCode == 200 && data['success'] == true) {
        final status = data['status'] == true;
        final message = (data['message'] ?? 'Berhasil diproses').toString();

        setState(() {
          _loading = false;
          _isSuccess = status;
          _resultMessage = message;
          if (status) _step = 3;
        });

        if (!status) _showSnack(message, isError: true);
      } else {
        setState(() => _loading = false);
        final err = (data['error'] ?? 'Error ${res.statusCode}').toString();
        _showSnack(err, isError: true);
      }
    } catch (e) {
      setState(() => _loading = false);
      _showSnack('Gagal konek ke server.', isError: true);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    GlassDialog.show(
      context,
      title: isError ? 'Error' : 'Info',
      message: msg,
      icon: isError
          ? Icons.error_outline_rounded
          : Icons.info_outline_rounded,
      accentColor: isError ? GlassPalette.red : GlassPalette.teal,
    );
  }

  void _resetFlow() {
    setState(() {
      _step = 1;
      _emailCtrl.clear();
      _linkCtrl.clear();
      _resultMessage = '';
      _isSuccess = false;
    });
  }

  void _openAlightMotion() {
    Clipboard.setData(const ClipboardData(text: 'Alight Motion'));
    _showSnack('Nama "Alight Motion" udah dicopy. Buka di Play Store.');
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _linkCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GlassPalette.bg,
      extendBodyBehindAppBar: true,
      body: GlassBg(
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildStepIndicator(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
                  child: _buildCurrentStep(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentStep() {
    switch (_step) {
      case 1:
        return _buildStep1();
      case 2:
        return _buildStep2();
      case 3:
        return _buildStep3();
      default:
        return _buildStep1();
    }
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (_step == 2) {
                setState(() => _step = 1);
              } else {
                Navigator.pop(context);
              }
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: GlassPalette.blue.withOpacity(0.25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: GlassPalette.blue.withOpacity(0.6),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: GlassPalette.blue.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: GlassPalette.white, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'ALIGHT MOTION',
            style: GlassFont.pixel(
              size: 11,
              weight: FontWeight.w700,
              color: GlassPalette.white,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        border: Border(
          bottom: BorderSide(
            color: Colors.white.withOpacity(0.15),
            width: 1.2,
          ),
        ),
      ),
      child: Row(
        children: [
          _buildStepDot(1, 'Email'),
          Expanded(
              child: Container(
                  height: 2,
                  decoration: BoxDecoration(
                    color: _step >= 2
                        ? GlassPalette.blue
                        : Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(2),
                  ))),
          _buildStepDot(2, 'Verifikasi'),
          Expanded(
              child: Container(
                  height: 2,
                  decoration: BoxDecoration(
                    color: _step >= 3
                        ? GlassPalette.teal
                        : Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(2),
                  ))),
          _buildStepDot(3, 'Sukses'),
        ],
      ),
    );
  }

  Widget _buildStepDot(int stepNum, String label) {
    final isActive = _step == stepNum;
    final isDone = _step > stepNum;
    final color = isDone
        ? GlassPalette.teal
        : (isActive ? GlassPalette.blue : Colors.white.withOpacity(0.1));

    return Column(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.white.withOpacity(0.25),
              width: 1.2,
            ),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: GlassPalette.blue.withOpacity(0.5),
                      blurRadius: 15,
                    ),
                  ]
                : null,
          ),
          child: Center(
            child: isDone
                ? const Icon(Icons.check_rounded,
                    color: GlassPalette.white, size: 18)
                : Text(
                    '$stepNum',
                    style: GlassFont.pixel(
                      size: 10,
                      weight: FontWeight.w700,
                      color: isActive
                          ? GlassPalette.white
                          : GlassPalette.textDim,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: GlassFont.body(
            size: 9,
            weight: isActive ? FontWeight.w900 : FontWeight.w500,
            color: isDone || isActive
                ? GlassPalette.white
                : GlassPalette.textDim,
          ),
        ),
      ],
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String desc,
  }) {
    return GlassCard(
      borderWidth: 1.5,
      radius: 20,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: GlassPalette.blue.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: GlassPalette.blue.withOpacity(0.6),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: GlassPalette.blue.withOpacity(0.4),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Icon(icon, color: GlassPalette.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.white)),
                const SizedBox(height: 4),
                Text(desc,
                    style: GlassFont.body(
                        size: 11,
                        weight: FontWeight.w400,
                        color: GlassPalette.textSub,
                        height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfoCard(
          icon: Icons.email_rounded,
          title: 'STEP 1: KIRIM EMAIL',
          desc:
              'Masukin email akun Alight Motion lu. Kami bakal kirim link verifikasi ke email itu.',
        ),
        const SizedBox(height: 16),
        GlassCard(
          borderWidth: 1.5,
          radius: 20,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('EMAIL AKUN ALIGHT MOTION',
                  style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white)),
              const SizedBox(height: 8),
              GlassInput(
                controller: _emailCtrl,
                hint: 'contoh@gmail.com',
                icon: Icons.email_rounded,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: GlassPalette.blue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(0.5),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded,
                        color: GlassPalette.white, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Email verifikasi bakal masuk ke inbox atau SPAM.',
                        style: GlassFont.body(
                          size: 10,
                          weight: FontWeight.w500,
                          color: GlassPalette.white,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        GlassButton(
          text: _loading ? 'MENGIRIM...' : 'SEND EMAIL',
          icon: _loading ? null : Icons.send_rounded,
          isLoading: _loading,
          onTap: _loading ? null : _sendEmail,
          bgColor: GlassPalette.blue,
          textColor: GlassPalette.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          fontSize: 11,
        ),
        const SizedBox(height: 20),
        _buildFooter(),
      ],
    );
  }

  Widget _buildStep2() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfoCard(
          icon: Icons.mark_email_read_rounded,
          title: 'STEP 2: PASTE LINK VERIFIKASI',
          desc:
              'Buka email (inbox atau SPAM) dari Alight Motion. Copy link verifikasi, terus paste di bawah.',
        ),
        const SizedBox(height: 16),
        GlassCard(
          borderWidth: 1.5,
          radius: 20,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('EMAIL',
                  style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white)),
              const SizedBox(height: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.2),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.email_rounded,
                        color: GlassPalette.white, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(_emailCtrl.text,
                          style: GlassFont.body(
                              size: 12,
                              weight: FontWeight.w600,
                              color: GlassPalette.white)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text('LINK VERIFIKASI',
                  style: GlassFont.pixel(
                      size: 9,
                      weight: FontWeight.w700,
                      color: GlassPalette.white)),
              const SizedBox(height: 6),
              GlassInput(
                controller: _linkCtrl,
                hint: 'Paste link verifikasi dari email...',
                icon: Icons.link_rounded,
                keyboardType: TextInputType.url,
                maxLines: 4,
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: GlassPalette.blue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: GlassPalette.blue.withOpacity(0.5),
                    width: 1.2,
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.tips_and_updates_rounded,
                        color: GlassPalette.white, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Link dimulai dengan "https://alight-creative.firebaseapp.com/..."',
                        style: GlassFont.body(
                            size: 10,
                            weight: FontWeight.w500,
                            color: GlassPalette.white,
                            height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        GlassButton(
          text: _loading ? 'MEMVERIFIKASI...' : 'VERIFIKASI',
          icon: _loading ? null : Icons.verified_rounded,
          isLoading: _loading,
          onTap: _loading ? null : _verifikasi,
          bgColor: GlassPalette.blue,
          textColor: GlassPalette.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          fontSize: 11,
        ),
        const SizedBox(height: 12),
        Center(
          child: GestureDetector(
            onTap: _resetFlow,
            child: Text(
              '← Kirim ulang email',
              style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.red),
            ),
          ),
        ),
        const SizedBox(height: 20),
        _buildFooter(),
      ],
    );
  }

  Widget _buildStep3() {
    return Column(
      children: [
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: GlassPalette.teal.withOpacity(0.25),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: GlassPalette.teal.withOpacity(0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: GlassPalette.teal.withOpacity(0.6),
                blurRadius: 30,
              ),
            ],
          ),
          child: const Icon(Icons.check_circle_rounded,
              color: GlassPalette.white, size: 70),
        ),
        const SizedBox(height: 24),
        Text(
          'SUKSES!',
          style: GlassFont.pixel(
            size: 18,
            weight: FontWeight.w700,
            color: GlassPalette.teal,
            letterSpacing: 3,
            shadows: const [
              Shadow(color: Color(0x6600E5FF), blurRadius: 15),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Alight Motion Free sukses diverifikasi!',
          textAlign: TextAlign.center,
          style: GlassFont.body(
            size: 14,
            weight: FontWeight.w900,
            color: GlassPalette.white,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Silakan login ke akun Alight Motion Anda',
          textAlign: TextAlign.center,
          style: GlassFont.body(
            size: 12,
            weight: FontWeight.w500,
            color: GlassPalette.textSub,
          ),
        ),
        const SizedBox(height: 24),
        if (_resultMessage.isNotEmpty)
          GlassCard(
            borderWidth: 1.5,
            radius: 20,
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DETAIL:',
                    style: GlassFont.pixel(
                        size: 9,
                        weight: FontWeight.w700,
                        color: GlassPalette.teal)),
                const SizedBox(height: 6),
                SelectableText(_resultMessage,
                    style: GlassFont.body(
                        size: 12,
                        weight: FontWeight.w600,
                        color: GlassPalette.white,
                        height: 1.5)),
              ],
            ),
          ),
        const SizedBox(height: 20),
        GlassButton(
          text: 'BUKA ALIGHT MOTION',
          icon: Icons.open_in_new_rounded,
          onTap: _openAlightMotion,
          bgColor: GlassPalette.teal,
          textColor: GlassPalette.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          fontSize: 11,
        ),
        const SizedBox(height: 12),
        Center(
          child: GestureDetector(
            onTap: _resetFlow,
            child: Text(
              '← Verifikasi akun lain',
              style: GlassFont.body(
                  size: 11,
                  weight: FontWeight.w700,
                  color: GlassPalette.red),
            ),
          ),
        ),
        const SizedBox(height: 20),
        _buildFooter(),
      ],
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Column(
        children: [
          Text('POWERED BY',
              style: GlassFont.pixel(
                  size: 8,
                  weight: FontWeight.w700,
                  color: GlassPalette.textDim)),
          const SizedBox(height: 4),
          Text('ATOMIC X PROJECT',
              style: GlassFont.pixel(
                  size: 10,
                  weight: FontWeight.w700,
                  color: GlassPalette.red,
                  shadows: const [
                    Shadow(color: Color(0x66FF3D5A), blurRadius: 10),
                  ])),
        ],
      ),
    );
  }
}