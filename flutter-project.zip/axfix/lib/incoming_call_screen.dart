// incoming_call_screen.dart
// ═══════════════════════════════════════════════════════════════════════════
// INCOMING CALL SCREEN — GLASSMORPHISM EDITION
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'call_service.dart';
import 'call_screen.dart';
import 'notification_service.dart';
import 'glass_theme.dart';

class IncomingCallScreen extends StatefulWidget {
  final CallService callService;
  final String fromUsername;
  final CallType callType;
  final String sdpOffer;
  final String callId;

  const IncomingCallScreen({
    super.key,
    required this.callService,
    required this.fromUsername,
    required this.callType,
    required this.sdpOffer,
    required this.callId,
  });

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  Timer? _ringTimer;
  Timer? _autoRejectTimer;
  int _ringSeconds = 0;
  bool _isAccepting = false;

  @override
  void initState() {
    super.initState();

    HapticFeedback.vibrate();
    _startRingPattern();

    _ringTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _ringSeconds++);
    });

    _autoRejectTimer = Timer(const Duration(seconds: 45), () {
      if (mounted && !_isAccepting) _reject();
    });
  }

  void _startRingPattern() {
    Timer.periodic(const Duration(seconds: 2), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      HapticFeedback.vibrate();
    });
  }

  @override
  void dispose() {
    _ringTimer?.cancel();
    _autoRejectTimer?.cancel();
    super.dispose();
  }

  Future<void> _accept() async {
    if (_isAccepting) return;
    _isAccepting = true;

    _ringTimer?.cancel();
    _autoRejectTimer?.cancel();

    if (!mounted) return;

    try {
      await widget.callService.acceptCall(
        fromUsername: widget.fromUsername,
        sdpOffer: widget.sdpOffer,
        type: widget.callType,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal terima panggilan: $e')),
        );
        Navigator.of(context).pop();
      }
      return;
    }

    try {
      await NotificationService().cancelIncomingCall();
    } catch (e) {
      debugPrint('[INCOMING] Cancel notif error: $e');
    }

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => CallScreen(
          callService: widget.callService,
          peerUsername: widget.fromUsername,
          callType: widget.callType,
          isIncoming: true,
        ),
      ),
    );
  }

  Future<void> _reject() async {
    _ringTimer?.cancel();
    _autoRejectTimer?.cancel();

    try {
      await NotificationService().cancelIncomingCall();
    } catch (_) {}

    await widget.callService.rejectCall();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.callType == CallType.video;

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (!didPop) _reject();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Container(
            color: Colors.black,
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    border: Border(
                      bottom: BorderSide(
                        color: Colors.white.withOpacity(0.15),
                        width: 1.5,
                      ),
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        isVideo
                            ? Icons.videocam_rounded
                            : Icons.phone_rounded,
                        color: GlassPalette.teal,
                        size: 32,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        isVideo ? 'VIDEO CALL MASUK' : 'PANGGILAN MASUK',
                        style: GlassFont.pixel(
                          size: 11,
                          weight: FontWeight.w700,
                          color: GlassPalette.teal,
                        ),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 140,
                          height: 140,
                          decoration: BoxDecoration(
                            color: GlassPalette.teal.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(32),
                            border: Border.all(
                              color: GlassPalette.teal.withOpacity(0.7),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: GlassPalette.teal.withOpacity(0.6),
                                blurRadius: 40,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              widget.fromUsername.isNotEmpty
                                  ? widget.fromUsername[0].toUpperCase()
                                  : '?',
                              style: GlassFont.pixel(
                                size: 52,
                                weight: FontWeight.w900,
                                color: GlassPalette.white,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        Text(
                          widget.fromUsername,
                          style: GlassFont.pixel(
                            size: 18,
                            weight: FontWeight.w700,
                            color: GlassPalette.white,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.2),
                              width: 1.2,
                            ),
                          ),
                          child: Text(
                            'Berdering... ${_ringSeconds}s',
                            style: GlassFont.body(
                              size: 12,
                              weight: FontWeight.w500,
                              color: Colors.white70,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 40, vertical: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _actionBtn(
                        icon: Icons.call_end_rounded,
                        label: 'TOLAK',
                        color: GlassPalette.red,
                        onTap: _reject,
                      ),
                      _actionBtn(
                        icon: isVideo
                            ? Icons.videocam_rounded
                            : Icons.call_rounded,
                        label: 'TERIMA',
                        color: GlassPalette.teal,
                        onTap: _accept,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: color.withOpacity(0.85),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.6),
                  blurRadius: 25,
                ),
              ],
            ),
            child: Icon(icon, color: GlassPalette.white, size: 36),
          ),
          const SizedBox(height: 10),
          Text(
            label,
            style: GlassFont.pixel(
              size: 10,
              weight: FontWeight.w700,
              color: GlassPalette.white,
            ),
          ),
        ],
      ),
    );
  }
}