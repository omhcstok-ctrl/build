// quick_menu_data.dart
// ═══════════════════════════════════════════════════════════════════════════
// QUICK MENU DATA — MODEL ONLY
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';

class QuickMenuItem {
  final IconData icon;
  final String title;
  final String sub;
  final String desc;
  final List<String> tags;
  final String? badge;
  final Color badgeBg;
  final Color accent;
  final VoidCallback onTap;
  final bool disabled;

  const QuickMenuItem({
    required this.icon,
    required this.title,
    required this.sub,
    required this.desc,
    required this.tags,
    this.badge,
    required this.badgeBg,
    required this.accent,
    required this.onTap,
    this.disabled = false,
  });
}

class QuickMenuCategory {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Color badgeBg;
  final String badge;
  final int itemCount;

  const QuickMenuCategory({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.badgeBg,
    required this.badge,
    required this.itemCount,
  });
}