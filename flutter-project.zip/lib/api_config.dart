const String baseUrl = "http://node-michie.jkt48node.id:3047";
const String WS_URL = 'ws://node-michie.jkt48node.id:3047/ws';