import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import 'notification_service.dart';

import 'neo.dart';
class Sk {
  static const Color metalDeep   = Color(0xFFF7F1E3);
  static const Color metalDark   = Color(0xFFFFFFFF);
  static const Color metalMid    = Color(0xFFFFFFFF);
  static const Color metalLight  = Color(0xFFEFE6CE);
  static const Color metalHi     = Color(0xFF3B6DF2);
  static const Color brassDeep   = Color(0xFFE0A800);
  static const Color brassDark   = Color(0xFFE0A800);
  static const Color brass       = Color(0xFFFFC72C);
  static const Color brassHi     = Color(0xFFFFD966);
  static const Color brassShine  = Color(0xFFFFE699);
  static const Color red         = Color(0xFFE03C3C);
  static const Color redBright   = Color(0xFFFF4D4D);
  static const Color redGlow     = Color(0xFFF0524F);
  static const Color greenGlow   = Color(0xFF12A869);
  static const Color amberHi     = Color(0xFFF5A524);
  static const Color cyanHi      = Color(0xFF17B8CC);
  static const Color cream       = Color(0xFF14142B);
  static const Color ink         = Color(0xFF14142B);
  static const Color leather     = Color(0xFFFFFFFF);
  static const Color leatherDark = Color(0xFFF7F1E3);
  static const Color leatherHi   = Color(0xFFEFE6CE);
}

class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    return NeoDot(color: color, size: size);
  }
}

class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 10});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

class _MetalPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPanel(
      padding: padding,
      radius: radius,
      color: null,
      accent: null,
      shadow: 4.toDouble(),
      child: child,
    );
  }
}

class _IndustrialButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.child,
    required this.onTap,
    this.color = Sk.brass,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    return NeoButton(child: child, onTap: onTap, color: color, height: height);
  }
}



// ═══════════════════════════════════════════════════════
// MODEL NOTIFIKASI
// ═══════════════════════════════════════════════════════
class AppNotification {
  final String id;
  final String title;
  final String body;
  final String type;
  final DateTime createdAt;
  final bool isRead;
  final String? fromUser;

  AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.createdAt,
    required this.isRead,
    this.fromUser,
  });

  AppNotification copyWith({bool? isRead}) => AppNotification(
        id: id,
        title: title,
        body: body,
        type: type,
        createdAt: createdAt,
        isRead: isRead ?? this.isRead,
        fromUser: fromUser,
      );

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? 'Notifikasi').toString(),
        body: (j['body'] ?? j['message'] ?? '').toString(),
        type: (j['type'] ?? 'info').toString().toLowerCase(),
        createdAt:
            DateTime.tryParse((j['created_at'] ?? '').toString())?.toLocal() ??
                DateTime.now(),
        isRead: j['is_read'] == true || j['is_read'] == 1,
        fromUser: j['from']?.toString(),
      );

  Color get accent {
    switch (type) {
      case 'success':
        return Sk.greenGlow;
      case 'warning':
        return Sk.amberHi;
      case 'error':
        return Sk.redGlow;
      default:
        return Sk.cyanHi;
    }
  }

  IconData get icon {
    switch (type) {
      case 'success':
        return Icons.check_circle_rounded;
      case 'warning':
        return Icons.warning_amber_rounded;
      case 'error':
        return Icons.error_rounded;
      default:
        return Icons.campaign_rounded;
    }
  }
}

// ═══════════════════════════════════════════════════════
// CHECK NOTIF PAGE — BROADCAST INBOX
// ═══════════════════════════════════════════════════════
class CheckNotifPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const CheckNotifPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<CheckNotifPage> createState() => _CheckNotifPageState();
}

class _CheckNotifPageState extends State<CheckNotifPage> {
  final List<AppNotification> _notifications = [];
  bool _isLoading = true;
  String? _error;
  Timer? _pollTimer;

  // ═══ Field untuk deteksi notif baru ═══
  final Set<String> _seenIds = {};
  bool _firstLoad = true;

  int get _unreadCount => _notifications.where((n) => !n.isRead).length;

  @override
  void initState() {
    super.initState();
    _fetch();

    _pollTimer = Timer.periodic(
      const Duration(seconds: 15),
      (_) => _fetch(silent: true),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════
  // API
  // ═══════════════════════════════════════════════════════
  Future<void> _fetch({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);
    try {
      final uri = Uri.parse(
        '$baseUrl/getNotifications'
        '?key=${Uri.encodeComponent(widget.sessionKey)}'
        '&username=${Uri.encodeComponent(widget.username)}',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['notifications'] ?? data['data'] ?? []) as List;
        final parsed = list
            .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

        // ═══════════════════════════════════════════════════
        // DETEKSI NOTIF BARU → tampilkan ke bar HP
        // ═══════════════════════════════════════════════════
        if (_firstLoad) {
          _seenIds.addAll(parsed.map((e) => e.id));
          _firstLoad = false;
        } else {
          for (final n in parsed) {
            if (!_seenIds.contains(n.id)) {
              _seenIds.add(n.id);
              if (!n.isRead) {
                await NotificationService.show(
                  id: n.id.hashCode & 0x7fffffff,
                  title: n.title,
                  body: n.body,
                  payload: n.id,
                );
              }
            }
          }
        }
        // ═══════════════════════════════════════════════════

        if (!mounted) return;
        setState(() {
          _notifications
            ..clear()
            ..addAll(parsed);
          _error = null;
        });
      } else {
        if (!mounted) return;
        setState(() => _error = 'HTTP ${res.statusCode}');
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Gagal memuat notifikasi');
    } finally {
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  Future<void> _markAsRead(AppNotification n) async {
    if (n.isRead) return;
    final idx = _notifications.indexWhere((e) => e.id == n.id);
    if (idx == -1) return;
    setState(() => _notifications[idx] = n.copyWith(isRead: true));

    try {
      await http
          .post(
            Uri.parse('$baseUrl/markNotificationRead'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
              'id': n.id,
            }),
          )
          .timeout(const Duration(seconds: 10));
    } catch (_) {}
  }

  Future<void> _markAllRead() async {
    if (_unreadCount == 0) return;
    HapticFeedback.mediumImpact();

    for (int i = 0; i < _notifications.length; i++) {
      if (!_notifications[i].isRead) {
        _notifications[i] = _notifications[i].copyWith(isRead: true);
      }
    }
    setState(() {});

    try {
      await http
          .post(
            Uri.parse('$baseUrl/markAllRead'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
            }),
          )
          .timeout(const Duration(seconds: 10));
      _snack('Semua notifikasi ditandai dibaca');
    } catch (_) {
      _snack('Gagal menandai semua', isError: true);
      _fetch(silent: true);
    }
  }

  Future<void> _deleteNotification(AppNotification n) async {
    final ok = await _confirmDialog(n);
    if (ok != true) return;
    final idx = _notifications.indexWhere((e) => e.id == n.id);
    if (idx == -1) return;
    final removed = _notifications.removeAt(idx);
    setState(() {});
    HapticFeedback.mediumImpact();

    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/deleteNotification'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
              'id': n.id,
            }),
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) throw Exception();
      _snack('Notifikasi disembunyikan');
    } catch (_) {
      if (!mounted) return;
      setState(() => _notifications.insert(idx, removed));
      _snack('Gagal menghapus notifikasi', isError: true);
    }
  }

  // ═══════════════════════════════════════════════════════
  // UI HELPERS
  // ═══════════════════════════════════════════════════════
  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    final c = isError ? Sk.redGlow : Sk.greenGlow;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: true),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: Neo.ink,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Sk.metalDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: Neo.ink, width: 2.5),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<bool?> _confirmDialog(AppNotification n) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.8),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.delete_forever_rounded,
                  color: Neo.redDeep, size: 36),
              const SizedBox(height: 12),
              const Text(
                'HAPUS DARI INBOX?',
                style: TextStyle(
                  color: Neo.redDeep,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                n.title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Neo.ink.withValues(alpha: 0.7),
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Notif ini hanya disembunyikan dari inbox Anda.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Neo.ink.withValues(alpha: 0.45),
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      color: Sk.metalMid,
                      height: 44,
                      onTap: () => Navigator.pop(ctx, false),
                      child: const Text(
                        'BATAL',
                        style: TextStyle(
                          color: Neo.ink,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'sans-serif-black',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      color: Sk.red,
                      height: 44,
                      onTap: () => Navigator.pop(ctx, true),
                      child: const Text(
                        'HAPUS',
                        style: TextStyle(
                          color: Neo.ink,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'sans-serif-black',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDetail(AppNotification n) {
    _markAsRead(n);
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                          border: Border.all(color: Neo.ink, width: 2.5),
                          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                        ),
                        child: Icon(n.icon, color: n.accent, size: 22),
                      ),
                      const Positioned(
                        top: -2,
                        right: -2,
                        child: _Led(color: Sk.greenGlow, size: 6, blink: true),
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          margin: const EdgeInsets.only(bottom: 4),
                          decoration: BoxDecoration(
                            color: n.accent.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: Neo.ink,
                              width: 2,
                            ),
                          ),
                          child: Text(
                            n.type.toUpperCase(),
                            style: TextStyle(
                              color: n.accent,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                        Text(
                          n.title,
                          style: const TextStyle(
                            color: Neo.ink,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'sans-serif-black',
                            letterSpacing: 0.3,
                            height: 1.2,
                            shadows: null,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formatTime(n.createdAt),
                          style: TextStyle(
                            color: Neo.ink.withValues(alpha: 0.55),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    Colors.transparent,
                    n.accent.withValues(alpha: 0.6),
                    Colors.transparent,
                  ]),
                ),
              ),
              const SizedBox(height: 14),
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(ctx).size.height * 0.4,
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: SelectableText(
                    n.body,
                    style: const TextStyle(
                      color: Neo.ink,
                      fontSize: 12,
                      height: 1.6,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
              ),
              if (n.fromUser != null && n.fromUser!.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Neo.ink, width: 2.5),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.podcasts_rounded,
                          size: 12, color: Neo.ink),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Broadcast dari: ${n.fromUser}',
                          style: TextStyle(
                            color: Neo.ink.withValues(alpha: 0.7),
                            fontSize: 11.5,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _IndustrialButton(
                      color: Sk.red,
                      height: 46,
                      onTap: () {
                        Navigator.pop(ctx);
                        _deleteNotification(n);
                      },
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.delete_outline_rounded,
                              color: Neo.ink, size: 14),
                          SizedBox(width: 6),
                          Text(
                            'HAPUS',
                            style: TextStyle(
                              color: Neo.ink,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _IndustrialButton(
                      color: n.accent,
                      height: 46,
                      onTap: () => Navigator.pop(ctx),
                      child: const Text(
                        'TUTUP',
                        style: TextStyle(
                          color: Neo.ink,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'sans-serif-black',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Neo.paper,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(colors: [Neo.paper, Neo.paper]),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 8),
                _buildAppBar(),
                const SizedBox(height: 12),
                Expanded(child: _buildBody()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.pop(context);
              },
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
                  border: Border.all(
                    color: Neo.ink,
                    width: 2,
                  ),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: Neo.ink,
                  size: 16,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                    border: Border.all(color: Neo.ink, width: 2.5),
                    boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                  ),
                  child: const Icon(
                    Icons.campaign_rounded,
                    color: Neo.cyanDeep,
                    size: 20,
                  ),
                ),
                if (_unreadCount > 0)
                  Positioned(
                    top: -3,
                    right: -3,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: Sk.redGlow,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                      ),
                      constraints: const BoxConstraints(minWidth: 16),
                      child: Text(
                        _unreadCount > 99 ? '99+' : '$_unreadCount',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Neo.ink,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'sans-serif-black',
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'NOTIFIKASI PAGE',
                    style: TextStyle(
                      color: Neo.ink,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                      height: 1,
                      shadows: null,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      const _Led(color: Sk.cyanHi, size: 4, blink: true),
                      const SizedBox(width: 5),
                      Text(
                        _unreadCount > 0
                            ? '$_unreadCount BELUM DIBACA'
                            : 'SEMUA TERBACA',
                        style: TextStyle(
                          color: Neo.ink.withValues(alpha: 0.55),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                _fetch();
              },
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
                  border: Border.all(
                    color: Neo.ink,
                    width: 2,
                  ),
                ),
                child: const Icon(
                  Icons.refresh_rounded,
                  color: Neo.ink,
                  size: 18,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading && _notifications.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation(Sk.brass),
          strokeWidth: 3,
        ),
      );
    }

    if (_error != null && _notifications.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _MetalPlate(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off_rounded,
                    color: Neo.redDeep, size: 40),
                const SizedBox(height: 12),
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Neo.ink,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 14),
                _IndustrialButton(
                  color: Sk.red,
                  height: 44,
                  onTap: () => _fetch(),
                  child: const Text(
                    'COBA LAGI',
                    style: TextStyle(
                      color: Neo.ink,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_notifications.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _MetalPlate(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                        border: Border.all(color: Neo.ink, width: 2.5),
                      ),
                      child: const Icon(
                        Icons.campaign_rounded,
                        color: Neo.blueDeep,
                        size: 28,
                      ),
                    ),
                    const Positioned(
                      top: -2,
                      right: -2,
                      child: _Led(color: Sk.cyanHi, size: 8, blink: true),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Text(
                  'TIDAK ADA BROADCAST',
                  style: TextStyle(
                    color: Neo.ink,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Owner belum mengirim broadcast.\nTarik ke bawah untuk refresh.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Neo.ink.withValues(alpha: 0.6),
                    fontSize: 11.5,
                    fontFamily: 'ShareTechMono',
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _fetch(),
      color: Sk.brass,
      backgroundColor: Sk.metalDark,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(
          parent: BouncingScrollPhysics(),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _notifications.length + 1,
        itemBuilder: (_, i) {
          if (i == 0) return _buildActionBar();
          final n = _notifications[i - 1];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _NotifTile(
              notif: n,
              onTap: () => _openDetail(n),
              onDelete: () => _deleteNotification(n),
              timeAgo: _formatTime(n.createdAt),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActionBar() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Neo.ink, width: 2.5),
              ),
              child: Row(
                children: [
                  const _Led(color: Sk.cyanHi, size: 6, blink: true),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'TOTAL: ${_notifications.length}  |  BARU: $_unreadCount',
                      style: TextStyle(
                        color: Neo.ink.withValues(alpha: 0.7),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _unreadCount > 0 ? _markAllRead : null,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  colors: _unreadCount > 0
                      ? [Sk.brassHi, Sk.brass, Sk.brassDark]
                      : [Sk.metalMid, Sk.metalDark],
                ),
                border: Border.all(
                  color: Neo.ink,
                  width: 2,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.done_all_rounded,
                    size: 12,
                    color: _unreadCount > 0
                        ? Colors.white
                        : Sk.cream.withValues(alpha: 0.4),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'BACA SEMUA',
                    style: TextStyle(
                      color: _unreadCount > 0
                          ? Colors.white
                          : Sk.cream.withValues(alpha: 0.4),
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static String _formatTime(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inSeconds < 0) return 'baru saja';
    if (d.inSeconds < 60) return '${d.inSeconds}s lalu';
    if (d.inMinutes < 60) return '${d.inMinutes}m lalu';
    if (d.inHours < 24) return '${d.inHours}j lalu';
    if (d.inDays < 7) return '${d.inDays}h lalu';
    final dd = t.day.toString().padLeft(2, '0');
    final mm = t.month.toString().padLeft(2, '0');
    return '$dd/$mm/${t.year}';
  }
}

// ═══════════════════════════════════════════════════════
// TILE NOTIFIKASI
// ═══════════════════════════════════════════════════════
class _NotifTile extends StatelessWidget {
  final AppNotification notif;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final String timeAgo;

  const _NotifTile({
    required this.notif,
    required this.onTap,
    required this.onDelete,
    required this.timeAgo,
  });

  @override
  Widget build(BuildContext context) {
    final c = notif.accent;
    final unread = !notif.isRead;

    return GestureDetector(
      onTap: onTap,
      onLongPress: () {
        HapticFeedback.mediumImpact();
        onDelete();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: unread
                ? [
                    Color.lerp(Sk.leatherHi, c, 0.08)!,
                    Sk.leather,
                    Sk.leatherDark,
                  ]
                : [Sk.leather, Sk.leatherDark],
          ),
          border: Border.all(
            color: Neo.ink,
            width: unread ? 1.5 : 1,
          ),
          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [c.withValues(alpha: 0.35), c.withValues(alpha: 0.35)]),
                      border: Border.all(
                        color: Neo.ink,
                        width: 2.5,
                      ),
                      boxShadow: unread
                          ? [
                              BoxShadow(color: Neo.ink, offset: Offset(3, 3), blurRadius: 0),
                            ]
                          : null,
                    ),
                    child: Icon(
                      notif.icon,
                      color: c,
                      size: 20,
                      shadows: null,
                    ),
                  ),
                  if (unread)
                    const Positioned(
                      top: -1,
                      right: -1,
                      child: _Led(color: Sk.redGlow, size: 7, blink: true),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            notif.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: unread ? Sk.brassHi : Sk.brass,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.5,
                              height: 1.2,
                              shadows: null,
                            ),
                          ),
                        ),
                        if (unread) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 1,
                            ),
                            decoration: BoxDecoration(
                              color: Sk.redGlow.withValues(alpha: 0.9),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'BARU',
                              style: TextStyle(
                                color: Neo.ink,
                                fontSize: 10.5,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'sans-serif-black',
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      notif.body,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color:
                            Neo.ink.withValues(alpha: unread ? 0.85 : 0.55),
                        fontSize: 11.5,
                        fontFamily: 'ShareTechMono',
                        height: 1.35,
                        letterSpacing: 0.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          Icons.schedule_rounded,
                          size: 10,
                          color: Neo.ink.withValues(alpha: 0.4),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          timeAgo,
                          style: TextStyle(
                            color: Neo.ink.withValues(alpha: 0.5),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 5,
                            vertical: 1,
                          ),
                          decoration: BoxDecoration(
                            color: c.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(3),
                            border: Border.all(
                              color: Neo.ink,
                              width: 2,
                            ),
                          ),
                          child: Text(
                            notif.type.toUpperCase(),
                            style: TextStyle(
                              color: c,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            HapticFeedback.lightImpact();
                            onDelete();
                          },
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black.withValues(alpha: 0.5),
                              border: Border.all(
                                color: Neo.ink,
                                width: 2,
                              ),
                            ),
                            child: const Icon(
                              Icons.close_rounded,
                              size: 11,
                              color: Neo.redDeep,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}