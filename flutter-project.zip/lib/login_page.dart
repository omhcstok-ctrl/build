// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';

const String baseUrl = "http://ranpukimakpanel.mbgwowo.web.id:2002";
const String _loginVideoAsset = 'assets/videos/login.mp4';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  String? androidId;
  bool _isObscure = true;
  bool _isLoading = false;
  String? _errorMsg;

  // Single local video used by the login preview box.
  late VideoPlayerController _loginVideoController;
  bool _loginVideoReady = false;

  // Fade-in animation
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // Slide-up animation
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);

    _slideController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));

    _initLoginVideo();
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _fadeController.forward();
      if (mounted) _slideController.forward();
    });

    _tryAutoLogin();
  }

  void _initLoginVideo() {
    _loginVideoController = VideoPlayerController.asset(_loginVideoAsset)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _loginVideoReady = true);
          _loginVideoController
            ..setLooping(true)
            ..setVolume(0.0)
            ..play();
        }
      }).catchError((e) {
        debugPrint('Login video error: $e');
      });
  }

  @override
  void dispose() {
    _loginVideoController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  // ── Auto Login ──────────────────────────────────────────────────
  Future<void> _tryAutoLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res = await http.get(Uri.parse(
          "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
        )).timeout(const Duration(seconds: 15));
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacementNamed(context, '/splash', arguments: {
            'username': savedUser, 'password': savedPass,
            'role': data['role'], 'key': data['key'],
            'expiredDate': data['expiredDate'],
            'listBug': data['listBug'] ?? [],
            'listPayload': data['listPayload'] ?? [],
            'listDDoS': data['listDDoS'] ?? [],
            'news': data['news'] ?? [],
          });
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (_) {
      return 'unknown_device';
    }
  }

  // ── Login ───────────────────────────────────────────────────────
  Future<void> _handleLogin() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      setState(() => _errorMsg = 'Username dan password harus diisi');
      return;
    }

    setState(() { _isLoading = true; _errorMsg = null; });

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(validate.body);

      if (data['expired'] == true) {
        setState(() {
          _isLoading = false;
          _errorMsg = 'Akses kamu sudah expired. Hubungi admin untuk perpanjang.';
        });
        return;
      }

      if (data['valid'] != true) {
        setState(() {
          _isLoading = false;
          _errorMsg = 'Username atau password salah. Coba lagi.';
        });
        return;
      }

      // Valid — save credentials
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString("username", username);
      await prefs.setString("password", password);
      await prefs.setString("key", data['key']);

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/splash', arguments: {
          'username': username, 'password': password,
          'role': data['role'], 'key': data['key'],
          'expiredDate': data['expiredDate'],
          'listBug': data['listBug'] ?? [],
          'listPayload': data['listPayload'] ?? [],
          'listDDoS': data['listDDoS'] ?? [],
          'news': data['news'] ?? [],
        });
      }
    } catch (_) {
      setState(() {
        _isLoading = false;
        _errorMsg = 'Gagal terhubung ke server. Coba lagi nanti.';
      });
    }
  }

  void _openTelegram() async {
    final uri = Uri.parse("tg://resolve?domain=Xcut Crasher");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(Uri.parse("https://t.me/Xcut Crasher"), mode: LaunchMode.externalApplication);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final sw = mq.size.width;
    final sh = mq.size.height;

    // UI dibuat mengikuti referensi: dark anime background, title besar,
    // preview banner, glass input, dan tombol putih.
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: const Color(0xFF07080D),
        resizeToAvoidBottomInset: true,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // ── Static dark background ───────────────────────────────
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF090A0E),
                    Color(0xFF050609),
                    Color(0xFF020204),
                  ],
                ),
              ),
            ),

            // Darken background so the UI remains readable.
            Container(color: Colors.black.withOpacity(0.68)),

            // Soft glass/vignette effect.
            Positioned(
              top: -sh * 0.08,
              left: -sw * 0.25,
              child: IgnorePointer(
                child: Container(
                  width: sw * 0.9,
                  height: sw * 0.9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Colors.white.withOpacity(0.10),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),

            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Center(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(34, 26, 34, 22),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 650),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // ── Brand ──────────────────────────────────
                            const Text(
                              'HIYUKI',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 48,
                                fontWeight: FontWeight.w400,
                                color: Colors.white,
                                letterSpacing: 6.5,
                                height: 1.0,
                              ),
                            ),
                            const SizedBox(height: 15),

                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 25,
                                vertical: 10,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.16),
                                borderRadius: BorderRadius.circular(28),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.18),
                                  width: 1,
                                ),
                              ),
                              child: const Text(
                                'APK BUG X SAOAP',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 13,
                                  color: Colors.white,
                                  letterSpacing: 2.8,
                                ),
                              ),
                            ),

                            const SizedBox(height: 44),

                            // ── Anime preview banner ────────────────────
                            _buildPreviewBanner(),

                            const SizedBox(height: 40),

                            // ── Username ─────────────────────────────────
                            _buildInputField(
                              controller: userController,
                              icon: FontAwesomeIcons.user,
                              hint: 'USERNAME',
                              obscure: false,
                            ),

                            const SizedBox(height: 18),

                            // ── Password ─────────────────────────────────
                            _buildInputField(
                              controller: passController,
                              icon: FontAwesomeIcons.lock,
                              hint: 'PASSWORD',
                              obscure: _isObscure,
                              suffix: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => setState(
                                  () => _isObscure = !_isObscure,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8),
                                  child: _DynamicIcon(
                                    _isObscure
                                        ? FontAwesomeIcons.eyeSlash
                                        : FontAwesomeIcons.eye,
                                    color: Colors.white.withOpacity(0.38),
                                    size: 17,
                                  ),
                                ),
                              ),
                            ),

                            if (_errorMsg != null) ...[
                              const SizedBox(height: 13),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFF5364)
                                      .withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: const Color(0xFFFF5364)
                                        .withOpacity(0.22),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.error_outline_rounded,
                                      color: Color(0xFFFF8792),
                                      size: 17,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _errorMsg!,
                                        style: const TextStyle(
                                          color: Color(0xFFFFA0A8),
                                          fontSize: 11,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],

                            const SizedBox(height: 38),

                            // ── White login button ───────────────────────
                            _buildLoginButton(),

                            const SizedBox(height: 20),

                            GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: _openTelegram,
                              child: Padding(
                                padding: const EdgeInsets.all(8),
                                child: Text(
                                  'CONTACT ADMIN',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.42),
                                    fontSize: 10,
                                    fontFamily: 'ShareTechMono',
                                    letterSpacing: 2.3,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 10),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Preview banner ─────────────────────────────────────────────
  Widget _buildPreviewBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: double.infinity,
        height: 178,
        decoration: BoxDecoration(
          color: const Color(0xFF171923),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: Colors.white.withOpacity(0.18),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.48),
              blurRadius: 22,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_loginVideoReady && _loginVideoController.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _loginVideoController.value.size.width,
                  height: _loginVideoController.value.size.height,
                  child: VideoPlayer(_loginVideoController),
                ),
              )
            else
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF343444),
                      Color(0xFF151722),
                    ],
                  ),
                ),
              ),
            Container(color: Colors.black.withOpacity(0.10)),
          ],
        ),
      ),
    );
  }

  // ── Input Field ────────────────────────────────────────────────
  Widget _buildInputField({
    required TextEditingController controller,
    required dynamic icon,
    required String hint,
    required bool obscure,
    Widget? suffix,
  }) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.13),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.white.withOpacity(0.20),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          const SizedBox(width: 17),
          _DynamicIcon(
            icon,
            color: Colors.white.withOpacity(0.58),
            size: 17,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              cursorColor: Colors.white,
              textInputAction: TextInputAction.next,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1.5,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                  color: Colors.white.withOpacity(0.30),
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 2.0,
                ),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          if (suffix != null)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: suffix,
            )
          else
            const SizedBox(width: 16),
        ],
      ),
    );
  }

  // ── Login Button ───────────────────────────────────────────────
  Widget _buildLoginButton() {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _isLoading ? null : _handleLogin,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        width: double.infinity,
        height: 60,
        decoration: BoxDecoration(
          color: _isLoading
              ? const Color(0xFFD6D6D6)
              : Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.24),
              blurRadius: 18,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: Center(
          child: _isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: Color(0xFF17171B),
                  ),
                )
              : const Text(
                  'LOGIN',
                  style: TextStyle(
                    color: Color(0xFF15151A),
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'MADEEvolveSansEVO',
                    letterSpacing: 3.8,
                  ),
                ),
        ),
      ),
    );
  }

}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
