import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:shimmer/shimmer.dart';

// ── COLOR SCHEME (Dashboard Clean — Group Variant) ──────────────────
class _GC {
  // TRANTOR Color Scheme (light, premium fintech — Group variant)
  static const bg           = Color(0xFF000000);
  static const bg2          = Color(0xFF0a0a0a);
  static const surface      = Color(0xFF111111);
  static const card         = Color(0xFF111111);
  static const accent       = Color(0xFFFF3B30);
  static const accent2      = Color(0xFFFF6B6B);
  static const accent3      = Color(0xFFCC2E25);
  static const gold         = Color(0xFF333333);
  static const success      = Color(0xFFFF3B30);
  static const whatsapp     = Color(0xFFFF3B30);
  static const whatsappDark = Color(0xFFCC2E25);
  static const text         = Color(0xFFE0E7FF);
  static const muted        = Color(0x73E0E7FF);
  static const muted2       = Color(0x38E0E7FF);
  static const border       = Color(0x1AFF3B30);
  static const border2      = Color(0x0FFFFFFF);
}

// ── GROUP BUG PAGE ──────────────────────────────────────────────────
class GroupBugPage extends StatefulWidget {

  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final linkGroupController = TextEditingController();
  static const String baseUrl = "http://114.10.118.133:1887";

  // ── Animation Controllers ─────────────────────────────────────────
  late AnimationController _pulseController;
  late AnimationController _staggerController;
  late AnimationController _btnPress;
  late AnimationController _shimmerController;

  // ── State ─────────────────────────────────────────────────────────
  bool _isSending = false;
  int _activeStep = 0; // 0=idle, 1=processing, 2=success
  bool _isLinkFocused = false;

  // ── Bug type selector ──
  // Di-load dinamis dari /bugGroupSystems (API baru).
  // Format: [{id, name, description, icon, count, delay}]
  List<Map<String, dynamic>> _bugTypes = [];
  String _selectedBugId = '';
  bool _loadingBugs = true;

  // ── My groups (daftar grup yang udah bot join) ──
  // Di-load dari /myGroup. Format: [{id, name, avatar, memberCount, joined}]
  List<Map<String, dynamic>> _myGroups = [];
  bool _loadingGroups = true;
  String? _selectedGroupId;

  // ── Input mode: invite link OR pick from My Groups ──
  bool _useMyGroups = false;

  // ── Live role (di-refresh dari server pas init) ──
  // Fix bug "Access Denied" pas user baru aja di-approve VIP.
  late String _currentRole;
  late String _currentExpired;

  // ── Refresh role & expiredDate dari /meByKey ──
  Future<void> _refreshRoleFromServer() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/meByKey?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? _currentRole).toString();
        final newExpired = (data['expiredDate'] ?? _currentExpired).toString();
        if (newRole != _currentRole || newExpired != _currentExpired) {
          if (mounted) {
            setState(() {
              _currentRole = newRole;
              _currentExpired = newExpired;
            });
          }
        }
      }
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    _currentRole = widget.role;
    _currentExpired = widget.expiredDate;
    _initBgVideo();
    _pulseController = AnimationController(vsync: this, duration: Duration(seconds: 3))..repeat(reverse: true);
    _staggerController = AnimationController(vsync: this, duration: Duration(milliseconds: 900))..forward();
    _btnPress = AnimationController(vsync: this, duration: Duration(milliseconds: 100), lowerBound: 0.0, upperBound: 1.0);
    _shimmerController = AnimationController(vsync: this, duration: Duration(seconds: 4))..repeat(reverse: true);
    _refreshRoleFromServer();
    _fetchBugSystems();
    _fetchMyGroups();
  }

  // ── Fetch bug systems dari API baru (/bugGroupSystems) ──
  // Ngambil daftar jenis bug grup yang available buat user.
  Future<void> _fetchBugSystems() async {
    if (widget.sessionKey.isEmpty) {
      if (mounted) setState(() => _loadingBugs = false);
      return;
    }
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/bugGroupSystems?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode != 200) {
        if (mounted) setState(() => _loadingBugs = false);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['bugSystems'] is List) {
        final list = (data['bugSystems'] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        if (mounted) {
          setState(() {
            _bugTypes = list;
            if (_selectedBugId.isEmpty && list.isNotEmpty) {
              _selectedBugId = list.first['id']?.toString() ?? '';
            }
            _loadingBugs = false;
          });
        }
      } else {
        if (mounted) setState(() => _loadingBugs = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingBugs = false);
    }
  }

  // ── Fetch my groups (grup yang bot udah join) dari /myGroup ──
  Future<void> _fetchMyGroups() async {
    if (widget.sessionKey.isEmpty) {
      if (mounted) setState(() => _loadingGroups = false);
      return;
    }
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/myGroup?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode != 200) {
        if (mounted) setState(() => _loadingGroups = false);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['groups'] is List) {
        final list = (data['groups'] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        if (mounted) {
          setState(() {
            _myGroups = list;
            _loadingGroups = false;
          });
        }
      } else {
        if (mounted) setState(() => _loadingGroups = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingGroups = false);
    }
  }

  // ── Join group via invite link (POST /joinGroup) ──
  // Dipake kalau user paste invite link. Bot bakal join grup dulu sebelum
  // bug dikirim. Response-nya diabaikan — /sendBugGroup bakal handle by link/JID.
  Future<void> _joinGroup(String inviteLink) async {
    try {
      await http.post(
        Uri.parse("$baseUrl/joinGroup"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'groupInput': inviteLink,
        }),
      ).timeout(Duration(seconds: 30));
    } catch (_) {}
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _staggerController.dispose();
    _btnPress.dispose();
    _shimmerController.dispose();
    linkGroupController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── Stagger Animation Helper ──────────────────────────────────────
  Animation<double> _anim(int i) {
    final s = (i * 0.07).clamp(0.0, 0.55);
    final e = (s + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(s, e, curve: Curves.easeOut),
    );
  }

  // ── Validation ───────────────────────────────────────────────────
  bool _isValidGroupLink(String input) {
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  // ── API ──────────────────────────────────────────────────────────
  Future<void> _sendGroupBug() async {
    if (_isSending) return;
    _btnPress.forward().then((_) => _btnPress.reverse());

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    final key = widget.sessionKey;

    // Tentuin target group: dari input link atau dari MyGroups selection.
    String linkGroup;
    if (_useMyGroups) {
      if (_selectedGroupId == null || _selectedGroupId!.isEmpty) {
        _showAlert("No Group", "Pick a group dari list MY GROUPS dulu.");
        setState(() {
          _isSending = false;
          _activeStep = 0;
        });
        return;
      }
      linkGroup = _selectedGroupId!;
    } else {
      linkGroup = linkGroupController.text.trim();
      if (linkGroup.isEmpty) {
        _showAlert("Empty Target", "Paste WhatsApp group invite link atau pilih dari MY GROUPS.");
        setState(() {
          _isSending = false;
          _activeStep = 0;
        });
        return;
      }
      if (!_isValidGroupLink(linkGroup)) {
        _showAlert("Invalid Link", "Please enter a valid WhatsApp group invite link.\nFormat: https://chat.whatsapp.com/xxxxxxxxxx");
        setState(() {
          _isSending = false;
          _activeStep = 0;
        });
        return;
      }
      // Bot join grup dulu lewat /joinGroup sebelum bug dikirim.
      // Kalau bot udah join, endpoint ini no-op (idempotent).
      await _joinGroup(linkGroup);
    }

    // Bug wajib dipilih
    if (_selectedBugId.isEmpty) {
      _showAlert("No Bug Type", "Pilih jenis bug dulu sebelum launch.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      // ── Endpoint baru: /sendBugGroup ──
      // Param `group` bisa groupJid (dari /myGroup) atau invite link
      // (server bakal resolve ke JID sendiri).
      final res = await http.get(Uri.parse(
        "$baseUrl/sendBugGroup?key=${Uri.encodeComponent(key)}"
        "&group=${Uri.encodeComponent(linkGroup)}"
        "&bugType=${Uri.encodeComponent(_selectedBugId)}"
      )).timeout(Duration(seconds: 60));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Cooldown group bug ${data["wait"] ?? ""} detik. Tunggu sebentar.");
      } else if (data["valid"] == false) {
        _showAlert("Failed", data["message"] ?? "Failed to send group bug.");
      } else if (data["sended"] == false) {
        _showAlert("Gagal", data["message"] ?? "Gagal mengirim bug ke grup.");
      } else {
        setState(() => _activeStep = 2);
        _showSuccessPopup(linkGroup, data);
      }
    } catch (_) {
      _showAlert("Error", "Connection error. Please try again.");
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          if (_activeStep != 2) _activeStep = 0;
        });
      }
    }
  }

  // ── Paste ─────────────────────────────────────────────────────────
  Future<void> _pasteLink() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      linkGroupController.text = data!.text!;
    }
  }

  // ── Alert (Bottom Sheet — Solid style) ───────────────────────────
  void _showAlert(String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: _GC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _GC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 24, offset: Offset(0, 12)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Accent bar
                Container(
                  width: 40, height: 3,
                  decoration: BoxDecoration(
                    color: _GC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _GC.accent.withOpacity(0.12),
                        border: Border.all(color: _GC.accent.withOpacity(0.2)),
                      ),
                      child: Center(child: FaIcon(FontAwesomeIcons.triangleExclamation, color: _GC.accent, size: 17)),
                    ),
                    SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 2),
                          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, color: _GC.text)),
                          SizedBox(height: 4),
                          Container(width: 28, height: 2, decoration: BoxDecoration(color: _GC.accent.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _GC.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(msg, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted, height: 1.6)),
                ),
                SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                      decoration: BoxDecoration(
                        color: _GC.accent,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [BoxShadow(color: _GC.accent.withOpacity(0.2), blurRadius: 12)],
                      ),
                      child: Text('OK', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 2)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Success Popup ─────────────────────────────────────────────────
  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _GroupSuccessDialog(
        linkGroup: linkGroup,
        bugType: _selectedBugId,
        data: data,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() => _activeStep = 0);
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override

  // ── Video Background ──────────────────────────────
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  Widget build(BuildContext context) {
    // Role-based access control
    if (!["vip", "owner", "high admin", "reseller", "founder", "seles"].contains(_currentRole.toLowerCase())) {
return Stack(
        children: [
          // ── Video Background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
                ),
              ),
            ),
          // ── Dark overlay ──
          Container(color: Colors.black.withOpacity(0.6)),
          // ── Page content ──
        Scaffold(
        backgroundColor: _GC.bg,
        body: Center(
          child: _buildAccessDenied(),
        ),
      ),
        ],
        );
    }

    return Scaffold(
      backgroundColor: _GC.bg,
      body: Stack(
        children: [
          // Simple gradient background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [_GC.bg, _GC.bg2, _GC.bg],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: 520),
                      child: Column(
                        children: [
                          SizedBox(height: 16),
                          _buildGroupHero(),
                          SizedBox(height: 16),
                          _buildProfileCard(),
                          SizedBox(height: 16),
                          _buildGroupLinkCard(),
                          SizedBox(height: 16),
                          _buildBugSelector(),
                          SizedBox(height: 16),
                          _buildFeatureStrip(),
                          SizedBox(height: 24),
                          _buildLaunchButton(),
                          SizedBox(height: 16),
                          _buildStatusBar(),
                          SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HEADER — Clean dashboard style
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        color: Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _GC.border)),
      ),
      child: Row(
        children: [
          // Back button
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _GC.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _GC.border2),
              ),
              child: Icon(Icons.arrow_back, color: _GC.text, size: 16),
            ),
          ),
          SizedBox(width: 10),
          // WhatsApp icon
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: _GC.whatsapp.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
            ),
            child: Center(child: FaIcon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 14)),
          ),
          SizedBox(width: 10),
          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "GROUP BUG",
                  style: TextStyle(
                    color: _GC.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: "MADEEvolveSansEVO",
                    letterSpacing: 1.5,
                  ),
                ),
                SizedBox(height: 1),
                Row(
                  children: [
                    Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        color: _GC.whatsapp,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)],
                      ),
                    ),
                    SizedBox(width: 5),
                    Text(
                      _isSending ? "INJECTING..." : "READY",
                      style: TextStyle(
                        color: _GC.muted,
                        fontSize: 10,
                        fontFamily: "ShareTechMono",
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Live badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _GC.whatsapp.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    color: _GC.whatsapp,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)],
                  ),
                ),
                SizedBox(width: 6),
                Text(
                  'LIVE',
                  style: TextStyle(
                    color: _GC.whatsapp,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  SOLID CARD HELPER — Clean dashboard style
  // ═══════════════════════════════════════════════════════════════════
  Widget _solidCard({required Widget child, int idx = -1}) {
    Widget cardChild = Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _GC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.border, width: 1),
      ),
      child: child,
    );

    if (idx >= 0) {
      final a = _anim(idx);
      return FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a),
          child: cardChild,
        ),
      );
    }
    return cardChild;
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GROUP HERO BANNER — Step tracker (solid card)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGroupHero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: _GC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.border, width: 1),
      ),
      child: Column(
        children: [
          // Title row
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (ctx, _) {
                  final v = _pulseController.value;
                  return Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _GC.whatsapp.withOpacity(0.12 + v * 0.04),
                      border: Border.all(color: _GC.whatsapp.withOpacity(0.3), width: 1.5),
                    ),
                    child: Center(child: FaIcon(FontAwesomeIcons.users, color: _GC.whatsapp, size: 16)),
                  );
                },
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('GROUP INFILTRATION', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _GC.text)),
                  SizedBox(height: 4),
                  Container(width: 36, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
                ],
              ),
            ],
          ),
          SizedBox(height: 22),
          // Step tracker
          Row(
            children: [
              _buildHeroStep(0, FontAwesomeIcons.link, 'LINK', 'Paste group invite'),
              _buildHeroStepConnector(0),
              _buildHeroStep(1, FontAwesomeIcons.droplet, 'INJECT', 'Deploy bug into group'),
              _buildHeroStepConnector(1),
              _buildHeroStep(2, FontAwesomeIcons.circleCheck, 'DONE', 'Group compromised'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStep(int step, FaIconData icon, String title, String desc) {
    final isActive = _activeStep == step;
    final isDone = _activeStep > step;
    final color = isDone ? _GC.success : isActive ? _GC.accent : _GC.muted2;

    return Expanded(
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (ctx, _) {
              final p = _pulseController.value;
              return Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(isActive ? 0.12 + p * 0.06 : 0.06),
                  border: Border.all(color: color.withOpacity(isActive ? 0.4 + p * 0.15 : 0.15), width: isActive ? 2.0 : 1.0),
                  boxShadow: isActive
                      ? [BoxShadow(color: color.withOpacity(0.1 + p * 0.08), blurRadius: 12)]
                      : null,
                ),
                child: Center(
                  child: isDone ? Icon(Icons.check, color: _GC.success, size: 22) : FaIcon(icon, color: color, size: 18),
                ),
              );
            },
          ),
          SizedBox(height: 10),
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: color)),
          SizedBox(height: 4),
          Text(desc, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _GC.muted2), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildHeroStepConnector(int step) {
    final isDone = _activeStep > step;
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        width: 28, height: 2.5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          color: isDone ? _GC.success.withOpacity(0.4) : _GC.border2,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PROFILE CARD (Solid style)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return _solidCard(
      idx: 0,
      child: Row(
        children: [
          // Avatar
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _GC.whatsapp.withOpacity(0.1),
              border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
            ),
            child: Center(
              child: Icon(
                _currentRole.toLowerCase() == "vip" ? FontAwesomeIcons.hatWizard : FontAwesomeIcons.mask,
                color: _GC.whatsapp, size: 22,
              ),
            ),
          ),
          SizedBox(width: 16),
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Operator', style: TextStyle(fontSize: 10, color: _GC.muted, letterSpacing: 1.8)),
                SizedBox(height: 3),
                Text(widget.username, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1, color: _GC.text), maxLines: 1, overflow: TextOverflow.ellipsis),
                SizedBox(height: 8),
                // Role badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: _GC.whatsapp.withOpacity(0.1),
                    border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      FaIcon(FontAwesomeIcons.circleCheck, color: _GC.whatsapp, size: 9),
                      SizedBox(width: 6),
                      Text(_currentRole.toUpperCase(), style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2, color: _GC.whatsapp)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Expiry
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: _GC.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Column(
              children: [
                FaIcon(FontAwesomeIcons.calendarDays, color: _GC.gold, size: 14),
                SizedBox(height: 4),
                Text(_currentExpired, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.gold)),
                SizedBox(height: 2),
                Text('EXPIRY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _GC.muted2, letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GROUP LINK CARD (Solid dashboard style)
  //  ── Toggle antara INVITE LINK (paste) & MY GROUPS (pilih dari list).
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGroupLinkCard() {
    return _solidCard(
      idx: 1,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.link, 'GROUP TARGET'),
          SizedBox(height: 14),
          // ── Toggle: INVITE LINK vs MY GROUPS ──
          Row(
            children: [
              Expanded(
                child: _buildToggleTab(
                  'INVITE LINK',
                  FontAwesomeIcons.link,
                  !_useMyGroups,
                  () => setState(() {
                    _useMyGroups = false;
                    _selectedGroupId = null;
                  }),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: _buildToggleTab(
                  'MY GROUPS',
                  FontAwesomeIcons.users,
                  _useMyGroups,
                  () => setState(() => _useMyGroups = true),
                ),
              ),
            ],
          ),
          SizedBox(height: 14),
          if (_useMyGroups)
            _buildMyGroupsList()
          else
            _buildInviteLinkInput(),
        ],
      ),
    );
  }

  // ── Toggle tab kecil ──
  Widget _buildToggleTab(String label, FaIconData icon, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: _isSending ? null : onTap,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: active ? _GC.whatsapp.withOpacity(0.12) : _GC.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active ? _GC.whatsapp : _GC.border2,
            width: active ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: active ? _GC.whatsapp : _GC.muted2, size: 11),
            SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: active ? _GC.whatsapp : _GC.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Invite link text field (mode default) ──
  Widget _buildInviteLinkInput() {
    return Column(
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          decoration: BoxDecoration(
            color: _GC.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _isLinkFocused ? _GC.whatsapp : _GC.border,
              width: _isLinkFocused ? 1.5 : 1.0,
            ),
          ),
          child: Focus(
            onFocusChange: (f) => setState(() => _isLinkFocused = f),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 0, 16),
                  child: Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _GC.whatsapp.withOpacity(_isLinkFocused ? 0.12 : 0.06),
                      border: Border.all(color: _GC.whatsapp.withOpacity(0.15)),
                    ),
                    child: Center(child: FaIcon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 17)),
                  ),
                ),
                Expanded(
                  child: TextField(
                    controller: linkGroupController,
                    keyboardType: TextInputType.url,
                    style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 14, color: _GC.text, letterSpacing: 0.3),
                    cursorColor: _GC.whatsapp,
                    cursorWidth: 2,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'https://chat.whatsapp.com/...',
                      hintStyle: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted2),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                    ),
                    onSubmitted: (_) => _sendGroupBug(),
                  ),
                ),
                GestureDetector(
                  onTap: _pasteLink,
                  child: Container(
                    margin: const EdgeInsets.all(12),
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _GC.surface,
                      border: Border.all(color: _GC.border2),
                    ),
                    child: Center(child: FaIcon(FontAwesomeIcons.paste, color: _GC.muted2, size: 14)),
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                FaIcon(FontAwesomeIcons.circleInfo, color: _GC.muted2, size: 10),
                SizedBox(width: 6),
                Text('WhatsApp group invite link', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.muted2)),
              ]),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _GC.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _GC.border),
                ),
                child: Text('chat.whatsapp.com', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _GC.whatsapp)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── My Groups list (mode alternative) ──
  // Tap group untuk select. Selected group bakal dipake jadi param `group`.
  Widget _buildMyGroupsList() {
    if (_loadingGroups) {
      return _buildGroupsShimmer();
    }
    if (_myGroups.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
        decoration: BoxDecoration(
          color: _GC.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _GC.border2),
        ),
        child: Column(
          children: [
            FaIcon(FontAwesomeIcons.usersSlash, color: _GC.muted2, size: 22),
            SizedBox(height: 10),
            Text('No groups yet', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 1)),
            SizedBox(height: 4),
            Text('Bot belum join grup apapun.\nSwitch ke INVITE LINK & paste link baru.', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _GC.muted2, height: 1.5), textAlign: TextAlign.center),
          ],
        ),
      );
    }

    return Column(
      children: [
        for (int i = 0; i < _myGroups.length; i++) ...[
          _buildGroupRow(_myGroups[i]),
          if (i < _myGroups.length - 1) SizedBox(height: 8),
        ],
      ],
    );
  }

  Widget _buildGroupRow(Map<String, dynamic> g) {
    final id = (g['id'] ?? '').toString();
    final name = (g['name'] ?? 'Unknown Group').toString();
    final memberCount = g['memberCount']?.toString() ?? '0';
    final joined = g['joined'] == true;
    final selected = _selectedGroupId == id;

    return GestureDetector(
      onTap: _isSending ? null : () => setState(() => _selectedGroupId = id),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? _GC.whatsapp.withOpacity(0.12) : _GC.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _GC.whatsapp : _GC.border2,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(color: _GC.whatsapp.withOpacity(0.15), blurRadius: 10)]
              : null,
        ),
        child: Row(
          children: [
            // Avatar circle (initial)
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? _GC.whatsapp : _GC.whatsapp.withOpacity(0.12),
                border: Border.all(color: _GC.whatsapp.withOpacity(0.3)),
              ),
              child: Center(
                child: Text(
                  name.isNotEmpty ? name[0].toUpperCase() : '?',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: selected ? _GC.text : _GC.whatsapp,
                  ),
                ),
              ),
            ),
            SizedBox(width: 12),
            // Group name + meta
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: selected ? _GC.whatsapp : _GC.text,
                    ),
                  ),
                  SizedBox(height: 2),
                  Row(
                    children: [
                      FaIcon(FontAwesomeIcons.users, size: 9, color: _GC.muted2),
                      SizedBox(width: 4),
                      Text('$memberCount members', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.muted2)),
                      SizedBox(width: 8),
                      Container(
                        width: 4, height: 4,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: joined ? _GC.whatsapp : _GC.muted2),
                      ),
                      SizedBox(width: 4),
                      Text(joined ? 'joined' : 'pending', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: joined ? _GC.whatsapp : _GC.muted2)),
                    ],
                  ),
                ],
              ),
            ),
            // Selected check
            if (selected)
              Container(
                width: 22, height: 22,
                decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.whatsapp),
                child: Center(child: Icon(Icons.check, color: _GC.text, size: 14)),
              ),
          ],
        ),
      ),
    );
  }

  // ── Shimmer loading untuk my groups list ──
  Widget _buildGroupsShimmer() {
    return Shimmer.fromColors(
      baseColor: _GC.surface,
      highlightColor: _GC.border,
      child: Column(
        children: List.generate(3, (_) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: _GC.surface,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.surface)),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 10, width: 120, decoration: BoxDecoration(color: _GC.surface, borderRadius: BorderRadius.circular(4))),
                    SizedBox(height: 6),
                    Container(height: 8, width: 80, decoration: BoxDecoration(color: _GC.surface, borderRadius: BorderRadius.circular(4))),
                  ],
                ),
              ),
            ],
          ),
        )),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUG SELECTOR (Pilih jenis bug grup) — data dari /bugGroupSystems
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBugSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _GC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.border, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _GC.whatsapp.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                ),
                child: Center(child: FaIcon(FontAwesomeIcons.bug, color: _GC.whatsapp, size: 12)),
              ),
              SizedBox(width: 10),
              Text('BUG TYPE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2, color: _GC.text)),
              Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _GC.whatsapp.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                ),
                child: Text(
                  _selectedBugId.isEmpty ? '--' : _selectedBugId.toUpperCase(),
                  style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.whatsapp, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          // Bug grid — render loading shimmer / empty state / grid.
          if (_loadingBugs)
            _buildBugShimmer()
          else if (_bugTypes.isEmpty)
            _buildBugEmpty()
          else
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: _bugTypes.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 1.1,
              ),
              itemBuilder: (ctx, i) {
                final bug = _bugTypes[i];
                final bugId = (bug['id'] ?? '').toString();
                final bugName = (bug['name'] ?? bugId).toString();
                final bugDesc = (bug['description'] ?? '').toString();
                final selected = _selectedBugId == bugId;
                return GestureDetector(
                  onTap: _isSending ? null : () {
                    setState(() => _selectedBugId = bugId);
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: selected ? _GC.whatsapp.withOpacity(0.12) : _GC.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: selected ? _GC.whatsapp : _GC.border2,
                        width: selected ? 1.5 : 1,
                      ),
                      boxShadow: selected
                          ? [BoxShadow(color: _GC.whatsapp.withOpacity(0.15), blurRadius: 12)]
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          selected ? FontAwesomeIcons.fire : FontAwesomeIcons.bug,
                          color: selected ? _GC.whatsapp : _GC.muted2,
                          size: 16,
                        ),
                        SizedBox(height: 6),
                        Text(
                          bugName,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                            color: selected ? _GC.whatsapp : _GC.muted,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          bugDesc,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 7,
                            color: selected ? _GC.muted : _GC.muted2,
                            height: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  // ── Shimmer loading untuk bug grid ──
  Widget _buildBugShimmer() {
    return Shimmer.fromColors(
      baseColor: _GC.surface,
      highlightColor: _GC.border,
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: 6,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          childAspectRatio: 1.1,
        ),
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: _GC.surface,
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  // ── Empty state kalau API gagal / belum return data ──
  Widget _buildBugEmpty() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
      decoration: BoxDecoration(
        color: _GC.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _GC.border2),
      ),
      child: Column(
        children: [
          FaIcon(FontAwesomeIcons.bugSlash, color: _GC.muted2, size: 18),
          SizedBox(height: 8),
          Text('No bug systems available', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _GC.muted, letterSpacing: 1)),
          SizedBox(height: 4),
          GestureDetector(
            onTap: _fetchBugSystems,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: _GC.whatsapp.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
              ),
              child: Text('Retry', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.whatsapp, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FEATURE STRIP (Solid cards with shimmer)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFeatureStrip() {
    return Row(
      children: [
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.droplet, 'INSTANT', 'Fast deploy', _GC.accent)),
        SizedBox(width: 10),
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.shieldHalved, 'STEALTH', 'Undetected', _GC.whatsapp)),
        SizedBox(width: 10),
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.users, 'MASS', 'All members', _GC.gold)),
      ],
    );
  }

  Widget _buildFeatureCard(FaIconData icon, String title, String subtitle, Color color) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (ctx, _) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
          decoration: BoxDecoration(
            color: _GC.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.12 + _shimmerController.value * 0.08), width: 1),
          ),
          child: Column(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.2)),
                ),
                child: Center(child: FaIcon(icon, color: color, size: 16)),
              ),
              SizedBox(height: 10),
              Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: color)),
              SizedBox(height: 3),
              Text(subtitle, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.muted2)),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  LAUNCH BUTTON (Green gradient with pulse)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final pulse = _pulseController.value;
        return Container(
          width: double.infinity,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: _GC.whatsapp.withOpacity(0.18 + pulse * 0.08), blurRadius: 24),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [_GC.whatsapp, _GC.whatsappDark],
                begin: Alignment(-0.7, -0.4),
                end: Alignment(0.7, 0.4),
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _isSending ? null : _sendGroupBug,
                splashColor: Colors.white.withOpacity(0.08),
                highlightColor: Colors.white.withOpacity(0.04),
                child: Center(
                  child: _isSending
                      ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white.withOpacity(0.4))),
                          SizedBox(width: 16),
                          Text('INJECTING', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 5, color: _GC.text)),
                        ])
                      : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          FaIcon(FontAwesomeIcons.dragon, color: _GC.text, size: 18),
                          SizedBox(width: 14),
                          Text('LAUNCH GROUP STRIKE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
                          SizedBox(width: 14),
                          Container(padding: const EdgeInsets.all(5), decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.1)), child: Icon(Icons.arrow_forward, color: _GC.text, size: 14)),
                        ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STATUS BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _GC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.whatsapp, boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)])),
                SizedBox(width: 8),
                Text('SYSTEM ONLINE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.whatsapp, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _GC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FaIcon(FontAwesomeIcons.users, color: _GC.accent, size: 10),
                SizedBox(width: 8),
                Text('MASS MODE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.accent, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ACCESS DENIED VIEW
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAccessDenied() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            color: _GC.accent.withOpacity(0.08),
            shape: BoxShape.circle,
            border: Border.all(color: _GC.accent.withOpacity(0.25), width: 2),
          ),
          child: FaIcon(FontAwesomeIcons.lock, color: _GC.accent, size: 32),
        ),
        SizedBox(height: 24),
        Text('ACCESS DENIED',
            style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 20, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 3)),
        SizedBox(height: 10),
        Container(width: 36, height: 2, decoration: BoxDecoration(color: _GC.accent.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
        SizedBox(height: 14),
        Text('This feature is only available for\nVIP and authorized roles.',
            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted, height: 1.6),
            textAlign: TextAlign.center),
      ],
    );
  }

  // ── Shared Section Header + Icon Helper ──────────────────────────────
  Widget _buildSectionHeader(FaIconData icon, String title) {
    return Row(
      children: [
        _buildSecIco(icon),
        SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
          SizedBox(height: 4),
          Container(width: 30, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
        ]),
      ],
    );
  }

  Widget _buildSecIco(FaIconData icon) {
    return Container(
      width: 42, height: 42,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        color: _GC.whatsapp.withOpacity(0.1),
        border: Border.all(color: _GC.whatsapp.withOpacity(0.18)),
      ),
      child: Center(child: FaIcon(icon, color: _GC.whatsapp, size: 17)),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════
//  GROUP SUCCESS DIALOG (Clean solid style — no video)
// ═════════════════════════════════════════════════════════════════════════
class _GroupSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final String bugType;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;

  const _GroupSuccessDialog({
    required this.linkGroup,
    required this.bugType,
    required this.data,
    required this.onDismiss,
  });

  @override
  State<_GroupSuccessDialog> createState() => _GroupSuccessDialogState();
}

class _GroupSuccessDialogState extends State<_GroupSuccessDialog> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _infoController;
  late AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _infoController = AnimationController(vsync: this, duration: Duration(milliseconds: 400));
    _glowController = AnimationController(vsync: this, duration: Duration(seconds: 2))..repeat(reverse: true);

    _scaleController.forward();

    // Auto-reveal info after short delay
    Future.delayed(Duration(milliseconds: 600), () {
      if (mounted) _revealInfo();
    });
  }

  void _revealInfo() {
    if (mounted) {
      _infoController.forward();
    }
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _infoController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.88;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ScaleTransition(
        scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        child: Container(
          width: w,
          constraints: BoxConstraints(maxWidth: 400),
          decoration: BoxDecoration(
            color: _GC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _GC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 36, offset: Offset(0, 14)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icon circle with animated glow
                    AnimatedBuilder(
                      animation: _glowController,
                      builder: (ctx, _) {
                        return Container(
                          width: 90, height: 90,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _GC.card,
                            border: Border.all(
                              color: _GC.whatsapp.withOpacity(0.25 + _glowController.value * 0.1),
                              width: 2,
                            ),
                          ),
                          child: Container(
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [_GC.whatsapp, _GC.whatsappDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: Center(
                              child: FaIcon(FontAwesomeIcons.dragon,
                                color: _GC.text, size: 36,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 24),
                    Text('GROUP OBLITERATED', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
                    SizedBox(height: 6),
                    Container(width: 40, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
                    SizedBox(height: 18),
                    // Target info
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: _GC.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _GC.border2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              FaIcon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 16),
                              SizedBox(width: 10),
                              Flexible(
                                child: Text(
                                  _truncateLink(widget.linkGroup),
                                  style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.w700, color: _GC.text),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          // Status badge
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: _GC.success.withOpacity(0.1),
                              border: Border.all(color: _GC.success.withOpacity(0.2)),
                            ),
                            child: Text(
                              widget.data["sended"] == true ? 'INJECTED' : (widget.data["success"] == true ? 'INJECTED' : 'FAILED'),
                              style: TextStyle(
                                fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2,
                                color: (widget.data["sended"] == true || widget.data["success"] == true) ? _GC.success : _GC.accent,
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          // Bug type badge
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: _GC.whatsapp.withOpacity(0.1),
                              border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                            ),
                            child: Text(
                              'BUG: ${widget.bugType.toUpperCase()}',
                              style: TextStyle(
                                fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2,
                                color: _GC.whatsapp,
                              ),
                            ),
                          ),
                          // Group info if available
                          if (widget.data["groupInfo"] != null) ...[
                            SizedBox(height: 12),
                            Container(height: 1, color: _GC.border2),
                            SizedBox(height: 10),
                            _buildDetailRow('Group', widget.data["groupInfo"]["subject"] ?? "Unknown"),
                            SizedBox(height: 6),
                            _buildDetailRow('Members', widget.data["groupInfo"]["participants"]?.toString() ?? "Unknown"),
                          ],
                          if (widget.data["canSendMessage"] != null) ...[
                            SizedBox(height: 6),
                            _buildDetailRow('Injection', widget.data["canSendMessage"] ? "SUCCESS" : "BLOCKED",
                                color: widget.data["canSendMessage"] ? _GC.success : _GC.accent),
                          ],
                        ],
                      ),
                    ),
                    SizedBox(height: 24),
                    // Close button
                    GestureDetector(
                      onTap: widget.onDismiss,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _GC.text,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 14)],
                        ),
                        child: Center(child: Text('CLOSE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _GC.bg))),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {Color? color}) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text('[$label]', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.muted)),
        ),
        Expanded(
          child: Text(value, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.w700, color: color ?? _GC.text)),
        ),
      ],
    );
  }

  String _truncateLink(String link) {
    if (link.length > 40) {
      return '${link.substring(0, 37)}...';
    }
    return link;
  }
}