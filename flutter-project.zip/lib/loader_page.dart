// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';
import 'dart:math' as math;
import 'dart:ui';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'device_dashboard.dart';
import 'anime.dart'; // ═══════════ ANIME IMPORT ═══════════

// ── COLOR SCHEME (redesigned palette) ─────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF070B18);
  static const bg2       = Color(0xFF0D1428);
  static const surface   = Color(0xFF111A30);
  static const card      = Color(0xFF111A30);
  static const accent    = Color(0xFF8B5CFF);
  static const accent2   = Color(0xFF633BDB);
  static const accent3   = Color(0xFF2583FF);
  static const gold      = Color(0xFFFFAD32);
  static const cyan      = Color(0xFF36D9FF);
  static const danger    = Color(0xFFFF4D6D);
  static const success   = Color(0xFF00D6A0);
  static const text      = Color(0xFFF5F7FF);
  static const muted     = Color(0xFFA8B4D8);
  static const muted2    = Color(0x66A8B4D8);
  static const border    = Color(0x1AFFFFFF);
  static const border2   = Color(0x14FFFFFF);
  // gradients
  static const purpleG1  = Color(0xFF9B5CFF);
  static const purpleG2  = Color(0xFF5728D9);
  static const blueG1    = Color(0xFF2787FF);
  static const blueG2    = Color(0xFF123CC7);
  static const greenG1   = Color(0xFF00D6A0);
  static const greenG2   = Color(0xFF007D66);
  // feature card colors
  static const waG1      = Color(0xFF00D6A0);
  static const waG2      = Color(0xFF007D66);
  static const tgG1      = Color(0xFF2787FF);
  static const tgG2      = Color(0xFF123CC7);
  static const ratG1     = Color(0xFF9B5CFF);
  static const ratG2     = Color(0xFF5728D9);
  // legacy aliases (keeps old widgets compiling)
  static const orangeG1  = purpleG1;
  static const orangeG2  = purpleG2;
  static const redG1     = Color(0xFFFF4D6D);
  static const redG2     = Color(0xFF5728D9);
  static const fanGreen1 = greenG1;
  static const fanBlue1  = blueG1;
  static const fanPurple1= purpleG1;
  static const qaGreen1  = Color(0xFF0F3D30);
  static const qaGreen2  = Color(0xFF07231C);
  static const qaOrange1 = Color(0xFF3D2600);
  static const qaOrange2 = Color(0xFF231600);
  static const qaBlue1   = Color(0xFF102A4D);
  static const qaBlue2   = Color(0xFF08182D);
  static const qaRed1    = Color(0xFF3D0F1A);
  static const qaRed2    = Color(0xFF23080F);
}

// ── DASHBOARD PAGE ────────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, WidgetsBindingObserver {

  // ── State ─────────────────────────────────────────────────────────────────
  late String _username;
  late String _password;
  late String _role;
  late String _sessionKey;
  late String _expiredDate;
  late List<Map<String, dynamic>> _listBug;
  late List<Map<String, dynamic>> _listPayload;
  late List<Map<String, dynamic>> _listDDoS;
  late List<dynamic> _newsList;
  String _uid = '';
  int _activeCount = 0;
  int _totalCount = 0;

  // Bottom nav
  int _bottomNavIndex = 0;
  static const double _bottomNavHeight = 72.0;

  // Real-time device info
  String _deviceTemp = '--°C';
  String _batteryLevel = '--%';
  BatteryState _batteryState = BatteryState.unknown;
  final Battery _battery = Battery();
  static const _deviceChannel = MethodChannel('com.Xcut Crasher/device');
  Timer? _tempTimer;

  // Prayer schedule
  Map<String, String> _prayerTimes = {};
  String _nextPrayerKey = '';
  String _prayerCountdown = '--:--:--';
  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  bool _prayerLoading = true;
  String _prayerError = '';
  static const _prayerKeys = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  static const _prayerLabels = {
    'Fajr':    'SUBUH',
    'Dhuhr':   'DZUHUR',
    'Asr':     'ASHAR',
    'Maghrib': 'MAGHRIB',
    'Isha':    'ISYA',
  };
  static const _prayerIcons = {
    'Fajr':    FontAwesomeIcons.moon,
    'Dhuhr':   FontAwesomeIcons.sun,
    'Asr':     FontAwesomeIcons.cloudSun,
    'Maghrib': FontAwesomeIcons.sunPlantWilt,
    'Isha':    FontAwesomeIcons.solidMoon,
  };

  // Anime
  List<dynamic> _latestAnime = [];
  bool _animeLoading = true;
  final ScrollController _animeScrollController = ScrollController();

  int _currentNewsIndex = 0;
  bool _isMusicPlaying = false;

  // Audio
  final AudioPlayer _audioPlayer = AudioPlayer();

  // WebSocket
  WebSocketChannel? _wsChannel;
  bool _wsConnected = false;

  // Video background
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;
  static const _bgVideoUrl = 'https://files.catbox.moe/fxalco.mp4';

  // Animation controllers
  late AnimationController _pulseRingController;
  late AnimationController _dashRingController;

  // News
  final PageController _newsController = PageController();
  final ScrollController _quickAccessController = ScrollController();

  // Settings
  bool _settingsNotif = true;
  bool _settingsSound = true;
  bool _settingsAutoConnect = false;
  bool _settingsDarkMode = true;

  // ── Init ──────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _pulseRingController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _dashRingController = AnimationController(
      vsync: this, duration: const Duration(seconds: 8),
    )..repeat();

    _username    = widget.username;
    _password    = widget.password;
    _role        = widget.role;
    _sessionKey  = widget.sessionKey;
    _expiredDate = widget.expiredDate;
    _listBug     = widget.listBug;
    _listPayload = widget.listPayload;
    _listDDoS    = widget.listDDoS;
    _newsList    = widget.news;

    _loadUserData();
    _connectWebSocket();
    _initBattery();
    _initTempMonitor();
    _fetchPrayerTimes();
    _startClockTimer();
    _initAudio();
    _fetchLatestAnime();
    _initBgVideo();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _bgVideoController.dispose();
    _pulseRingController.dispose();
    _dashRingController.dispose();
    _newsController.dispose();
    _quickAccessController.dispose();
    _animeScrollController.dispose();
    _audioPlayer.dispose();
    _wsChannel?.sink.close(status.goingAway);
    _tempTimer?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!_bgVideoReady) return;
    if (state == AppLifecycleState.paused) {
      _bgVideoController.pause();
    } else if (state == AppLifecycleState.resumed) {
      _bgVideoController.play();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // VIDEO BACKGROUND
  // ═══════════════════════════════════════════════════════════════════════════
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.networkUrl(Uri.parse(_bgVideoUrl))
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FETCH LATEST ANIME
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchLatestAnime() async {
    setState(() => _animeLoading = true);
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/home'),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final ongoingList = jsonData['data']?['ongoing']?['animeList'] ?? [];
        final completedList = jsonData['data']?['completed']?['animeList'] ?? [];
        final List<dynamic> combined = [];
        combined.addAll(ongoingList.take(10));
        combined.addAll(completedList.take(5));
        if (mounted) {
          setState(() {
            _latestAnime = combined;
            _animeLoading = false;
          });
        }
      } else {
        throw Exception('status ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) setState(() => _animeLoading = false);
    }
  }

  // ── Battery ───────────────────────────────────────────────────────────────
  Future<void> _initBattery() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      if (mounted) {
        setState(() {
          _batteryLevel = '$level%';
          _batteryState = state;
        });
      }
      _battery.onBatteryStateChanged.listen((s) async {
        final lvl = await _battery.batteryLevel;
        if (mounted) {
          setState(() {
            _batteryLevel = '$lvl%';
            _batteryState = s;
          });
        }
      });
    } catch (_) {
      if (mounted) setState(() => _batteryLevel = '--');
    }
  }

  // ── Temp monitor ──────────────────────────────────────────────────────────
  void _initTempMonitor() {
    _fetchDeviceTemp();
    _tempTimer = Timer.periodic(const Duration(seconds: 30), (_) => _fetchDeviceTemp());
  }

  Future<void> _fetchDeviceTemp() async {
    try {
      final temp = await _deviceChannel.invokeMethod<double>('getBatteryTemp');
      if (temp != null && mounted) {
        setState(() => _deviceTemp = '${temp.toStringAsFixed(1)}°C');
      }
    } catch (_) {
      if (mounted && _deviceTemp == '--°C') setState(() => _deviceTemp = 'N/A');
    }
  }

  // ── Prayer ────────────────────────────────────────────────────────────────
  void _startClockTimer() {
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _now = DateTime.now();
          _updateNextPrayer();
        });
      }
    });
  }

  Future<void> _fetchPrayerTimes() async {
    setState(() { _prayerLoading = true; _prayerError = ''; });
    try {
      final now = DateTime.now();
      final ts = now.millisecondsSinceEpoch ~/ 1000;
      final url = 'https://api.aladhan.com/v1/timings/$ts?latitude=-6.2088&longitude=106.8456&method=11';
      final res = await http.get(Uri.parse(url))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final timings = body['data']['timings'] as Map<String, dynamic>;
        final Map<String, String> times = {};
        for (final k in _prayerKeys) {
          final raw = timings[k]?.toString() ?? '';
          times[k] = raw.contains(' ') ? raw.split(' ').first : raw;
        }
        if (mounted) {
          setState(() {
            _prayerTimes = times;
            _prayerLoading = false;
            _updateNextPrayer();
          });
        }
      } else {
        throw Exception('status ${res.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _prayerLoading = false;
          _prayerError = 'Gagal memuat jadwal';
        });
      }
    }
  }

  void _updateNextPrayer() {
    if (_prayerTimes.isEmpty) return;
    final now = _now;
    String? nextKey;
    Duration? minDiff;

    for (final k in _prayerKeys) {
      final t = _prayerTimes[k];
      if (t == null) continue;
      final parts = t.split(':');
      if (parts.length < 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      var prayerDt = DateTime(now.year, now.month, now.day, h, m);
      if (prayerDt.isBefore(now)) {
        prayerDt = prayerDt.add(const Duration(days: 1));
      }
      final diff = prayerDt.difference(now);
      if (minDiff == null || diff < minDiff) {
        minDiff = diff;
        nextKey = k;
      }
    }

    _nextPrayerKey = nextKey ?? '';
    if (minDiff != null) {
      final h = minDiff.inHours.toString().padLeft(2, '0');
      final m = (minDiff.inMinutes % 60).toString().padLeft(2, '0');
      final s = (minDiff.inSeconds % 60).toString().padLeft(2, '0');
      _prayerCountdown = '$h:$m:$s';
    }
  }

  bool _isPrayerPassed(String key) {
    final t = _prayerTimes[key];
    if (t == null) return false;
    final parts = t.split(':');
    if (parts.length < 2) return false;
    final h = int.tryParse(parts[0]) ?? 0;
    final m = int.tryParse(parts[1]) ?? 0;
    final prayerDt = DateTime(_now.year, _now.month, _now.day, h, m);
    return prayerDt.isBefore(_now);
  }

  // ── Data Loading ──────────────────────────────────────────────────────────
  Future<void> _loadUserData() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      _uid = androidInfo.id;
    } catch (_) { _uid = 'unknown'; }
    if (mounted) setState(() {});
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────
  void _connectWebSocket() {
    try {
      _wsChannel = WebSocketChannel.connect(Uri.parse('wss://beli-panel-di-daiyatstore.ptrodactyl.my.id:3482'));
      _wsChannel!.sink.add(jsonEncode({'type': 'validate', 'key': _sessionKey, 'androidId': _uid}));
      _wsChannel!.sink.add(jsonEncode({'type': 'stats'}));
      _wsChannel!.stream.listen(
        (msg) => _handleWsMessage(jsonDecode(msg)),
        onDone: () { setState(() => _wsConnected = false); Future.delayed(const Duration(seconds: 5), _connectWebSocket); },
        onError: (_) { setState(() => _wsConnected = false); Future.delayed(const Duration(seconds: 5), _connectWebSocket); },
      );
      setState(() => _wsConnected = true);
    } catch (_) { setState(() => _wsConnected = false); }
  }

  void _handleWsMessage(Map<String, dynamic> data) {
    if (data['type'] == 'myInfo' && data['valid'] == false) {
      String msg = 'Session invalid. Please login again.';
      if (data['reason'] == 'androidIdMismatch') msg = 'Your account has logged on another device.';
      else if (data['reason'] == 'keyInvalid') msg = 'Key is not valid. Please login again.';
      _handleInvalidSession(msg);
    }
  }

  Future<void> _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface.withOpacity(0.98),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _C.accent.withOpacity(0.5), width: 1),
        ),
        title: Row(children: [
          const Icon(Icons.warning_amber_rounded, color: Color(0xFF8B5CFF)),
          const SizedBox(width: 10),
          const Text('Session Expired', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16)),
        ]),
        content: Text(message, style: const TextStyle(fontSize: 14)),
        actions: [TextButton(
          onPressed: () => Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()), (r) => false),
          child: const Text('OK'),
        )],
      ),
    );
  }

  // ── Audio ─────────────────────────────────────────────────────────────────
  Future<void> _initAudio() async {
    try {
      await _audioPlayer.setSourceUrl('https://files.catbox.moe/yfd2b4.mp3');
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.setVolume(0.3);
    } catch (_) {}
  }

  Future<void> _toggleMusic() async {
    if (_isMusicPlaying) await _audioPlayer.pause();
    else await _audioPlayer.resume();
    setState(() => _isMusicPlaying = !_isMusicPlaying);
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigateTo(String page) {
    switch (page) {
      case 'home': setState(() => _bottomNavIndex = 0); break;
      case 'bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'custom_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'group_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'telegram': Navigator.of(context).push(MaterialPageRoute(builder: (_) => TelegramSpamPage(sessionKey: _sessionKey))); break;
      case 'rat': Navigator.of(context).push(MaterialPageRoute(builder: (_) => DeviceDashboardPage(username: _username, role: _role, sessionKey: _sessionKey))); break;
      case 'ddos': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: _sessionKey, listDDoS: _listDDoS))); break;
      case 'tools': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ToolsPage(sessionKey: _sessionKey, userRole: _role, username: _username, listDDoS: _listDDoS))); break;
      case 'seller': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SellerPage(keyToken: _sessionKey))); break;
      case 'admin': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminPage(sessionKey: _sessionKey))); break;
      case 'sender': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SenderPage(sessionKey: _sessionKey))); break;
      case 'change_password': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: _username, sessionKey: _sessionKey))); break;
      case 'settings': _showSettingsPage(); break;
    }
  }

  void _copyUid() {
    Clipboard.setData(ClipboardData(text: _uid));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('UID copied!', style: TextStyle(color: Color(0xFFF5F7FF))),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 2),
    ));
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _wsChannel?.sink.close(status.goingAway);
    await _audioPlayer.stop();
    if (mounted) Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()), (r) => false);
  }

  // ── Battery icon helper ───────────────────────────────────────────────────
  dynamic _batteryIcon() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return Icons.battery_charging_full;
    if (lvl >= 80) return Icons.battery_full;
    if (lvl >= 50) return Icons.battery_4_bar;
    if (lvl >= 20) return Icons.battery_2_bar;
    return Icons.battery_alert;
  }

  Color _batteryColor() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return const Color(0xFF36D9FF);
    if (lvl >= 50) return const Color(0xFF00D6A0);
    if (lvl >= 20) return _C.gold;
    return _C.danger;
  }

  // ── Settings page launcher ────────────────────────────────────────────────
  void _showSettingsPage() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => _SettingsPage(
      username: _username, sessionKey: _sessionKey,
      notif: _settingsNotif, sound: _settingsSound,
      autoConnect: _settingsAutoConnect, darkMode: _settingsDarkMode,
      onToggleNotif: (v) => setState(() => _settingsNotif = v),
      onToggleSound: (v) => setState(() => _settingsSound = v),
      onToggleAutoConnect: (v) => setState(() => _settingsAutoConnect = v),
      onToggleDarkMode: (v) => setState(() => _settingsDarkMode = v),
      onToggleMusic: _toggleMusic, isMusicPlaying: _isMusicPlaying,
    )));
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final screenWidth = mq.size.width;
    final bottomInset = mq.padding.bottom;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: true,
      body: Stack(
        children: [
          // ── Video background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF070B18), Color(0xFF0D1428), Color(0xFF070B18)],
                ),
              ),
            ),

          // ── Dark + navy overlay for readability ──
          Container(color: Colors.black.withOpacity(0.55)),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  const Color(0xFF070B18).withOpacity(0.55),
                  Colors.transparent,
                  const Color(0xFF070B18).withOpacity(0.75),
                ],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
          ),

          // ── Content ──
          SafeArea(
            bottom: false,
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: IndexedStack(
                    index: _bottomNavIndex == 2 ? 0 : _bottomNavIndex,
                    children: [
                      _buildHomeTab(screenWidth, bottomInset),
                      _buildMenuTab(bottomInset),
                      const SizedBox.shrink(),
                      _buildNewsTab(bottomInset),
                      _buildProfileTab(bottomInset),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Bottom Nav ──
          _buildBottomNav(bottomInset),
        ],
      ),
    );
  }
  
    // ═════════════════════════════════════════════════════════════════════════
  // HOME TAB
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildHomeTab(double screenWidth, double bottomInset) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(
        bottom: _bottomNavHeight + bottomInset + 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),
          _buildQuickActionsRow(),
          const SizedBox(height: 16),
          _buildProfileCard(),
          const SizedBox(height: 20),
          _buildQuickAccess(screenWidth),
          const SizedBox(height: 20),
          _buildLatestNews(),
          const SizedBox(height: 20),
          _buildLatestAnime(),
          const SizedBox(height: 20),
          _buildPrayerSchedule(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // MENU TAB (migrated sidebar destinations)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildMenuTab(double bottomInset) {
    final items = <Map<String, dynamic>>[
      {'icon': FontAwesomeIcons.store,      'label': 'Seller Panel', 'page': 'seller'},
      {'icon': FontAwesomeIcons.hatWizard,  'label': 'Admin',        'page': 'admin'},
      {'icon': FontAwesomeIcons.paperPlane, 'label': 'Sender Hub',   'page': 'sender'},
      {'icon': FontAwesomeIcons.toolbox,    'label': 'Tools',        'page': 'tools'},
      {'icon': FontAwesomeIcons.whatsapp,   'label': 'WA Crash',     'page': 'bug'},
      {'icon': FontAwesomeIcons.usersSlash, 'label': 'Group Bug',    'page': 'group_bug'},
      {'icon': FontAwesomeIcons.code,       'label': 'Custom Bug',   'page': 'custom_bug'},
      {'icon': FontAwesomeIcons.telegram,   'label': 'TG Spam',      'page': 'telegram'},
      {'icon': FontAwesomeIcons.android,    'label': 'RAT Control',  'page': 'rat'},
      {'icon': FontAwesomeIcons.bug,        'label': 'DDoS',         'page': 'ddos'},
      {'icon': FontAwesomeIcons.lock,       'label': 'Password',     'page': 'change_password'},
      {'icon': FontAwesomeIcons.gear,       'label': 'Settings',     'page': 'settings'},
    ];

    return SingleChildScrollView(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: _bottomNavHeight + bottomInset + 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('MENU',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 20, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const SizedBox(height: 4),
          Text('Semua fitur aplikasi',
              style: TextStyle(fontSize: 12, color: _C.muted)),
          const SizedBox(height: 16),
          GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.95,
            ),
            itemBuilder: (ctx, i) {
              final it = items[i];
              return _menuTile(it['icon'], it['label'], it['page']);
            },
          ),
        ],
      ),
    );
  }

  Widget _menuTile(dynamic icon, String label, String page) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () => _navigateTo(page),
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          decoration: BoxDecoration(
            color: _C.card.withOpacity(0.65),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: _C.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _DynamicIcon(icon, color: _C.accent, size: 17),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 11, color: _C.text, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // NEWS TAB
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildNewsTab(double bottomInset) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: _bottomNavHeight + bottomInset + 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('PREMIUM NEWS',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 20, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const SizedBox(height: 16),
          _buildLatestNews(),
          const SizedBox(height: 20),
          _buildLatestAnime(),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // PROFILE TAB
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildProfileTab(double bottomInset) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: _bottomNavHeight + bottomInset + 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('PROFILE',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 20, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const SizedBox(height: 16),
          _buildProfileCard(),
          const SizedBox(height: 16),
          _accountActionsCard(),
        ],
      ),
    );
  }

  Widget _accountActionsCard() {
    return Container(
      decoration: BoxDecoration(
        color: _C.card.withOpacity(0.65),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border),
      ),
      child: Column(children: [
        _profileAction(Icons.lock_outline, 'Change Password',
            () => _navigateTo('change_password')),
        Divider(height: 1, color: _C.border2),
        _profileAction(Icons.settings_outlined, 'Settings', _showSettingsPage),
        Divider(height: 1, color: _C.border2),
        _profileAction(Icons.logout, 'Logout', _logout, danger: true),
      ]),
    );
  }

  Widget _profileAction(IconData icon, String label, VoidCallback onTap,
      {bool danger = false}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            Icon(icon, color: danger ? _C.danger : _C.muted, size: 18),
            const SizedBox(width: 14),
            Expanded(
              child: Text(label,
                  style: TextStyle(
                    fontSize: 14,
                    color: danger ? _C.danger : _C.text,
                  )),
            ),
            Icon(Icons.chevron_right, color: _C.muted2, size: 18),
          ]),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BOTTOM NAV
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildBottomNav(double bottomInset) {
    return Positioned(
      left: 12, right: 12,
      bottom: bottomInset + 8,
      child: Container(
        height: _bottomNavHeight,
        decoration: BoxDecoration(
          color: const Color(0xFF0D1428).withOpacity(0.92),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _C.accent.withOpacity(0.35), width: 1),
          boxShadow: [
            BoxShadow(
              color: _C.accent.withOpacity(0.18),
              blurRadius: 24,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Row(
              children: [
                Expanded(child: _navItemNew(FontAwesomeIcons.house, 'Home', 0)),
                Expanded(child: _navItemNew(FontAwesomeIcons.bars, 'Menu', 1)),
                Expanded(child: _centerActionButton()),
                Expanded(child: _navItemNew(FontAwesomeIcons.newspaper, 'News', 3)),
                Expanded(child: _navItemNew(FontAwesomeIcons.user, 'Profile', 4)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItemNew(dynamic icon, String label, int index) {
    final active = _bottomNavIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => setState(() => _bottomNavIndex = index),
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                width: 32, height: 32,
                decoration: BoxDecoration(
                  color: active ? _C.accent.withOpacity(0.18) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: active
                      ? [BoxShadow(color: _C.accent.withOpacity(0.45), blurRadius: 12)]
                      : null,
                ),
                child: _DynamicIcon(
                  icon,
                  size: 15,
                  color: active ? _C.accent : _C.muted,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                  color: active ? _C.text : _C.muted2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _centerActionButton() {
    return Center(
      child: GestureDetector(
        onTap: _showCenterActionSheet,
        child: Container(
          width: 58, height: 58,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [_C.purpleG1, _C.purpleG2],
            ),
            boxShadow: [
              BoxShadow(
                color: _C.accent.withOpacity(0.55),
                blurRadius: 18,
                spreadRadius: 1,
              ),
            ],
          ),
          child: const Icon(Icons.add, color: Colors.white, size: 26),
        ),
      ),
    );
  }

  void _showCenterActionSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: _C.muted2, borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          Text('QUICK ACTION',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 14, fontWeight: FontWeight.bold, color: _C.text,
              )),
          const SizedBox(height: 20),
          _bugTypeOption(FontAwesomeIcons.whatsapp, 'WA Crash',
              () { Navigator.of(ctx).pop(); _navigateTo('bug'); }),
          const SizedBox(height: 10),
          _bugTypeOption(FontAwesomeIcons.telegram, 'TG Spam',
              () { Navigator.of(ctx).pop(); _navigateTo('telegram'); }),
          const SizedBox(height: 10),
          _bugTypeOption(FontAwesomeIcons.android, 'RAT Control',
              () { Navigator.of(ctx).pop(); _navigateTo('rat'); }),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  Widget _bugTypeOption(dynamic icon, String label, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.border),
          ),
          child: Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _C.accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: _DynamicIcon(icon, color: _C.accent, size: 16),
            ),
            const SizedBox(width: 14),
            Expanded(child: Text(label,
                style: TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w600))),
            Icon(Icons.chevron_right, color: _C.muted, size: 20),
          ]),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // HEADER
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        border: Border(bottom: BorderSide(color: _C.border2, width: 0.5)),
      ),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_C.purpleG1, _C.purpleG2]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: _C.accent.withOpacity(0.35), blurRadius: 12),
                ],
              ),
              child: const Icon(Icons.bolt, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Xcut Crasher',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _C.text,
                        letterSpacing: 0.3,
                      )),
                  const SizedBox(height: 1),
                  Text('Tools For Your Future',
                      style: TextStyle(fontSize: 10, color: _C.muted)),
                ],
              ),
            ),
            _headerIconButton(FontAwesomeIcons.magnifyingGlass, () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Search coming soon'),
                  backgroundColor: _C.card,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }),
            const SizedBox(width: 8),
            _headerIconButton(FontAwesomeIcons.bell, () {
              setState(() => _bottomNavIndex = 3);
            }),
            const SizedBox(width: 8),
            _headerIconButton(FontAwesomeIcons.gear, _showSettingsPage),
          ]),
        ),
      ),
    );
  }

  Widget _headerIconButton(dynamic icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: _C.surface.withOpacity(0.7),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _C.border2),
        ),
        child: _DynamicIcon(icon, color: _C.muted, size: 15),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // QUICK ACTION ROW (three feature cards)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildQuickActionsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Expanded(child: _quickActionCard(
          'WA CRASH', 'Contact bug',
          _C.waG1, _C.waG2, FontAwesomeIcons.whatsapp,
          () => _navigateTo('bug'),
        )),
        const SizedBox(width: 10),
        Expanded(child: _quickActionCard(
          'TG SPAM', 'Mass sender',
          _C.tgG1, _C.tgG2, FontAwesomeIcons.telegram,
          () => _navigateTo('telegram'),
        )),
        const SizedBox(width: 10),
        Expanded(child: _quickActionCard(
          'RAT CTRL', 'Remote device',
          _C.ratG1, _C.ratG2, FontAwesomeIcons.android,
          () => _navigateTo('rat'),
        )),
      ]),
    );
  }

  Widget _quickActionCard(
    String title,
    String subtitle,
    Color g1,
    Color g2,
    dynamic icon,
    VoidCallback onTap,
  ) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          height: 96,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [g1.withOpacity(0.22), g2.withOpacity(0.10)],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: g1.withOpacity(0.45), width: 1),
          ),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: g1.withOpacity(0.20),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: g1.withOpacity(0.35)),
                  ),
                  child: _DynamicIcon(icon, color: g1, size: 15),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: _C.text,
                          letterSpacing: 0.5,
                        )),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 9, color: _C.muted)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // PROFILE CARD
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.72),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20),
          ],
        ),
        child: Column(children: [
          Row(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network('https://files.catbox.moe/ycw0o4.png',
                  width: 48, height: 48 * 16 / 9, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 48, height: 85, color: _C.surface,
                    child: Icon(Icons.person, color: _C.muted2),
                  )),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('WELCOME BACK', style: TextStyle(fontSize: 11, color: _C.muted, letterSpacing: 1)),
              const SizedBox(height: 2),
              Text(_username.toUpperCase(),
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 17, fontWeight: FontWeight.bold, color: _C.text,
                  )),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _C.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.check_circle, color: _C.accent, size: 11),
                  const SizedBox(width: 4),
                  Text(_role.toUpperCase(),
                      style: TextStyle(color: _C.accent, fontSize: 9, fontWeight: FontWeight.w600)),
                ]),
              ),
            ])),
            Opacity(opacity: 0.75, child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network('https://j.top4top.io/p_3843d57a91.jpg',
                  width: 100, height: 100, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    width: 100, height: 100, color: _C.surface,
                  )),
            )),
          ]),
          const SizedBox(height: 12),
          Container(height: 1, color: _C.border2),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _statBox('ACTIVE', '$_activeCount', _C.accent)),
            const SizedBox(width: 8),
            Expanded(child: _statBox('TOTAL', '$_totalCount', _C.text)),
            const SizedBox(width: 8),
            Expanded(child: _statBox('UNTIL', _expiredDate, _C.gold)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Row(children: [
              Text('UID: ', style: TextStyle(fontSize: 11, color: _C.muted)),
              Flexible(child: Text(_uid,
                  style: TextStyle(fontSize: 11, color: _C.text, fontWeight: FontWeight.w600),
                  overflow: TextOverflow.ellipsis)),
              const SizedBox(width: 4),
              GestureDetector(
                onTap: _copyUid,
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: _C.surface, borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(Icons.copy, color: _C.muted, size: 12),
                ),
              ),
            ])),
            Row(children: [
              Icon(Icons.thermostat,
                  color: _deviceTemp == 'N/A' ? _C.muted2 : _C.accent, size: 13),
              const SizedBox(width: 3),
              Text(_deviceTemp,
                  style: TextStyle(fontSize: 11,
                      color: _deviceTemp == 'N/A' ? _C.muted2 : _C.text)),
              const SizedBox(width: 10),
              _DynamicIcon(_batteryIcon(), color: _batteryColor(), size: 13),
              const SizedBox(width: 3),
              Text(_batteryLevel,
                  style: TextStyle(fontSize: 11, color: _batteryColor())),
            ]),
          ]),
        ]),
      ),
    );
  }

  Widget _statBox(String label, String value, Color valueColor) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(label, style: TextStyle(fontSize: 9, color: _C.muted, letterSpacing: 1)),
        const SizedBox(height: 4),
        Text(value,
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: valueColor),
            overflow: TextOverflow.ellipsis),
      ]),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // QUICK ACCESS
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildQuickAccess(double screenWidth) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Text('QUICK ACCESS',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 12, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const Spacer(),
          GestureDetector(
            onTap: () => setState(() => _bottomNavIndex = 1),
            child: Text('See All', style: TextStyle(fontSize: 11, color: _C.accent)),
          ),
        ]),
      ),
      const SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Expanded(child: _quickAccessCard(
            'SENDER', 'Kirim pesan massal',
            const [Color(0xFF0F3D30), Color(0xFF07231C)],
            FontAwesomeIcons.paperPlane,
            () => _navigateTo('sender'),
          )),
          const SizedBox(width: 12),
          Expanded(child: _quickAccessCard(
            'TOOLS', 'Utilitas & fitur',
            const [Color(0xFF3D2600), Color(0xFF231600)],
            FontAwesomeIcons.toolbox,
            () => _navigateTo('tools'),
          )),
        ]),
      ),
    ]);
  }

  Widget _quickAccessCard(String label, String subtitle, List<Color> gradientColors,
      dynamic icon, VoidCallback onTap) {
    return Material(
      color: Colors.transparent, borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(16),
        splashColor: gradientColors[0].withOpacity(0.3),
        child: Ink(
          height: 118,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: gradientColors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: gradientColors[0].withOpacity(0.5), width: 1),
          ),
          child: Stack(children: [
            Positioned(right: -10, bottom: -14,
                child: _DynamicIcon(icon, size: 80, color: Colors.white.withOpacity(0.06))),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
                        ),
                        child: _DynamicIcon(icon, color: Colors.white.withOpacity(0.85), size: 15),
                      ),
                      Icon(Icons.arrow_forward_ios,
                          color: Colors.white.withOpacity(0.25), size: 11),
                    ],
                  ),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(label,
                        style: const TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12, fontWeight: FontWeight.bold,
                          color: Colors.white,
                        )),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.white.withOpacity(0.5),
                        )),
                  ]),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // LATEST NEWS
  // ═════════════════════════════════════════════════════════════════════════
  static const _newsAssets = [
    {'asset': 'assets/images/news1.jpg', 'title': 'Update Terbaru', 'tag': 'NEW'},
    {'asset': 'assets/images/news2.jpg', 'title': 'Maintenance Server', 'tag': 'INFO'},
    {'asset': 'assets/images/news3.jpg', 'title': 'Fitur Baru Tersedia', 'tag': 'NEW'},
  ];

  Widget _buildLatestNews() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Text('PREMIUM NEWS',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 12, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const Spacer(),
          GestureDetector(
            onTap: () => setState(() => _bottomNavIndex = 3),
            child: Text('View All', style: TextStyle(fontSize: 11, color: _C.accent)),
          ),
        ]),
      ),
      const SizedBox(height: 10),
      SizedBox(
        height: 180,
        child: PageView.builder(
          controller: _newsController,
          onPageChanged: (i) => setState(() => _currentNewsIndex = i),
          itemCount: _newsAssets.length,
          itemBuilder: (ctx, i) {
            final item = _newsAssets[i];
            final isRed = item['tag'] == 'NEW';
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                margin: const EdgeInsets.only(right: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _C.border),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(fit: StackFit.expand, children: [
                    Image.asset(item['asset']!, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: _C.bg2,
                          child: Center(child: Icon(Icons.newspaper, color: _C.muted2, size: 40)),
                        )),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black.withOpacity(0.85)],
                          stops: const [0.4, 1.0],
                        ),
                      ),
                    ),
                    Positioned(bottom: 14, left: 14, right: 14, child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isRed ? _C.accent.withOpacity(0.85) : _C.surface.withOpacity(0.85),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(item['tag']!,
                                style: TextStyle(
                                  fontSize: 9, fontWeight: FontWeight.bold,
                                  color: isRed ? Colors.white : _C.muted,
                                )),
                          ),
                          const Spacer(),
                          const Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 12),
                        ]),
                        const SizedBox(height: 8),
                        Text(item['title']!,
                            style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white,
                              shadows: [Shadow(color: Colors.black54, blurRadius: 4)],
                            )),
                      ],
                    )),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 10),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_newsAssets.length, (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: _currentNewsIndex == i ? 18 : 6, height: 6,
          decoration: BoxDecoration(
            color: _currentNewsIndex == i ? _C.accent : _C.muted2,
            borderRadius: BorderRadius.circular(3),
          ),
        )),
      ),
    ]);
  }

  // ═════════════════════════════════════════════════════════════════════════
  // LATEST ANIME
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildLatestAnime() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _C.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.accent.withOpacity(0.25)),
                ),
                child: const _DynamicIcon(FontAwesomeIcons.tv, color: _C.accent, size: 13),
              ),
              const SizedBox(width: 10),
              Text('LATEST ANIME',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12, fontWeight: FontWeight.bold,
                    color: _C.text, letterSpacing: 1,
                  )),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const HomeAnimePage()),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.border2),
                  ),
                  child: Row(children: [
                    Text('See All', style: TextStyle(fontSize: 10, color: _C.muted)),
                    const SizedBox(width: 4),
                    Icon(Icons.chevron_right, color: _C.muted, size: 12),
                  ]),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (_animeLoading)
          SizedBox(
            height: 210,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: 6,
              itemBuilder: (_, __) => Container(
                width: 125,
                margin: const EdgeInsets.only(right: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 125, height: 170,
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border2),
                      ),
                      child: Center(
                        child: SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: _C.accent.withOpacity(0.5),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      width: 125, height: 12,
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        else if (_latestAnime.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              height: 100,
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.wifi_off, color: _C.muted2, size: 24),
                    const SizedBox(height: 8),
                    Text('Failed to load anime',
                        style: TextStyle(fontSize: 12, color: _C.muted)),
                    const SizedBox(height: 6),
                    GestureDetector(
                      onTap: _fetchLatestAnime,
                      child: Text('Retry',
                          style: TextStyle(color: _C.accent, fontSize: 11, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          SizedBox(
            height: 240,
            child: ListView.builder(
              controller: _animeScrollController,
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _latestAnime.length,
              itemBuilder: (context, index) {
                final anime = _latestAnime[index];
                final String title = anime['title'] ?? 'Unknown';
                final String poster = anime['poster'] ?? '';
                final String slug = anime['animeId'] ?? '';
                final String? episodes = anime['episodes']?.toString();
                final String? status = anime['status'];
                final String? score = anime['score'];
                final bool isOngoing = status?.toLowerCase() == 'ongoing';

                return Container(
                  width: 128,
                  margin: const EdgeInsets.only(right: 12),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => AnimeDetailPage(slug: slug)),
                        );
                      },
                      borderRadius: BorderRadius.circular(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Container(
                                width: 128, height: 175,
                                decoration: BoxDecoration(
                                  color: _C.surface,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: _C.border2),
                                ),
                                child: poster.isNotEmpty
                                    ? Image.network(poster, width: 128, height: 175,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) => Center(
                                          child: Icon(Icons.image_not_supported, color: _C.muted2, size: 28),
                                        ))
                                    : Center(child: Icon(Icons.movie, color: _C.muted2, size: 28)),
                              ),
                            ),
                            if (score != null && score.isNotEmpty)
                              Positioned(top: 8, left: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: _C.gold.withOpacity(0.9),
                                    borderRadius: BorderRadius.circular(6),
                                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4)],
                                  ),
                                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                                    const Icon(Icons.star, color: Colors.black87, size: 10),
                                    const SizedBox(width: 3),
                                    Text(score,
                                        style: const TextStyle(
                                          color: Colors.black87, fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'ShareTechMono',
                                        )),
                                  ]),
                                ),
                              ),
                            Positioned(top: 8, right: 8,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                decoration: BoxDecoration(
                                  color: isOngoing
                                      ? _C.accent.withOpacity(0.85)
                                      : const Color(0xFF00D6A0).withOpacity(0.85),
                                  borderRadius: BorderRadius.circular(6),
                                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4)],
                                ),
                                child: Text(
                                  (status ?? '?').toUpperCase(),
                                  style: const TextStyle(
                                    color: Colors.white, fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.transparent,
                                      Colors.transparent,
                                      Colors.black.withOpacity(0.6),
                                    ],
                                    stops: const [0.5, 0.7, 1.0],
                                  ),
                                ),
                              ),
                            ),
                            if (episodes != null)
                              Positioned(bottom: 8, left: 8, right: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.55),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.play_circle_outline, color: _C.accent3, size: 12),
                                      const SizedBox(width: 4),
                                      Text('$episodes Eps',
                                          style: TextStyle(
                                            color: _C.text, fontSize: 10,
                                            fontFamily: 'ShareTechMono',
                                          )),
                                    ],
                                  ),
                                ),
                              ),
                          ]),
                          const SizedBox(height: 8),
                          SizedBox(
                            width: 128,
                            child: Text(title,
                                style: TextStyle(
                                  color: _C.text, fontSize: 11,
                                  fontWeight: FontWeight.w600, height: 1.3,
                                ),
                                maxLines: 2, overflow: TextOverflow.ellipsis),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // PRAYER SCHEDULE
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildPrayerSchedule() {
    final hh = _now.hour.toString().padLeft(2, '0');
    final mm = _now.minute.toString().padLeft(2, '0');
    final ss = _now.second.toString().padLeft(2, '0');
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    final dayName = days[_now.weekday % 7];
    final dateStr = '$dayName, ${_now.day} ${months[_now.month - 1]} ${_now.year}';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Text('JADWAL SHOLAT',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 12, fontWeight: FontWeight.bold,
                color: _C.text, letterSpacing: 1,
              )),
          const Spacer(),
          GestureDetector(
            onTap: _fetchPrayerTimes,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.border2),
              ),
              child: Row(children: [
                Icon(Icons.refresh, color: _C.muted, size: 11),
                const SizedBox(width: 4),
                Text('Refresh', style: TextStyle(fontSize: 10, color: _C.muted)),
              ]),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card.withOpacity(0.72),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _C.border),
          ),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                gradient: const LinearGradient(
                  colors: [Color(0xFF1a2540), Color(0xFF0f1525)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
              ),
              child: Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('$hh:$mm:$ss',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 28, fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [Shadow(color: _C.accent.withOpacity(0.6), blurRadius: 12)],
                      )),
                  const SizedBox(height: 2),
                  Text(dateStr,
                      style: TextStyle(fontSize: 11, color: _C.muted, fontFamily: 'ShareTechMono')),
                ]),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Row(children: [
                    Icon(Icons.location_on, color: _C.accent, size: 12),
                    const SizedBox(width: 3),
                    Text('Jakarta, ID', style: TextStyle(fontSize: 11, color: _C.muted)),
                  ]),
                  const SizedBox(height: 6),
                  if (!_prayerLoading && _nextPrayerKey.isNotEmpty) ...[
                    Text(_prayerLabels[_nextPrayerKey] ?? _nextPrayerKey,
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 9, color: _C.accent, letterSpacing: 1,
                        )),
                    const SizedBox(height: 2),
                    Text(_prayerCountdown,
                        style: const TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 16, fontWeight: FontWeight.bold,
                          color: Colors.white,
                        )),
                    Text('menuju waktu berikutnya',
                        style: TextStyle(fontSize: 9, color: _C.muted)),
                  ],
                ]),
              ]),
            ),
            Container(height: 1, color: _C.border2),
            if (_prayerLoading)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Center(child: SizedBox(
                  width: 24, height: 24,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _C.accent),
                )),
              )
            else if (_prayerError.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Icon(Icons.wifi_off, color: _C.muted2, size: 28),
                  const SizedBox(height: 8),
                  Text(_prayerError, style: TextStyle(color: _C.muted, fontSize: 12)),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: _fetchPrayerTimes,
                    child: Text('Coba lagi', style: TextStyle(color: _C.accent, fontSize: 12)),
                  ),
                ]),
              )
            else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(children: _prayerKeys.map((k) => _prayerTile(k)).toList()),
              ),
          ]),
        ),
      ),
    ]);
  }

  Widget _prayerTile(String key) {
    final isNext    = key == _nextPrayerKey;
    final isPassed  = _isPrayerPassed(key) && !isNext;
    final time      = _prayerTimes[key] ?? '--:--';
    final label     = _prayerLabels[key] ?? key;
    final icon      = _prayerIcons[key] ?? FontAwesomeIcons.mosque;

    Color iconColor;
    Color labelColor;
    Color timeColor;
    Color bgColor;
    Color borderColor;

    if (isNext) {
      iconColor   = _C.accent;
      labelColor  = Colors.white;
      timeColor   = _C.accent;
      bgColor     = _C.accent.withOpacity(0.08);
      borderColor = _C.accent.withOpacity(0.25);
    } else if (isPassed) {
      iconColor   = _C.muted2;
      labelColor  = _C.muted;
      timeColor   = _C.muted;
      bgColor     = Colors.transparent;
      borderColor = Colors.transparent;
    } else {
      iconColor   = _C.muted;
      labelColor  = _C.text;
      timeColor   = _C.text;
      bgColor     = Colors.transparent;
      borderColor = Colors.transparent;
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: isNext ? 1 : 0),
      ),
      child: Row(children: [
        Container(
          width: 34, height: 34,
          decoration: BoxDecoration(
            color: isNext ? _C.accent.withOpacity(0.12) : _C.surface,
            borderRadius: BorderRadius.circular(10),
          ),
          child: _DynamicIcon(icon, color: iconColor, size: 14),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(
            fontFamily: 'MADEEvolveSansEVO',
            fontSize: 11, fontWeight: isNext ? FontWeight.bold : FontWeight.w500,
            color: labelColor,
          )),
          if (isNext) ...[
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: _C.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text('BERIKUTNYA',
                  style: TextStyle(
                    fontSize: 8, color: _C.accent,
                    fontWeight: FontWeight.bold, letterSpacing: 0.5,
                  )),
            ),
          ],
        ])),
        Text(time, style: TextStyle(
          fontFamily: 'ShareTechMono', fontSize: 15,
          fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
          color: timeColor,
        )),
        const SizedBox(width: 8),
        if (isPassed)
          Icon(Icons.check_circle, color: _C.muted2, size: 14)
        else if (isNext)
          Container(width: 8, height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.accent,
              boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.5), blurRadius: 6)],
            ))
        else
          Container(width: 8, height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: _C.muted2)),
      ]),
    );
  }

} // ← END OF _DashboardPageState
// ═════════════════════════════════════════════════════════════════════════════
// DASHED CIRCLE PAINTER
// ═════════════════════════════════════════════════════════════════════════════
class _DashedCirclePainter extends CustomPainter {
  final Color color;
  final double dashWidth;
  final double dashGap;
  final double strokeWidth;

  _DashedCirclePainter({
    required this.color,
    this.dashWidth = 6,
    this.dashGap = 6,
    this.strokeWidth = 1.5,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;
    final circumference = 2 * 3.14159265 * radius;
    final totalDash = dashWidth + dashGap;
    final dashCount = (circumference / totalDash).floor();
    for (int i = 0; i < dashCount; i++) {
      final startAngle = (i * totalDash / circumference) * 2 * 3.14159265;
      final sweepAngle = (dashWidth / circumference) * 2 * 3.14159265;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle, sweepAngle, false, paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═════════════════════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ═════════════════════════════════════════════════════════════════════════════
class _SettingsPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final bool notif, sound, autoConnect, darkMode;
  final ValueChanged<bool> onToggleNotif, onToggleSound, onToggleAutoConnect, onToggleDarkMode;
  final VoidCallback onToggleMusic;
  final bool isMusicPlaying;

  const _SettingsPage({
    required this.username,
    required this.sessionKey,
    required this.notif,
    required this.sound,
    required this.autoConnect,
    required this.darkMode,
    required this.onToggleNotif,
    required this.onToggleSound,
    required this.onToggleAutoConnect,
    required this.onToggleDarkMode,
    required this.onToggleMusic,
    required this.isMusicPlaying,
  });

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  late bool _n, _s, _a, _d, _m;

  @override
  void initState() {
    super.initState();
    _n = widget.notif;
    _s = widget.sound;
    _a = widget.autoConnect;
    _d = widget.darkMode;
    _m = widget.isMusicPlaying;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg2, elevation: 0,
        title: Text('SETTINGS',
            style: TextStyle(
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 14, fontWeight: FontWeight.bold, color: _C.text,
            )),
        iconTheme: IconThemeData(color: _C.text),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _C.border),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _sl('GENERAL'),
          const SizedBox(height: 8),
          _tt('Notifications', _n,
              (v) { setState(() => _n = v); widget.onToggleNotif(v); }, Icons.notifications),
          _tt('Sound Effects', _s,
              (v) { setState(() => _s = v); widget.onToggleSound(v); }, Icons.volume_up),
          _tt('Auto Connect', _a,
              (v) { setState(() => _a = v); widget.onToggleAutoConnect(v); }, Icons.sync),
          _tt('Dark Mode', _d,
              (v) { setState(() => _d = v); widget.onToggleDarkMode(v); }, Icons.dark_mode),
          const SizedBox(height: 16),
          _sl('AUDIO'),
          const SizedBox(height: 8),
          _tt('Background Music', _m,
              (_) { setState(() => _m = !_m); widget.onToggleMusic(); }, Icons.music_note),
          const SizedBox(height: 16),
          _sl('ACCOUNT'),
          const SizedBox(height: 8),
          _at('Change Password', Icons.lock,
              () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => ChangePasswordPage(
                  username: widget.username, sessionKey: widget.sessionKey,
                ),
              ))),
          _at('Logout', Icons.logout, () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (mounted) {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (r) => false);
            }
          }),
        ]),
      ),
    );
  }

  Widget _sl(String l) => Text(l,
      style: TextStyle(
        fontFamily: 'ShareTechMono', fontSize: 11,
        color: _C.muted, letterSpacing: 2,
      ));

  Widget _tt(String label, bool value, ValueChanged<bool> onChanged, dynamic icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: Row(children: [
        _DynamicIcon(icon, color: _C.muted, size: 18),
        const SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
        GestureDetector(
          onTap: () => onChanged(!value),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 44, height: 24,
            decoration: BoxDecoration(
              color: value ? _C.accent : _C.surface,
              borderRadius: BorderRadius.circular(12),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 200),
              alignment: value ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                width: 20, height: 20,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: value ? _C.accent : _C.muted2,
                  shape: BoxShape.circle,
                  boxShadow: value
                      ? [BoxShadow(color: _C.accent.withOpacity(0.4), blurRadius: 6)]
                      : [],
                ),
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: value ? Colors.white : _C.muted2,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _at(String label, dynamic icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border),
        ),
        child: Row(children: [
          _DynamicIcon(icon, color: _C.muted, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
          Icon(Icons.chevron_right, color: _C.muted, size: 18),
        ]),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// WEBA2APK DYNAMIC ICON
// ═════════════════════════════════════════════════════════════════════════════
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!
                .map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius))
                .toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}