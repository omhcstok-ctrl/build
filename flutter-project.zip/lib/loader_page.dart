// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';
import 'dart:math' as math;
import 'dart:ui';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';

import 'pair_spam_page.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'device_dashboard.dart';
import 'vip_upgrade_page.dart';
import 'leaderboard_page.dart';
import 'anime.dart'; // ═══════════ ANIME IMPORT ═══════════

// ── COLOR SCHEME ──────────────────────────────────────────────────────────────
class _C {
  // TRANTOR Color Scheme (light, premium fintech)
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFF333333);
  static const danger    = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
  static const greenG1   = Color(0xFFFF3B30);
  static const greenG2   = Color(0xFFCC2E25);
  static const blueG1    = Color(0xFFFF3B30);
  static const blueG2    = Color(0xFFCC2E25);
  static const purpleG1  = Color(0xFFFF3B30);
  static const purpleG2  = Color(0xFFCC2E25);
  static const orangeG1  = Color(0xFFFF3B30);
  static const orangeG2  = Color(0xFFCC2E25);
  static const redG1     = Color(0xFFFF3B30);
  static const redG2     = Color(0xFFD70015);
  static const fanGreen1 = Color(0xFFFF3B30);
  static const fanBlue1  = Color(0xFFFF3B30);
  static const fanPurple1= Color(0xFF333333);
  // Soft quick access (pastel)
  static const qaGreen1  = Color(0xFFE8FBF4);
  static const qaGreen2  = Color(0xFFC7F0DD);
  static const qaOrange1 = Color(0xFF222222);
  static const qaOrange2 = Color(0xFFFFE5A8);
  static const qaBlue1   = Color(0xFF333333);
  static const qaBlue2   = Color(0xFFD4B8E5);
  static const qaRed1    = Color(0xFFFFE5E5);
  static const qaRed2    = Color(0xFFFFC7C7);
}

// ── DASHBOARD PAGE ────────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {

  // ── State ─────────────────────────────────────────────────────────────────
  late String _username;
  late String _password;
  late String _role;
  late String _sessionKey;
  late String _expiredDate;
  late List<Map<String, dynamic>> _listBug;
  late List<Map<String, dynamic>> _listPayload;
  late List<Map<String, dynamic>> _listDDoS;
  late List<dynamic> _newsList;
  String _uid = '';
  int _activeCount = 0;
  int _totalCount = 0;
  bool _isLoadingSenders = false;
  List<dynamic> _dashboardSenders = [];

  // Real-time device info
  String _deviceTemp = '--°C';
  String _batteryLevel = '--%';
  BatteryState _batteryState = BatteryState.unknown;
  final Battery _battery = Battery();
  static const _deviceChannel = MethodChannel('com.yakuzaxsilence/device');
  Timer? _tempTimer;

  // Prayer schedule
  Map<String, String> _prayerTimes = {};
  String _nextPrayerKey = '';
  String _prayerCountdown = '--:--:--';
  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  bool _prayerLoading = true;
  String _prayerError = '';
  static const _prayerKeys = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  static const _prayerLabels = {
    'Fajr':    'SUBUH',
    'Dhuhr':   'DZUHUR',
    'Asr':     'ASHAR',
    'Maghrib': 'MAGHRIB',
    'Isha':    'ISYA',
  };
  static final _prayerIcons = {
    'Fajr':    FontAwesomeIcons.moon,
    'Dhuhr':   FontAwesomeIcons.sun,
    'Asr':     FontAwesomeIcons.cloudSun,
    'Maghrib': FontAwesomeIcons.sunPlantWilt,
    'Isha':    FontAwesomeIcons.solidMoon,
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // ═══ ANIME LATEST DATA ═══════════════════════════════════════════════════
  // ═══════════════════════════════════════════════════════════════════════════
  List<dynamic> _latestAnime = [];
  bool _animeLoading = true;
  final ScrollController _animeScrollController = ScrollController();

  bool _isSidebarOpen = false;
  bool _isFanMenuOpen = false;
  int _currentNavIndex = 0;
  int _currentNewsIndex = 0;
  bool _isMusicPlaying = false;
  String _currentPage = 'home';

  // Audio
  final AudioPlayer _audioPlayer = AudioPlayer();

  // WebSocket
  WebSocketChannel? _wsChannel;
  bool _wsConnected = false;

  // Video background
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;
  static const _bgVideoUrl = 'assets/videos/bg_video.mp4';

  // Animation controllers
  late AnimationController _pulseRingController;
  late AnimationController _dashRingController;
  late AnimationController _fanMenuController;
  late AnimationController _fanStaggerController;
  late AnimationController _sidebarController;

  // News
  final PageController _newsController = PageController();
  final ScrollController _quickAccessController = ScrollController();

  // Settings
  bool _settingsNotif = true;
  bool _settingsSound = true;
  bool _settingsAutoConnect = false;
  bool _settingsDarkMode = true;

  // ── Init ──────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    _pulseRingController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _dashRingController = AnimationController(
      vsync: this, duration: Duration(seconds: 8),
    )..repeat();

    _fanMenuController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 300),
    )..addListener(() { if (mounted) setState(() {}); });

    _fanStaggerController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 400),
    )..addListener(() { if (mounted) setState(() {}); });

    _sidebarController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 260),
    );

    _username    = widget.username;
    _password    = widget.password;
    _role        = widget.role;
    _sessionKey  = widget.sessionKey;
    _expiredDate = widget.expiredDate;
    _listBug     = widget.listBug;
    _listPayload = widget.listPayload;
    _listDDoS    = widget.listDDoS;
    _newsList    = widget.news;

    _loadUserData();
    _connectWebSocket();
    _initBattery();
    _initTempMonitor();
    _fetchPrayerTimes();
    _startClockTimer();
    _initAudio();
    _fetchLatestAnime(); // ═══════════ ANIME FETCH ═══════════
    _initBgVideo();
    _fetchBroadcasts(); // ═══════════ BROADCAST NOTIF ═══════════
    _fetchDashboardSenders();
  }

  @override
  void dispose() {
    _bgVideoController.dispose();
    _pulseRingController.dispose();
    _dashRingController.dispose();
    _fanMenuController.dispose();
    _fanStaggerController.dispose();
    _sidebarController.dispose();
    _newsController.dispose();
    _quickAccessController.dispose();
    _animeScrollController.dispose();
    _audioPlayer.dispose();
    _wsChannel?.sink.close(status.goingAway);
    _tempTimer?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // VIDEO BACKGROUND
  // ═══════════════════════════════════════════════════════════════════════════
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ═══ FETCH LATEST ANIME ══════════════════════════════════════════════════
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchLatestAnime() async {
    setState(() => _animeLoading = true);
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/home'),
      ).timeout(Duration(seconds: 10));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final ongoingList = jsonData['data']?['ongoing']?['animeList'] ?? [];
        final completedList = jsonData['data']?['completed']?['animeList'] ?? [];
        // Ambil 10 pertama dari ongoing + 5 dari completed untuk variasi
        final List<dynamic> combined = [];
        combined.addAll(ongoingList.take(10));
        combined.addAll(completedList.take(5));
        if (mounted) {
          setState(() {
            _latestAnime = combined;
            _animeLoading = false;
          });
        }
      } else {
        throw Exception('status ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _animeLoading = false);
      }
    }
  }

  // ── Real-time Battery ─────────────────────────────────────────────────────
  Future<void> _initBattery() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      if (mounted) {
        setState(() {
          _batteryLevel = '$level%';
          _batteryState = state;
        });
      }
      _battery.onBatteryStateChanged.listen((s) async {
        final lvl = await _battery.batteryLevel;
        if (mounted) {
          setState(() {
            _batteryLevel = '$lvl%';
            _batteryState = s;
          });
        }
      });
    } catch (_) {
      if (mounted) setState(() => _batteryLevel = '--');
    }
  }

  // ── Real-time Temperature ─────────────────────────────────────────────────
  // Requires native MethodChannel — lihat catatan di bawah file
  void _initTempMonitor() {
    _fetchDeviceTemp();
    _tempTimer = Timer.periodic(Duration(seconds: 30), (_) => _fetchDeviceTemp());
  }

  Future<void> _fetchDeviceTemp() async {
    try {
      final temp = await _deviceChannel.invokeMethod<double>('getBatteryTemp');
      if (temp != null && mounted) {
        setState(() => _deviceTemp = '${temp.toStringAsFixed(1)}°C');
      }
    } catch (_) {
      if (mounted && _deviceTemp == '--°C') setState(() => _deviceTemp = 'N/A');
    }
  }

  // ── Prayer Schedule ───────────────────────────────────────────────────────
  void _startClockTimer() {
    _clockTimer = Timer.periodic(Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _now = DateTime.now();
          _updateNextPrayer();
        });
      }
    });
  }

  Future<void> _fetchPrayerTimes() async {
    setState(() { _prayerLoading = true; _prayerError = ''; });
    try {
      final now = DateTime.now();
      final ts = now.millisecondsSinceEpoch ~/ 1000;
      final url = 'https://api.aladhan.com/v1/timings/$ts?latitude=-6.2088&longitude=106.8456&method=11';
      final res = await http.get(Uri.parse(url))
          .timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final timings = body['data']['timings'] as Map<String, dynamic>;
        final Map<String, String> times = {};
        for (final k in _prayerKeys) {
          final raw = timings[k]?.toString() ?? '';
          // strip timezone suffix if present e.g. "04:32 (WIB)" -> "04:32"
          times[k] = raw.contains(' ') ? raw.split(' ').first : raw;
        }
        if (mounted) {
          setState(() {
            _prayerTimes = times;
            _prayerLoading = false;
            _updateNextPrayer();
          });
        }
      } else {
        throw Exception('status ${res.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _prayerLoading = false;
          _prayerError = 'Gagal memuat jadwal';
        });
      }
    }
  }

  void _updateNextPrayer() {
    if (_prayerTimes.isEmpty) return;
    final now = _now;
    String? nextKey;
    Duration? minDiff;

    for (final k in _prayerKeys) {
      final t = _prayerTimes[k];
      if (t == null) continue;
      final parts = t.split(':');
      if (parts.length < 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      var prayerDt = DateTime(now.year, now.month, now.day, h, m);
      if (prayerDt.isBefore(now)) {
        prayerDt = prayerDt.add(Duration(days: 1));
      }
      final diff = prayerDt.difference(now);
      if (minDiff == null || diff < minDiff) {
        minDiff = diff;
        nextKey = k;
      }
    }

    _nextPrayerKey = nextKey ?? '';
    if (minDiff != null) {
      final h = minDiff.inHours.toString().padLeft(2, '0');
      final m = (minDiff.inMinutes % 60).toString().padLeft(2, '0');
      final s = (minDiff.inSeconds % 60).toString().padLeft(2, '0');
      _prayerCountdown = '$h:$m:$s';
    }
  }

  bool _isPrayerPassed(String key) {
    final t = _prayerTimes[key];
    if (t == null) return false;
    final parts = t.split(':');
    if (parts.length < 2) return false;
    final h = int.tryParse(parts[0]) ?? 0;
    final m = int.tryParse(parts[1]) ?? 0;
    final prayerDt = DateTime(_now.year, _now.month, _now.day, h, m);
    return prayerDt.isBefore(_now);
  }

  // ── Data Loading ──────────────────────────────────────────────────────────
  Future<void> _loadUserData() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      _uid = androidInfo.id;
    } catch (_) { _uid = 'unknown'; }
    if (mounted) setState(() {});
    // Refresh role + expiredDate dari server — penting biar pas VIP
    // di-approve owner, dashboard langsung tau tanpa harus re-login.
    _refreshRoleFromServer();
  }

  // ── Refresh role & expiredDate dari server ───────────────────────────────
  // Dipanggil:
  //   - pas initState (biar data selalu fresh)
  //   - pas balik dari VipUpgradePage (kalau owner baru aja approve/reject)
  Future<void> _refreshRoleFromServer() async {
    if (_sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "http://114.10.118.133:1887/meByKey?key=${Uri.encodeComponent(_sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? 'member').toString();
        final newExpired = (data['expiredDate'] ?? _expiredDate).toString();
        if (newRole != _role || newExpired != _expiredDate) {
          if (mounted) {
            setState(() {
              _role = newRole;
              _expiredDate = newExpired;
            });
            debugPrint('[DASH] Role refreshed: $_role | Expired: $_expiredDate');
          }
        }
      }
    } catch (_) {}
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────
  void _connectWebSocket() {
    try {
      _wsChannel = WebSocketChannel.connect(Uri.parse('http://114.10.118.133:1887'));
      _wsChannel!.sink.add(jsonEncode({'type': 'validate', 'key': _sessionKey, 'androidId': _uid}));
      _wsChannel!.sink.add(jsonEncode({'type': 'stats'}));
      _wsChannel!.stream.listen(
        (msg) => _handleWsMessage(jsonDecode(msg)),
        onDone: () { setState(() => _wsConnected = false); Future.delayed(Duration(seconds: 5), _connectWebSocket); },
        onError: (_) { setState(() => _wsConnected = false); Future.delayed(Duration(seconds: 5), _connectWebSocket); },
      );
      setState(() => _wsConnected = true);
    } catch (_) { setState(() => _wsConnected = false); }
  }

  void _handleWsMessage(Map<String, dynamic> data) {
    if (data['type'] == 'myInfo' && data['valid'] == false) {
      String msg = 'Session invalid. Please login again.';
      if (data['reason'] == 'androidIdMismatch') msg = 'Your account has logged on another device.';
      else if (data['reason'] == 'keyInvalid') msg = 'Key is not valid. Please login again.';
      _handleInvalidSession(msg);
    }
  }

  Future<void> _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface.withOpacity(0.98),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _C.accent.withOpacity(0.5), width: 1),
        ),
        title: Row(children: [
          Icon(Icons.warning_amber_rounded, color: _C.accent),
          SizedBox(width: 10),
          Text('Session Expired', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16)),
        ]),
        content: Text(message, style: TextStyle(fontSize: 14)),
        actions: [TextButton(
          onPressed: () => Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => LoginPage()), (r) => false),
          child: Text('OK'),
        )],
      ),
    );
  }

  // ── Broadcast Notifications ──────────────────────────────────────────────
  // Fetch active broadcasts dari server & tampilkan popup kalau ada.
  // Owner bisa kirim broadcast (maintenance/update/info/warning) lewat
  // Admin Panel → BROADCAST. User dapet popup pas buka app.
  // ── Fetch sender counts for dashboard ──
  Future<void> _fetchDashboardSenders() async {
    if (_isLoadingSenders) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        "http://114.10.118.133:1887/mySender?key=${_sessionKey}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['connections'] != null) {
          final conns = data['connections'];
          List<dynamic> allSenders = [];
          if (conns is Map) {
            allSenders = [...(conns['private'] ?? []), ...(conns['global'] ?? [])];
          } else if (conns is List) {
            allSenders = conns;
          }
          if (mounted) {
            setState(() {
              _dashboardSenders = allSenders;
              _totalCount = allSenders.length;
              _activeCount = allSenders.where((s) => s is Map && (s['isActive'] ?? true) == true).length;
            });
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  Future<void> _fetchBroadcasts() async {
    if (_sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "http://114.10.118.133:1887/getBroadcasts?key=${Uri.encodeComponent(_sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final broadcasts = data['broadcasts'] as List? ?? [];
        if (broadcasts.isNotEmpty && mounted) {
          // Tampilkan broadcast pertama (paling baru). User dismiss dulu
          // sebelum broadcast berikutnya muncul.
          Future.delayed(Duration(milliseconds: 1500), () {
            if (mounted) _showBroadcastPopup(broadcasts);
          });
        }
      }
    } catch (_) {}
  }

  void _showBroadcastPopup(List<dynamic> broadcasts) {
    if (broadcasts.isEmpty) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BroadcastDialog(
        broadcasts: broadcasts,
        sessionKey: _sessionKey,
        onDismiss: () {
          Navigator.of(context).pop();
        },
      ),
    );
  }

  // ── Audio ─────────────────────────────────────────────────────────────────
  Future<void> _initAudio() async {
    try {
      await _audioPlayer.setSourceUrl('https://files.catbox.moe/yfd2b4.mp3');
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.setVolume(0.3);
    } catch (_) {}
  }

  Future<void> _toggleMusic() async {
    if (_isMusicPlaying) await _audioPlayer.pause();
    else await _audioPlayer.resume();
    setState(() => _isMusicPlaying = !_isMusicPlaying);
  }

  // ── Sidebar ───────────────────────────────────────────────────────────────
  void _openSidebar() {
    setState(() => _isSidebarOpen = true);
    _sidebarController.forward();
  }

  void _closeSidebar() {
    _sidebarController.reverse().then((_) {
      if (mounted) setState(() => _isSidebarOpen = false);
    });
  }

  void _selectFromDrawer(String page) {
    _closeSidebar();
    _navigateTo(page);
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigateTo(String page) {
    setState(() => _currentPage = page);
    switch (page) {
      case 'home': setState(() => _currentNavIndex = 0); break;
      case 'bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'custom_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'group_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'pair_spam': Navigator.of(context).push(MaterialPageRoute(builder: (_) => PairSpamPage(sessionKey: _sessionKey, username: _username))); break;
      case 'rat':
        // RAT hanya untuk VIP dan Owner
        if (_role.toLowerCase() != 'owner' && _role.toLowerCase() != 'vip') {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('RAT hanya untuk VIP & Owner', style: TextStyle(fontFamily: 'ShareTechMono')),
            backgroundColor: Color(0xFFFF3B30),
          ));
          return;
        }
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => DeviceDashboardPage(username: _username, sessionKey: _sessionKey)));
        break;
      case 'vip': Navigator.of(context).push(MaterialPageRoute(builder: (_) => VipUpgradePage(username: _username, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))).then((_) => _refreshRoleFromServer()); break;
      case 'ddos': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: _sessionKey, listDDoS: _listDDoS))); break;
      case 'tools': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ToolsPage(sessionKey: _sessionKey, userRole: _role, username: _username, listDDoS: _listDDoS))); break;
      case 'seller': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SellerPage(keyToken: _sessionKey))); break;
      case 'admin': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminPage(sessionKey: _sessionKey))); break;
      case 'sender': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SenderPage(sessionKey: _sessionKey))); break;
      case 'change_password': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: _username, sessionKey: _sessionKey))); break;
      case 'leaderboard': Navigator.of(context).push(MaterialPageRoute(builder: (_) => LeaderboardPage(sessionKey: _sessionKey, username: _username))); break;
      case 'settings': _showSettingsPage(); break;
    }
  }

  void _onNavTap(int index) {
    switch (index) {
      case 0: setState(() { _currentNavIndex = 0; _currentPage = 'home'; }); break;
      case 1: setState(() => _currentNavIndex = 1); Navigator.of(context).push(MaterialPageRoute(builder: (_) => ToolsPage(sessionKey: _sessionKey, userRole: _role, username: _username, listDDoS: _listDDoS))); break;
      case 2: break;
      case 3: setState(() => _currentNavIndex = 3); Navigator.of(context).push(MaterialPageRoute(builder: (_) => VipUpgradePage(username: _username, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))).then((_) => _refreshRoleFromServer()); break;
      case 4: _showSettingsPage(); break;
    }
  }

  void _toggleFanMenu() {
    setState(() => _isFanMenuOpen = !_isFanMenuOpen);
    if (_isFanMenuOpen) { _fanMenuController.forward(); _fanStaggerController.forward(); }
    else { _fanMenuController.reverse(); _fanStaggerController.reverse(); }
  }

  void _closeFanMenu() {
    if (_isFanMenuOpen) {
      setState(() => _isFanMenuOpen = false);
      _fanMenuController.reverse();
      _fanStaggerController.reverse();
    }
  }

  void _copyUid() {
    Clipboard.setData(ClipboardData(text: _uid));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('UID copied!', style: TextStyle(color: _C.text)),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: Duration(seconds: 2),
    ));
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _wsChannel?.sink.close(status.goingAway);
    await _audioPlayer.stop();
    if (mounted) Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginPage()), (r) => false);
  }

  // ── Battery icon helper ───────────────────────────────────────────────────
  FaIconData _batteryIcon() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return Icons.battery_charging_full;
    if (lvl >= 80) return Icons.battery_full;
    if (lvl >= 50) return Icons.battery_4_bar;
    if (lvl >= 20) return Icons.battery_2_bar;
    return Icons.battery_alert;
  }

  Color _batteryColor() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return Color(0xFF00D2FF);
    if (lvl >= 50) return Color(0xFFFF3B30);
    if (lvl >= 20) return _C.gold;
    return _C.danger;
  }

  // ── MODALS ────────────────────────────────────────────────────────────────
  void _showBugTypeModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.muted2, borderRadius: BorderRadius.circular(2))),
            SizedBox(height: 16),
            Text('SELECT BUG TYPE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.bold, color: _C.text)),
            SizedBox(height: 20),
            _bugTypeOption(FontAwesomeIcons.user, 'Contact Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 10),
            _bugTypeOption(FontAwesomeIcons.usersSlash, 'Group Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 10),
            _bugTypeOption(FontAwesomeIcons.terminal, 'Custom Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _bugTypeOption(FaIconData icon, String label, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
          child: Row(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: _C.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(10)), child: FaIcon(icon, color: _C.accent, size: 16)),
            SizedBox(width: 14),
            Expanded(child: Text(label, style: TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w600))),
            Icon(Icons.chevron_right, color: _C.muted, size: 20),
          ]),
        ),
      ),
    );
  }

  void _showAccountModal() {
    showModalBottomSheet(
      context: context, backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.muted2, borderRadius: BorderRadius.circular(2))),
          SizedBox(height: 20),
          Container(width: 64, height: 64, decoration: BoxDecoration(color: _C.accent.withOpacity(0.15), shape: BoxShape.circle), child: FaIcon(FontAwesomeIcons.user, color: _C.accent, size: 24)),
          SizedBox(height: 12),
          Text(_username.toUpperCase(), style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.bold, color: _C.text)),
          SizedBox(height: 4),
          Text(_role.toUpperCase(), style: TextStyle(fontSize: 11, color: _C.muted)),
          SizedBox(height: 20),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton(
            onPressed: () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: _username, sessionKey: _sessionKey))); },
            style: ElevatedButton.styleFrom(backgroundColor: _C.gold, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: Text('CHANGE PASSWORD', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold)),
          )),
          SizedBox(height: 10),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton(
            onPressed: () { Navigator.of(ctx).pop(); _logout(); },
            style: ElevatedButton.styleFrom(backgroundColor: _C.accent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: Text('LOGOUT', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold)),
          )),
          SizedBox(height: 20),
        ]),
      ),
    );
  }

  void _showSettingsPage() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => _SettingsPage(
      username: _username, sessionKey: _sessionKey,
      notif: _settingsNotif, sound: _settingsSound,
      autoConnect: _settingsAutoConnect, darkMode: _settingsDarkMode,
      onToggleNotif: (v) => setState(() => _settingsNotif = v),
      onToggleSound: (v) => setState(() => _settingsSound = v),
      onToggleAutoConnect: (v) => setState(() => _settingsAutoConnect = v),
      onToggleDarkMode: (v) => setState(() => _settingsDarkMode = v),
      onToggleMusic: _toggleMusic, isMusicPlaying: _isMusicPlaying,
    )));
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // ── Video Background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF000000), Color(0xFF0a0a0a)],
                ),
              ),
            ),
          // ── Dark overlay for text readability ──
          Container(color: Colors.black.withOpacity(0.55)),
          // ── Main scrollable content ──
          SafeArea(
            top: true,
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                // ── 1. HEADER: greeting + bell + avatar ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hey, $_username!',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                              fontFamily: 'MADEEvolveSansEVO',
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Welcome back! 👋',
                            style: TextStyle(fontSize: 13, color: _C.muted),
                          ),
                        ],
                      ),
                      Spacer(),
                      // Leaderboard button (trophy icon — red accent)
                      GestureDetector(
                        onTap: () => _navigateTo('leaderboard'),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _C.accent.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.accent.withOpacity(0.35)),
                            boxShadow: [
                              BoxShadow(
                                color: _C.accent.withOpacity(0.2),
                                blurRadius: 8,
                                spreadRadius: 0,
                                offset: Offset(0, 0),
                              ),
                            ],
                          ),
                          child: Icon(Icons.leaderboard_rounded,
                              color: _C.accent, size: 20),
                        ),
                      ),
                      SizedBox(width: 10),
                      // Notification bell
                      GestureDetector(
                        onTap: () => _navigateTo('settings'),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _C.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.border),
                          ),
                          child: Icon(Icons.notifications_none_rounded,
                              color: _C.text, size: 20),
                        ),
                      ),
                      SizedBox(width: 10),
                      // Avatar circle
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.accent,
                          border: Border.all(color: _C.text, width: 2),
                        ),
                        child: Center(
                          child: Text(
                            _username.isNotEmpty ? _username[0].toUpperCase() : '?',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ── 2. MAIN BALANCE / ACCOUNT STATUS CARD (dark) ──
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Color(0xFF1a1a1a), // #0A0A0B dark
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ACCOUNT STATUS',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.white54,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 1,
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            _role.toUpperCase(),
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                              fontFamily: 'MADEEvolveSansEVO',
                            ),
                          ),
                          SizedBox(width: 12),
                          Padding(
                            padding: EdgeInsets.only(bottom: 4),
                            child: Text(
                              'Active',
                              style: TextStyle(
                                fontSize: 12,
                                color: _C.greenG1,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.calendar_today,
                              color: Colors.white54, size: 12),
                          SizedBox(width: 6),
                          Text(
                            'Exp: $_expiredDate',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white54,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          Spacer(),
                          // Active senders count
                          Text(
                            '$_activeCount/$_totalCount senders',
                            style: TextStyle(
                              fontSize: 12,
                              color: _C.accent, // mint green
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // ── 3. ACTION BUTTONS ROW: LAUNCH BUG + SENDER ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: _showBugTypeModal,
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: Color(0xFF1a1a1a), // TRANTOR dark card
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.bug_report, color: Colors.white, size: 18),
                                SizedBox(width: 8),
                                Text(
                                  'LAUNCH BUG',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _navigateTo('sender'),
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: _C.accent, // mint green
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.send, color: Colors.white, size: 18), // black icon on mint
                                SizedBox(width: 8),
                                Text(
                                  'SENDER',
                                  style: TextStyle(
                                    color: Colors.white, // black text on mint
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ── 4. QUICK ACCESS CARD (dark, red accent) ──
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _C.card, // dark card
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _C.accent.withOpacity(0.2), width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 24, height: 24,
                            decoration: BoxDecoration(
                              color: _C.accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(Icons.grid_view_rounded, color: _C.accent, size: 14),
                          ),
                          SizedBox(width: 8),
                          Text(
                            'QUICK ACCESS',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                              fontFamily: 'MADEEvolveSansEVO',
                              letterSpacing: 1,
                            ),
                          ),
                          Spacer(),
                          Text(
                            'Tools',
                            style: TextStyle(
                              fontSize: 10,
                              color: _C.muted,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      // Grid of quick access buttons (3 columns × 2 rows)
                      GridView.count(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        crossAxisCount: 3,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.0,
                        children: [
                          _quickAccessItem(Icons.bug_report, 'BUG', _showBugTypeModal),
                          _quickAccessItem(Icons.code, 'CUSTOM', () => _navigateTo('custom_bug')),
                          _quickAccessItem(Icons.group, 'GROUP', () => _navigateTo('group_bug')),
                          _quickAccessItem(Icons.celebration, 'VIP', () => _navigateTo('vip')),
                          _quickAccessItem(Icons.phonelink_lock, 'PAIR', () => _navigateTo('pair_spam')),
                          _quickAccessItem(Icons.admin_panel_settings, 'ADMIN', () => _navigateTo('admin')),
                        ],
                      ),
                    ],
                  ),
                ),

                // ── 5. SENDER / ASSET LIST (dark card) ──
                Container(
                  margin: const EdgeInsets.all(20),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Color(0xFF1a1a1a), // TRANTOR dark card
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      // Header
                      Row(
                        children: [
                          Text(
                            'SENDERS',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              fontFamily: 'MADEEvolveSansEVO',
                              letterSpacing: 1,
                            ),
                          ),
                          Spacer(),
                          GestureDetector(
                            onTap: () => _navigateTo('sender'),
                            child: Text(
                              'View All ▼',
                              style: TextStyle(
                                fontSize: 10,
                                color: _C.accent,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      // Sender items (placeholder rows in TRANTOR asset-list style)
                      _buildSenderListItems(),
                    ],
                  ),
                ),

                // Bottom padding so content isn't hidden behind floating nav bar
                SizedBox(height: 100),
              ],
            ),
          ),

          // ── 6. BOTTOM NAVIGATION BAR (black floating style) ──
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Container(
              height: 64,
              decoration: BoxDecoration(
                color: Color(0xFF1a1a1a), // TRANTOR dark card
                borderRadius: BorderRadius.circular(32),
                boxShadow: [
                  // Original drop shadow
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 20,
                    offset: Offset(0, 8),
                  ),
                  // ── NEON GLOW (red accent — primary brand glow) ──
                  BoxShadow(
                    color: Color(0xFFFF3B30).withOpacity(0.3),
                    blurRadius: 20,
                    spreadRadius: 2,
                    offset: Offset(0, 0),
                  ),
                  // ── Secondary blue glow (cyber vibe) ──
                  BoxShadow(
                    color: Color(0xFF3B82F6).withOpacity(0.15),
                    blurRadius: 15,
                    spreadRadius: 1,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Tools / Activity
                  _buildNavItem(Icons.bar_chart_rounded, 'Tools', 1, () => _navigateTo('tools')),
                  // Home (active by default)
                  _buildNavItem(Icons.home_rounded, 'Home', 0, () {
                    setState(() {
                      _currentNavIndex = 0;
                      _currentPage = 'home';
                    });
                  }),
                  // More / Settings
                  _buildNavItem(Icons.apps_rounded, 'More', 2, _showSettingsPage),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // TRANTOR LAYOUT HELPERS
  // ═════════════════════════════════════════════════════════════════════════

  /// Quick-access grid cell (white card with icon + label).
  Widget _quickAccessItem(FaIconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.accent.withOpacity(0.15)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: _C.accent, size: 22),
            SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: _C.text,
                fontFamily: 'MADEEvolveSansEVO',
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Bottom-nav circular item. Active state = white pill with dark icon
  /// + animated neon glow (red, pulsing via _pulseRingController).
  Widget _buildNavItem(FaIconData icon, String label, int index, VoidCallback onTap) {
    final isActive = _currentNavIndex == index;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: _pulseRingController,
        builder: (_, __) {
          // Pulse value 0..1 — dipake buat glow strength.
          final pulse = _pulseRingController.value;
          return Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive ? Colors.white : Colors.transparent,
              boxShadow: isActive
                  ? [
                      // Neon red glow — pulsing strength
                      BoxShadow(
                        color: Color(0xFFFF3B30).withOpacity(0.4 + pulse * 0.2),
                        blurRadius: 12 + pulse * 8,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
            child: Icon(
              icon,
              color: isActive ? Color(0xFF000000) : Colors.white54,
              size: 24,
            ),
          );
        },
      ),
    );
  }

  /// Builds 3 placeholder sender rows in TRANTOR asset-list style.
  /// Each row: status dot + name/label + big number + small green delta.
  Widget _buildSenderListItems() {
    // Real sender data from API, or placeholder if still loading
    if (_dashboardSenders.isEmpty && _isLoadingSenders) {
      return Column(
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: SizedBox(
              width: 20, height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: _C.accent),
            ),
          ),
          GestureDetector(
            onTap: () => _navigateTo('sender'),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('View All', style: TextStyle(fontSize: 11, color: _C.accent, fontFamily: 'ShareTechMono', letterSpacing: 1)),
                  SizedBox(width: 4),
                  Icon(Icons.keyboard_arrow_down, color: _C.accent, size: 14),
                ],
              ),
            ),
          ),
        ],
      );
    }

    // Build rows from real sender data
    final rows = <Map<String, dynamic>>[];
    
    if (_dashboardSenders.isNotEmpty) {
      // Show up to 3 real senders
      for (int i = 0; i < _dashboardSenders.length && i < 3; i++) {
        final s = _dashboardSenders[i] as Map<String, dynamic>;
        final sessionName = (s['sessionName'] ?? s['number'] ?? 'Unknown').toString();
        final owner = (s['owner'] ?? 'developer').toString();
        final isActive = (s['isActive'] ?? true) == true;
        rows.add({
          'dot': isActive ? _C.accent : Color(0xFF333333),
          'name': sessionName.length > 15 ? sessionName.substring(0, 12) + '...' : sessionName,
          'label': owner.toUpperCase(),
          'value': isActive ? 'ONLINE' : 'OFFLINE',
          'delta': isActive ? '+active' : 'offline',
          'deltaColor': isActive ? _C.accent : _C.muted,
        });
      }
    }
    
    // If no real senders, show summary
    if (rows.isEmpty) {
      rows.add({
        'dot': _C.accent,
        'name': 'WA Sender',
        'label': 'WHATSAPP',
        'value': '$_activeCount active',
        'delta': _totalCount > 0 ? '+$_totalCount total' : 'no senders',
        'deltaColor': _totalCount > 0 ? _C.accent : _C.muted,
      });
    }

    return Column(
      children: [
        for (int i = 0; i < rows.length; i++) ...[
          _senderRow(rows[i]),
          if (i < rows.length - 1)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Divider(
                color: Colors.white.withOpacity(0.06),
                height: 1,
              ),
            ),
        ],
        SizedBox(height: 12),
        GestureDetector(
          onTap: () => _navigateTo('sender'),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'View All',
                  style: TextStyle(
                    fontSize: 11,
                    color: _C.accent,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1,
                  ),
                ),
                SizedBox(width: 4),
                Icon(Icons.keyboard_arrow_down, color: _C.accent, size: 14),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _senderRow(Map<String, dynamic> data) {
    final Color dot = data['dot'] as Color;
    final String name = data['name'] as String;
    final String label = data['label'] as String;
    final String value = data['value'] as String;
    final String delta = data['delta'] as String;
    final Color deltaColor = data['deltaColor'] as Color;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          // Status dot
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: dot,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  color: _C.card,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),
          SizedBox(width: 12),
          // Name + label
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _C.text,
                    fontFamily: 'MADEEvolveSansEVO',
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white54,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          // Value + delta
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: _C.text,
                  fontFamily: 'MADEEvolveSansEVO',
                ),
              ),
              SizedBox(height: 2),
              Text(
                delta,
                style: TextStyle(
                  fontSize: 11,
                  color: deltaColor,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 1. HEADER
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            height: 56,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              children: [
                // Tappable brand → opens sidebar
                GestureDetector(
                  onTap: _openSidebar,
                  behavior: HitTestBehavior.opaque,
                  child: Row(
                    children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(
                            image: NetworkImage('https://i.imgur.com/SlimeIcon.png'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Text(
                        'YakuzaXsilence',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: _C.text,
                          shadows: [Shadow(color: _C.accent, blurRadius: 8)],
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(),
                _headerIconButton(FontAwesomeIcons.bell, _openSidebar),
                SizedBox(width: 8),
                _headerIconButton(FontAwesomeIcons.user, _showAccountModal),
                SizedBox(width: 8),
                _headerIconButton(FontAwesomeIcons.gear, _showSettingsPage),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _headerIconButton(FaIconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _C.border2)),
        child: FaIcon(icon, color: _C.muted, size: 15),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 2. TOP BANNER
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildTopBanner() {
    final String? bannerUrl = _newsList.isNotEmpty
        ? (_newsList[0]['image'] ?? _newsList[0]['img'] ?? _newsList[0]['thumbnail'] ?? _newsList[0]['banner'])?.toString()
        : null;
    final hasBanner = bannerUrl != null && bannerUrl.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: 16 / 7,
          child: hasBanner
              ? Image.network(
                  bannerUrl,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                  errorBuilder: (_, __, ___) => _bannerFallback(),
                )
              : _bannerFallback(),
        ),
      ),
    );
  }

  Widget _bannerFallback() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1a1f3a), Color(0xFF0a0e1f)],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned(
            right: -20,
            top: -20,
            child: Icon(Icons.bolt, size: 140, color: _C.accent.withOpacity(0.15)),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.accent.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.accent.withOpacity(0.4), width: 1),
                  ),
                  child: Text(
                    'YAKUZAXSILENCE',
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      color: _C.accent2,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Welcome to the Panel',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _C.text,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Pilih menu di sisi kiri untuk mulai',
                  style: TextStyle(fontSize: 11, color: _C.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 3. PROFILE CARD (real-time battery & temp)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
        ),
        child: Column(
          children: [
            // ── Top row: avatar + welcome + role ──
            Row(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _C.accent.withOpacity(0.4), width: 1),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(13),
                    child: Image.network(
                      'https://files.catbox.moe/ycw0o4.png',
                      width: 52, height: 52, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: _C.surface,
                        child: Icon(Icons.person, color: _C.muted2, size: 24),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'WELCOME BACK',
                        style: TextStyle(fontSize: 10, color: _C.muted, letterSpacing: 1.5),
                      ),
                      SizedBox(height: 3),
                      Text(
                        _username.toUpperCase(),
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _C.text,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _C.accent.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.accent.withOpacity(0.3), width: 0.5),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.check_circle, color: _C.accent, size: 11),
                            SizedBox(width: 4),
                            Text(
                              _role.toUpperCase(),
                              style: TextStyle(color: _C.accent, fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 0.5),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 14),
            Container(height: 1, color: _C.border2),
            SizedBox(height: 14),
            // ── Stats row ──
            Row(
              children: [
                Expanded(child: _statBox('ACTIVE', '$_activeCount', _C.accent)),
                SizedBox(width: 8),
                Expanded(child: _statBox('TOTAL', '$_totalCount', _C.text)),
                SizedBox(width: 8),
                Expanded(child: _statBox('UNTIL', _expiredDate.isEmpty ? '--' : _expiredDate, _C.gold)),
              ],
            ),
            SizedBox(height: 12),
            // ── Bottom row: UID + device info ──
            Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Text('UID: ', style: TextStyle(fontSize: 11, color: _C.muted)),
                      Flexible(
                        child: Text(
                          _uid.isEmpty ? 'unknown' : _uid,
                          style: TextStyle(fontSize: 11, color: _C.text, fontWeight: FontWeight.w600),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      SizedBox(width: 6),
                      GestureDetector(
                        onTap: _copyUid,
                        child: Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(6)),
                          child: Icon(Icons.copy, color: _C.muted, size: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Icon(Icons.thermostat, color: _deviceTemp == 'N/A' ? _C.muted2 : _C.accent, size: 14),
                    SizedBox(width: 4),
                    Text(_deviceTemp, style: TextStyle(fontSize: 11, color: _deviceTemp == 'N/A' ? _C.muted2 : _C.text)),
                    SizedBox(width: 12),
                    Icon(_batteryIcon(), color: _batteryColor(), size: 14),
                    SizedBox(width: 4),
                    Text(_batteryLevel, style: TextStyle(fontSize: 11, color: _batteryColor())),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statBox(String label, String value, Color valueColor) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(label, style: TextStyle(fontSize: 9, color: _C.muted, letterSpacing: 1)),
        SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: valueColor), overflow: TextOverflow.ellipsis),
      ]),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 5. QUICK ACCESS
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildQuickAccess(double screenWidth) {
    final cardWidth = (screenWidth - 14 * 2 - 56) * 0.52; // 56 = rail width; ~1.9 cards visible
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _C.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.accent.withOpacity(0.25)),
                ),
                child: Icon(Icons.flash_on, color: _C.accent, size: 14),
              ),
              SizedBox(width: 10),
              Text(
                'QUICK ACCESS',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: _C.text,
                  letterSpacing: 1,
                ),
              ),
              Spacer(),
              Text('Swipe →', style: TextStyle(fontSize: 10, color: _C.muted, fontFamily: 'ShareTechMono')),
            ],
          ),
        ),
        SizedBox(height: 12),
        SizedBox(
          height: 110,
          child: ListView(
            controller: _quickAccessController,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            children: [
              _quickAccessCard('WA CRASH', 'Bug contact/group/custom', const [_C.greenG1, _C.greenG2], FontAwesomeIcons.whatsapp, () => _showBugTypeModal(), cardWidth),
              SizedBox(width: 10),
              _quickAccessCard('PAIR SPAM', 'Spam pairing code via Baileys', const [_C.blueG1, _C.blueG2], FontAwesomeIcons.link, () => _navigateTo('pair_spam'), cardWidth),
              SizedBox(width: 10),
              _quickAccessCard('UPGRADE VIP', 'Upgrade ke VIP & nikmati fitur premium', const [_C.purpleG1, _C.purpleG2], FontAwesomeIcons.crown, () => _navigateTo('vip'), cardWidth),
              SizedBox(width: 10),
              _quickAccessCard('SENDER', 'Kirim pesan massal', const [_C.qaOrange1, _C.qaOrange2], FontAwesomeIcons.paperPlane, () => _navigateTo('sender'), cardWidth),
              SizedBox(width: 10),
              _quickAccessCard('TOOLS', 'Utilitas & fitur', const [_C.qaBlue1, _C.qaBlue2], FontAwesomeIcons.toolbox, () => _navigateTo('tools'), cardWidth),
              SizedBox(width: 10),
              _quickAccessCard('SECURITY', 'Keamanan akun', const [_C.qaRed1, _C.qaRed2], FontAwesomeIcons.shieldHalved, () => _navigateTo('settings'), cardWidth),
            ],
          ),
        ),
      ],
    );
  }

  Widget _quickAccessCard(String label, String subtitle, List<Color> gradientColors, FaIconData icon, VoidCallback onTap, double width) {
    return Material(
      color: Colors.transparent, borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(16),
        splashColor: gradientColors[0].withOpacity(0.3), highlightColor: Colors.white.withOpacity(0.04),
        child: Ink(
          width: width, height: 110,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(colors: gradientColors, begin: Alignment.topLeft, end: Alignment.bottomRight),
            border: Border.all(color: gradientColors[0].withOpacity(0.5), width: 1),
          ),
          child: Stack(children: [
            Positioned(right: -8, bottom: -12, child: FaIcon(icon, size: 80, color: Colors.white.withOpacity(0.06))),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white.withOpacity(0.1), width: 1)),
                    child: FaIcon(icon, color: Colors.white.withOpacity(0.85), size: 15),
                  ),
                  Icon(Icons.arrow_forward_ios, color: Colors.white.withOpacity(0.25), size: 11),
                ]),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, color: _C.text)),
                  SizedBox(height: 2),
                  Text(subtitle, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white.withOpacity(0.45))),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 6. LATEST NEWS
  // ═════════════════════════════════════════════════════════════════════════
  static const _newsAssets = [
    {'asset': 'assets/images/news1.jpg', 'title': 'Update Terbaru', 'tag': 'NEW'},
    {'asset': 'assets/images/news2.jpg', 'title': 'Maintenance Server', 'tag': 'INFO'},
    {'asset': 'assets/images/news3.jpg', 'title': 'Fitur Baru Tersedia', 'tag': 'NEW'},
  ];

  Widget _buildLatestNews() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(children: [
          Text('PREMIUM NEWS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, color: _C.text, letterSpacing: 1)),
          Spacer(),
          Text('View All', style: TextStyle(fontSize: 11, color: _C.accent)),
        ]),
      ),
      SizedBox(height: 10),
      SizedBox(
        height: 180,
        child: PageView.builder(
          controller: _newsController,
          onPageChanged: (i) => setState(() => _currentNewsIndex = i),
          itemCount: _newsAssets.length,
          itemBuilder: (ctx, i) {
            final item = _newsAssets[i];
            final isRed = item['tag'] == 'NEW';
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Container(
                margin: const EdgeInsets.only(right: 6),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: _C.border)),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(fit: StackFit.expand, children: [
                    Image.asset(item['asset']!, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: _C.bg2, child: Center(child: Icon(Icons.newspaper, color: _C.muted2, size: 40)))),
                    Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withOpacity(0.85)], stops: const [0.4, 1.0]))),
                    Positioned(bottom: 14, left: 14, right: 14, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: isRed ? _C.accent.withOpacity(0.85) : _C.surface.withOpacity(0.85), borderRadius: BorderRadius.circular(6)),
                          child: Text(item['tag']!, style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: isRed ? Colors.white : _C.muted)),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 12),
                      ]),
                      SizedBox(height: 8),
                      Text(item['title']!, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: _C.text, shadows: [Shadow(color: Colors.black54, blurRadius: 4)])),
                    ])),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
      SizedBox(height: 10),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(_newsAssets.length, (i) => AnimatedContainer(
        duration: Duration(milliseconds: 250),
        margin: const EdgeInsets.symmetric(horizontal: 3),
        width: _currentNewsIndex == i ? 18 : 6, height: 6,
        decoration: BoxDecoration(color: _currentNewsIndex == i ? _C.accent : _C.muted2, borderRadius: BorderRadius.circular(3)),
      ))),
    ]);
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 7. LATEST ANIME (NEW SECTION)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildLatestAnime() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Section header ──
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: _C.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.accent.withOpacity(0.25)),
                ),
                child: FaIcon(FontAwesomeIcons.tv, color: _C.accent, size: 13),
              ),
              SizedBox(width: 10),
              Text(
                'LATEST ANIME',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: _C.text,
                  letterSpacing: 1,
                ),
              ),
              Spacer(),
              GestureDetector(
                onTap: () {
                  // Navigate to full anime home page
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => HomeAnimePage()),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.border2),
                  ),
                  child: Row(
                    children: [
                      Text('See All', style: TextStyle(fontSize: 10, color: _C.muted)),
                      SizedBox(width: 4),
                      Icon(Icons.chevron_right, color: _C.muted, size: 12),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 12),

        // ── Anime horizontal list ──
        if (_animeLoading)
          SizedBox(
            height: 210,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: 6,
              itemBuilder: (_, __) => Container(
                width: 125,
                margin: const EdgeInsets.only(right: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 125,
                      height: 170,
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border2),
                      ),
                      child: Center(
                        child: SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: _C.accent.withOpacity(0.5),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    Container(
                      width: 125,
                      height: 12,
                      decoration: BoxDecoration(
                        color: _C.surface,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        else if (_latestAnime.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 100,
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.wifi_off, color: _C.muted2, size: 24),
                    SizedBox(height: 8),
                    Text('Failed to load anime', style: TextStyle(fontSize: 12, color: _C.muted)),
                    SizedBox(height: 6),
                    GestureDetector(
                      onTap: _fetchLatestAnime,
                      child: Text('Retry', style: TextStyle(color: _C.accent, fontSize: 11, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          SizedBox(
            height: 240,
            child: ListView.builder(
              controller: _animeScrollController,
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: _latestAnime.length,
              itemBuilder: (context, index) {
                final anime = _latestAnime[index];
                final String title = anime['title'] ?? 'Unknown';
                final String poster = anime['poster'] ?? '';
                final String slug = anime['animeId'] ?? '';
                final String? episodes = anime['episodes']?.toString();
                final String? status = anime['status'];
                final String? score = anime['score'];
                final bool isOngoing = status?.toLowerCase() == 'ongoing';

                return Container(
                  width: 128,
                  margin: const EdgeInsets.only(right: 12),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => AnimeDetailPage(slug: slug),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // ── Poster image ──
                          Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: Container(
                                  width: 128,
                                  height: 175,
                                  decoration: BoxDecoration(
                                    color: _C.surface,
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: _C.border2),
                                  ),
                                  child: poster.isNotEmpty
                                      ? Image.network(
                                          poster,
                                          width: 128,
                                          height: 175,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Center(
                                            child: Icon(Icons.image_not_supported, color: _C.muted2, size: 28),
                                          ),
                                        )
                                      : Center(
                                          child: Icon(Icons.movie, color: _C.muted2, size: 28),
                                        ),
                                ),
                              ),

                              // ── Score badge (top-left) ──
                              if (score != null && score.isNotEmpty)
                                Positioned(
                                  top: 8,
                                  left: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: _C.gold.withOpacity(0.9),
                                      borderRadius: BorderRadius.circular(6),
                                      boxShadow: [
                                        BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4),
                                      ],
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.star, color: Colors.black87, size: 10),
                                        SizedBox(width: 3),
                                        Text(
                                          score,
                                          style: TextStyle(
                                            color: Colors.black87,
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                              // ── Status badge (top-right) ──
                              Positioned(
                                top: 8,
                                right: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: isOngoing ? _C.accent.withOpacity(0.85) : Color(0xFFFF3B30).withOpacity(0.85),
                                    borderRadius: BorderRadius.circular(6),
                                    boxShadow: [
                                      BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 4),
                                    ],
                                  ),
                                  child: Text(
                                    (status ?? '?').toUpperCase(),
                                    style: TextStyle(
                                      color: _C.text,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'MADEEvolveSansEVO',
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                              ),

                              // ── Play overlay ──
                              Positioned.fill(
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.transparent,
                                        Colors.black.withOpacity(0.6),
                                      ],
                                      stops: const [0.5, 0.7, 1.0],
                                    ),
                                  ),
                                ),
                              ),

                              // ── Episodes count (bottom) ──
                              if (episodes != null)
                                Positioned(
                                  bottom: 8,
                                  left: 8,
                                  right: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.55),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.play_circle_outline,
                                          color: _C.accent3,
                                          size: 12,
                                        ),
                                        SizedBox(width: 4),
                                        Text(
                                          '${episodes} Eps',
                                          style: TextStyle(
                                            color: _C.text,
                                            fontSize: 10,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(height: 8),
                          // ── Title ──
                          SizedBox(
                            width: 128,
                            child: Text(
                              title,
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                height: 1.3,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 8. JADWAL SHOLAT (ganti Activity Log)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildPrayerSchedule() {
    final hh = _now.hour.toString().padLeft(2, '0');
    final mm = _now.minute.toString().padLeft(2, '0');
    final ss = _now.second.toString().padLeft(2, '0');

    // Day names in Indonesian
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    final dayName = days[_now.weekday % 7];
    final dateStr = '$dayName, ${_now.day} ${months[_now.month - 1]} ${_now.year}';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(children: [
          Text('JADWAL SHOLAT', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, color: _C.text, letterSpacing: 1)),
          Spacer(),
          GestureDetector(
            onTap: _fetchPrayerTimes,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.border2)),
              child: Row(children: [
                Icon(Icons.refresh, color: _C.muted, size: 11),
                SizedBox(width: 4),
                Text('Refresh', style: TextStyle(fontSize: 10, color: _C.muted)),
              ]),
            ),
          ),
        ]),
      ),
      SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _C.border),
          ),
          child: Column(children: [

            // ── TOP: jam + lokasi + tanggal ──
            Container(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                gradient: LinearGradient(
                  colors: [Color(0xFF1a2540), Color(0xFF0f1525)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
              ),
              child: Row(children: [
                // Jam digital
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('$hh:$mm:$ss', style: TextStyle(
                    fontFamily: 'ShareTechMono', fontSize: 28, fontWeight: FontWeight.bold,
                    color: _C.text,
                    shadows: [Shadow(color: Color(0xFFFF6B6B).withOpacity(0.6), blurRadius: 12)],
                  )),
                  SizedBox(height: 2),
                  Text(dateStr, style: TextStyle(fontSize: 11, color: _C.muted, fontFamily: 'ShareTechMono')),
                ]),
                Spacer(),
                // Lokasi + next prayer countdown
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Row(children: [
                    Icon(Icons.location_on, color: Color(0xFFFF6B6B), size: 12),
                    SizedBox(width: 3),
                    Text('Jakarta, ID', style: TextStyle(fontSize: 11, color: _C.muted)),
                  ]),
                  SizedBox(height: 6),
                  if (!_prayerLoading && _nextPrayerKey.isNotEmpty) ...[
                    Text(
                      _prayerLabels[_nextPrayerKey] ?? _nextPrayerKey,
                      style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 9, color: Color(0xFFFF6B6B), letterSpacing: 1),
                    ),
                    SizedBox(height: 2),
                    Text(_prayerCountdown, style: TextStyle(
                      fontFamily: 'ShareTechMono', fontSize: 16, fontWeight: FontWeight.bold,
                      color: _C.text,
                    )),
                    Text('menuju waktu berikutnya', style: TextStyle(fontSize: 9, color: _C.muted)),
                  ],
                ]),
              ]),
            ),

            // ── DIVIDER ──
            Container(height: 1, color: _C.border2),

            // ── PRAYER LIST ──
            if (_prayerLoading)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Center(child: SizedBox(
                  width: 24, height: 24,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _C.accent),
                )),
              )
            else if (_prayerError.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Icon(Icons.wifi_off, color: _C.muted2, size: 28),
                  SizedBox(height: 8),
                  Text(_prayerError, style: TextStyle(color: _C.muted, fontSize: 12)),
                  SizedBox(height: 8),
                  GestureDetector(
                    onTap: _fetchPrayerTimes,
                    child: Text('Coba lagi', style: TextStyle(color: _C.accent, fontSize: 12)),
                  ),
                ]),
              )
            else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(children: _prayerKeys.map((k) => _prayerTile(k)).toList()),
              ),

          ]),
        ),
      ),
    ]);
  }

  Widget _prayerTile(String key) {
    final isNext    = key == _nextPrayerKey;
    final isPassed  = _isPrayerPassed(key) && !isNext;
    final time      = _prayerTimes[key] ?? '--:--';
    final label     = _prayerLabels[key] ?? key;
    final icon      = _prayerIcons[key] ?? FontAwesomeIcons.mosque;

    Color iconColor;
    Color labelColor;
    Color timeColor;
    Color bgColor;
    Color borderColor;

    if (isNext) {
      iconColor   = Color(0xFFFF6B6B);
      labelColor  = Colors.white;
      timeColor   = Color(0xFFFF6B6B);
      bgColor     = Color(0xFFFF6B6B).withOpacity(0.08);
      borderColor = Color(0xFFFF6B6B).withOpacity(0.25);
    } else if (isPassed) {
      iconColor   = _C.muted2;
      labelColor  = _C.muted;
      timeColor   = _C.muted;
      bgColor     = Colors.transparent;
      borderColor = Colors.transparent;
    } else {
      iconColor   = _C.muted;
      labelColor  = _C.text;
      timeColor   = _C.text;
      bgColor     = Colors.transparent;
      borderColor = Colors.transparent;
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: isNext ? 1 : 0),
      ),
      child: Row(children: [
        // Icon
        Container(
          width: 34, height: 34,
          decoration: BoxDecoration(
            color: isNext ? Color(0xFFFF6B6B).withOpacity(0.12) : _C.surface,
            borderRadius: BorderRadius.circular(10),
          ),
          child: FaIcon(icon, color: iconColor, size: 14),
        ),
        SizedBox(width: 12),
        // Label
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(
            fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: isNext ? FontWeight.bold : FontWeight.w500,
            color: labelColor,
          )),
          if (isNext) ...[
            SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: Color(0xFFFF6B6B).withOpacity(0.15), borderRadius: BorderRadius.circular(4)),
              child: Text('BERIKUTNYA', style: TextStyle(fontSize: 8, color: Color(0xFFFF6B6B), fontWeight: FontWeight.bold, letterSpacing: 0.5)),
            ),
          ],
        ])),
        // Time
        Text(time, style: TextStyle(
          fontFamily: 'ShareTechMono', fontSize: 15,
          fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
          color: timeColor,
        )),
        SizedBox(width: 8),
        // Status indicator
        if (isPassed)
          Icon(Icons.check_circle, color: _C.muted2, size: 14)
        else if (isNext)
          Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFF6B6B), boxShadow: [BoxShadow(color: Color(0xFFFF6B6B).withOpacity(0.5), blurRadius: 6)]))
        else
          Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.muted2)),
      ]),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // 9. LEFT RAIL NAVIGATION (in-flow glassmorphism column)
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildLeftRail() {
    return Container(
      width: 56,
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        border: Border(right: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      child: Align(
        alignment: Alignment.center,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              width: 46,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(0.07), width: 0.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 18,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _railItem(FontAwesomeIcons.house, 0),
                  SizedBox(height: 4),
                  _railItem(FontAwesomeIcons.wrench, 1),
                  SizedBox(height: 4),
                  _buildRailFanButton(),
                  SizedBox(height: 4),
                  _railItem(FontAwesomeIcons.android, 3),
                  SizedBox(height: 4),
                  _railItem(FontAwesomeIcons.sliders, 4),
                  SizedBox(height: 4),
                  Container(width: 18, height: 0.5, color: Colors.white.withOpacity(0.08)),
                  SizedBox(height: 4),
                  _railItemSmall(FontAwesomeIcons.bell, () { _openSidebar(); }),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _railItem(FaIconData icon, int index) {
    final active = _currentNavIndex == index;
    return GestureDetector(
      onTap: () => _onNavTap(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: active
              ? _C.accent.withOpacity(0.3)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: active
              ? Border.all(color: _C.accent.withOpacity(0.4), width: 0.5)
              : null,
        ),
        child: Icon(
          icon,
          color: active ? Colors.white : Colors.white.withOpacity(0.4),
          size: 14,
        ),
      ),
    );
  }

  Widget _railItemSmall(FaIconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: FaIcon(icon, color: Colors.white.withOpacity(0.3), size: 12),
      ),
    );
  }

  Widget _buildRailFanButton() {
    return GestureDetector(
      onTap: _toggleFanMenu,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: [_C.accent, _C.accent3],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(color: _C.accent.withOpacity(0.45), blurRadius: 12),
          ],
          border: Border.all(color: Colors.white.withOpacity(0.15), width: 0.5),
        ),
        child: FaIcon(FontAwesomeIcons.whatsapp, color: _C.text, size: 14),
      ),
    );
  }


  Widget _navItem(FaIconData icon, String label, int index) {
    final active = _currentNavIndex == index;
    return GestureDetector(
      onTap: () => _onNavTap(index), behavior: HitTestBehavior.opaque,
      child: SizedBox(width: 50, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        FaIcon(icon, color: active ? Colors.white : Color(0x66FFFFFF), size: 17, shadows: active ? [Shadow(color: _C.accent.withOpacity(0.6), blurRadius: 6)] : []),
        SizedBox(height: 3),
        Text(label, style: TextStyle(fontSize: 8, fontWeight: active ? FontWeight.bold : FontWeight.normal, color: active ? Colors.white : Color(0x66FFFFFF))),
        if (active) ...[SizedBox(height: 3), Container(width: 5, height: 5, decoration: BoxDecoration(color: _C.accent, shape: BoxShape.circle))],
      ])),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // 10. FAN MENU
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildFanMenuOverlay(double screenWidth) {
    // Fan menu opens from the left rail WhatsApp button area
    final railX = 29.0; // center of 58px rail
    final railY = 230.0; // approximate Y position of WA button in rail
    return Stack(children: [
      Positioned.fill(child: GestureDetector(
        onTap: _closeFanMenu, behavior: HitTestBehavior.opaque,
        child: ClipRect(child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6), child: Container(color: Colors.black54))),
      )),
      // Fan buttons emanate from the left rail WA button
      _fanButtonFromRail(icon: FontAwesomeIcons.user, label: 'CONTACT', g1: _C.fanGreen1, g2: _C.greenG2, angle: -60, radius: 80, delay: 0, originX: railX, originY: railY, onTap: () { _closeFanMenu(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
      _fanButtonFromRail(icon: FontAwesomeIcons.users, label: 'GROUP', g1: _C.fanBlue1, g2: _C.blueG2, angle: 0, radius: 90, delay: 70, originX: railX, originY: railY, onTap: () { _closeFanMenu(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
      _fanButtonFromRail(icon: FontAwesomeIcons.code, label: 'CUSTOM', g1: _C.fanPurple1, g2: _C.purpleG2, angle: 60, radius: 80, delay: 140, originX: railX, originY: railY, onTap: () { _closeFanMenu(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
      // Close button
      Positioned(left: 2, top: railY - 28, child: GestureDetector(
        onTap: _closeFanMenu,
        child: AnimatedBuilder(animation: _fanStaggerController, builder: (ctx, child) {
          final v = Curves.easeOut.transform((_fanStaggerController.value - 0.5).clamp(0.0, 1.0));
          return Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.scale(scale: (0.8 + v * 0.2).clamp(0.8, 1.0), child: child));
        }, child: Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.accent, boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.4), blurRadius: 16, spreadRadius: 2)]), child: Icon(Icons.close, color: _C.text, size: 24))),
      )),
    ]);
  }

  Widget _fanButtonFromRail({required FaIconData icon, required String label, required Color g1, required Color g2, required int angle, required double radius, required int delay, required double originX, required double originY, required VoidCallback onTap}) {
    final rad = angle * math.pi / 180;
    final targetDx = radius * math.cos(rad);
    final targetDy = radius * math.sin(rad);
    return AnimatedBuilder(
      animation: _fanStaggerController,
      builder: (ctx, child) {
        final delayFraction = delay / 400.0;
        final adjusted = (_fanStaggerController.value - delayFraction).clamp(0.0, 1.0);
        final curved = Curves.easeOutBack.transform(adjusted);
        final leftPos = originX + targetDx * curved - 28;
        final topPos = originY + targetDy * curved - 28;
        return Positioned(left: leftPos, top: topPos, child: Opacity(opacity: curved.clamp(0.0, 1.0), child: child));
      },
      child: GestureDetector(onTap: onTap, child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 56, height: 56, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [g1, g2], begin: Alignment.topCenter, end: Alignment.bottomCenter), boxShadow: [BoxShadow(color: g1.withOpacity(0.3), blurRadius: 12)]),
          child: Stack(alignment: Alignment.center, children: [
            Container(width: 56, height: 28, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.white.withOpacity(0.25), Colors.transparent], begin: Alignment.topCenter, end: Alignment.bottomCenter), borderRadius: const BorderRadius.vertical(top: Radius.circular(28)))),
            FaIcon(icon, color: _C.text, size: 19),
          ]),
        ),
        SizedBox(height: 6),
        Text(label, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 7, color: _C.text, fontWeight: FontWeight.bold)),
      ])),
    );
  }

// _fanButtonPositioned removed - replaced by _fanButtonFromRail

  // ═════════════════════════════════════════════════════════════════════════
  // 11. SIDEBAR (tanpa History)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildSidebar() {
    return Positioned(
      top: 0, bottom: 0, left: 0,
      child: SlideTransition(
        position: Tween<Offset>(begin: Offset(-1.0, 0.0), end: Offset.zero).animate(
          CurvedAnimation(parent: _sidebarController, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic)),
        child: Container(
          width: 260,
          decoration: BoxDecoration(
            color: _C.bg2, border: Border(right: BorderSide(color: _C.border)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24, offset: Offset(4, 0))],
          ),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
              child: Row(children: [
                Text('NAVIGATE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, color: _C.accent, letterSpacing: 2)),
                Spacer(),
                GestureDetector(onTap: _closeSidebar, child: Container(width: 32, height: 32, decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(8)), child: Icon(Icons.close, color: _C.muted, size: 16))),
              ]),
            ),
            Divider(color: _C.border, height: 1),
            Expanded(child: ListView(padding: const EdgeInsets.symmetric(vertical: 8), children: [
              _sidebarItem(FontAwesomeIcons.store,      'Seller Panel', 'seller'),
              _sidebarItem(FontAwesomeIcons.hatWizard,      'Admin',        'admin'),
              _sidebarItem(FontAwesomeIcons.paperPlane, 'Sender Hub',   'sender'),
              // History dihapus
              _sidebarItem(FontAwesomeIcons.toolbox,    'Tools',        'tools'),
            ])),
            Container(padding: const EdgeInsets.all(16), child: Text('YakuzaXsilence · OmhcSilence', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 9, color: _C.muted2))),
          ]),
        ),
      ),
    );
  }

  Widget _sidebarItem(FaIconData icon, String label, String page) {
    return Material(color: Colors.transparent, child: InkWell(
      onTap: () => _selectFromDrawer(page),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          FaIcon(icon, color: _C.muted, size: 16),
          SizedBox(width: 14),
          Text(label, style: TextStyle(fontSize: 14, color: _C.text)),
        ]),
      ),
    ));
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// DASHED CIRCLE PAINTER
// ═════════════════════════════════════════════════════════════════════════════
class _DashedCirclePainter extends CustomPainter {
  final Color color;
  final double dashWidth;
  final double dashGap;
  final double strokeWidth;

  _DashedCirclePainter({required this.color, this.dashWidth = 6, this.dashGap = 6, this.strokeWidth = 1.5});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    final paint = Paint()..color = color..strokeWidth = strokeWidth..style = PaintingStyle.stroke;
    final circumference = 2 * 3.14159265 * radius;
    final totalDash = dashWidth + dashGap;
    final dashCount = (circumference / totalDash).floor();
    for (int i = 0; i < dashCount; i++) {
      final startAngle = (i * totalDash / circumference) * 2 * 3.14159265;
      final sweepAngle = (dashWidth / circumference) * 2 * 3.14159265;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), startAngle, sweepAngle, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═════════════════════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ═════════════════════════════════════════════════════════════════════════════
class _SettingsPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final bool notif, sound, autoConnect, darkMode;
  final ValueChanged<bool> onToggleNotif, onToggleSound, onToggleAutoConnect, onToggleDarkMode;
  final VoidCallback onToggleMusic;
  final bool isMusicPlaying;

  const _SettingsPage({required this.username, required this.sessionKey, required this.notif, required this.sound, required this.autoConnect, required this.darkMode, required this.onToggleNotif, required this.onToggleSound, required this.onToggleAutoConnect, required this.onToggleDarkMode, required this.onToggleMusic, required this.isMusicPlaying});

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  late bool _n, _s, _a, _d, _m;

  @override
  void initState() {
    super.initState();
    _n = widget.notif; _s = widget.sound; _a = widget.autoConnect; _d = widget.darkMode; _m = widget.isMusicPlaying;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg2, elevation: 0,
        title: Text('SETTINGS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.bold, color: _C.text)),
        iconTheme: IconThemeData(color: _C.text),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _sl('GENERAL'), SizedBox(height: 8),
          _tt('Notifications', _n, (v) { setState(() => _n = v); widget.onToggleNotif(v); }, Icons.notifications),
          _tt('Sound Effects', _s, (v) { setState(() => _s = v); widget.onToggleSound(v); }, Icons.volume_up),
          _tt('Auto Connect', _a, (v) { setState(() => _a = v); widget.onToggleAutoConnect(v); }, Icons.sync),
          _tt('Dark Mode', _d, (v) { setState(() => _d = v); widget.onToggleDarkMode(v); }, Icons.dark_mode),
          SizedBox(height: 16),
          _sl('AUDIO'), SizedBox(height: 8),
          _tt('Background Music', _m, (_) { setState(() => _m = !_m); widget.onToggleMusic(); }, Icons.music_note),
          SizedBox(height: 16),
          _sl('ACCOUNT'), SizedBox(height: 8),
          _at('Change Password', Icons.lock, () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey)))),
          _at('Logout', Icons.logout, () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => LoginPage()), (r) => false);
          }),
        ]),
      ),
    );
  }

  Widget _sl(String l) => Text(l, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _C.muted, letterSpacing: 2));

  Widget _tt(String label, bool value, ValueChanged<bool> onChanged, FaIconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
      child: Row(children: [
        FaIcon(icon, color: _C.muted, size: 18), SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
        GestureDetector(onTap: () => onChanged(!value), child: AnimatedContainer(
          duration: Duration(milliseconds: 200), width: 44, height: 24,
          decoration: BoxDecoration(color: value ? _C.accent : _C.surface, borderRadius: BorderRadius.circular(12)),
          child: AnimatedAlign(duration: Duration(milliseconds: 200), alignment: value ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(width: 20, height: 20, margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(color: value ? _C.accent : _C.muted2, shape: BoxShape.circle, boxShadow: value ? [BoxShadow(color: _C.accent.withOpacity(0.4), blurRadius: 6)] : []),
              child: Container(margin: const EdgeInsets.all(3), decoration: BoxDecoration(color: value ? Colors.white : _C.muted2, shape: BoxShape.circle)),
            ),
          ),
        )),
      ]),
    );
  }

  Widget _at(String label, FaIconData icon, VoidCallback onTap) {
    return GestureDetector(onTap: onTap, child: Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
      child: Row(children: [
        FaIcon(icon, color: _C.muted, size: 18), SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
        Icon(Icons.chevron_right, color: _C.muted, size: 18),
      ]),
    ));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// BROADCAST DIALOG — popup notifikasi yang muncul pas user buka app
// kalau owner kirim broadcast (maintenance/update/info/warning).
// ═══════════════════════════════════════════════════════════════════════════
class _BroadcastDialog extends StatefulWidget {
  final List<dynamic> broadcasts;
  final String sessionKey;
  final VoidCallback onDismiss;

  const _BroadcastDialog({
    required this.broadcasts,
    required this.sessionKey,
    required this.onDismiss,
  });

  @override
  State<_BroadcastDialog> createState() => _BroadcastDialogState();
}

class _BroadcastDialogState extends State<_BroadcastDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    )..forward();
    _glowController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  // Type styling
  Map<String, dynamic> _getTypeStyle(String type) {
    switch ((type ?? 'info').toLowerCase()) {
      case 'maintenance':
        return {'color': Color(0xFF222222), 'icon': FontAwesomeIcons.screwdriverWrench, 'label': 'MAINTENANCE'};
      case 'update':
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.arrowsRotate, 'label': 'UPDATE'};
      case 'warning':
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.triangleExclamation, 'label': 'WARNING'};
      case 'info':
      default:
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.circleInfo, 'label': 'INFO'};
    }
  }

  Future<void> _dismissCurrent() async {
    final broadcasts = widget.broadcasts;
    if (_currentIndex >= broadcasts.length) {
      widget.onDismiss();
      return;
    }
    final current = broadcasts[_currentIndex] as Map<String, dynamic>;
    final id = current['id'] as String?;

    // Tell server user dismissed this broadcast
    if (id != null) {
      try {
        await http.post(
          Uri.parse("http://114.10.118.133:1887/dismissBroadcast"),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'key': widget.sessionKey, 'broadcastId': id}),
        ).timeout(Duration(seconds: 5));
      } catch (_) {}
    }

    // Next broadcast or close
    if (_currentIndex + 1 < broadcasts.length) {
      setState(() {
        _currentIndex++;
        _scaleController.reset();
        _scaleController.forward();
      });
    } else {
      widget.onDismiss();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentIndex >= widget.broadcasts.length) {
      return const SizedBox.shrink();
    }
    final broadcast = widget.broadcasts[_currentIndex] as Map<String, dynamic>;
    final typeStyle = _getTypeStyle(broadcast['type'] as String? ?? 'info');
    final primary = typeStyle['color'] as Color;
    final typeIcon = typeStyle['icon'];
    final typeLabel = typeStyle['label'] as String;
    final primaryDark = Color.lerp(primary, Colors.black, 0.4)!;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.7, end: 1.0).animate(
          CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            // Glow ring
            Positioned(
              top: -20,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (_, __) => Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primary.withOpacity(0.4 + _glowController.value * 0.3),
                        blurRadius: 30 + _glowController.value * 20,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Main card
            Container(
              margin: const EdgeInsets.only(top: 40),
              padding: const EdgeInsets.fromLTRB(22, 36, 22, 22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF222222),
                    Color(0xFF111111),
                  ],
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: primary.withOpacity(0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(color: primary.withOpacity(0.2), blurRadius: 40),
                  BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Type icon
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [primary, primaryDark],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: primary.withOpacity(0.5), blurRadius: 20),
                      ],
                    ),
                    child: FaIcon(typeIcon, color: _C.text, size: 32),
                  ),
                  SizedBox(height: 14),
                  // Type label badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: primary.withOpacity(0.3)),
                    ),
                    child: Text(typeLabel,
                        style: TextStyle(
                          color: primary,
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        )),
                  ),
                  SizedBox(height: 14),
                  // Title
                  Text(
                    broadcast['title'] as String? ?? 'Notification',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF000000),
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 6),
                  Container(width: 40, height: 2, color: primary.withOpacity(0.5)),
                  SizedBox(height: 14),
                  // Message
                  Text(
                    broadcast['message'] as String? ?? '',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0x73E0E7FF),
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                      height: 1.6,
                    ),
                  ),
                  SizedBox(height: 18),
                  // Progress dots (kalau multiple broadcasts)
                  if (widget.broadcasts.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          widget.broadcasts.length,
                          (i) => Container(
                            width: 6, height: 6,
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: i == _currentIndex
                                  ? primary
                                  : primary.withOpacity(0.2),
                            ),
                          ),
                        ),
                      ),
                    ),
                  // Dismiss button
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: _dismissCurrent,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text(
                        _currentIndex + 1 < widget.broadcasts.length
                            ? 'NEXT (${_currentIndex + 2}/${widget.broadcasts.length})'
                            : 'GOT IT',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
