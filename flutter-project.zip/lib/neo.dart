// ═══════════════════════════════════════════════════════════
//  NEO — design system neobrutalism (putih / outline tebal /
//  bayangan keras tanpa blur). Dipakai oleh semua halaman.
// ═══════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Neo {
  Neo._();

  // ── Warna dasar ───────────────────────────────────────────
  static const Color ink = Color(0xFF14142B);
  static const Color paper = Color(0xFFFFFDF8); // putih hangat (latar halaman)
  static const Color white = Color(0xFFFFFFFF);
  static const Color cream = Color(0xFFF7F1E3);
  static const Color tan = Color(0xFFEFE6CE);

  static const Color yellow = Color(0xFFFFC72C);
  static const Color pink = Color(0xFFFF4D7E);
  static const Color purple = Color(0xFF7C6CFF);
  static const Color green = Color(0xFF3CC63C);
  static const Color lime = Color(0xFFA4D920);
  static const Color blue = Color(0xFF3B6DF2);
  static const Color orange = Color(0xFFFF9F1C);
  static const Color red = Color(0xFFFF4D4D);
  static const Color cyan = Color(0xFF17B8CC);

  // Versi gelap — untuk teks/ikon berwarna di atas latar putih
  static const Color greenDeep = Color(0xFF0E7A4B);
  static const Color redDeep = Color(0xFFB92A2A);
  static const Color amberDeep = Color(0xFFB36B00);
  static const Color cyanDeep = Color(0xFF0E7A8C);
  static const Color blueDeep = Color(0xFF1F4FBF);
  static const Color purpleDeep = Color(0xFF4C3CB0);
  static const Color pinkDeep = Color(0xFFCC2E7A);

  static const Color sub = Color(0xFF55566E); // teks sekunder
  static const Color dim = Color(0xFF8E8FA3); // teks redup

  // ── Ukuran ────────────────────────────────────────────────
  static const double border = 2.5;
  static const double radius = 14;

  static List<BoxShadow> shadow([double d = 4, Color color = ink]) => [
        BoxShadow(color: color, offset: Offset(d, d), blurRadius: 0),
      ];

  static const TextStyle title = TextStyle(
    fontFamily: 'sans-serif-black',
    fontWeight: FontWeight.w900,
    fontSize: 30,
    height: 1.08,
    color: ink,
    letterSpacing: -0.5,
  );

  static const TextStyle heading = TextStyle(
    fontFamily: 'sans-serif-black',
    fontWeight: FontWeight.w900,
    fontSize: 16,
    color: ink,
  );

  static const TextStyle body = TextStyle(
    fontFamily: 'sans-serif-black',
    fontWeight: FontWeight.w700,
    fontSize: 13,
    color: ink,
  );

  static const TextStyle caption = TextStyle(
    fontFamily: 'sans-serif-black',
    fontWeight: FontWeight.w700,
    fontSize: 11.5,
    color: sub,
  );

  static void tick() => HapticFeedback.selectionClick();
}

// ═══════════════════════════════════════════════════════════
//  Transisi halaman — slide halus + fade
// ═══════════════════════════════════════════════════════════
Widget _neoTransition(
    Animation<double> animation, Animation<double> secondary, Widget child) {
  final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
  final back = CurvedAnimation(parent: secondary, curve: Curves.easeOutCubic);
  return SlideTransition(
    position: Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(-0.08, 0),
    ).animate(back),
    child: FadeTransition(
      opacity: Tween<double>(begin: 1, end: 0.6).animate(back),
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.12, 0),
          end: Offset.zero,
        ).animate(curved),
        child: FadeTransition(opacity: curved, child: child),
      ),
    ),
  );
}

class NeoTransitions extends PageTransitionsBuilder {
  const NeoTransitions();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) =>
      _neoTransition(animation, secondaryAnimation, child);
}

PageRoute<T> neoRoute<T>(Widget page) => PageRouteBuilder<T>(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 320),
      reverseTransitionDuration: const Duration(milliseconds: 260),
      transitionsBuilder: (_, anim, sec, child) =>
          _neoTransition(anim, sec, child),
    );

class NeoScrollBehavior extends MaterialScrollBehavior {
  const NeoScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) =>
      const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());

  @override
  Widget buildOverscrollIndicator(
          BuildContext context, Widget child, ScrollableDetails details) =>
      child;
}

// ═══════════════════════════════════════════════════════════
//  Latar — putih hangat + pola titik tipis (statis, ringan)
// ═══════════════════════════════════════════════════════════
class NeoBackground extends StatelessWidget {
  final Widget? child;
  final bool dots;
  const NeoBackground({super.key, this.child, this.dots = true});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Neo.paper,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (dots)
            const IgnorePointer(
              child: RepaintBoundary(
                child: CustomPaint(painter: _DotGridPainter()),
              ),
            ),
          if (child != null) child!,
        ],
      ),
    );
  }
}

class _DotGridPainter extends CustomPainter {
  const _DotGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = Neo.ink.withValues(alpha: 0.07);
    const gap = 22.0;
    for (double y = gap / 2; y < size.height; y += gap) {
      for (double x = gap / 2; x < size.width; x += gap) {
        canvas.drawCircle(Offset(x, y), 1.2, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════
//  Kartu / panel
// ═══════════════════════════════════════════════════════════
class NeoPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Color? color;
  final Color? accent; // tint pastel opsional
  final double shadow;
  final EdgeInsetsGeometry? margin;

  const NeoPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = Neo.radius,
    this.color,
    this.accent,
    this.shadow = 4,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    Color fill = color ?? Neo.white;
    if (color == null && accent != null) {
      fill = Color.alphaBlend(accent!.withValues(alpha: 0.16), Neo.white);
    }
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: fill,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Neo.ink, width: Neo.border),
        boxShadow: shadow <= 0 ? null : Neo.shadow(shadow),
      ),
      child: child,
    );
  }
}

/// Area "cekung" — untuk input / tampilan data di dalam panel.
class NeoInset extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Color? color;
  const NeoInset({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.radius = 10,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? Neo.cream,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Neo.ink, width: 2),
      ),
      child: child,
    );
  }
}

class NeoBadge extends StatelessWidget {
  final String text;
  final Color color;
  final Color textColor;
  const NeoBadge(this.text,
      {super.key, this.color = Neo.pink, this.textColor = Neo.white});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Neo.ink, width: 1.5),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'sans-serif-black',
          fontWeight: FontWeight.w900,
          fontSize: 9.5,
          color: textColor,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}

class NeoSectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const NeoSectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(text, style: Neo.heading)),
        if (trailing != null) trailing!,
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Pressable — bayangan "tenggelam" saat ditekan
// ═══════════════════════════════════════════════════════════
class NeoPress extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Color color;
  final double radius;
  final double depth;
  final EdgeInsetsGeometry padding;
  final double? width;
  final double? height;
  final bool haptic;

  const NeoPress({
    super.key,
    required this.child,
    required this.onTap,
    this.onLongPress,
    this.color = Neo.white,
    this.radius = 12,
    this.depth = 4,
    this.padding = EdgeInsets.zero,
    this.width,
    this.height,
    this.haptic = true,
  });

  @override
  State<NeoPress> createState() => _NeoPressState();
}

class _NeoPressState extends State<NeoPress>
    with SingleTickerProviderStateMixin {
  bool _down = false;
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 90),
    reverseDuration: const Duration(milliseconds: 260),
  );
  late final Animation<double> _press = CurvedAnimation(
    parent: _ctrl,
    curve: Curves.easeOut,
    reverseCurve: Curves.easeOutBack,
  );

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _set(bool v) {
    if (_down == v) return;
    _down = v;
    v ? _ctrl.forward() : _ctrl.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null || widget.onLongPress != null;
    final d = widget.depth;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => _set(true) : null,
      onTapUp: enabled ? (_) => _set(false) : null,
      onTapCancel: enabled ? () => _set(false) : null,
      onTap: widget.onTap == null
          ? null
          : () {
              if (widget.haptic) Neo.tick();
              widget.onTap!();
            },
      onLongPress: widget.onLongPress,
      child: AnimatedBuilder(
        animation: _press,
        builder: (context, child) {
          final t = enabled ? _press.value.clamp(0.0, 1.0) : 1.0;
          final off = d * t;
          final shadow = (d * (1 - t)).clamp(0.0, d);
          return Transform.translate(
            offset: Offset(off, off),
            child: Container(
              width: widget.width,
              height: widget.height,
              padding: widget.padding,
              decoration: BoxDecoration(
                color: enabled ? widget.color : Neo.tan,
                borderRadius: BorderRadius.circular(widget.radius),
                border: Border.all(color: Neo.ink, width: Neo.border),
                boxShadow: shadow <= 0.05
                    ? null
                    : [
                        BoxShadow(
                          color: Neo.ink,
                          offset: Offset(shadow, shadow),
                        ),
                      ],
              ),
              child: child,
            ),
          );
        },
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Tombol
// ═══════════════════════════════════════════════════════════
class NeoButton extends StatelessWidget {
  final String? label;
  final Widget? child;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  final bool loading;
  final bool expand;
  final Color textColor;

  const NeoButton({
    super.key,
    this.label,
    this.child,
    this.icon,
    required this.onTap,
    this.color = Neo.yellow,
    this.height = 52,
    this.loading = false,
    this.expand = false,
    this.textColor = Neo.ink,
  });

  @override
  Widget build(BuildContext context) {
    final fs = height < 44 ? 12.0 : 14.0;
    Widget content;
    if (loading) {
      content = SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(strokeWidth: 3, color: textColor),
      );
    } else if (child != null) {
      content = child!;
    } else {
      content = Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Icon(icon, size: fs + 5, color: textColor),
            if (label != null) const SizedBox(width: 8),
          ],
          if (label != null)
            Flexible(
              child: Text(
                label!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontFamily: 'sans-serif-black',
                  fontWeight: FontWeight.w900,
                  fontSize: fs,
                  color: textColor,
                ),
              ),
            ),
        ],
      );
    }

    final btn = NeoPress(
      onTap: loading ? null : onTap,
      color: color,
      height: height,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Center(child: content),
    );
    if (expand) return SizedBox(width: double.infinity, child: btn);
    return btn;
  }
}

class NeoIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final Color color;
  final Color iconColor;
  const NeoIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.size = 40,
    this.color = Neo.white,
    this.iconColor = Neo.ink,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPress(
      onTap: onTap,
      color: color,
      radius: 10,
      depth: 3,
      width: size,
      height: size,
      child: Center(child: Icon(icon, size: size * 0.5, color: iconColor)),
    );
  }
}

/// Titik status (pengganti LED) — datar, tanpa glow.
class NeoDot extends StatelessWidget {
  final Color color;
  final double size;
  const NeoDot({super.key, required this.color, this.size = 8});

  @override
  Widget build(BuildContext context) {
    final s = size < 8 ? 8.0 : size;
    return Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Neo.ink, width: 1.5),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Input
// ═══════════════════════════════════════════════════════════
class NeoField extends StatefulWidget {
  final TextEditingController controller;
  final String? hint;
  final String? label;
  final IconData? icon;
  final bool obscure;
  final Widget? suffix;
  final bool numericOnly;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final int maxLines;

  const NeoField({
    super.key,
    required this.controller,
    this.hint,
    this.label,
    this.icon,
    this.obscure = false,
    this.suffix,
    this.numericOnly = false,
    this.validator,
    this.keyboardType,
    this.onChanged,
    this.onSubmitted,
    this.maxLines = 1,
  });

  @override
  State<NeoField> createState() => _NeoFieldState();
}

class _NeoFieldState extends State<NeoField> {
  final FocusNode _focus = FocusNode();
  bool _has = false;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      if (mounted) setState(() => _has = _focus.hasFocus);
    });
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final field = AnimatedContainer(
      duration: const Duration(milliseconds: 140),
      decoration: BoxDecoration(
        color: Neo.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Neo.ink, width: Neo.border),
        boxShadow: Neo.shadow(_has ? 5 : 3, _has ? Neo.blue : Neo.ink),
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        validator: widget.validator,
        maxLines: widget.obscure ? 1 : widget.maxLines,
        onChanged: widget.onChanged,
        onFieldSubmitted: widget.onSubmitted,
        keyboardType: widget.numericOnly
            ? TextInputType.number
            : widget.keyboardType,
        inputFormatters: widget.numericOnly
            ? [FilteringTextInputFormatter.digitsOnly]
            : null,
        cursorColor: Neo.ink,
        style: const TextStyle(
          fontFamily: 'sans-serif-black',
          fontWeight: FontWeight.w800,
          fontSize: 14,
          color: Neo.ink,
        ),
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: const TextStyle(
            fontFamily: 'sans-serif-black',
            fontWeight: FontWeight.w600,
            fontSize: 13.5,
            color: Neo.dim,
          ),
          prefixIcon: widget.icon == null
              ? null
              : Icon(widget.icon, color: Neo.ink, size: 20),
          suffixIcon: widget.suffix,
          filled: false,
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          focusedErrorBorder: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          errorStyle: const TextStyle(
            fontFamily: 'sans-serif-black',
            fontSize: 11,
            color: Neo.redDeep,
          ),
        ),
      ),
    );

    if (widget.label == null) return field;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 8),
          child: Text(widget.label!, style: Neo.body),
        ),
        field,
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Kartu "folder" — tab di atas, ikon berwarna, judul tebal
// ═══════════════════════════════════════════════════════════
class NeoFolderCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? subtitle2;
  final IconData icon;
  final Color color;
  final String? badge;
  final VoidCallback? onTap;
  final double height;
  final bool compact;

  const NeoFolderCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.subtitle,
    this.subtitle2,
    this.badge,
    this.onTap,
    this.height = 112,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height + 14,
      child: Stack(
        children: [
          // tab folder
          Positioned(
            left: 10,
            top: 0,
            child: Container(
              width: 56,
              height: 18,
              decoration: BoxDecoration(
                color: color,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(8)),
                border: Border.all(color: Neo.ink, width: Neo.border),
              ),
            ),
          ),
          Positioned.fill(
            top: 13,
            child: NeoPress(
              onTap: onTap,
              color: Neo.white,
              radius: 14,
              depth: 4,
              padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
              child: compact
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(color: Neo.ink, width: 2),
                          ),
                          child: Icon(icon, size: 20, color: Neo.ink),
                        ),
                        const Spacer(),
                        Text(
                          title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontFamily: 'sans-serif-black',
                            fontWeight: FontWeight.w900,
                            fontSize: 12.5,
                            height: 1.12,
                            color: Neo.ink,
                          ),
                        ),
                        if (subtitle != null) ...[
                          const SizedBox(height: 2),
                          Text(subtitle!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontFamily: 'sans-serif-black',
                                fontWeight: FontWeight.w700,
                                fontSize: 10.5,
                                color: Neo.sub,
                              )),
                        ],
                      ],
                    )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: Neo.ink, width: 2),
                        ),
                        child: Icon(icon, size: 21, color: Neo.ink),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (subtitle != null)
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      subtitle!,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Neo.caption,
                                    ),
                                  ),
                                  if (badge != null) ...[
                                    const SizedBox(width: 5),
                                    NeoBadge(badge!),
                                  ],
                                ],
                              ),
                            if (subtitle2 != null)
                              Text(subtitle2!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Neo.caption),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: 'sans-serif-black',
                      fontWeight: FontWeight.w900,
                      fontSize: 14.5,
                      height: 1.15,
                      color: Neo.ink,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
//  Reveal — muncul bertahap (fade + naik) sekali saat build
// ═══════════════════════════════════════════════════════════
class NeoReveal extends StatelessWidget {
  final Widget child;
  final int index;
  const NeoReveal({super.key, required this.child, this.index = 0});

  @override
  Widget build(BuildContext context) {
    final ms = 380 + (index > 8 ? 8 : index) * 60;
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: ms),
      curve: Curves.easeOutCubic,
      builder: (_, v, c) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, (1 - v) * 18), child: c),
      ),
      child: child,
    );
  }
}
