import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'api_config.dart';

import 'neo.dart';
// ═══════════════════════════════════════════════════════════
// SOFT SKEUOMORPHISM PALETTE
// ═══════════════════════════════════════════════════════════
class Sk {
  // Metal
  static const Color metalDeep   = Color(0xFFF7F1E3);
  static const Color metalDark   = Color(0xFFFFFFFF);
  static const Color metalMid    = Color(0xFFFFFFFF);
  static const Color metalLight  = Color(0xFFEFE6CE);
  static const Color metalHi     = Color(0xFF3B6DF2);

  // Brass
  static const Color brassDeep   = Color(0xFFE0A800);
  static const Color brassDark   = Color(0xFFE0A800);
  static const Color brass       = Color(0xFFFFC72C);
  static const Color brassHi     = Color(0xFFFFD966);
  static const Color brassShine  = Color(0xFFFFE699);

  // Red (primary)
  static const Color redDeep     = Color(0xFFB92A2A);
  static const Color red         = Color(0xFFE03C3C);
  static const Color redBright   = Color(0xFFFF4D4D);
  static const Color redGlow     = Color(0xFFF0524F);
  static const Color redHi       = Color(0xFFFF4D4D);

  // Green
  static const Color greenDeep   = Color(0xFF0E7A4B);
  static const Color green       = Color(0xFF14B873);
  static const Color greenHi     = Color(0xFF2CC585);
  static const Color greenGlow   = Color(0xFF12A869);

  // Amber
  static const Color amberDeep   = Color(0xFFCC7A00);
  static const Color amber       = Color(0xFFFF9F1C);
  static const Color amberHi     = Color(0xFFF5A524);

  // Surface
  static const Color leather     = Color(0xFFFFFFFF);
  static const Color leatherDark = Color(0xFFF7F1E3);
  static const Color leatherHi   = Color(0xFFEFE6CE);
  static const Color cream       = Color(0xFF14142B);
  static const Color ink         = Color(0xFF14142B);
}

// ═══════════════════════════════════════════════════════════
// REUSABLE COMPONENTS
// ═══════════════════════════════════════════════════════════

/// Static LED
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});

  @override
  Widget build(BuildContext context) {
    return NeoDot(color: color, size: size);
  }
}

/// Rivet
class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 5});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

/// Screw
class _Screw extends StatelessWidget {
  final double size;
  const _Screw({this.size = 10});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

/// Soft metal panel
class _SoftPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPanel(
      padding: padding,
      radius: radius,
      color: null,
      accent: accent,
      shadow: 4.toDouble(),
      child: child,
    );
  }
}

/// Inset panel
class _SoftInset extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    return NeoInset(padding: padding, child: child);
  }
}

// ═══════════════════════════════════════════════════════════
// CHANGE PASSWORD PAGE
// ═══════════════════════════════════════════════════════════
class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl     = TextEditingController();
  final newPassCtrl     = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool _isLoading       = false;
  bool _obscureOld      = true;
  bool _obscureNew      = true;
  bool _obscureConfirm  = true;

  @override
  void dispose() {
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // API
  // ═══════════════════════════════════════════════════════════
  Future<void> _changePassword() async {
    HapticFeedback.lightImpact();
    final oldPass     = oldPassCtrl.text.trim();
    final newPass     = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }
    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }
    if (newPass.length < 6) {
      _showMessage("Password minimal 6 karakter.");
      return;
    }

    setState(() => _isLoading = true);
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error. Periksa jaringan.");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    HapticFeedback.mediumImpact();
    final color = isSuccess ? Sk.greenHi : Sk.amberHi;
    final icon = isSuccess
        ? Icons.check_circle_rounded
        : Icons.warning_amber_rounded;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: _SoftPanel(
          padding: const EdgeInsets.all(20),
          accent: color.withOpacity(0.6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.15),
                  border: Border.all(
                      color: Neo.ink, width: 2.5),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(height: 14),

              // Title
              Text(
                isSuccess ? 'SUKSES' : 'PERINGATAN',
                style: TextStyle(
                  color: color,
                  fontFamily: 'sans-serif-black',
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 0.3,
                  shadows: null,
                ),
              ),
              const SizedBox(height: 10),

              // Message
              Text(
                msg,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Neo.ink.withOpacity(0.7),
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 20),

              // OK button
              _MetalButton(
                label: 'OK',
                color: color,
                height: 42,
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Neo.paper,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Neo.paper, Neo.paper]),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 20),
                  child: Column(
                    children: [
                      const SizedBox(height: 8),

                      // Lock icon housing
                      _buildLockIcon(),
                      const SizedBox(height: 16),

                      // Title
                      const Text(
                        'SECURITY UPDATE',
                        style: TextStyle(
                          color: Neo.ink,
                          fontFamily: 'sans-serif-black',
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 0.3,
                          shadows: null,
                        ),
                      ),
                      const SizedBox(height: 8),

                      // Divider
                      Container(
                        width: 60,
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              Sk.redBright,
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Subtitle
                      Text(
                        'Masukkan password lama dan baru kamu.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Neo.ink.withOpacity(0.55),
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          fontSize: 11.5,
                          letterSpacing: 0.5,
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Credentials section
                      _buildSectionHeader('CREDENTIALS'),
                      const SizedBox(height: 10),

                      // Fields panel
                      _SoftPanel(
                        padding: const EdgeInsets.all(14),
                        accent: Sk.redBright.withOpacity(0.4),
                        child: Column(
                          children: [
                            _buildInput(
                              controller: oldPassCtrl,
                              label: 'OLD PASSWORD',
                              icon: Icons.lock_outline_rounded,
                              obscure: _obscureOld,
                              onToggle: () =>
                                  setState(() => _obscureOld = !_obscureOld),
                            ),
                            const SizedBox(height: 12),
                            _buildInput(
                              controller: newPassCtrl,
                              label: 'NEW PASSWORD',
                              icon: Icons.vpn_key_rounded,
                              obscure: _obscureNew,
                              onToggle: () =>
                                  setState(() => _obscureNew = !_obscureNew),
                            ),
                            const SizedBox(height: 12),
                            _buildInput(
                              controller: confirmPassCtrl,
                              label: 'CONFIRM PASSWORD',
                              icon: Icons.enhanced_encryption_rounded,
                              obscure: _obscureConfirm,
                              onToggle: () => setState(
                                  () => _obscureConfirm = !_obscureConfirm),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Update button
                      _MetalButton(
                        label: _isLoading
                            ? 'PROCESSING...'
                            : 'UPDATE PASSWORD',
                        color: Sk.redBright,
                        height: 56,
                        icon: _isLoading ? null : Icons.security_rounded,
                        loading: _isLoading,
                        onTap: _isLoading ? null : _changePassword,
                      ),

                      const SizedBox(height: 16),

                      // Info panel
                      _SoftPanel(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Sk.amberDeep,
                                border: Border.all(
                                    color: Neo.ink,
                                    width: 2),
                              ),
                              child: const Icon(Icons.info_outline_rounded,
                                  color: Neo.amberDeep, size: 12),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Gunakan password yang kuat & mudah diingat.',
                                style: TextStyle(
                                  color: Neo.ink.withOpacity(0.55),
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 11,
                                  height: 1.4,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: const LinearGradient(colors: [Sk.metalMid, Sk.metalMid]),
          border: Border.all(
            color: Neo.ink,
            width: 2,
          ),
          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              const _Screw(size: 12),
              const SizedBox(width: 8),
              _MetalIconButton(
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: () => Navigator.pop(context),
              ),
              const SizedBox(width: 10),
              const _Led(color: Sk.redGlow, size: 8),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'CHANGE PASSWORD',
                      style: TextStyle(
                        color: Neo.redDeep,
                        fontFamily: 'sans-serif-black',
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 0.3,
                        shadows: null,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '@${widget.username}',
                      style: TextStyle(
                        color: Neo.ink.withOpacity(0.55),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              const _Screw(size: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          const _Led(color: Sk.brass, size: 6),
          const SizedBox(width: 10),
          Text(
            '// $title',
            style: const TextStyle(
              color: Neo.ink,
              fontFamily: 'sans-serif-black',
              fontWeight: FontWeight.w900,
              fontSize: 11.5,
              letterSpacing: 0.3,
              shadows: null,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Sk.redBright.withOpacity(0.5),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOCK ICON
  // ═══════════════════════════════════════════════════════════
  Widget _buildLockIcon() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Outer ring
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
            border: Border.all(
              color: Neo.ink,
              width: 2.5,
            ),
            boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
          ),
        ),
        // Inner ring
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Sk.leatherDark,
            border: Border.all(
              color: Neo.ink,
              width: 2,
            ),
          ),
          child: const Icon(
            Icons.lock_reset_rounded,
            color: Neo.redDeep,
            size: 32,
          ),
        ),
        // Top LED
        Positioned(
          top: 0,
          right: 0,
          child: _Led(color: Sk.redGlow, size: 10),
        ),
        // Bottom rivet
        const Positioned(
          bottom: 2,
          child: _Rivet(size: 6),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INPUT FIELD (Skeuomorphic)
  // ═══════════════════════════════════════════════════════════
  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            label,
            style: TextStyle(
              color: Neo.ink.withOpacity(0.5),
              fontSize: 10.5,
              fontFamily: 'sans-serif-black',
              fontWeight: FontWeight.w900,
              letterSpacing: 0.3,
            ),
          ),
        ),
        // Field
        _SoftInset(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: Sk.redDeep,
                  border: Border.all(
                      color: Neo.ink, width: 2),
                ),
                child: Icon(icon, color: Neo.redDeep, size: 13),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  obscureText: obscure,
                  style: const TextStyle(
                    color: Neo.ink,
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3,
                  ),
                  cursorColor: Sk.brass,
                  cursorWidth: 2,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              GestureDetector(
                onTap: onToggle,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: Sk.metalMid.withOpacity(0.5),
                    border: Border.all(color: Neo.ink, width: 2),
                  ),
                  child: Icon(
                    obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: Neo.ink,
                    size: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalButton extends StatelessWidget {
  final String label;
  final Color color;
  final double height;
  final VoidCallback? onTap;
  final IconData? icon;
  final bool loading;
  const _MetalButton({
    required this.label,
    required this.color,
    required this.height,
    required this.onTap,
    this.icon,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return NeoButton(
      label: label,
      color: color,
      height: height,
      onTap: onTap,
      icon: icon,
      loading: loading,
    );
  }
}



// ═══════════════════════════════════════════════════════════
// METAL ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  const _MetalIconButton({
    required this.icon,
    required this.onTap,
    this.size = 34,
  });

  @override
  Widget build(BuildContext context) {
    return NeoIconButton(icon: icon, onTap: onTap, size: size);
  }
}

