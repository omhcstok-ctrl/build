import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class MusicPlayerPage extends StatefulWidget {
  const MusicPlayerPage({super.key});
  @override
  State<MusicPlayerPage> createState() => _MusicPlayerPageState();
}

class _MusicPlayerPageState extends State<MusicPlayerPage> {
  static const Color bg = Color(0xFFF7F1E3);
  static const Color panel = Color(0xFFFFFFFF);
  static const Color blue = Color(0xFF3B6DF2);
  static const Color violet = Color(0xFF6D5BD0);
  final _query = TextEditingController();
  final _player = AudioPlayer();
  bool _loading = false;
  bool _playing = false;
  String? _error;
  String? _title, _audioUrl, _thumbnail;
  int _duration = 0;

  @override
  void initState() {
    super.initState();
    _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playing = s == PlayerState.playing);
    });
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  Future<void> _search() async {
    final q = _query.text.trim();
    if (q.isEmpty) return;
    setState(() { _loading = true; _error = null; });
    try {
      final uri = Uri.https('api.ikyyxd.my.id', '/search/ytplayv2', {'q': q});
      final response = await http.get(uri).timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) throw Exception('Server merespons ${response.statusCode}');
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final result = data['result'] as Map<String, dynamic>?;
      final audio = result?['audio'] as Map<String, dynamic>?;
      final audioUrl = audio?['url']?.toString();
      if (data['status'] != true || audioUrl == null || audioUrl.isEmpty) {
        throw Exception('Audio tidak ditemukan. Coba judul lain.');
      }
      await _player.stop();
      setState(() {
        _title = result?['title']?.toString() ?? q;
        _audioUrl = audioUrl;
        _thumbnail = result?['thumbnail']?.toString();
        _duration = int.tryParse('${result?['duration'] ?? 0}') ?? 0;
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _togglePlayback() async {
    if (_audioUrl == null) return;
    try {
      if (_playing) {
        await _player.pause();
      } else {
        if (_player.state == PlayerState.paused) {
          await _player.resume();
        } else {
          await _player.play(UrlSource(_audioUrl!));
        }
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'Gagal memutar audio. Coba cari ulang.');
    }
  }

  String _time(int seconds) {
    final m = seconds ~/ 60, s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _query.dispose();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg, foregroundColor: const Color(0xFF14142B), elevation: 0,
        title: const Text('STARS MUSIC', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2, fontSize: 17)),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0B1530), bg, Color(0xFF160F2B)]),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(colors: [Color(0xFF17264A), Color(0xFF17152F)]),
                  border: Border.all(color: blue.withOpacity(.28)),
                ),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.graphic_eq_rounded, color: blue, size: 34),
                  SizedBox(height: 14),
                  Text('Your space. Your sound.', style: TextStyle(color: const Color(0xFF14142B), fontSize: 23, fontWeight: FontWeight.w800)),
                  SizedBox(height: 6),
                  Text('Cari lagu, lihat cover, lalu putar audio.', style: TextStyle(color: Color(0xFFAFBBD5), fontSize: 13)),
                ]),
              ),
              const SizedBox(height: 22),
              TextField(
                controller: _query,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _search(),
                style: const TextStyle(color: const Color(0xFF14142B)),
                decoration: InputDecoration(
                  hintText: 'Cari judul lagu atau penyanyi',
                  hintStyle: const TextStyle(color: Color(0xFF7F8AA5), fontSize: 13),
                  prefixIcon: const Icon(Icons.search_rounded, color: blue),
                  filled: true, fillColor: panel,
                  suffixIcon: IconButton(onPressed: _loading ? null : _search, icon: const Icon(Icons.arrow_forward_rounded, color: const Color(0xFF14142B))),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 20),
              if (_loading) const Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator(color: blue))),
              if (_error != null) Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF321D2B), borderRadius: BorderRadius.circular(14)),
                child: Text(_error!, style: const TextStyle(color: Color(0xFFFFB4C4))),
              ),
              if (_title != null) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: violet.withOpacity(.25))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: AspectRatio(aspectRatio: 1.2, child: _thumbnail == null
                        ? const ColoredBox(color: Color(0xFF1A2140), child: Icon(Icons.music_note_rounded, color: blue, size: 70))
                        : Image.network(_thumbnail!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF1A2140), child: Icon(Icons.music_note_rounded, color: blue, size: 70)))),
                    ),
                    const SizedBox(height: 18),
                    Text(_title!, style: const TextStyle(color: const Color(0xFF14142B), fontSize: 17, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text('Durasi ${_time(_duration)}', style: const TextStyle(color: Color(0xFF9DAAC6), fontSize: 12)),
                    const SizedBox(height: 16),
                    SizedBox(width: double.infinity, height: 50, child: FilledButton.icon(
                      onPressed: _togglePlayback,
                      icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                      label: Text(_playing ? 'PAUSE' : 'PLAY MUSIC'),
                      style: FilledButton.styleFrom(backgroundColor: blue, foregroundColor: const Color(0xFF081226), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    )),
                  ]),
                ),
              ],
              const SizedBox(height: 20),
              const Text('Hasil audio dan thumbnail diambil dari field result.audio.url dan result.thumbnail.', style: TextStyle(color: Color(0xFF7886A5), fontSize: 11, height: 1.5)),
            ],
          ),
        ),
      ),
    );
  }
}
