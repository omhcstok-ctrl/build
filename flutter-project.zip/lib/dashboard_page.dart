import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:battery_plus/battery_plus.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'login_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'bug_group_page.dart';
import 'tqto.dart';
import 'chat.dart';
import 'notification_page.dart';
import 'ai_page.dart';
import 'check_notif_page.dart';

import 'neo.dart';
class Sk {
  static const Color metalDeep    = Color(0xFFF7F1E3);
  static const Color metalDark    = Color(0xFFFFFFFF);
  static const Color metalMid     = Color(0xFFFFFFFF);
  static const Color metalLight   = Color(0xFFEFE6CE);
  static const Color metalShine   = Color(0xFF3B6DF2);
  static const Color metalHi      = Color(0xFF3B6DF2);

  static const Color brassDeep    = Color(0xFFE0A800);
  static const Color brassDark    = Color(0xFFE0A800);
  static const Color brass        = Color(0xFFFFC72C);
  static const Color brassHi      = Color(0xFFFFD966);
  static const Color brassShine   = Color(0xFFFFE699);

  static const Color redDeep      = Color(0xFFB92A2A);
  static const Color redDark      = Color(0xFFCC3333);
  static const Color red          = Color(0xFFE03C3C);
  static const Color redBright    = Color(0xFFFF4D4D);
  static const Color redGlow      = Color(0xFFF0524F);

  static const Color amberDeep    = Color(0xFFCC7A00);
  static const Color amber        = Color(0xFFFF9F1C);
  static const Color amberHi      = Color(0xFFF5A524);

  static const Color greenDeep    = Color(0xFF0E7A4B);
  static const Color green        = Color(0xFF14B873);
  static const Color greenHi      = Color(0xFF2CC585);
  static const Color greenGlow    = Color(0xFF12A869);

  static const Color cream        = Color(0xFF14142B);
  static const Color paper        = Color(0xFFFFFDF8);
  static const Color ink          = Color(0xFF14142B);

  static const Color leather      = Color(0xFFFFFFFF);
  static const Color leatherDark  = Color(0xFFF7F1E3);
  static const Color leatherHi    = Color(0xFFEFE6CE);
}

const String wsUrl = 'ws://lelendxdaycintapanel.ymzpterodactyl.biz.id:2079';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE — 1 ticker untuk semua LED
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;

  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }

  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    return NeoDot(color: color, size: size);
  }
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final double size;
  final double rotation;
  const _Screw({this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 10});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPanel(
      padding: padding,
      radius: radius,
      color: brass ? Neo.yellow : null,
      accent: null,
      shadow: 4.toDouble(),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// INSET PANEL
// ═══════════════════════════════════════════════════════════
class _InsetPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color glowColor;
  final bool glow;
  const _InsetPanel({
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.glowColor = Sk.brass,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    return NeoInset(padding: padding, child: child);
  }
}

// ═══════════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════════
class _IndustrialButton extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.child,
    required this.onTap,
    this.color = Sk.brass,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    return NeoButton(child: child, onTap: onTap, color: color, height: height);
  }
}



// ═══════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';
  String deviceModel = 'Unknown';
  String deviceBrand = 'Unknown';
  VideoPlayerController? _bannerVideoCtrl;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _glowCtrl;

  Timer? _statsTimer;
  int activeConnections = 0;
  int _signalStrength = 85;
  int batteryLevel = 78;
  String batteryState = 'Charging';
  bool _isBatteryLoaded = false;
  String _clockTime = '';
  Timer? _clockTimer;
  int _totalRamMb = 4096;
  int _usedRamMb = 2048;
  int _totalStorageGb = 128;
  int _freeStorageGb = 64;
  int sdkInt = 33;
  String _accountStatus = 'Active';
  int _accountDaysLeft = 365;
  double _accountProgress = 0.75;

  bool get _isAdmin => ['creator', 'developer', 'staf', 'exec', 'vvip',
      'svip', 'owner', 'ceo', 'mod', 'pt', 'reseller']
      .contains(role.toLowerCase());

  void _getBatteryLevel() async {
    try {
      final battery = Battery();
      final level = await battery.batteryLevel;
      final state = await battery.batteryState;
      if (!mounted) return;
      setState(() {
        batteryLevel = level;
        batteryState = state.toString().split('.').last;
        _isBatteryLoaded = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        batteryLevel = 24;
        batteryState = 'Unknown';
        _isBatteryLoaded = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);

    _initAndroidId();
    _initBannerVideo();

    _clockTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
    _updateClock();
    _getBatteryLevel();
    Timer.periodic(const Duration(seconds: 30), (_) => _getBatteryLevel());
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _glowCtrl.dispose();
    _bannerVideoCtrl?.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }

  void _updateClock() {
    final now = DateTime.now();
    final newTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    if (newTime != _clockTime && mounted) {
      setState(() => _clockTime = newTime);
    }
  }

  void _initBannerVideo() {
    _bannerVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _bannerVideoCtrl?.setLooping(true);
        _bannerVideoCtrl?.setVolume(0);
        _bannerVideoCtrl?.play();
      }).catchError((_) {});
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      deviceModel = info.model ?? 'Unknown';
      deviceBrand = info.brand ?? 'Unknown';
    } catch (_) {}
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    } catch (e) {
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) _connectWS();
      });
      return;
    }

    channel!.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel!.stream.listen((event) {
      try {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' &&
            data['valid'] == true &&
            mounted) {
          channel!.sink.add(jsonEncode({'type': 'stats'}));
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
            activeConnections = activeConns;
          });
        }
        if (data['type'] == 'notification' && mounted) {
          _showSkeuoSnack(data['title'] ?? 'Notifikasi baru');
        }
        if (data['type'] == 'myInfo' &&
            data['valid'] == false &&
            mounted) {
          _handleInvalidSession(data['reason'] ?? 'Session invalid');
        }
        if (data['type'] == 'forceLogout' && mounted) {
          _handleInvalidSession(data['reason'] ?? 'Logged out');
        }
      } catch (_) {}
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel?.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  void _showSkeuoSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const _Led(color: Sk.greenGlow, size: 8, blink: true),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        backgroundColor: Sk.metalDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: const BorderSide(color: Neo.ink, width: 2.5),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  _Led(color: Sk.redGlow, size: 12, blink: true),
                  SizedBox(width: 10),
                  Text(
                    'SESSION EXPIRED',
                    style: TextStyle(
                      color: Neo.ink,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Text(message,
                  style: const TextStyle(color: Neo.ink, fontSize: 12)),
              const SizedBox(height: 22),
              _IndustrialButton(
                color: Sk.red,
                height: 48,
                onTap: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (_) => false,
                ),
                child: const Text(
                  'KEMBALI KE LOGIN',
                  style: TextStyle(
                    color: Neo.ink,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3,
                    fontFamily: 'sans-serif-black',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() => _navIndex = index);
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 0:
        return _buildHome();
      case 2:
        return ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          username: username,
          listDoos: listDoos,
        );
      case 3:
        return CheckNotifPage(
           sessionKey: sessionKey,
           username: username,
           role: role,
        );
      default:
        return _buildHome();
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return Sk.greenGlow;
      case 'expired':
        return Sk.redGlow;
      case 'suspended':
        return Sk.amberHi;
      default:
        return Sk.brass;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return Icons.check_circle_rounded;
      case 'expired':
        return Icons.cancel_rounded;
      case 'suspended':
        return Icons.warning_rounded;
      default:
        return Icons.info_rounded;
    }
  }

  String _formatDate(String date) {
    if (date.isEmpty) return 'N/A';
    final parts = date.split('-');
    if (parts.length == 3) return '${parts[2]}/${parts[1]}/${parts[0]}';
    return date;
  }

  Widget _buildHome() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBannerWithOverlay(),
            const SizedBox(height: 16),
            _buildProfilePlate(),
            const SizedBox(height: 14),
            _buildCommandCenter(),
            const SizedBox(height: 14),
            _buildSocialRack(),
          ],
        ),
      ),
    );
  }

  // ─── BANNER ─────────────────────────────────────────────
  Widget _buildBannerWithOverlay() {
    return RepaintBoundary(
      child: _MetalPlate(
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(13),
          child: AspectRatio(
            aspectRatio: 20 / 9,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_bannerVideoCtrl != null &&
                    _bannerVideoCtrl!.value.isInitialized)
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bannerVideoCtrl!.value.size.width,
                      height: _bannerVideoCtrl!.value.size.height,
                      child: VideoPlayer(_bannerVideoCtrl!),
                    ),
                  )
                else
                  Image.asset(
                    'assets/images/trasher.jpeg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: Sk.leatherDark,
                      child: const Center(
                        child: Text(
                          'VS',
                          style: TextStyle(
                            color: Neo.ink,
                            fontSize: 24,
                            fontFamily: 'sans-serif-black',
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                  ),

                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.7),
                        Colors.transparent,
                        Colors.transparent,
                        Colors.black.withOpacity(0.8),
                      ],
                      stops: const [0.0, 0.3, 0.7, 1.0],
                    ),
                  ),
                ),

                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Neo.paper,
                      border: Border.all(color: Neo.ink, width: 2),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const _Led(
                            color: Sk.greenGlow, size: 6, blink: true),
                        const SizedBox(width: 6),
                        Text(
                          'LIVE',
                          style: TextStyle(
                            color: Neo.ink.withOpacity(0.9),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'sans-serif-black',
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        _slideRoute(NotificationPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        )),
                      );
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
                        border: Border.all(color: Neo.ink, width: 2.5),
                        boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: const [
                          Icon(Icons.notifications_rounded,
                              color: Neo.ink, size: 20),
                          Positioned(
                            top: 6,
                            right: 6,
                            child: _Led(
                                color: Sk.redGlow, size: 6, blink: true),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 12,
                  bottom: 10,
                  right: 12,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'WELCOME BACK,',
                              style: TextStyle(
                                color: Neo.ink.withOpacity(0.85),
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'sans-serif-black',
                                letterSpacing: 0.3,
                                shadows: null,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    username.toUpperCase(),
                                    style: const TextStyle(
                                      color: Neo.ink,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'sans-serif-black',
                                      letterSpacing: 0.3,
                                      shadows: null,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    gradient: const LinearGradient(colors: [Sk.brassDark, Sk.brassDark]),
                                    border: Border.all(
                                        color: Neo.ink, width: 2),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: const TextStyle(
                                      color: Neo.ink,
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'sans-serif-black',
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const Positioned(top: 4, left: 4, child: _Rivet(size: 8)),
                const Positioned(top: 4, right: 4, child: _Rivet(size: 8)),
                const Positioned(
                    bottom: 4, left: 4, child: _Rivet(size: 8)),
                const Positioned(
                    bottom: 4, right: 4, child: _Rivet(size: 8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── PROFILE PLATE ──────────────────────────────────────
  Widget _buildProfilePlate() {
    return RepaintBoundary(
      child: _MetalPlate(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                    border: Border.all(color: Neo.ink, width: 2.5),
                    boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                  ),
                  child: const Center(
                    child: _Led(
                        color: Sk.greenGlow, size: 12, blink: true),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _getGreeting(),
                        style: TextStyle(
                          color: Neo.ink.withOpacity(0.7),
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.3,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        username,
                        style: const TextStyle(
                          color: Neo.ink,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'sans-serif-black',
                          letterSpacing: 0.3,
                          shadows: null,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          _Led(
                              color: _getStatusColor(_accountStatus),
                              size: 5),
                          const SizedBox(width: 6),
                          Text(
                            'ACTIVE · ${_formatDate(expiredDate)}',
                            style: TextStyle(
                              color: Neo.ink.withOpacity(0.6),
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _signalBar(3, true),
                        _signalBar(6, true),
                        _signalBar(9, true),
                        _signalBar(12, true),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'SIGNAL',
                      style: TextStyle(
                        color: Neo.ink.withOpacity(0.7),
                        fontSize: 10.5,
                        fontFamily: 'sans-serif-black',
                        letterSpacing: 0.3,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Sk.brass.withOpacity(0.4),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.info_outline, color: Neo.ink, size: 12),
                const SizedBox(width: 6),
                Text(
                  'Ziferr Invictus · Project Nted',
                  style: TextStyle(
                    color: Neo.ink.withOpacity(0.7),
                    fontSize: 11.5,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Upgrade Role? ',
                  style: TextStyle(
                    color: Neo.ink.withOpacity(0.5),
                    fontSize: 11.5,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                GestureDetector(
                  onTap: () async {
                    final url = Uri.parse("https://t.me/NtedPakeE");
                    if (await canLaunchUrl(url)) {
                      await launchUrl(url,
                          mode: LaunchMode.externalApplication);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(3),
                      color: Sk.brassDeep.withOpacity(0.5),
                      border: Border.all(color: Neo.ink, width: 2),
                    ),
                    child: const Text(
                      '@NtedPakeE',
                      style: TextStyle(
                        color: Neo.ink,
                        fontSize: 11.5,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _signalBar(double h, bool active) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 1),
      child: Container(
        width: 3,
        height: h,
        decoration: BoxDecoration(
          color: active ? Sk.greenGlow : Sk.metalDark,
          borderRadius: BorderRadius.circular(1),
          boxShadow: active
              ? [
                  BoxShadow(color: Neo.ink, offset: Offset(3, 3), blurRadius: 0),
                ]
              : null,
        ),
      ),
    );
  }

  // ─── COMMAND CENTER ─────────────────────────────────────
  Widget _buildCommandCenter() {
    final statusColor = _getStatusColor(_accountStatus);

    return RepaintBoundary(
      child: _MetalPlate(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: const [
                _Screw(size: 12),
                SizedBox(width: 10),
                _Led(color: Sk.brass, size: 6, blink: true),
                SizedBox(width: 8),
                Expanded(
                  child: Center(
                    child: Text(
                      'COMMAND CENTER',
                      style: TextStyle(
                        color: Neo.ink,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'sans-serif-black',
                        letterSpacing: 0.3,
                        shadows: null,
                      ),
                    ),
                  ),
                ),
                _Led(color: Sk.greenGlow, size: 6, blink: true),
                SizedBox(width: 10),
                _Screw(size: 12),
              ],
            ),
            const SizedBox(height: 12),

            _InsetPanel(
              padding: const EdgeInsets.all(10),
              glowColor: statusColor,
              glow: true,
              child: Row(
                children: [
                  Icon(_getStatusIcon(_accountStatus),
                      color: statusColor, size: 12),
                  const SizedBox(width: 6),
                  Text(
                    _accountStatus.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 6,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        color: Neo.paper,
                        border:
                            Border.all(color: Neo.ink, width: 2),
                      ),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: _accountProgress.clamp(0.0, 1.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(3),
                            gradient: LinearGradient(colors: [statusColor.withOpacity(0.6), statusColor.withOpacity(0.6)]),
                            boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '$_accountDaysLeft D',
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: _readoutCell(
                    icon: FontAwesomeIcons.crown,
                    label: 'ROLE',
                    value: role.toUpperCase(),
                    color: Sk.amberHi,
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _readoutCell(
                    icon: FontAwesomeIcons.calendarAlt,
                    label: 'EXPIRED',
                    value: _formatDate(expiredDate),
                    color: Sk.brass,
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _readoutCell(
                    icon: FontAwesomeIcons.users,
                    label: 'ONLINE',
                    value: '$onlineUsers',
                    color: Sk.greenGlow,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _readoutCell({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    bool showProgress = false,
    double progressValue = 0.0,
    Color progressColor = Colors.white,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        color: Neo.paper,
        border: Border.all(color: Neo.ink, width: 2),
        boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 9),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  color: Neo.ink.withOpacity(0.5),
                  fontSize: 10.5,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.3,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 11.5,
              fontWeight: FontWeight.w900,
              fontFamily: 'sans-serif-black',
              letterSpacing: 0.5,
              shadows: null,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          if (showProgress) ...[
            const SizedBox(height: 3),
            Container(
              height: 3,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: Neo.paper,
                border: Border.all(color: Neo.ink, width: 2),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progressValue.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    color: progressColor,
                    boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── SOCIAL RACK ────────────────────────────────────────
  Widget _buildSocialRack() {
    return RepaintBoundary(
      child: _MetalPlate(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              child: _IndustrialButton(
                color: const Color(0xFF1E88E5),
                height: 52,
                onTap: () => _openUrl('https://t.me/NtedPakeE'),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FaIcon(FontAwesomeIcons.telegram,
                        color: Neo.ink, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'TELEGRAM',
                      style: TextStyle(
                        color: Neo.ink,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        fontFamily: 'sans-serif-black',
                        letterSpacing: 0.3,
                        shadows: null,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _IndustrialButton(
                color: const Color(0xFF212121),
                height: 52,
                onTap: () => _openUrl('https://www.tiktok.com/@nted.exec'),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FaIcon(FontAwesomeIcons.tiktok,
                        color: Neo.ink, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'TIKTOK',
                      style: TextStyle(
                        color: Neo.ink,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        fontFamily: 'sans-serif-black',
                        letterSpacing: 0.3,
                        shadows: null,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SHEET ITEM ─────────────────────────────────────────
  Widget _buildSheetItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return _IndustrialButton(
      color: Sk.metalMid,
      height: 68,
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [iconColor.withOpacity(0.3), iconColor.withOpacity(0.3)]),
              border:
                  Border.all(color: Neo.ink, width: 2),
              boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Neo.ink,
                    fontFamily: 'sans-serif-black',
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Neo.ink.withOpacity(0.55),
                    fontFamily: 'ShareTechMono',
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios_rounded,
              color: Neo.ink, size: 14),
        ],
      ),
    );
  }

  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      isScrollControlled: true,
      builder: (context) {
        return _MetalPlate(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 4,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: Sk.metalLight,
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
              ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [Sk.metalHi, Sk.metalHi]),
                      border: Border.all(
                          color: Neo.ink,
                          width: 2.5),
                      boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                    ),
                    child: const FaIcon(FontAwesomeIcons.whatsapp,
                        color: Neo.greenDeep, size: 20),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Text(
                      'WHATSAPP TOOLS',
                      style: TextStyle(
                        color: Neo.ink,
                        fontFamily: 'sans-serif-black',
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                        shadows: null,
                      ),
                    ),
                  ),
                  const _Led(color: Sk.greenGlow, size: 8, blink: true),
                ],
              ),
              const SizedBox(height: 18),
              _buildSheetItem(
                icon: Icons.bug_report_rounded,
                iconColor: Sk.redGlow,
                title: 'WhatsApp Crash',
                subtitle: 'Send payloads & crash codes',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => HomePage(
                        username: username,
                        password: password,
                        sessionKey: sessionKey,
                        listBug: listBug,
                        role: role,
                        expiredDate: expiredDate,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),
              _buildSheetItem(
                icon: Icons.phone_android_rounded,
                iconColor: Sk.greenGlow,
                title: 'Manage Sender',
                subtitle: 'Pair devices & manage sessions',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BugSenderPage(
                        sessionKey: sessionKey,
                        username: username,
                        role: role,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),
              _buildSheetItem(
                icon: Icons.groups_rounded,
                iconColor: Sk.amberHi,
                title: 'Bug Group',
                subtitle: 'Send bugs to groups',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BugGroupPage(
                        sessionKey: sessionKey,
                        role: role,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return '☀️ GOOD MORNING';
    if (hour < 18) return '🌤 GOOD AFTERNOON';
    return '🌙 GOOD EVENING';
  }

  // ═══════════════════════════════════════════════════════
  // SCAFFOLD
  // ═══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(colors: [Neo.paper, Neo.paper]),
        ),
        child: Stack(
          children: [
            const Positioned.fill(
              child: IgnorePointer(
                child: RepaintBoundary(
                  child: CustomPaint(painter: _LeatherWallPainter()),
                ),
              ),
            ),
            SafeArea(
              bottom: false,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeIn,
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.03),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: KeyedSubtree(
                  key: ValueKey(_navIndex),
                  child: _buildCurrentPage(),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ─── APP BAR ────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      iconTheme: const IconThemeData(color: Neo.ink),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Sk.metalMid, Sk.metalMid]),
          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
          border: const Border(
            bottom: BorderSide(color: Neo.ink, width: 2.5),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: const [
          _Led(color: Sk.greenGlow, size: 6, blink: true),
          SizedBox(width: 10),
          Text(
            'Ziferr Invictus',
            style: TextStyle(
              color: Neo.ink,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              fontFamily: 'sans-serif-black',
              letterSpacing: 0.3,
              shadows: null,
            ),
          ),
          SizedBox(width: 10),
          _Led(color: Sk.brass, size: 6, blink: true),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              _slideRoute(NotificationPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              )),
            );
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
              border: Border.all(color: Neo.ink, width: 2),
            ),
            child: const Icon(Icons.notifications_rounded,
                color: Neo.ink, size: 20),
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            )),
          ),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
              border: Border.all(color: Neo.ink, width: 2),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const _Led(color: Sk.greenGlow, size: 5, blink: true),
                const SizedBox(width: 6),
                Text(
                  username.length > 8
                      ? '${username.substring(0, 8)}…'
                      : username,
                  style: const TextStyle(
                    color: Neo.ink,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── DRAWER ─────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.85,
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Sk.leatherHi, Sk.leatherHi]),
          border: const Border(
            right: BorderSide(color: Neo.ink, width: 2.5),
          ),
        ),
        child: Stack(
          children: [
            const Positioned.fill(
              child: RepaintBoundary(
                child: CustomPaint(painter: _LeatherWallPainter()),
              ),
            ),
            SafeArea(
              child: Column(
                children: [
                  Container(
                    height: 220,
                    margin: const EdgeInsets.all(16),
                    child: _MetalPlate(
                      brass: true,
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 90,
                            height: 90,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                              border:
                                  Border.all(color: Neo.ink, width: 3),
                              boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                            ),
                            child: Center(
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/images/logo.jpg',
                                  width: 78,
                                  height: 78,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(
                                    Icons.security_rounded,
                                    color: Neo.ink,
                                    size: 40,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          const Text(
                            'Ziferr Invictus',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.3,
                              color: Neo.ink,
                              shadows: null,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  Sk.brass.withOpacity(0.7),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            username,
                            style: const TextStyle(
                              color: Neo.ink,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'sans-serif-black',
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const _Led(
                                  color: Sk.greenGlow,
                                  size: 6,
                                  blink: true),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 3),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(4),
                                  gradient: const LinearGradient(colors: [Sk.brassDark, Sk.brassDark]),
                                  border: Border.all(
                                      color: Neo.ink, width: 2),
                                ),
                                child: Text(
                                  role.toUpperCase(),
                                  style: const TextStyle(
                                    color: Neo.ink,
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'sans-serif-black',
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          Text(
                            'EXP: $expiredDate',
                            style: TextStyle(
                              color: Neo.ink.withOpacity(0.6),
                              fontSize: 11.5,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 16),
                      children: [
                        if (_isAdmin)
                          _buildDrawerItem(
                            icon: Icons.admin_panel_settings,
                            title: 'Admin Page',
                            color: Sk.redGlow,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => OwnerPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase() == 'reseller')
                          _buildDrawerItem(
                            icon: Icons.storefront,
                            title: 'Seller Dashboard',
                            color: Sk.amberHi,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      SellerPage(keyToken: sessionKey),
                                ),
                              );
                            },
                          ),
                        _buildDrawerItem(
                          icon: Icons.lock_reset,
                          title: 'Change Password',
                          color: Sk.brass,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                    username: username,
                                    sessionKey: sessionKey),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          icon: Icons.system_update_alt,
                          title: 'Update App',
                          color: Sk.greenGlow,
                          onTap: () {
                            Navigator.pop(context);
                            _showSkeuoSnack(
                                'Fitur Update App sedang dalam pengembangan');
                          },
                        ),
                        _buildDrawerItem(
                          icon: Icons.favorite_rounded,
                          title: 'TQTO',
                          color: Sk.redGlow,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const TqtoPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          icon: Icons.chat_rounded,
                          title: 'Chat',
                          color: Sk.brassShine,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          icon: Icons.smart_toy,
                          title: 'AI Assistant',
                          color: Sk.greenGlow,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AIPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          icon: Icons.logout_rounded,
                          title: 'Logout',
                          color: Sk.redGlow,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const LoginPage()),
                              (_) => false,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Neo.paper,
                      border: Border.all(color: Neo.ink, width: 2),
                    ),
                    child: Center(
                      child: Text(
                        'VOID STARS © SINCE 2026',
                        style: TextStyle(
                          color: Neo.ink.withOpacity(0.6),
                          fontSize: 11.5,
                          fontFamily: 'sans-serif-black',
                          letterSpacing: 0.3,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: _IndustrialButton(
        color: Sk.metalMid,
        height: 56,
        onTap: onTap,
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    color.withOpacity(0.25),
                    color.withOpacity(0.05)
                  ],
                ),
                border:
                    Border.all(color: Neo.ink, width: 2),
                boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Neo.ink,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.8,
                ),
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                color: Neo.ink, size: 12),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM NAV ─────────────────────────────────────────
  Widget _buildBottomNav() {
    return RepaintBoundary(
      child: Container(
        decoration: const BoxDecoration(
          color: Neo.white,
          border: Border(
            top: BorderSide(color: Neo.ink, width: Neo.border),
          ),
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 68,
            child: Row(
              children: [
                _buildNavBtn(
                  icon: Icons.home_rounded,
                  label: 'HOME',
                  index: 0,
                ),
                _buildNavBtn(
                  icon: FontAwesomeIcons.whatsapp,
                  label: 'WHATSAPP',
                  index: 1,
                  accent: true,
                ),
                _buildNavBtn(
                  icon: Icons.build_rounded,
                  label: 'TOOLS',
                  index: 2,
                ),
                _buildNavBtn(
                  icon: Icons.notifications_active,
                  label: 'NOTIF',
                  index: 3,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavBtn({
    required IconData icon,
    required String label,
    required int index,
    bool accent = false,
  }) {
    final active = _navIndex == index;
    final tint = accent ? Sk.greenGlow : Sk.brass;
    final color = active ? Neo.ink : (accent ? Sk.greenGlow : Neo.dim);

    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Neo.tick();
          _onNavTap(index);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          decoration: BoxDecoration(
            color: active ? tint : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: active ? Neo.ink : Colors.transparent,
              width: 2,
            ),
          ),
          transform: Matrix4.translationValues(0, active ? -2 : 0, 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (active) ...[
                _Led(color: color, size: 4, blink: accent),
                const SizedBox(height: 3),
              ],
              AnimatedScale(
                scale: active ? 1.08 : 1.0,
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutBack,
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(height: 2),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 220),
                style: TextStyle(
                  color: color,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.3,
                ),
                child: Text(label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// ROUTE HELPER
// ═══════════════════════════════════════════════════════════
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

class _LeatherWallPainter extends CustomPainter {
  const _LeatherWallPainter();

  @override
  void paint(Canvas canvas, Size size) {
    // flat — tidak ada tekstur
  }

  @override
  bool shouldRepaint(_LeatherWallPainter old) => false;
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _ctrl!.value.aspectRatio,
          child: VideoPlayer(_ctrl!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(color: Sk.brass, strokeWidth: 2),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Sk.leatherDark,
        child: const Icon(Icons.error_rounded, color: Neo.sub),
      ),
    );
  }
}