import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'neo.dart';
class Sk {
  static const Color metalDark = Color(0xFFFFFFFF);
  static const Color metalMid = Color(0xFFFFFFFF);
  static const Color metalLight = Color(0xFFEFE6CE);
  static const Color metalHi = Color(0xFF3B6DF2);
  static const Color brassDark = Color(0xFFE0A800);
  static const Color brass = Color(0xFFFFC72C);
  static const Color brassHi = Color(0xFFFFD966);
  static const Color purpleDark  = Color(0xFF4C3CB0);
  static const Color purple = Color(0xFF6D5BD0);
  static const Color purpleHi = Color(0xFF8573DE);
  static const Color purpleGlow = Color(0xFF9B8CFF);
  static const Color redDeep = Color(0xFFB92A2A);
  static const Color red = Color(0xFFE03C3C);
  static const Color redBright = Color(0xFFFF4D4D);
  static const Color green = Color(0xFF14B873);
  static const Color cyan = Color(0xFF17B8CC);
  static const Color leather = Color(0xFFFFFFFF);
  static const Color leatherDark = Color(0xFFF7F1E3);
  static const Color cream = Color(0xFF14142B);
  static const Color ink = Color(0xFF14142B);
}

class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 8});

  @override
  Widget build(BuildContext context) {
    return NeoDot(color: color, size: size);
  }
}

/// Small rivet
class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 8});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

/// Small screw
class _Screw extends StatelessWidget {
  final double size;
  const _Screw({this.size = 12});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

/// Soft metal panel
class _SoftPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _SoftPanel({
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 14,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPanel(
      padding: padding,
      radius: radius,
      color: null,
      accent: null,
      shadow: 4.toDouble(),
      child: child,
    );
  }
}

class TqtoPage extends StatelessWidget {
  const TqtoPage({super.key});

  final List<Map<String, String>> contributors = const [
    {
      'name': 'Nted',
      'role': 'Maker',
      'avatar': 'https://files.catbox.moe/2ryxq0.jpg',
      'contact': 'https://t.me/NtedPakeE',
    },
    {
      'name': 'Shiro',
      'role': 'Dev Zeus',
      'avatar': 'https://files.catbox.moe/2ryxq0.jpg',
      'contact': 'https://t.me/rdsimmune',
    },
    {
      'name': 'Randa',
      'role': 'Developer Rxhl',
      'avatar': 'https://files.catbox.moe/y6ab5n.jpg',
      'contact': 'https://t.me/rxhlvr',
    },
    {
      'name': 'Melvin',
      'role': 'My best friend',
      'avatar': 'https://files.catbox.moe/y6ab5n.jpg',
      'contact': 'https://t.me/luyatiem',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Neo.paper,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Neo.paper, Neo.paper]),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(context),
              const SizedBox(height: 4),
              _buildTitle(),
              const SizedBox(height: 12),
              _buildStatsBar(),
              const SizedBox(height: 14),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 4),
                  physics: const BouncingScrollPhysics(),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.82,
                  ),
                  itemCount: contributors.length,
                  itemBuilder: (context, index) {
                    final item = contributors[index];
                    return _ContributorCard(
                      name: item['name']!,
                      role: item['role']!,
                      avatarUrl: item['avatar']!,
                      contactUrl: item['contact']!,
                      index: index,
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: const LinearGradient(colors: [Sk.metalMid, Sk.metalMid]),
          border: Border.all(
            color: Neo.ink,
            width: 2,
          ),
          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              const _Screw(size: 12),
              const SizedBox(width: 8),

              // Back button (metal circle)
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
                    border: Border.all(
                      color: Neo.ink,
                      width: 2,
                    ),
                    boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: Neo.ink,
                    size: 14,
                  ),
                ),
              ),
              const SizedBox(width: 10),

              // LED
              const _Led(color: Sk.purpleGlow, size: 6),
              const SizedBox(width: 10),

              // Title
              const Expanded(
                child: Text(
                  'SPECIAL FAMILY',
                  style: TextStyle(
                    color: Neo.ink,
                    fontFamily: 'sans-serif-black',
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 0.3,
                    shadows: null,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),

              // Count badge
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  gradient: const LinearGradient(colors: [Sk.brassHi, Sk.brassHi]),
                  border: Border.all(color: Neo.ink, width: 2),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
                child: Text(
                  '${contributors.length} MEMBER',
                  style: const TextStyle(
                    color: Neo.ink,
                    fontFamily: 'sans-serif-black',
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                    letterSpacing: 0.3,
                  ),
                ),
              ),

              const SizedBox(width: 8),
              const _Screw(size: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TITLE PANEL (TQ TO)
  // ═══════════════════════════════════════════════════════════
  Widget _buildTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _SoftPanel(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        child: Column(
          children: [
            // Main title with brass engraved effect
            Stack(
              alignment: Alignment.center,
              children: [
                // Shadow layer
                Transform.translate(
                  offset: const Offset(2, 2),
                  child: Text(
                    'THANK YOU',
                    style: TextStyle(
                      color: Colors.black.withOpacity(0.7),
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                // Main text
                const Text(
                  'THANK YOU',
                  style: TextStyle(
                    color: Neo.ink,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.3,
                    shadows: null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),

            // Subtitle
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _Rivet(size: 6),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: Sk.purpleDark.withOpacity(0.6),
                    border: Border.all(
                      color: Neo.ink,
                      width: 2,
                    ),
                  ),
                  child: const Text(
                    'TO ALL CONTRIBUTORS',
                    style: TextStyle(
                      color: Neo.purpleDeep,
                      fontSize: 11,
                      fontFamily: 'sans-serif-black',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                _Rivet(size: 6),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATS BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildStatsBar() {
    final creatorCount = contributors
        .where((c) =>
            c['role']!.toLowerCase() == 'creator' ||
            c['role']!.toLowerCase() == 'ceo')
        .length;
    final supportCount = contributors
        .where((c) => c['role']!.toLowerCase() == 'support')
        .length;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _SoftPanel(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _statItem(
              icon: Icons.star_rounded,
              value: '$creatorCount',
              label: 'CREATOR',
              color: Sk.brass,
            ),
            _statItem(
              icon: Icons.support_agent_rounded,
              value: '$supportCount',
              label: 'SUPPORT',
              color: Sk.cyan,
            ),
            _statItem(
              icon: Icons.favorite_rounded,
              value: '∞',
              label: 'THANKS',
              color: Sk.redBright,
            ),
          ],
        ),
      ),
    );
  }

  Widget _statItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.15),
            border: Border.all(
              color: Neo.ink,
              width: 2,
            ),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w900,
            fontSize: 14,
            fontFamily: 'sans-serif-black',
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: Neo.ink.withOpacity(0.55),
            fontSize: 10.5,
            fontFamily: 'ShareTechMono',
            letterSpacing: 0.3,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTRIBUTOR CARD (Soft Skeuomorphic)
// ═══════════════════════════════════════════════════════════
class _ContributorCard extends StatelessWidget {
  final String name;
  final String role;
  final String avatarUrl;
  final String contactUrl;
  final int index;

  const _ContributorCard({
    required this.name,
    required this.role,
    required this.avatarUrl,
    required this.contactUrl,
    required this.index,
  });

  // Role → color mapping
  Color _roleColor(String r) {
    switch (r.toLowerCase()) {
      case 'creator':
        return Sk.brass;
      case 'ceo':
        return Sk.brassHi;
      case 'support':
        return Sk.cyan;
      default:
        return Sk.purpleGlow;
    }
  }

  @override
  Widget build(BuildContext context) {
    final roleColor = _roleColor(role);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(colors: [Sk.leather, Sk.leather]),
        border: Border.all(
          color: Neo.ink,
          width: 2,
        ),
        boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
      ),
      child: Stack(
        children: [
          // Corner rivets
          const Positioned(top: 4, left: 4, child: _Rivet(size: 6)),
          const Positioned(top: 4, right: 4, child: _Rivet(size: 6)),
          const Positioned(bottom: 4, left: 4, child: _Rivet(size: 6)),
          const Positioned(bottom: 4, right: 4, child: _Rivet(size: 6)),

          // Main content
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Avatar in metal ring housing
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 62,
                      height: 62,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [roleColor.withOpacity(0.7), roleColor.withOpacity(0.7)]),
                        boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                      ),
                      child: Container(
                        margin: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Sk.metalDark,
                          border: Border.all(
                            color: Neo.ink,
                            width: 2,
                          ),
                        ),
                        child: ClipOval(
                          child: Image.network(
                            avatarUrl,
                            width: 56,
                            height: 56,
                            fit: BoxFit.cover,
                            // NO loadingBuilder (performance)
                            errorBuilder: (_, __, ___) => Container(
                              width: 56,
                              height: 56,
                              color: Sk.metalDark,
                              child: Icon(
                                Icons.person_rounded,
                                color: roleColor.withOpacity(0.6),
                                size: 26,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // LED indicator
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: _Led(color: roleColor, size: 8),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Name
                Text(
                  name,
                  style: const TextStyle(
                    color: Neo.ink,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.5,
                    shadows: null,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),

                // Role badge
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: roleColor.withOpacity(0.2),
                    border: Border.all(
                      color: Neo.ink,
                      width: 2,
                    ),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: roleColor,
                      fontSize: 10.5,
                      fontFamily: 'sans-serif-black',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // Contact button (small metal)
                _ContactButton(
                  color: roleColor,
                  onTap: () async {
                    final Uri uri = Uri.parse(contactUrl);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CONTACT BUTTON
// ═══════════════════════════════════════════════════════════
class _ContactButton extends StatefulWidget {
  final Color color;
  final VoidCallback onTap;
  const _ContactButton({
    required this.color,
    required this.onTap,
  });

  @override
  State<_ContactButton> createState() => _ContactButtonState();
}

class _ContactButtonState extends State<_ContactButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        transform: Matrix4.translationValues(
          _pressed ? 1 : 0,
          _pressed ? 1 : 0,
          0,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: _pressed
                ? [
                    widget.color.withOpacity(0.4),
                    widget.color.withOpacity(0.2),
                  ]
                : [
                    widget.color.withOpacity(0.7),
                    widget.color.withOpacity(0.4),
                  ],
          ),
          border: Border.all(
            color: Neo.ink,
            width: 2,
          ),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(color: Neo.ink, offset: Offset(3, 3), blurRadius: 0),
                  BoxShadow(color: Neo.ink, offset: const Offset(0, 2), blurRadius: 0),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.chat_rounded,
              color: Neo.ink,
              size: 12,
            ),
            const SizedBox(width: 5),
            Text(
              'CONTACT',
              style: TextStyle(
                color: Neo.ink,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                fontFamily: 'sans-serif-black',
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}