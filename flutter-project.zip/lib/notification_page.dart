import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'api_config.dart';

import 'neo.dart';
class Sk {
  static const Color metalDeep    = Color(0xFFF7F1E3);
  static const Color metalDark    = Color(0xFFFFFFFF);
  static const Color metalMid     = Color(0xFFFFFFFF);
  static const Color metalLight   = Color(0xFFEFE6CE);
  static const Color metalHi      = Color(0xFF3B6DF2);
  static const Color brassDeep    = Color(0xFFE0A800);
  static const Color brassDark    = Color(0xFFE0A800);
  static const Color brass        = Color(0xFFFFC72C);
  static const Color brassHi      = Color(0xFFFFD966);
  static const Color brassShine   = Color(0xFFFFE699);
  static const Color red          = Color(0xFFE03C3C);
  static const Color redBright    = Color(0xFFFF4D4D);
  static const Color redGlow      = Color(0xFFF0524F);
  static const Color greenGlow    = Color(0xFF12A869);
  static const Color amberHi      = Color(0xFFF5A524);
  static const Color cyanHi       = Color(0xFF17B8CC);
  static const Color cream        = Color(0xFF14142B);
  static const Color ink          = Color(0xFF14142B);
  static const Color leather      = Color(0xFFFFFFFF);
  static const Color leatherDark  = Color(0xFFF7F1E3);
  static const Color leatherHi    = Color(0xFFEFE6CE);
}

class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    return NeoDot(color: color, size: size);
  }
}

// ═══════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final double size;
  const _Screw({this.size = 14});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

// ═══════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final double size;
  const _Rivet({this.size = 10});

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

// ═══════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    return NeoPanel(
      padding: padding,
      radius: radius,
      color: null,
      accent: null,
      shadow: 4.toDouble(),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════
class _IndustrialButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.child,
    required this.onTap,
    this.color = Sk.brass,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    return NeoButton(child: child, onTap: onTap, color: color, height: height);
  }
}



// ═══════════════════════════════════════════════════════
// NOTIFICATION PAGE
// ═══════════════════════════════════════════════════════
class NotificationPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const NotificationPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
  }) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final TextEditingController _messageController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _sendReport() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) {
      _showSkeuoSnack('Harap isi pesan laporan', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/sendReport'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
              'message': message,
            }),
          )
          .timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        _showSkeuoSnack('Laporan berhasil dikirim ke owner!', isError: false);
        _messageController.clear();
        _showSuccessDialog();
      } else {
        _showSkeuoSnack(
            'Gagal: ${data['message'] ?? 'Unknown error'}', isError: true);
      }
    } catch (e) {
      _showSkeuoSnack('Server tidak merespon, membuka Telegram...',
          isError: false);
      _openTelegramChat();
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _openTelegramChat() async {
    const ownerUsername = 'elltzyy1_md';
    final url = 'https://t.me/$ownerUsername';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      _showSkeuoSnack('Tidak dapat membuka Telegram', isError: true);
    }
  }

  void _showSkeuoSnack(String message, {bool isError = false}) {
    final c = isError ? Sk.redGlow : Sk.greenGlow;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: true),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: Neo.ink,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Sk.metalDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: Neo.ink, width: 2.5),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // SUCCESS DIALOG
  // ═══════════════════════════════════════════════════════
  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon header
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                          border: Border.all(color: Neo.ink, width: 2.5),
                          boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                        ),
                        child: const Icon(
                          Icons.check_rounded,
                          color: Neo.greenDeep,
                          size: 30,
                          shadows: null,
                        ),
                      ),
                      const Positioned(
                        top: -2,
                        right: -2,
                        child: _Led(color: Sk.greenGlow, size: 8, blink: true),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // Title
              const Text(
                'LAPORAN TERKIRIM',
                style: TextStyle(
                  color: Neo.ink,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.3,
                  shadows: null,
                ),
              ),
              const SizedBox(height: 10),

              // Message
              Text(
                'Pesan Anda telah diteruskan ke owner.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Neo.ink.withOpacity(0.75),
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),

              // OK button
              _IndustrialButton(
                color: Sk.greenGlow,
                height: 46,
                onTap: () => Navigator.pop(ctx),
                child: const Text(
                  'OK',
                  style: TextStyle(
                    color: Neo.ink,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Neo.paper,
      body: Stack(
        children: [
          // Background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(colors: [Neo.paper, Neo.paper]),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 8),
                _buildAppBar(),
                const SizedBox(height: 12),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeaderPanel(),
                        const SizedBox(height: 14),
                        _buildFormPlate(),
                        const SizedBox(height: 14),
                        _buildInfoPlate(),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // APP BAR
  // ═══════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            // Back button
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.pop(context);
              },
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: const LinearGradient(colors: [Sk.metalLight, Sk.metalLight]),
                  border: Border.all(color: Neo.ink, width: 2),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Neo.ink, size: 16),
              ),
            ),
            const SizedBox(width: 12),

            // Icon + Title
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(colors: [Sk.metalHi, Sk.metalHi]),
                    border: Border.all(color: Neo.ink, width: 2.5),
                    boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                  ),
                  child: const Icon(
                    Icons.notifications_active_rounded,
                    color: Neo.redDeep,
                    size: 20,
                  ),
                ),
                const Positioned(
                  top: -2,
                  right: -2,
                  child: _Led(color: Sk.redGlow, size: 6, blink: true),
                ),
              ],
            ),
            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'NULL TR4SHER LAPORAN',
                    style: TextStyle(
                      color: Neo.ink,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                      height: 1,
                      shadows: null,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      const _Led(color: Sk.redGlow, size: 4, blink: true),
                      const SizedBox(width: 5),
                      Text(
                        'SEND TO OWNER',
                        style: TextStyle(
                          color: Neo.ink.withOpacity(0.55),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // HEADER PANEL
  // ═══════════════════════════════════════════════════════
  Widget _buildHeaderPanel() {
    return _MetalPlate(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          // Icon housing
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [Sk.redBright.withOpacity(0.5), Sk.redBright.withOpacity(0.5)]),
                  border: Border.all(color: Neo.ink, width: 2.5),
                  boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
                ),
                child: const Icon(
                  Icons.campaign_rounded,
                  color: Neo.redDeep,
                  size: 26,
                  shadows: null,
                ),
              ),
              const Positioned(
                top: 0,
                right: 0,
                child: _Led(color: Sk.amberHi, size: 7, blink: true),
              ),
            ],
          ),
          const SizedBox(width: 14),

          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BUAT LAPORAN',
                  style: TextStyle(
                    color: Neo.ink,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.3,
                    height: 1,
                    shadows: null,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Kirim pesan langsung ke owner',
                  style: TextStyle(
                    color: Neo.ink.withOpacity(0.6),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),

          const _Led(color: Sk.greenGlow, size: 8, blink: true),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // FORM PLATE
  // ═══════════════════════════════════════════════════════
  Widget _buildFormPlate() {
    return _MetalPlate(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with screws
          Row(
            children: const [
              _Screw(size: 12),
              SizedBox(width: 10),
              Expanded(
                child: Center(
                  child: Text(
                    'FORM LAPORAN',
                    style: TextStyle(
                      color: Neo.ink,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'sans-serif-black',
                      letterSpacing: 0.3,
                      shadows: null,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10),
              _Screw(size: 12),
            ],
          ),
          const SizedBox(height: 16),

          // Label
          Row(
            children: [
              const _Rivet(size: 6),
              const SizedBox(width: 6),
              const Icon(Icons.edit_note_rounded, color: Neo.ink, size: 14),
              const SizedBox(width: 6),
              const Text(
                'PESAN LAPORAN',
                style: TextStyle(
                  color: Neo.ink,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // TextField (inset)
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: const LinearGradient(colors: [Neo.paper, Neo.paper]),
              border: Border.all(color: Neo.ink, width: 2.5),
              boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
            ),
            child: TextField(
              controller: _messageController,
              maxLines: 6,
              minLines: 5,
              style: const TextStyle(
                color: Neo.ink,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.3,
                height: 1.5,
              ),
              cursorColor: Sk.greenGlow,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Tuliskan laporan atau keluhan Anda...',
                hintStyle: TextStyle(
                  color: Neo.ink.withOpacity(0.3),
                  fontSize: 12,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 0.5,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(14),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // User info panel
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: Neo.paper,
              border: Border.all(color: Neo.ink, width: 2),
              boxShadow: [BoxShadow(color: Neo.ink, offset: Offset(4, 4), blurRadius: 0)],
            ),
            child: Row(
              children: [
                const _Led(color: Sk.greenGlow, size: 6, blink: true),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Dikirim sebagai: ${widget.username} (${widget.role})',
                    style: TextStyle(
                      color: Neo.ink.withOpacity(0.7),
                      fontSize: 11.5,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 0.5,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Send button
          _IndustrialButton(
            color: _isLoading ? Sk.metalMid : Sk.red,
            height: 54,
            onTap: _isLoading ? null : _sendReport,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isLoading)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Sk.brass),
                    ),
                  )
                else
                  const Icon(Icons.send_rounded, color: Neo.ink, size: 18),
                const SizedBox(width: 10),
                Text(
                  _isLoading ? 'MENGIRIM...' : 'KIRIM LAPORAN',
                  style: const TextStyle(
                    color: Neo.ink,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'sans-serif-black',
                    letterSpacing: 0.3,
                    shadows: null,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // INFO PLATE
  // ═══════════════════════════════════════════════════════
  Widget _buildInfoPlate() {
    return _MetalPlate(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: const [
              _Rivet(size: 8),
              SizedBox(width: 8),
              Icon(Icons.info_outline, color: Neo.ink, size: 14),
              SizedBox(width: 6),
              Text(
                'INFORMASI',
                style: TextStyle(
                  color: Neo.ink,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'sans-serif-black',
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _infoLine('• Laporan langsung diteruskan ke owner bot'),
          _infoLine('• Pastikan pesan jelas, sopan, dan tidak spam'),
          _infoLine('• Balasan akan dikirim via Telegram bot'),
          _infoLine('• Jika server down, otomatis buka Telegram owner'),
        ],
      ),
    );
  }

  Widget _infoLine(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            text,
            style: TextStyle(
              color: Neo.ink.withOpacity(0.65),
              fontSize: 11.5,
              fontFamily: 'ShareTechMono',
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}