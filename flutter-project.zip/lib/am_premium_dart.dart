import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AmPremiumDart extends StatefulWidget {
  const AmPremiumDart({super.key});

  @override
  State<AmPremiumDart> createState() => _AmPremiumDartState();
}

class _AmPremiumDartState extends State<AmPremiumDart> {
  static const String baseUrl =
      'http://node-michie.jkt48node.id:3047';

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _magicLinkController =
      TextEditingController();

  bool _sending = false;
  bool _verifying = false;
  bool _linkSent = false;
  bool _success = false;

  String _message = '';
  String _planName = '';
  String _validUntil = '';
  String _uid = '';

  // Neobrutalism — flat cream bg, solid black border, bold accent (kept old
  // field names so the rest of the file needs no structural changes).
  static const Color galaxyBlue = Color(0xFF3B6DF2);
  static const Color galaxyPurple = Color(0xFF6D5BD0);
  static const Color galaxyBackground = Color(0xFFF7F1E3);
  static const Color galaxyCard = Color(0xFFFFFFFF);

  @override
  void dispose() {
    _emailController.dispose();
    _magicLinkController.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _post(
    String endpoint,
    Map<String, dynamic> body,
  ) async {
    final response = await http
        .post(
          Uri.parse('$baseUrl$endpoint'),
          headers: const {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 25));

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is! Map<String, dynamic>) {
      throw Exception('Respons backend tidak valid.');
    }

    if (response.statusCode < 200 ||
        response.statusCode >= 300 ||
        decoded['success'] != true) {
      throw Exception(
        decoded['message']?.toString() ??
            'Permintaan gagal (${response.statusCode}).',
      );
    }

    return decoded;
  }

  Future<void> _sendMagicLink() async {
    FocusScope.of(context).unfocus();

    final email = _emailController.text.trim();

    if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
        .hasMatch(email)) {
      _showMessage('Masukkan alamat Gmail yang valid.');
      return;
    }

    setState(() {
      _sending = true;
      _message = '';
    });

    try {
      final result = await _post(
        '/api/am-premium/send-link',
        {'email': email},
      );

      if (!mounted) return;

      setState(() {
        _linkSent = true;
        _message = result['message']?.toString() ??
            'Permintaan berhasil. Periksa inbox Gmail kamu.';
      });

      _showMessage('Magic Link berhasil diminta. Periksa email kamu.');
    } catch (e) {
      if (!mounted) return;
      _showMessage(_cleanError(e));
    } finally {
      if (mounted) {
        setState(() => _sending = false);
      }
    }
  }

  Future<void> _verifyMagicLink() async {
    FocusScope.of(context).unfocus();

    final email = _emailController.text.trim();
    final magicLink = _magicLinkController.text.trim();

    if (email.isEmpty) {
      _showMessage('Masukkan Gmail terlebih dahulu.');
      return;
    }

    if (magicLink.isEmpty) {
      _showMessage('Tempel Magic Link dari email kamu.');
      return;
    }

    final uri = Uri.tryParse(magicLink);

    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      _showMessage('Magic Link harus berupa URL HTTPS yang valid.');
      return;
    }

    setState(() {
      _verifying = true;
      _message = '';
    });

    try {
      final result = await _post(
        '/api/am-premium/verify-link',
        {
          'email': email,
          'magicLink': magicLink,
        },
      );

      if (!mounted) return;

      setState(() {
        _success = true;
        _uid = result['uid']?.toString() ?? '';
        _planName = result['planName']?.toString() ?? '';
        _validUntil = result['validUntil']?.toString() ?? '';
        _message = result['message']?.toString() ??
            'Verifikasi berhasil.';
      });
    } catch (e) {
      if (!mounted) return;
      _showMessage(_cleanError(e));
    } finally {
      if (mounted) {
        setState(() => _verifying = false);
      }
    }
  }

  String _cleanError(Object error) {
    return error.toString().replaceFirst('Exception: ', '');
  }

  void _showMessage(String text) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          behavior: SnackBarBehavior.floating,
          backgroundColor: galaxyCard,
        ),
      );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      style: const TextStyle(
        color: const Color(0xFF14142B),
        fontSize: 14,
      ),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: const TextStyle(color: const Color(0xB214142B)),
        hintStyle: const TextStyle(color: const Color(0x6114142B)),
        prefixIcon: Icon(icon, color: galaxyBlue),
        filled: true,
        fillColor: const Color(0xFF0B1229),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: const Color(0x1F14142B)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: const Color(0x1F14142B)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: galaxyBlue),
        ),
      ),
    );
  }

  Widget _buildPrimaryButton({
    required String label,
    required IconData icon,
    required bool loading,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [galaxyBlue, galaxyPurple],
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: ElevatedButton.icon(
          onPressed: loading ? null : onPressed,
          icon: loading
              ? const SizedBox(
                  width: 19,
                  height: 19,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: const Color(0xFF14142B),
                  ),
                )
              : Icon(icon),
          label: Text(
            loading ? 'Memproses...' : label,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            disabledBackgroundColor: Colors.transparent,
            foregroundColor: const Color(0xFF14142B),
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStep(int number, String title, bool active) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active
                ? galaxyBlue.withValues(alpha: 0.16)
                : const Color(0xFF14142B).withValues(alpha: 0.04),
            border: Border.all(
              color: active ? galaxyBlue : const Color(0x3D14142B),
            ),
          ),
          child: Text(
            '$number',
            style: TextStyle(
              color: active ? galaxyBlue : const Color(0x8A14142B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: active ? const Color(0xFF14142B) : const Color(0x8A14142B),
              fontSize: 13,
              fontWeight: active ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSuccess() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: galaxyCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: galaxyBlue.withValues(alpha: 0.4)),
      ),
      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.greenAccent.withValues(alpha: 0.12),
            ),
            child: const Icon(
              Icons.verified_rounded,
              size: 48,
              color: Colors.greenAccent,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'VERIFIKASI BERHASIL',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: const Color(0xFF14142B),
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: const Color(0xB214142B),
              height: 1.5,
            ),
          ),
          if (_planName.isNotEmpty) ...[
            const SizedBox(height: 20),
            _infoRow('Plan', _planName),
          ],
          if (_validUntil.isNotEmpty)
            _infoRow('Berlaku hingga', _validUntil),
          if (_uid.isNotEmpty) _infoRow('UID', _uid),
          const SizedBox(height: 24),
          OutlinedButton.icon(
            onPressed: () {
              setState(() {
                _success = false;
                _linkSent = false;
                _message = '';
                _planName = '';
                _validUntil = '';
                _uid = '';
                _magicLinkController.clear();
              });
            },
            icon: const Icon(Icons.arrow_back_rounded),
            label: const Text('Kembali'),
            style: OutlinedButton.styleFrom(
              foregroundColor: galaxyBlue,
              side: const BorderSide(color: galaxyBlue),
              minimumSize: const Size(double.infinity, 48),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 105,
            child: Text(
              label,
              style: const TextStyle(color: const Color(0x8A14142B), fontSize: 12),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: const Color(0xFF14142B),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: galaxyBackground,
      appBar: AppBar(
        backgroundColor: galaxyBackground,
        foregroundColor: const Color(0xFF14142B),
        elevation: 0,
        title: const Text(
          'AM PREMIUM',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF101D40),
              galaxyBackground,
              Color(0xFF160F32),
            ],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: galaxyCard.withValues(alpha: 0.85),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0x1F14142B)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.auto_awesome_rounded,
                      size: 32,
                      color: galaxyBlue,
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'AM Premium Access',
                      style: TextStyle(
                        color: const Color(0xFF14142B),
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Verifikasi akses melalui email dengan Magic Link.',
                      style: TextStyle(
                        color: const Color(0xB214142B),
                        height: 1.5,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildStep(1, 'Masukkan Gmail', true),
                    const SizedBox(height: 14),
                    _buildStep(2, 'Kirim Magic Link', _linkSent),
                    const SizedBox(height: 14),
                    _buildStep(3, 'Verifikasi berhasil', _success),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (_success)
                _buildSuccess()
              else
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: galaxyCard.withValues(alpha: 0.92),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0x1F14142B)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Verifikasi Email',
                        style: TextStyle(
                          color: const Color(0xFF14142B),
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 18),
                      _buildTextField(
                        controller: _emailController,
                        label: 'Alamat Gmail',
                        hint: 'nama@gmail.com',
                        icon: Icons.mail_outline_rounded,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 14),
                      _buildPrimaryButton(
                        label: 'Kirim Magic Link',
                        icon: Icons.send_rounded,
                        loading: _sending,
                        onPressed: _sendMagicLink,
                      ),
                      if (_linkSent) ...[
                        const SizedBox(height: 24),
                        const Divider(color: const Color(0x1F14142B)),
                        const SizedBox(height: 16),
                        const Text(
                          'Masukkan Magic Link',
                          style: TextStyle(
                            color: const Color(0xFF14142B),
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Buka email kamu, salin Magic Link, lalu tempel di bawah.',
                          style: TextStyle(
                            color: const Color(0x9914142B),
                            fontSize: 12,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildTextField(
                          controller: _magicLinkController,
                          label: 'Magic Link',
                          hint: 'https://...',
                          icon: Icons.link_rounded,
                          keyboardType: TextInputType.url,
                          maxLines: 3,
                        ),
                        const SizedBox(height: 14),
                        _buildPrimaryButton(
                          label: 'Verifikasi Magic Link',
                          icon: Icons.verified_user_outlined,
                          loading: _verifying,
                          onPressed: _verifyMagicLink,
                        ),
                      ],
                    ],
                  ),
                ),
              const SizedBox(height: 20),
              const Text(
                'VOID STARS  •  SECURE ACCESS',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0x6114142B),
                  fontSize: 10,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}